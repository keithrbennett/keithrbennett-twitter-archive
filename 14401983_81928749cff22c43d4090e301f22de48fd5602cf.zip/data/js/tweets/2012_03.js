Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185899005249724416",
  "text" : "Fixed rvm 1.9.3 install error on Mac by installing ActiveTCL and adding tcl option: rvm install 1.9.3 --with-ActiveTcl=\/Library\/Tcl",
  "id" : 185899005249724416,
  "created_at" : "2012-03-31 01:19:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "error",
      "indices" : [ 80, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185826311686725632",
  "text" : "Can't install Ruby 1.9 on 1 of my Macs, get err: \/usr\/include\/tk.h:23:3: error: #error Tk 8.5 must be compiled with tcl.h from Tcl 8.5.  ???",
  "id" : 185826311686725632,
  "created_at" : "2012-03-30 20:30:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185514388017516545",
  "text" : "I may be going to Singapore and (Philippines and\/or Thailand) for a few weeks.  Anyone there want to get together, maybe pair program?",
  "id" : 185514388017516545,
  "created_at" : "2012-03-29 23:50:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185506986731896832",
  "text" : "After years of working with Ruby *Not* Rails, finally studying Rails in earnest.",
  "id" : 185506986731896832,
  "created_at" : "2012-03-29 23:21:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luis de la Rosa",
      "screen_name" : "louielouie",
      "indices" : [ 0, 11 ],
      "id_str" : "688983",
      "id" : 688983
    }, {
      "name" : "Jared Richardson",
      "screen_name" : "jaredrichardson",
      "indices" : [ 12, 28 ],
      "id_str" : "10790362",
      "id" : 10790362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183645760531861504",
  "geo" : { },
  "id_str" : "183647005791367168",
  "in_reply_to_user_id" : 688983,
  "text" : "@louielouie @jaredrichardson Don't remember which RAM, but I ran the Crucial tool, and ordered exactly what it recommended.",
  "id" : 183647005791367168,
  "in_reply_to_status_id" : 183645760531861504,
  "created_at" : "2012-03-24 20:10:32 +0000",
  "in_reply_to_screen_name" : "louielouie",
  "in_reply_to_user_id_str" : "688983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183463333687599104",
  "geo" : { },
  "id_str" : "183645926831828992",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano I've lived in Sweden, speak some Swedish, and have some technical contacts there, in case I can be helpful.",
  "id" : 183645926831828992,
  "in_reply_to_status_id" : 183463333687599104,
  "created_at" : "2012-03-24 20:06:15 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Richardson",
      "screen_name" : "jaredrichardson",
      "indices" : [ 0, 16 ],
      "id_str" : "10790362",
      "id" : 10790362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "183570207007178755",
  "geo" : { },
  "id_str" : "183644290638032899",
  "in_reply_to_user_id" : 10790362,
  "text" : "@jaredrichardson I just upgraded my 2011 13\" MBP to 16 GB despite Apple's mention of 8 GB maximum w\/memory from Crucial, and it works fine.",
  "id" : 183644290638032899,
  "in_reply_to_status_id" : 183570207007178755,
  "created_at" : "2012-03-24 19:59:45 +0000",
  "in_reply_to_screen_name" : "jaredrichardson",
  "in_reply_to_user_id_str" : "10790362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyNation",
      "screen_name" : "rubynation",
      "indices" : [ 0, 11 ],
      "id_str" : "1556704207",
      "id" : 1556704207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183641715104677888",
  "in_reply_to_user_id" : 28483214,
  "text" : "@rubynation Great talks.  Too many friends, too little time.  Thanks, everyone.",
  "id" : 183641715104677888,
  "created_at" : "2012-03-24 19:49:31 +0000",
  "in_reply_to_screen_name" : "nationjs",
  "in_reply_to_user_id_str" : "28483214",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyNation",
      "screen_name" : "rubynation",
      "indices" : [ 0, 11 ],
      "id_str" : "1556704207",
      "id" : 1556704207
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubynation",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/jfRX4UDu",
      "expanded_url" : "http:\/\/maps.google.com\/maps\/ms?msa=0&msid=215348656028104440651.0004bbd5c47d83586e1b1",
      "display_url" : "maps.google.com\/maps\/ms?msa=0&\u2026"
    }, {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/ztaAHlHd",
      "expanded_url" : "http:\/\/tech.groups.yahoo.com\/group\/novarubygroup\/message\/2506",
      "display_url" : "tech.groups.yahoo.com\/group\/novaruby\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182840813712191488",
  "in_reply_to_user_id" : 28483214,
  "text" : "@rubynation Walking to Sheraton from Reston Town Center is about 30 mins - see http:\/\/t.co\/jfRX4UDu and http:\/\/t.co\/ztaAHlHd. #rubynation",
  "id" : 182840813712191488,
  "created_at" : "2012-03-22 14:47:01 +0000",
  "in_reply_to_screen_name" : "nationjs",
  "in_reply_to_user_id_str" : "28483214",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]