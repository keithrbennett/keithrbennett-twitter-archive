Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Szmajda",
      "screen_name" : "jszmajda",
      "indices" : [ 0, 9 ],
      "id_str" : "2049811",
      "id" : 2049811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "737033409873076225",
  "geo" : { },
  "id_str" : "737328186522927104",
  "in_reply_to_user_id" : 2049811,
  "text" : "@jszmajda I'm eating at *your* house tonight! Oh wait, I'm in the Philippines.",
  "id" : 737328186522927104,
  "in_reply_to_status_id" : 737033409873076225,
  "created_at" : "2016-05-30 17:01:53 +0000",
  "in_reply_to_screen_name" : "jszmajda",
  "in_reply_to_user_id_str" : "2049811",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/736099888484651008\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/08HMPLzSzG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjcm3WXVAAEhKcZ.jpg",
      "id_str" : "736099796436451329",
      "id" : 736099796436451329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjcm3WXVAAEhKcZ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/08HMPLzSzG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736099888484651008",
  "text" : "1 of Duterte's accomplishments in Davao is that it's the most nonsmoker-friendly city in the Phils., possibly Asia. https:\/\/t.co\/08HMPLzSzG",
  "id" : 736099888484651008,
  "created_at" : "2016-05-27 07:41:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/736098591874240512\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/LHpujYpMJL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cjclp5EUoAAALDn.jpg",
      "id_str" : "736098465722179584",
      "id" : 736098465722179584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cjclp5EUoAAALDn.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LHpujYpMJL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "736098591874240512",
  "text" : "Finally tried durian cappuccino in Davao. My verdict: I love durian and cappucino separately, but not together. https:\/\/t.co\/LHpujYpMJL",
  "id" : 736098591874240512,
  "created_at" : "2016-05-27 07:35:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/735668316585349120\/photo\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/YjPx2jGpb9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWeZ91UYAAtQ9K.jpg",
      "id_str" : "735668283077058560",
      "id" : 735668283077058560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWeZ91UYAAtQ9K.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YjPx2jGpb9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735668316585349120",
  "text" : "...and on the other side... https:\/\/t.co\/YjPx2jGpb9",
  "id" : 735668316585349120,
  "created_at" : "2016-05-26 03:06:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/735668175212183554\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/juYAihhtK3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjWeR-NUYAACnm3.jpg",
      "id_str" : "735668145738768384",
      "id" : 735668145738768384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjWeR-NUYAACnm3.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/juYAihhtK3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735668175212183554",
  "text" : "In front of Abreeza Mall in Davao, Philippines. https:\/\/t.co\/juYAihhtK3",
  "id" : 735668175212183554,
  "created_at" : "2016-05-26 03:05:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripAdvisor",
      "screen_name" : "TripAdvisor",
      "indices" : [ 0, 12 ],
      "id_str" : "16365636",
      "id" : 16365636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "userhostile",
      "indices" : [ 136, 148 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735466332997586945",
  "in_reply_to_user_id" : 16365636,
  "text" : "@tripadvisor I love your svc but why do you separate \"price\" from \"taxes&amp;fees\" when the latter differs across vendors &amp; hotels? #userhostile",
  "id" : 735466332997586945,
  "created_at" : "2016-05-25 13:43:32 +0000",
  "in_reply_to_screen_name" : "TripAdvisor",
  "in_reply_to_user_id_str" : "16365636",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/735147029664387072\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/O1kcx4uF9e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CjPETpOVAAE-0t2.jpg",
      "id_str" : "735147005954031617",
      "id" : 735147005954031617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CjPETpOVAAE-0t2.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/O1kcx4uF9e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "735147029664387072",
  "text" : "I have arrived in Davao, home of Duterte and durian. Check out \"Pungent...\" in my hotel info sheet. Must try marang! https:\/\/t.co\/O1kcx4uF9e",
  "id" : 735147029664387072,
  "created_at" : "2016-05-24 16:34:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "talk2GLOBE",
      "screen_name" : "talk2GLOBE",
      "indices" : [ 0, 11 ],
      "id_str" : "15092616",
      "id" : 15092616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732897227006337024",
  "in_reply_to_user_id" : 15092616,
  "text" : "@talk2GLOBE How can I make a collect call to a USA phone number from my Globe mobile phone?",
  "id" : 732897227006337024,
  "created_at" : "2016-05-18 11:34:50 +0000",
  "in_reply_to_screen_name" : "talk2GLOBE",
  "in_reply_to_user_id_str" : "15092616",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732636047528497152",
  "geo" : { },
  "id_str" : "732638588756578304",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg I only cancelled web hosting, not domains. I expected them to act like grown ups and professionals and they did neither.",
  "id" : 732638588756578304,
  "in_reply_to_status_id" : 732636047528497152,
  "created_at" : "2016-05-17 18:27:05 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732636047528497152",
  "geo" : { },
  "id_str" : "732638135041953792",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Plus I had no idea that they were as hostile and malicious as they are, I haven't seen anything like it in many years.",
  "id" : 732638135041953792,
  "in_reply_to_status_id" : 732636047528497152,
  "created_at" : "2016-05-17 18:25:17 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732636047528497152",
  "geo" : { },
  "id_str" : "732637946793222145",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg 20\/20 hindsight. ;) The charge was &gt; $400 &amp; given their behavior I expect them to fold any day now. This happened to me once!",
  "id" : 732637946793222145,
  "in_reply_to_status_id" : 732636047528497152,
  "created_at" : "2016-05-17 18:24:32 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/yZbXzYa2rK",
      "expanded_url" : "https:\/\/medium.com\/@keithrbennett",
      "display_url" : "medium.com\/@keithrbennett"
    } ]
  },
  "geo" : { },
  "id_str" : "732599488183853056",
  "text" : "The TechHumans blog will be moved, possibly permanently, to https:\/\/t.co\/yZbXzYa2rK.",
  "id" : 732599488183853056,
  "created_at" : "2016-05-17 15:51:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bluehost",
      "screen_name" : "bluehost",
      "indices" : [ 1, 10 ],
      "id_str" : "551208828",
      "id" : 551208828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/MFDqbP8TYo",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/1b7fd1b561666830f9fd92812bd2d1e7",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "732540411391053824",
  "geo" : { },
  "id_str" : "732549020938178560",
  "in_reply_to_user_id" : 14401983,
  "text" : ".@bluehost's response to my tweet: https:\/\/t.co\/MFDqbP8TYo. Unbashedly holding my domains hostage.  Is this legal\/enforceable?",
  "id" : 732549020938178560,
  "in_reply_to_status_id" : 732540411391053824,
  "created_at" : "2016-05-17 12:31:11 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bluehost",
      "screen_name" : "bluehost",
      "indices" : [ 7, 16 ],
      "id_str" : "551208828",
      "id" : 551208828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/uKnyijU7fx",
      "expanded_url" : "http:\/\/bbs-software.com",
      "display_url" : "bbs-software.com"
    } ]
  },
  "in_reply_to_status_id_str" : "732527801694195712",
  "geo" : { },
  "id_str" : "732540411391053824",
  "in_reply_to_user_id" : 14401983,
  "text" : "Due to @bluehost freezing of my account my https:\/\/t.co\/uKnyijU7fx site is down &amp; I am unable to move the domain to another web hosting svc.",
  "id" : 732540411391053824,
  "in_reply_to_status_id" : 732527801694195712,
  "created_at" : "2016-05-17 11:56:58 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "732423846381387776",
  "geo" : { },
  "id_str" : "732531072177594368",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius When they embrace Unix for their OS's, I will be truly impressed and welcome them with open arms.",
  "id" : 732531072177594368,
  "in_reply_to_status_id" : 732423846381387776,
  "created_at" : "2016-05-17 11:19:52 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bluehost",
      "screen_name" : "bluehost",
      "indices" : [ 13, 22 ],
      "id_str" : "551208828",
      "id" : 551208828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanksalot",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732527801694195712",
  "text" : "I disputed a @bluehost web hosting charge, so *as per their TOS* they locked me out of my acct so I can't manage my domains.  #thanksalot",
  "id" : 732527801694195712,
  "created_at" : "2016-05-17 11:06:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "732168664913346560",
  "text" : "I need to document all interactions (chat, phone, email, w\/date-time, etc.) w\/a co. for a charge dispute. Software suggestions? Case mgmt?",
  "id" : 732168664913346560,
  "created_at" : "2016-05-16 11:19:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HOZK6Vleux",
      "expanded_url" : "http:\/\/meetu.ps\/2WDj04",
      "display_url" : "meetu.ps\/2WDj04"
    } ]
  },
  "geo" : { },
  "id_str" : "731805813816184832",
  "text" : "This meetup about humanoid robots sounds fascinating.  If I were not out of the country, I'd definitely be there! https:\/\/t.co\/HOZK6Vleux",
  "id" : 731805813816184832,
  "created_at" : "2016-05-15 11:17:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/730359345876062209\/photo\/1",
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/EJbTq4Oxdi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiLB7PEUUAA9ftY.jpg",
      "id_str" : "730359312988524544",
      "id" : 730359312988524544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiLB7PEUUAA9ftY.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EJbTq4Oxdi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730359345876062209",
  "text" : "A 4 story Starbucks store (in Taipei). That's a record. https:\/\/t.co\/EJbTq4Oxdi",
  "id" : 730359345876062209,
  "created_at" : "2016-05-11 11:30:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/730254266128965632\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/UcM9sXglsz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiJiXagUkAAP4Cb.jpg",
      "id_str" : "730254243978842112",
      "id" : 730254243978842112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiJiXagUkAAP4Cb.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UcM9sXglsz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730254266128965632",
  "text" : "So impressed with the many ways helpfulness pervades Taiwan. Here, 1 of many clean metro rest rooms. https:\/\/t.co\/UcM9sXglsz",
  "id" : 730254266128965632,
  "created_at" : "2016-05-11 04:32:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/730253274868146177\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/qt2hZvBMI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiJhc06UgAA5keu.jpg",
      "id_str" : "730253237454929920",
      "id" : 730253237454929920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiJhc06UgAA5keu.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/qt2hZvBMI3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730253274868146177",
  "text" : "Mirrored space on walkway between metro stations in Taipei is used for practicing dance, Tai Chi, etc. https:\/\/t.co\/qt2hZvBMI3",
  "id" : 730253274868146177,
  "created_at" : "2016-05-11 04:28:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u4E94\u500D\u7D05\u5BF6\u77F3",
      "screen_name" : "5xruby",
      "indices" : [ 49, 56 ],
      "id_str" : "2483611052",
      "id" : 2483611052
    }, {
      "name" : "Mu-Fan Teng",
      "screen_name" : "ryudoawaru",
      "indices" : [ 91, 102 ],
      "id_str" : "17306085",
      "id" : 17306085
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/729924491921391616\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/80OIzuEZU5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiE2a33U4AARivl.jpg",
      "id_str" : "729924449911234560",
      "id" : 729924449911234560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiE2a33U4AARivl.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/80OIzuEZU5"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729924491921391616",
  "text" : "Wonderful Taiwanese lunch feast and talking with @5xruby #rubyfriends in Taipei.  Thanks,  @ryudoawaru! https:\/\/t.co\/80OIzuEZU5",
  "id" : 729924491921391616,
  "created_at" : "2016-05-10 06:42:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729653033278181376",
  "geo" : { },
  "id_str" : "729720482254102529",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms Not sure.  I thought so, but then I heard that same music in another station.",
  "id" : 729720482254102529,
  "in_reply_to_status_id" : 729653033278181376,
  "created_at" : "2016-05-09 17:11:35 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/UUAtxW6lhg",
      "expanded_url" : "https:\/\/youtu.be\/Tgj-GJ3ls_4",
      "display_url" : "youtu.be\/Tgj-GJ3ls_4"
    } ]
  },
  "in_reply_to_status_id_str" : "729345014342393856",
  "geo" : { },
  "id_str" : "729644248962732032",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms I went back to the station and took a video so you could hear the music.  It's at https:\/\/t.co\/UUAtxW6lhg.",
  "id" : 729644248962732032,
  "in_reply_to_status_id" : 729345014342393856,
  "created_at" : "2016-05-09 12:08:39 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729342624818028545",
  "geo" : { },
  "id_str" : "729344278418182144",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms ? Funny thing was I only found this station because I got on the train going the wrong way! Got off at this stop to turn back.",
  "id" : 729344278418182144,
  "in_reply_to_status_id" : 729342624818028545,
  "created_at" : "2016-05-08 16:16:41 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "729341628196880384",
  "geo" : { },
  "id_str" : "729342415622918144",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms I don't know, I didn't recognize it, but it sounded like meditation music, and I hadn't heard it in any other station.",
  "id" : 729342415622918144,
  "in_reply_to_status_id" : 729341628196880384,
  "created_at" : "2016-05-08 16:09:17 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/729341150939611137\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/8sMlBiY40H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch8j6SpVEAABmT6.jpg",
      "id_str" : "729341149001879552",
      "id" : 729341149001879552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch8j6SpVEAABmT6.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8sMlBiY40H"
    } ],
    "hashtags" : [ {
      "text" : "Taipei",
      "indices" : [ 5, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729341150939611137",
  "text" : "This #Taipei metro station with meditating hands sculpture also had meditation music announcing the train's arrival. https:\/\/t.co\/8sMlBiY40H",
  "id" : 729341150939611137,
  "created_at" : "2016-05-08 16:04:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 31, 44 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/729340372057346049\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/FAbNDvLVPI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ch8jM5qUYAU-zxm.jpg",
      "id_str" : "729340369201029125",
      "id" : 729340369201029125,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ch8jM5qUYAU-zxm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 4128,
        "resize" : "fit",
        "w" : 2322
      } ],
      "display_url" : "pic.twitter.com\/FAbNDvLVPI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729340372057346049",
  "text" : "At Taipei's national park with @JuanitoFatas with a volcano behind us. We rode up the mountain on his motorbike. https:\/\/t.co\/FAbNDvLVPI",
  "id" : 729340372057346049,
  "created_at" : "2016-05-08 16:01:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/728584342054707204\/photo\/1",
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/a0V3bs3gGh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Chxzjt8UgAA1XSZ.jpg",
      "id_str" : "728584297192390656",
      "id" : 728584297192390656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Chxzjt8UgAA1XSZ.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      } ],
      "display_url" : "pic.twitter.com\/a0V3bs3gGh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728584342054707204",
  "text" : "McDonald's dessert in Taipei: ice cream with green tea powder and beans. https:\/\/t.co\/a0V3bs3gGh",
  "id" : 728584342054707204,
  "created_at" : "2016-05-06 13:56:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 40, 53 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/728584035987939328\/photo\/1",
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/uI1lKiXbsv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChxzSYkVAAAtw-M.jpg",
      "id_str" : "728583999396839424",
      "id" : 728583999396839424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChxzSYkVAAAtw-M.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uI1lKiXbsv"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728584035987939328",
  "text" : "Post-night-market-wandering coffee with @JuanitoFatas in Taipei. #rubyfriends https:\/\/t.co\/uI1lKiXbsv",
  "id" : 728584035987939328,
  "created_at" : "2016-05-06 13:55:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NairubyKE",
      "screen_name" : "NairubyKE",
      "indices" : [ 3, 13 ],
      "id_str" : "2462100788",
      "id" : 2462100788
    }, {
      "name" : "Raymond T. Hightower",
      "screen_name" : "RayHightower",
      "indices" : [ 73, 86 ],
      "id_str" : "17503660",
      "id" : 17503660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyConfKenya2016",
      "indices" : [ 15, 33 ]
    }, {
      "text" : "opensource",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "entrepreneur",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728500434982162432",
  "text" : "RT @NairubyKE: #RubyConfKenya2016 officially kicks off with a Keynote by @RayHightower all the way from USA. #opensource #entrepreneur",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Raymond T. Hightower",
        "screen_name" : "RayHightower",
        "indices" : [ 58, 71 ],
        "id_str" : "17503660",
        "id" : 17503660
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RubyConfKenya2016",
        "indices" : [ 0, 18 ]
      }, {
        "text" : "opensource",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "entrepreneur",
        "indices" : [ 106, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "728126208454463490",
    "text" : "#RubyConfKenya2016 officially kicks off with a Keynote by @RayHightower all the way from USA. #opensource #entrepreneur",
    "id" : 728126208454463490,
    "created_at" : "2016-05-05 07:36:30 +0000",
    "user" : {
      "name" : "NairubyKE",
      "screen_name" : "NairubyKE",
      "protected" : false,
      "id_str" : "2462100788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459584639523241985\/wuuZhm6Y_normal.png",
      "id" : 2462100788,
      "verified" : false
    }
  },
  "id" : 728500434982162432,
  "created_at" : "2016-05-06 08:23:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lulalala_it",
      "screen_name" : "lulalala_it",
      "indices" : [ 0, 12 ],
      "id_str" : "539691358",
      "id" : 539691358
    }, {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 13, 26 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728488454129078272",
  "geo" : { },
  "id_str" : "728491892757823488",
  "in_reply_to_user_id" : 539691358,
  "text" : "@lulalala_it @JuanitoFatas I'm open to any place.",
  "id" : 728491892757823488,
  "in_reply_to_status_id" : 728488454129078272,
  "created_at" : "2016-05-06 07:49:36 +0000",
  "in_reply_to_screen_name" : "lulalala_it",
  "in_reply_to_user_id_str" : "539691358",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/728466979648983041\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/NHIiLBBBrP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChwI1cBVIAEUUhO.jpg",
      "id_str" : "728466953875038209",
      "id" : 728466953875038209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChwI1cBVIAEUUhO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NHIiLBBBrP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728466979648983041",
  "text" : "I just paid $180 for this lunch!  Good thing I'm in Taipei and they're Taiwanese dollars! https:\/\/t.co\/NHIiLBBBrP",
  "id" : 728466979648983041,
  "created_at" : "2016-05-06 06:10:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/728304440743055360\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/HDhOBIpQ94",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cht1ALCVAAAyr22.jpg",
      "id_str" : "728304410573471744",
      "id" : 728304410573471744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cht1ALCVAAAyr22.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HDhOBIpQ94"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728304440743055360",
  "text" : "Watermelon milk, papaya milk, and asparagus juice at the Family Mart in Taipei. https:\/\/t.co\/HDhOBIpQ94",
  "id" : 728304440743055360,
  "created_at" : "2016-05-05 19:24:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cebupacific",
      "screen_name" : "cebupacific",
      "indices" : [ 3, 15 ],
      "id_str" : "8740532",
      "id" : 8740532
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/728213906099871745\/photo\/1",
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/E6gu9UFGYB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChsioY5UUAEkP65.jpg",
      "id_str" : "728213842023436289",
      "id" : 728213842023436289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChsioY5UUAEkP65.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/E6gu9UFGYB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728213906099871745",
  "text" : "On @cebupacific, this is one of the very few times in my life I wish I were shorter. https:\/\/t.co\/E6gu9UFGYB",
  "id" : 728213906099871745,
  "created_at" : "2016-05-05 13:24:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "cebupacific",
      "screen_name" : "cebupacific",
      "indices" : [ 9, 21 ],
      "id_str" : "8740532",
      "id" : 8740532
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728213340812546048",
  "text" : "On board @cebupacific, announcement: ...aircraft being refueled, for safety leave seat belt unfastened. Should I run now?",
  "id" : 728213340812546048,
  "created_at" : "2016-05-05 13:22:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 62, 73 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "purposeful_wandering",
      "indices" : [ 118, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728189120246210560",
  "text" : "Leaving Cebu for Taipei tonight.  Will meet the nice folks of @rubytaiwan and enjoy visiting a new (for me) country.  #purposeful_wandering",
  "id" : 728189120246210560,
  "created_at" : "2016-05-05 11:46:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 1, 6 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "728105176909815808",
  "geo" : { },
  "id_str" : "728187041897287680",
  "in_reply_to_user_id" : 737649619,
  "text" : ".@_ZPH I'm departing Cebu for Taipei, at airport now. Security confiscated my power strip (!).  Power strips unsafe (only) here?",
  "id" : 728187041897287680,
  "in_reply_to_status_id" : 728105176909815808,
  "created_at" : "2016-05-05 11:38:14 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mactan Cebu Airport",
      "screen_name" : "Cebu_Airport",
      "indices" : [ 0, 13 ],
      "id_str" : "879580754",
      "id" : 879580754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "728186263367356417",
  "in_reply_to_user_id" : 879580754,
  "text" : "@Cebu_Airport Free wifi is a great idea, but it's unusably slow. Also, requiring a Facebook login or Ph. phone is not traveler friendly.",
  "id" : 728186263367356417,
  "created_at" : "2016-05-05 11:35:08 +0000",
  "in_reply_to_screen_name" : "Cebu_Airport",
  "in_reply_to_user_id_str" : "879580754",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mu-Fan Teng",
      "screen_name" : "ryudoawaru",
      "indices" : [ 0, 11 ],
      "id_str" : "17306085",
      "id" : 17306085
    }, {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 12, 23 ],
      "id_str" : "110385172",
      "id" : 110385172
    }, {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 101, 114 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727765542271062016",
  "geo" : { },
  "id_str" : "727766315566563328",
  "in_reply_to_user_id" : 14401983,
  "text" : "@ryudoawaru @rubytaiwan Never mind.  I just found the amazing guide you guys put together (thanks to @JuanitoFatas for pointing me to it).",
  "id" : 727766315566563328,
  "in_reply_to_status_id" : 727765542271062016,
  "created_at" : "2016-05-04 07:46:25 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mu-Fan Teng",
      "screen_name" : "ryudoawaru",
      "indices" : [ 0, 11 ],
      "id_str" : "17306085",
      "id" : 17306085
    }, {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 12, 23 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727759468528832512",
  "geo" : { },
  "id_str" : "727765542271062016",
  "in_reply_to_user_id" : 17306085,
  "text" : "@ryudoawaru @rubytaiwan Thanks, that would be super helpful!  BTW, where can I buy a Taiwan SIM card?  Airport? 7-11? Mall?",
  "id" : 727765542271062016,
  "in_reply_to_status_id" : 727759468528832512,
  "created_at" : "2016-05-04 07:43:21 +0000",
  "in_reply_to_screen_name" : "ryudoawaru",
  "in_reply_to_user_id_str" : "17306085",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 3, 10 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727714897946152961",
  "text" : "RT @bryanl: looked a problem in the face for the majority of the day that had an extremely simple solution. maybe i need to invest in a rub\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "727659800490876928",
    "text" : "looked a problem in the face for the majority of the day that had an extremely simple solution. maybe i need to invest in a rubber duck.",
    "id" : 727659800490876928,
    "created_at" : "2016-05-04 00:43:10 +0000",
    "user" : {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "protected" : false,
      "id_str" : "659933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778347166909825024\/71crhfwO_normal.jpg",
      "id" : 659933,
      "verified" : false
    }
  },
  "id" : 727714897946152961,
  "created_at" : "2016-05-04 04:22:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/USlbagCuGm",
      "expanded_url" : "http:\/\/stackoverflow.com\/users\/501266\/keith-bennett",
      "display_url" : "stackoverflow.com\/users\/501266\/k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727546016820396032",
  "text" : "Baby step, but I'm happy about exceeding 1,000 reputation StackOverflow points helping with Ruby questions: https:\/\/t.co\/USlbagCuGm",
  "id" : 727546016820396032,
  "created_at" : "2016-05-03 17:11:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 128, 139 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727401065730072576",
  "text" : "Anyone have any recommendations for neighborhood \/ hotel \/ coworking \/ therapeutic massage in Taipei? (I'm a visiting Rubyist)  @rubytaiwan",
  "id" : 727401065730072576,
  "created_at" : "2016-05-03 07:35:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 126, 137 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "727400790743117824",
  "text" : "Planning to visit Taipei for a few days starting Fri May 6. Any Rubyists want to meet? Interested in a Functional Ruby talk?  @rubytaiwan",
  "id" : 727400790743117824,
  "created_at" : "2016-05-03 07:33:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "HelloFax",
      "screen_name" : "hellofax",
      "indices" : [ 27, 36 ],
      "id_str" : "141387512",
      "id" : 141387512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "727322051384475649",
  "geo" : { },
  "id_str" : "727394767575764992",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH I've been happy with @hellofax.",
  "id" : 727394767575764992,
  "in_reply_to_status_id" : 727322051384475649,
  "created_at" : "2016-05-03 07:10:01 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/UKJUtsTUi6",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/.travis.yml#L5-6",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "727067599809310720",
  "text" : "For mysterious Travis CI build failures w\/\"\nNoMethodError: undefined method `spec' for nil:NilClass\", use this: https:\/\/t.co\/UKJUtsTUi6.",
  "id" : 727067599809310720,
  "created_at" : "2016-05-02 09:29:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "indices" : [ 3, 14 ],
      "id_str" : "15851832",
      "id" : 15851832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/itASuU0N1K",
      "expanded_url" : "http:\/\/rubyforgood.org\/",
      "display_url" : "rubyforgood.org"
    } ]
  },
  "geo" : { },
  "id_str" : "726792032883118081",
  "text" : "RT @RubyInside: Ruby for Good: A Practical Ruby Event in Washington DC, June 16-19 - https:\/\/t.co\/itASuU0N1K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/itASuU0N1K",
        "expanded_url" : "http:\/\/rubyforgood.org\/",
        "display_url" : "rubyforgood.org"
      } ]
    },
    "geo" : { },
    "id_str" : "726749521804447744",
    "text" : "Ruby for Good: A Practical Ruby Event in Washington DC, June 16-19 - https:\/\/t.co\/itASuU0N1K",
    "id" : 726749521804447744,
    "created_at" : "2016-05-01 12:26:03 +0000",
    "user" : {
      "name" : "Ruby Inside",
      "screen_name" : "RubyInside",
      "protected" : false,
      "id_str" : "15851832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/58236097\/large-png-antialiased_normal.png",
      "id" : 15851832,
      "verified" : false
    }
  },
  "id" : 726792032883118081,
  "created_at" : "2016-05-01 15:14:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726639183993823232",
  "text" : "I still feel the need to liberate myself from Wordpress though.  Suggestions? Jekyll?  Middleman?  Want text, images, embed sound &amp; video.",
  "id" : 726639183993823232,
  "created_at" : "2016-05-01 05:07:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726638571214393344",
  "text" : "Sped up my WP blog load from &gt;8 to 2.5 seconds by deleting all 7000+ non-admin users, almost all spammers.  Sorry to any legitimate users.",
  "id" : 726638571214393344,
  "created_at" : "2016-05-01 05:05:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]