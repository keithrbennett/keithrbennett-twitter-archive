Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Owens",
      "screen_name" : "joshowens",
      "indices" : [ 0, 10 ],
      "id_str" : "768288",
      "id" : 768288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274273579598749696",
  "geo" : { },
  "id_str" : "274627088449929216",
  "in_reply_to_user_id" : 768288,
  "text" : "@joshowens Why yes, I am. :-)",
  "id" : 274627088449929216,
  "in_reply_to_status_id" : 274273579598749696,
  "created_at" : "2012-11-30 21:32:54 +0000",
  "in_reply_to_screen_name" : "joshowens",
  "in_reply_to_user_id_str" : "768288",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 84, 95 ],
      "id_str" : "520859958",
      "id" : 520859958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/23WYeVMJ",
      "expanded_url" : "http:\/\/rspec-next-steps.herokuapp.com\/",
      "display_url" : "rspec-next-steps.herokuapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "274187548786569217",
  "text" : "Excellent presentation on advanced RSpec at the Arlington Ruby Meetup last night by @cupakromer. Slides at http:\/\/t.co\/23WYeVMJ.",
  "id" : 274187548786569217,
  "created_at" : "2012-11-29 16:26:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "Parrot AR.Drone",
      "screen_name" : "ardrone",
      "indices" : [ 68, 76 ],
      "id_str" : "87285403",
      "id" : 87285403
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 55 ],
      "url" : "https:\/\/t.co\/AhjFVcbS",
      "expanded_url" : "https:\/\/github.com\/jimweirich\/argus",
      "display_url" : "github.com\/jimweirich\/arg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274186418933350403",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich We enjoyed using your https:\/\/t.co\/AhjFVcbS library for @ardrone at the Northern Virginia Ruby Meetup a couple of evenings ago.",
  "id" : 274186418933350403,
  "created_at" : "2012-11-29 16:21:51 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273805375503990784",
  "text" : "Seems to me Twitter's move away from Ruby is not a condemnation of Ruby, but an acknowledgment that it was the wrong tool for the job.",
  "id" : 273805375503990784,
  "created_at" : "2012-11-28 15:07:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273543084132941825",
  "geo" : { },
  "id_str" : "273547327099244544",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Good, but I get stuck sometimes when the unknowns pile up. Doesn't help that I didn't choose the simplest schema. Now reading up...",
  "id" : 273547327099244544,
  "in_reply_to_status_id" : 273543084132941825,
  "created_at" : "2012-11-27 22:02:19 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 18, 29 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 103 ],
      "url" : "https:\/\/t.co\/CS8jzEXE",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/karaoke-list",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273542336619896832",
  "text" : "Belated thanks to @seanmarcia for helping me with my humble learning Rails app at https:\/\/t.co\/CS8jzEXE.",
  "id" : 273542336619896832,
  "created_at" : "2012-11-27 21:42:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "273518647664852992",
  "geo" : { },
  "id_str" : "273538938608709632",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight At least 1 or 2 intermediate variables would be helpful there for us mortals.  ;)",
  "id" : 273538938608709632,
  "in_reply_to_status_id" : 273518647664852992,
  "created_at" : "2012-11-27 21:28:59 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/bLefNaEF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=FkTi9T7Tg_w&feature=related",
      "display_url" : "youtube.com\/watch?v=FkTi9T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "272537673338589188",
  "text" : "Damn! I miss a capella singing!  Used to be in a fine group. Watching http:\/\/t.co\/bLefNaEF I so want to do it again, but can't find a group.",
  "id" : 272537673338589188,
  "created_at" : "2012-11-25 03:10:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272418943942135808",
  "text" : "Spoke w\/Amazon Web Services, said I hadn't used the now-expired 12 mo.free trial, asked to extend it another year.  They agreed. Thanks AWS!",
  "id" : 272418943942135808,
  "created_at" : "2012-11-24 19:18:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "272123118674391041",
  "geo" : { },
  "id_str" : "272126315539345408",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick \u2026but the default Java stack setting was not intended for a language like Clojure, &amp; AFAIK is not a function of total memory.",
  "id" : 272126315539345408,
  "in_reply_to_status_id" : 272123118674391041,
  "created_at" : "2012-11-23 23:55:44 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 8, 13 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272109811422867457",
  "text" : "Thanks, @avdi for Ruby tidbit- Class.new passes any block it gets onto the instance's initialize(). Didn't know that happened automatically.",
  "id" : 272109811422867457,
  "created_at" : "2012-11-23 22:50:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271387940788260864",
  "geo" : { },
  "id_str" : "271446203730907136",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich For SOAP with Ruby: Savon, but if it's nontrivial I'd seriously consider using a Java SOAP library with JRuby.",
  "id" : 271446203730907136,
  "in_reply_to_status_id" : 271387940788260864,
  "created_at" : "2012-11-22 02:53:12 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270660676278685696",
  "text" : "Pleasantly surprised...suburban Ashburn, VA has a Lotte Plaza (Asian) supermarket, complete with mini food court. Eating palak paneer.",
  "id" : 270660676278685696,
  "created_at" : "2012-11-19 22:51:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269921277383421953",
  "text" : "Cycled about 26 mi, Reston &lt;--&gt; Ashburn, wearing street clothes, cold most of the way.  Here's hoping I don't get sick.  Any tips?",
  "id" : 269921277383421953,
  "created_at" : "2012-11-17 21:53:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269480819721138176",
  "text" : "#ruby doc tip: ri w\/o arguments gives you an interactive ri shell. If using rvm, u may need to: rvm docs generate-ri.",
  "id" : 269480819721138176,
  "created_at" : "2012-11-16 16:43:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268601807943659521",
  "text" : "So many non-Rails Rubyists in tonight's DevOpsDC meeting.  Smart and friendly folks too.  Nice!",
  "id" : 268601807943659521,
  "created_at" : "2012-11-14 06:30:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Haeffner",
      "screen_name" : "TourDeDave",
      "indices" : [ 3, 14 ],
      "id_str" : "16220257",
      "id" : 16220257
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 25, 39 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268601259148328960",
  "text" : "RT @TourDeDave: Watching @keithrbennett teach these DevOps DC kiddies a thing or two about Ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 9, 23 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268518356624228353",
    "text" : "Watching @keithrbennett teach these DevOps DC kiddies a thing or two about Ruby",
    "id" : 268518356624228353,
    "created_at" : "2012-11-14 00:58:59 +0000",
    "user" : {
      "name" : "Dave Haeffner",
      "screen_name" : "TourDeDave",
      "protected" : false,
      "id_str" : "16220257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455491296186994688\/XjwLsfAZ_normal.jpeg",
      "id" : 16220257,
      "verified" : false
    }
  },
  "id" : 268601259148328960,
  "created_at" : "2012-11-14 06:28:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/QEBa8UYo",
      "expanded_url" : "http:\/\/www.meetup.com\/DevOpsDC\/events\/80753582\/",
      "display_url" : "meetup.com\/DevOpsDC\/event\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268425958409764864",
  "text" : "Doing a Ruby presentation for my local DevOps Meetup this evening (http:\/\/t.co\/QEBa8UYo).  Showing sysadmin-y stuff with Ruby.",
  "id" : 268425958409764864,
  "created_at" : "2012-11-13 18:51:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/u3k9Y4lp",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/11\/09\/linux-mint-13-maya-with-mate-a-great-ruby-development-environment-and-desktop\/",
      "display_url" : "bbs-software.com\/blog\/2012\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "266969449461059584",
  "text" : "Just published this blog article to help people use Linux as a development environment for Ruby +:, with Linux Mint: http:\/\/t.co\/u3k9Y4lp.",
  "id" : 266969449461059584,
  "created_at" : "2012-11-09 18:24:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 15, 25 ],
      "id_str" : "14498747",
      "id" : 14498747
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 29, 43 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/IcnZXEjA",
      "expanded_url" : "http:\/\/img.ly\/pps0",
      "display_url" : "img.ly\/pps0"
    } ]
  },
  "geo" : { },
  "id_str" : "265866103027286016",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius &amp; @tom_enebo to @yukihiro_matz at #rubyconf: \"You're putting *what* in Ruby 2.1?\" (kidding, not really) http:\/\/t.co\/IcnZXEjA",
  "id" : 265866103027286016,
  "created_at" : "2012-11-06 17:19:53 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265853692119486466",
  "geo" : { },
  "id_str" : "265858624826507264",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Agreed.  I advise using it only when other options have been exhausted, and preferably with the input of an experienced Rubyist.",
  "id" : 265858624826507264,
  "in_reply_to_status_id" : 265853692119486466,
  "created_at" : "2012-11-06 16:50:10 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265852453411487744",
  "text" : "Helped teach Ruby at last night's Novarug Code Clinic.  Most Impressive Ruby Feature award went to\u2026drum roll...method_missing.",
  "id" : 265852453411487744,
  "created_at" : "2012-11-06 16:25:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Angelo",
      "screen_name" : "johnangelo",
      "indices" : [ 10, 21 ],
      "id_str" : "7832772",
      "id" : 7832772
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 34, 48 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265669120333344768",
  "text" : "Thnks! RT @johnangelo Enjoyed the @keithrbennett lecture on Ruby at tonight's Code Clinic. Tug-of-war between Ruby and PHP for my newest app",
  "id" : 265669120333344768,
  "created_at" : "2012-11-06 04:17:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 12, 23 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/UeSHhX3i",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/11\/05\/intro-to-functional-programming-in-ruby\/#more-847",
      "display_url" : "bbs-software.com\/blog\/2012\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265575613589499904",
  "text" : "Inspired by @jimweirich's FP keynote, I wrote this blog article on an intro to FP programming in Ruby: http:\/\/t.co\/UeSHhX3i #rubyconf",
  "id" : 265575613589499904,
  "created_at" : "2012-11-05 22:05:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Jim Gay",
      "screen_name" : "saturnflyer",
      "indices" : [ 12, 24 ],
      "id_str" : "6173562",
      "id" : 6173562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265176131559362561",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @saturnflyer United's Android app that is. Great idea about the lock screen, maybe it can be done with a PDF.",
  "id" : 265176131559362561,
  "created_at" : "2012-11-04 19:38:11 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 0, 11 ],
      "id_str" : "35954885",
      "id" : 35954885
    }, {
      "name" : "Jim Gay",
      "screen_name" : "saturnflyer",
      "indices" : [ 12, 24 ],
      "id_str" : "6173562",
      "id" : 6173562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "265117784206364672",
  "geo" : { },
  "id_str" : "265168919021633536",
  "in_reply_to_user_id" : 35954885,
  "text" : "@joshsusser @saturnflyer United's app wants access to my address book. Why? I refuse. Too bad for me and them.",
  "id" : 265168919021633536,
  "in_reply_to_status_id" : 265117784206364672,
  "created_at" : "2012-11-04 19:09:31 +0000",
  "in_reply_to_screen_name" : "joshsusser",
  "in_reply_to_user_id_str" : "35954885",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Waldo Jaquith",
      "screen_name" : "waldojaquith",
      "indices" : [ 3, 16 ],
      "id_str" : "206283535",
      "id" : 206283535
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4pNeWyMN",
      "expanded_url" : "http:\/\/www.telegraph.co.uk\/history\/9653497\/British-have-invaded-nine-out-of-ten-countries-so-look-out-Luxembourg.html",
      "display_url" : "telegraph.co.uk\/history\/965349\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265163075819294720",
  "text" : "RT @waldojaquith: England has invaded every country in the world, save for 22. Look out, Marshall Islands\u2014you're next. http:\/\/t.co\/4pNeWyMN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/4pNeWyMN",
        "expanded_url" : "http:\/\/www.telegraph.co.uk\/history\/9653497\/British-have-invaded-nine-out-of-ten-countries-so-look-out-Luxembourg.html",
        "display_url" : "telegraph.co.uk\/history\/965349\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "265143497630306304",
    "text" : "England has invaded every country in the world, save for 22. Look out, Marshall Islands\u2014you're next. http:\/\/t.co\/4pNeWyMN",
    "id" : 265143497630306304,
    "created_at" : "2012-11-04 17:28:30 +0000",
    "user" : {
      "name" : "Waldo Jaquith",
      "screen_name" : "waldojaquith",
      "protected" : false,
      "id_str" : "206283535",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459705033282420736\/lrr8ZvPe_normal.png",
      "id" : 206283535,
      "verified" : false
    }
  },
  "id" : 265163075819294720,
  "created_at" : "2012-11-04 18:46:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/264854683120717825\/photo\/1",
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/1C0PAThH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6zz7ljCUAAHFW-.jpg",
      "id_str" : "264854683124912128",
      "id" : 264854683124912128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6zz7ljCUAAHFW-.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1C0PAThH"
    } ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 9, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264854683120717825",
  "text" : "Lunch at #rubyconf. http:\/\/t.co\/1C0PAThH",
  "id" : 264854683120717825,
  "created_at" : "2012-11-03 22:20:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 0, 8 ],
      "id_str" : "6083342",
      "id" : 6083342
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264820367816814592",
  "in_reply_to_user_id" : 6083342,
  "text" : "@bascule Marty said you're the guy for karaoke in Denver.  Let's try to meet up here at #rubyconf, ok? I'd like to ask for some advice.",
  "id" : 264820367816814592,
  "created_at" : "2012-11-03 20:04:30 +0000",
  "in_reply_to_screen_name" : "bascule",
  "in_reply_to_user_id_str" : "6083342",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264788962122530817",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf Anyone interested in karaoke tonight at Julie's Bar&amp;Grill (Filipino restaurant in Colorado Springs)? It's from 930 to 2, no cover.",
  "id" : 264788962122530817,
  "created_at" : "2012-11-03 17:59:42 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/C5PlC2zd",
      "expanded_url" : "http:\/\/www.sweetadelineintl.org\/index.cfm?id=42",
      "display_url" : "sweetadelineintl.org\/index.cfm?id=42"
    } ]
  },
  "geo" : { },
  "id_str" : "264650248574607360",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer #rubyconf Self-correction: they're singing at the Pepsi Center, but I saw them at the Conv. Ctr. on Thurs. http:\/\/t.co\/C5PlC2zd",
  "id" : 264650248574607360,
  "created_at" : "2012-11-03 08:48:30 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "264595116172378112",
  "geo" : { },
  "id_str" : "264648706463252480",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer #rubyconf We're sharing the convention center with the Sweet Adelines (female barbershop singers) international competition.",
  "id" : 264648706463252480,
  "in_reply_to_status_id" : 264595116172378112,
  "created_at" : "2012-11-03 08:42:23 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u039Erik",
      "screen_name" : "sferik",
      "indices" : [ 0, 7 ],
      "id_str" : "7505382",
      "id" : 7505382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 113 ],
      "url" : "https:\/\/t.co\/iIGvLW1q",
      "expanded_url" : "https:\/\/github.com\/sferik\/t",
      "display_url" : "github.com\/sferik\/t"
    } ]
  },
  "geo" : { },
  "id_str" : "264522076365402113",
  "in_reply_to_user_id" : 7505382,
  "text" : "@sferik showed us his great Twitter command line tool \"t\" at a lightning talk at #rubyconf (https:\/\/t.co\/iIGvLW1q).",
  "id" : 264522076365402113,
  "created_at" : "2012-11-03 00:19:12 +0000",
  "in_reply_to_screen_name" : "sferik",
  "in_reply_to_user_id_str" : "7505382",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brian austin santos",
      "screen_name" : "austin_bv",
      "indices" : [ 0, 10 ],
      "id_str" : "412544239",
      "id" : 412544239
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/264486037538099200\/photo\/1",
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/JbaFUtcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6ukplvCUAERket.jpg",
      "id_str" : "264486037542293505",
      "id" : 264486037542293505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6ukplvCUAERket.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JbaFUtcR"
    } ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "arduino",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "rubyconf",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264486037538099200",
  "in_reply_to_user_id" : 412544239,
  "text" : "@austin_bv's cool #ruby driven #arduino controlled t shirt cannon at #rubyconf. http:\/\/t.co\/JbaFUtcR",
  "id" : 264486037538099200,
  "created_at" : "2012-11-02 21:56:01 +0000",
  "in_reply_to_screen_name" : "austin_bv",
  "in_reply_to_user_id_str" : "412544239",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Johnson",
      "screen_name" : "benbjohnson",
      "indices" : [ 0, 12 ],
      "id_str" : "14137255",
      "id" : 14137255
    }, {
      "name" : "Ben Curren",
      "screen_name" : "bcurren",
      "indices" : [ 13, 21 ],
      "id_str" : "14576372",
      "id" : 14576372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263698138529931264",
  "geo" : { },
  "id_str" : "264194683490684928",
  "in_reply_to_user_id" : 14137255,
  "text" : "@benbjohnson @bcurren  So sorry, I didn't see your messages.  I decided to go to RubyConf after all; the storm wasn't bad at all by me.",
  "id" : 264194683490684928,
  "in_reply_to_status_id" : 263698138529931264,
  "created_at" : "2012-11-02 02:38:15 +0000",
  "in_reply_to_screen_name" : "benbjohnson",
  "in_reply_to_user_id_str" : "14137255",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 12, 22 ],
      "id_str" : "14498747",
      "id" : 14498747
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 27, 35 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264148617219153920",
  "text" : "Listened to @tom_enebo and @headius, JRuby creators, speak at #rubyconf in Denver. These guys are my heroes for their tough &amp; great work.",
  "id" : 264148617219153920,
  "created_at" : "2012-11-01 23:35:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]