Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Holloway",
      "screen_name" : "StuartHolloway",
      "indices" : [ 13, 28 ],
      "id_str" : "937335816",
      "id" : 937335816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10642665323",
  "text" : "Listening to @stuartholloway and RIch Hickey on Clojure in Reston, Virginia.  Stu recommends http:\/\/bit.ly\/4JRT4R as required reading.",
  "id" : 10642665323,
  "created_at" : "2010-03-17 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Kaczor",
      "screen_name" : "kaczoanoker",
      "indices" : [ 0, 12 ],
      "id_str" : "32923605",
      "id" : 32923605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10217748549",
  "geo" : { },
  "id_str" : "10217891317",
  "in_reply_to_user_id" : 32923605,
  "text" : "@kaczoanoker You're welcome.  If you do and would like any info, feel free to let me know (best is gmail -- id is keithrbennett).",
  "id" : 10217891317,
  "in_reply_to_status_id" : 10217748549,
  "created_at" : "2010-03-09 00:00:00 +0000",
  "in_reply_to_screen_name" : "kaczoanoker",
  "in_reply_to_user_id_str" : "32923605",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10188534483",
  "text" : "Returned from Thailand, photos at http:\/\/snipurl.com\/upp9t.  New blog articles at http:\/\/snipurl.com\/uppbj and http:\/\/snipurl.com\/uppbz.",
  "id" : 10188534483,
  "created_at" : "2010-03-08 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]