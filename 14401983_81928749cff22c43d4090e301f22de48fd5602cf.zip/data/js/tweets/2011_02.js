Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 3, 12 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36918208380280833",
  "text" : "RT @venkat_s: Agile process in the absence of agility is like wings on a penguin, you can flap but not fly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36786001062006784",
    "text" : "Agile process in the absence of agility is like wings on a penguin, you can flap but not fly.",
    "id" : 36786001062006784,
    "created_at" : "2011-02-13 13:57:20 +0000",
    "user" : {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "protected" : false,
      "id_str" : "14429713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633469991\/venkatsubramaniam_normal.jpg",
      "id" : 14429713,
      "verified" : false
    }
  },
  "id" : 36918208380280833,
  "created_at" : "2011-02-13 22:42:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]