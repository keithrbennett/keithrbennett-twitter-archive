Grailbird.data.tweets_2013_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396095698791579648",
  "text" : "Fellow Virginians, please vote on Tuesday!  Also, if you can donate time or funds, please do. This race is important and not a sure thing.",
  "id" : 396095698791579648,
  "created_at" : "2013-11-01 02:05:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391914887079026689",
  "geo" : { },
  "id_str" : "391966845474856960",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Evan, she was so fortunate to have you, heroic and attentive husband\/caregiver, to escort her through the last years of her life.",
  "id" : 391966845474856960,
  "in_reply_to_status_id" : 391914887079026689,
  "created_at" : "2013-10-20 16:39:13 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "!!StevenNunez",
      "screen_name" : "_StevenNunez",
      "indices" : [ 6, 19 ],
      "id_str" : "286200673",
      "id" : 286200673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391742311782420480",
  "geo" : { },
  "id_str" : "391963632184983552",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @_StevenNunez Is 'a' + 'b' similarly optimized in Ruby, resolving to a single string at runtime?",
  "id" : 391963632184983552,
  "in_reply_to_status_id" : 391742311782420480,
  "created_at" : "2013-10-20 16:26:26 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 16, 23 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391352025033629696",
  "geo" : { },
  "id_str" : "391396493350821888",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms cc @elight  I'll have what you're having. ;)",
  "id" : 391396493350821888,
  "in_reply_to_status_id" : 391352025033629696,
  "created_at" : "2013-10-19 02:52:50 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 0, 10 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "391189806937833473",
  "geo" : { },
  "id_str" : "391353037920665600",
  "in_reply_to_user_id" : 15243796,
  "text" : "@ngauthier A plaid suit!  Classy!  :)",
  "id" : 391353037920665600,
  "in_reply_to_status_id" : 391189806937833473,
  "created_at" : "2013-10-19 00:00:09 +0000",
  "in_reply_to_screen_name" : "ngauthier",
  "in_reply_to_user_id_str" : "15243796",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/vJV8fRvuJd",
      "expanded_url" : "http:\/\/superuser.com\/questions\/547528\/turn-off-auto-complete-auto-correct-on-lync-on-mac",
      "display_url" : "superuser.com\/questions\/5475\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "391304521898405888",
  "text" : "How to disable autocorrect on Lync for Mac: http:\/\/t.co\/vJV8fRvuJd",
  "id" : 391304521898405888,
  "created_at" : "2013-10-18 20:47:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 11, 21 ],
      "id_str" : "74286565",
      "id" : 74286565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lync",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "391303700200689664",
  "text" : "Thank you, @microsoft #lync, for autocorrecting 'dmg' to 'dog' so I could tell tech support I just downloaded the dog.",
  "id" : 391303700200689664,
  "created_at" : "2013-10-18 20:44:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Thomas",
      "screen_name" : "pragdave",
      "indices" : [ 0, 9 ],
      "id_str" : "6186692",
      "id" : 6186692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Zfb7il4Unx",
      "expanded_url" : "http:\/\/media.pragprog.com\/titles\/ruby3\/app_socket.pdf",
      "display_url" : "media.pragprog.com\/titles\/ruby3\/a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "388108995476463617",
  "in_reply_to_user_id" : 6186692,
  "text" : "@pragdave et al released for free the Ruby 1.9 Socket Library appendix formerly in the Pickaxe book at http:\/\/t.co\/Zfb7il4Unx.",
  "id" : 388108995476463617,
  "created_at" : "2013-10-10 01:09:29 +0000",
  "in_reply_to_screen_name" : "pragdave",
  "in_reply_to_user_id_str" : "6186692",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "russolsen",
      "screen_name" : "russolsen",
      "indices" : [ 0, 10 ],
      "id_str" : "15740685",
      "id" : 15740685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "387661595901304832",
  "geo" : { },
  "id_str" : "388016824803020801",
  "in_reply_to_user_id" : 15740685,
  "text" : "@russolsen ...not to mention, good taste. ;)",
  "id" : 388016824803020801,
  "in_reply_to_status_id" : 387661595901304832,
  "created_at" : "2013-10-09 19:03:14 +0000",
  "in_reply_to_screen_name" : "russolsen",
  "in_reply_to_user_id_str" : "15740685",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]