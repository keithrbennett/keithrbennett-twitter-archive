Grailbird.data.tweets_2013_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/6q2gSkhvIJ",
      "expanded_url" : "http:\/\/forums.whirlpool.net.au\/archive\/2095947",
      "display_url" : "forums.whirlpool.net.au\/archive\/2095947"
    } ]
  },
  "geo" : { },
  "id_str" : "371740770673238016",
  "text" : "Not a fraud, but parasitic nonetheless.  See Michael Ross post at http:\/\/t.co\/6q2gSkhvIJ. They bid on expiring domains. The greed...",
  "id" : 371740770673238016,
  "created_at" : "2013-08-25 21:08:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371704789978980352",
  "text" : "Just found out -- the purported owner didn't even own the domain name.  It was a total fraud.",
  "id" : 371704789978980352,
  "created_at" : "2013-08-25 18:45:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "371704656117780481",
  "text" : "My gut feeling: domain name brokers are opportunistic parasites who add no value whatsoever to the economy.  Am I wrong?",
  "id" : 371704656117780481,
  "created_at" : "2013-08-25 18:44:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 0, 3 ],
      "id_str" : "1133971",
      "id" : 1133971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/iG4sF4LKeL",
      "expanded_url" : "https:\/\/creditcards.chase.com\/credit-cards\/united-airlines-credit-card1.aspx?icell=6B13&unitedclubsplit=2&unitedmileageplussplit=1",
      "display_url" : "creditcards.chase.com\/credit-cards\/u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "371691044833734656",
  "geo" : { },
  "id_str" : "371697940739260416",
  "in_reply_to_user_id" : 1133971,
  "text" : "@j3 Check out the United Visa card: https:\/\/t.co\/iG4sF4LKeL; 30K mile bonus, first checked bag free, no foreign exchange fee, club passes.",
  "id" : 371697940739260416,
  "in_reply_to_status_id" : 371691044833734656,
  "created_at" : "2013-08-25 18:17:49 +0000",
  "in_reply_to_screen_name" : "j3",
  "in_reply_to_user_id_str" : "1133971",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hennell",
      "screen_name" : "hennell",
      "indices" : [ 3, 11 ],
      "id_str" : "14556769",
      "id" : 14556769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Microsoft",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370982378258579456",
  "text" : "RT @hennell: Steve Ballmer to retire from #Microsoft within 'next 12 months' - Specific date unknown because no-one trusts this: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hennell\/status\/370920779853987841\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/AY67tau6Nk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BSXGe-uCAAAvCOw.jpg",
        "id_str" : "370920779862376448",
        "id" : 370920779862376448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BSXGe-uCAAAvCOw.jpg",
        "sizes" : [ {
          "h" : 175,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 448
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 448
        } ],
        "display_url" : "pic.twitter.com\/AY67tau6Nk"
      } ],
      "hashtags" : [ {
        "text" : "Microsoft",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "370920779853987841",
    "text" : "Steve Ballmer to retire from #Microsoft within 'next 12 months' - Specific date unknown because no-one trusts this: http:\/\/t.co\/AY67tau6Nk",
    "id" : 370920779853987841,
    "created_at" : "2013-08-23 14:49:40 +0000",
    "user" : {
      "name" : "Hennell",
      "screen_name" : "hennell",
      "protected" : false,
      "id_str" : "14556769",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761495913835663360\/FLWGAAB5_normal.jpg",
      "id" : 14556769,
      "verified" : false
    }
  },
  "id" : 370982378258579456,
  "created_at" : "2013-08-23 18:54:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "slaps_self",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370979646549921794",
  "text" : "Usually the stickler for good names, I named a comparator lookup hash comparators, not comparator_lookup.  Now paying the price. #slaps_self",
  "id" : 370979646549921794,
  "created_at" : "2013-08-23 18:43:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mongo",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370686699765919744",
  "text" : "i.e. Don't permit any periods or $'s in any app data that might ever possibly be a hash key, if you might ever use #mongo. Or esc\/unesc them",
  "id" : 370686699765919744,
  "created_at" : "2013-08-22 23:19:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370686307720130560",
  "text" : "Bummed I have to remove periods from all app hash keys because MongoDB can't handle them. Could be a big problem w\/3rd party data.",
  "id" : 370686307720130560,
  "created_at" : "2013-08-22 23:17:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iloveruby",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "370573552124059649",
  "text" : "on = %w(on true yes).include?(value_string.downcase)   #iloveruby",
  "id" : 370573552124059649,
  "created_at" : "2013-08-22 15:49:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Yu5WHmiIoD",
      "expanded_url" : "http:\/\/www.fairfaxcounty.gov\/domesticviolence\/dvac\/court-attire.htm#donationdrive",
      "display_url" : "fairfaxcounty.gov\/domesticviolen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "369122627907887104",
  "text" : "Fairfax County (Virginia, USA) Domestic Violence Action Center seeks men's &amp; women's lightly used dress clothes: http:\/\/t.co\/Yu5WHmiIoD",
  "id" : 369122627907887104,
  "created_at" : "2013-08-18 15:44:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 1, 13 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 16, 30 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc13",
      "indices" : [ 85, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368937977772113921",
  "text" : "\"@angelaharms: .@SteelCityRuby What a delightful conference! Thank you so much. :-)\" #scrc13",
  "id" : 368937977772113921,
  "created_at" : "2013-08-18 03:30:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "\u239B\u2686_\u2686\u23A0 Kerri Miller",
      "screen_name" : "kerrizor",
      "indices" : [ 6, 15 ],
      "id_str" : "2998581",
      "id" : 2998581
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368811742811267073",
  "geo" : { },
  "id_str" : "368812279623479296",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH @kerrizor No worries, Zander, you're still awesome &amp; I look forward to pairing with you on Elixir someday. :-)",
  "id" : 368812279623479296,
  "in_reply_to_status_id" : 368811742811267073,
  "created_at" : "2013-08-17 19:11:14 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce_Adams",
      "screen_name" : "Bruce_Adams",
      "indices" : [ 3, 15 ],
      "id_str" : "16496967",
      "id" : 16496967
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Bruce_Adams\/status\/368440972239044608\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/mLQD4kejxd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BRz3HLdCAAAJxYZ.jpg",
      "id_str" : "368440972243238912",
      "id" : 368440972243238912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRz3HLdCAAAJxYZ.jpg",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 63,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 111,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 1796
      } ],
      "display_url" : "pic.twitter.com\/mLQD4kejxd"
    } ],
    "hashtags" : [ {
      "text" : "scrc13",
      "indices" : [ 33, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368518735704760320",
  "text" : "RT @Bruce_Adams: Friday hug from #scrc13 http:\/\/t.co\/mLQD4kejxd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bruce_Adams\/status\/368440972239044608\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/mLQD4kejxd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BRz3HLdCAAAJxYZ.jpg",
        "id_str" : "368440972243238912",
        "id" : 368440972243238912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BRz3HLdCAAAJxYZ.jpg",
        "sizes" : [ {
          "h" : 189,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 63,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 111,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 1796
        } ],
        "display_url" : "pic.twitter.com\/mLQD4kejxd"
      } ],
      "hashtags" : [ {
        "text" : "scrc13",
        "indices" : [ 16, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "368440972239044608",
    "text" : "Friday hug from #scrc13 http:\/\/t.co\/mLQD4kejxd",
    "id" : 368440972239044608,
    "created_at" : "2013-08-16 18:35:47 +0000",
    "user" : {
      "name" : "Bruce_Adams",
      "screen_name" : "Bruce_Adams",
      "protected" : false,
      "id_str" : "16496967",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672417368954408960\/ZoEItgeF_normal.jpg",
      "id" : 16496967,
      "verified" : false
    }
  },
  "id" : 368518735704760320,
  "created_at" : "2013-08-16 23:44:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc13",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368472111868030976",
  "text" : "Anyone interested in karaoke tonight, maybe at KBox? What time's good? 9:00? #scrc13",
  "id" : 368472111868030976,
  "created_at" : "2013-08-16 20:39:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "368326459099975680",
  "geo" : { },
  "id_str" : "368399277539610624",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH I'm looking forward to it!",
  "id" : 368399277539610624,
  "in_reply_to_status_id" : 368326459099975680,
  "created_at" : "2013-08-16 15:50:06 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc13",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "368246320386932737",
  "text" : "Looking forward to pair programming during the long breaks at #scrc13, and possibly tomorrow (Friday) evening.  Anyone interested?",
  "id" : 368246320386932737,
  "created_at" : "2013-08-16 05:42:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "367301533357965313",
  "text" : "Rubyists, TIL if you get a segmentation fault it may be fixed by blowing away and reinstalling your gems.",
  "id" : 367301533357965313,
  "created_at" : "2013-08-13 15:08:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James A Rosen",
      "screen_name" : "jamesarosen",
      "indices" : [ 0, 12 ],
      "id_str" : "7114202",
      "id" : 7114202
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 13, 27 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363870132386279424",
  "geo" : { },
  "id_str" : "366576982386933761",
  "in_reply_to_user_id" : 7114202,
  "text" : "@jamesarosen @SteelCityRuby Yes, possibly. I'm very interested in promiscuous pairing, er, coding that is, at the conf, esp. between talks.",
  "id" : 366576982386933761,
  "in_reply_to_status_id" : 363870132386279424,
  "created_at" : "2013-08-11 15:08:57 +0000",
  "in_reply_to_screen_name" : "jamesarosen",
  "in_reply_to_user_id_str" : "7114202",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/K6pYALIA2P",
      "expanded_url" : "http:\/\/svn.ruby-lang.org\/repos\/ruby\/tags\/v1_9_3_448\/ChangeLog",
      "display_url" : "svn.ruby-lang.org\/repos\/ruby\/tag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "365867695792594944",
  "text" : "Looking at http:\/\/t.co\/K6pYALIA2P... thanks to our Japanese friends for all their hard work making the Ruby language so great.",
  "id" : 365867695792594944,
  "created_at" : "2013-08-09 16:10:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/j1nDiR3npk",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/?p=1320",
      "display_url" : "bbs-software.com\/blog\/?p=1320"
    } ]
  },
  "in_reply_to_status_id_str" : "363831267684384769",
  "geo" : { },
  "id_str" : "363831999837904896",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Ah, WordPress has \"short links\".  This one works: http:\/\/t.co\/j1nDiR3npk.",
  "id" : 363831999837904896,
  "in_reply_to_status_id" : 363831267684384769,
  "created_at" : "2013-08-04 01:21:23 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "363830530803892224",
  "geo" : { },
  "id_str" : "363831267684384769",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett URL messed up because of the apple logo char. I guess I was asking for trouble. ;) Even copy\/pasting all the link text fails.",
  "id" : 363831267684384769,
  "in_reply_to_status_id" : 363830530803892224,
  "created_at" : "2013-08-04 01:18:28 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/E0zeLLBx6A",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/08\/03\/",
      "display_url" : "bbs-software.com\/blog\/2013\/08\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "363830530803892224",
  "text" : "Put \uF8FF in Your System Prompt...just published a new blog article at http:\/\/t.co\/E0zeLLBx6A\uF8FF-in-your-system-prompt\/.",
  "id" : 363830530803892224,
  "created_at" : "2013-08-04 01:15:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Zen",
      "screen_name" : "dailyzen",
      "indices" : [ 3, 12 ],
      "id_str" : "14850840",
      "id" : 14850840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "363679161413816320",
  "text" : "RT @dailyzen: \u201CYou don\u2019t need to be perfect to inspire others. Let people get inspired by how you deal with your imperfection.\u201D  \u2014 Wilson K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "363632098323595264",
    "text" : "\u201CYou don\u2019t need to be perfect to inspire others. Let people get inspired by how you deal with your imperfection.\u201D  \u2014 Wilson Kanadi",
    "id" : 363632098323595264,
    "created_at" : "2013-08-03 12:07:02 +0000",
    "user" : {
      "name" : "Daily Zen",
      "screen_name" : "dailyzen",
      "protected" : false,
      "id_str" : "14850840",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712828571841114113\/9cMlNAUu_normal.jpg",
      "id" : 14850840,
      "verified" : false
    }
  },
  "id" : 363679161413816320,
  "created_at" : "2013-08-03 15:14:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]