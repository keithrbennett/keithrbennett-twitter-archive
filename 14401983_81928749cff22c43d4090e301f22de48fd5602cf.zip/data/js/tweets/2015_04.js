Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BaltimoreRiots",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ZRS1Vvvco2",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/4c2198e1-d51a-44e7-a57b-ce22a00097e2",
      "display_url" : "amp.twimg.com\/v\/4c2198e1-d51\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592883867956150273",
  "text" : "RT @ACFromDaBranch: They not showing this on the news  #BaltimoreRiots https:\/\/t.co\/ZRS1Vvvco2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BaltimoreRiots",
        "indices" : [ 35, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 74 ],
        "url" : "https:\/\/t.co\/ZRS1Vvvco2",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/4c2198e1-d51a-44e7-a57b-ce22a00097e2",
        "display_url" : "amp.twimg.com\/v\/4c2198e1-d51\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "592839101574946817",
    "text" : "They not showing this on the news  #BaltimoreRiots https:\/\/t.co\/ZRS1Vvvco2",
    "id" : 592839101574946817,
    "created_at" : "2015-04-27 23:53:50 +0000",
    "user" : {
      "name" : "A v o u n Escobar",
      "screen_name" : "VonFromDaPook",
      "protected" : false,
      "id_str" : "726462492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810256756119076864\/BnzGp-e2_normal.jpg",
      "id" : 726462492,
      "verified" : false
    }
  },
  "id" : 592883867956150273,
  "created_at" : "2015-04-28 02:51:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592429257147559937",
  "geo" : { },
  "id_str" : "592429780529733634",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Possibly.  Still, even if it doubled since then, MoCo would still have a small percentage of the tech work in the DC area.",
  "id" : 592429780529733634,
  "in_reply_to_status_id" : 592429257147559937,
  "created_at" : "2015-04-26 20:47:21 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 8, 19 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Marius Lucian Pop",
      "screen_name" : "mlpinit",
      "indices" : [ 20, 28 ],
      "id_str" : "125417337",
      "id" : 125417337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592086448402075648",
  "geo" : { },
  "id_str" : "592427962286403585",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @seanmarcia @mlpinit Driving home 1 rainy day took 2 hours, and I missed most of my daughter's performance in school. Never again.",
  "id" : 592427962286403585,
  "in_reply_to_status_id" : 592086448402075648,
  "created_at" : "2015-04-26 20:40:07 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 8, 19 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Marius Lucian Pop",
      "screen_name" : "mlpinit",
      "indices" : [ 20, 28 ],
      "id_str" : "125417337",
      "id" : 125417337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "592086448402075648",
  "geo" : { },
  "id_str" : "592426105975504897",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @seanmarcia @mlpinit I lived in MoCo ~15 yrs. Most jobs were in NoVa. Awful commute cost in time, $, health, energy, happiness.",
  "id" : 592426105975504897,
  "in_reply_to_status_id" : 592086448402075648,
  "created_at" : "2015-04-26 20:32:45 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "indices" : [ 19, 32 ],
      "id_str" : "18061835",
      "id" : 18061835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/1yeNS0t63y",
      "expanded_url" : "http:\/\/www.meetup.com\/novarug\/photos\/26075282\/436703813\/#436703815",
      "display_url" : "meetup.com\/novarug\/photos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592054620920352769",
  "text" : "Uploaded photos of @aidanfeldman from his Mustachio talk at the Northern Virginia Ruby User Group meeting at http:\/\/t.co\/1yeNS0t63y",
  "id" : 592054620920352769,
  "created_at" : "2015-04-25 19:56:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta",
      "screen_name" : "Delta",
      "indices" : [ 9, 15 ],
      "id_str" : "5920532",
      "id" : 5920532
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 85, 92 ],
      "id_str" : "260907612",
      "id" : 260907612
    }, {
      "name" : "American Airlines",
      "screen_name" : "AmericanAir",
      "indices" : [ 96, 108 ],
      "id_str" : "22536055",
      "id" : 22536055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/eOzSuSGkQ2",
      "expanded_url" : "http:\/\/creditcardforum.com\/blog\/american-express-rewards-point-value\/",
      "display_url" : "creditcardforum.com\/blog\/american-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592034076208541697",
  "text" : "So true: @Delta\u2019s SkyMiles called 'SkyPesos' because they're not as valuable as say, @united or @AmericanAir miles.' -http:\/\/t.co\/eOzSuSGkQ2",
  "id" : 592034076208541697,
  "created_at" : "2015-04-25 18:34:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "DevJam Studios",
      "screen_name" : "DevJamStudios",
      "indices" : [ 99, 113 ],
      "id_str" : "1601287728",
      "id" : 1601287728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SDTConf",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590868129452007424",
  "text" : "RT @nashjain: 8th Simple Design &amp; Testing Conference #SDTConf is planned on 13-14th June'15 at @DevJamStudios, Minneapolis http:\/\/t.co\/Bsoe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DevJam Studios",
        "screen_name" : "DevJamStudios",
        "indices" : [ 85, 99 ],
        "id_str" : "1601287728",
        "id" : 1601287728
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SDTConf",
        "indices" : [ 43, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/BsoevlsWYN",
        "expanded_url" : "http:\/\/sdtconf.com\/",
        "display_url" : "sdtconf.com"
      } ]
    },
    "geo" : { },
    "id_str" : "590854323401175042",
    "text" : "8th Simple Design &amp; Testing Conference #SDTConf is planned on 13-14th June'15 at @DevJamStudios, Minneapolis http:\/\/t.co\/BsoevlsWYN Plz RT",
    "id" : 590854323401175042,
    "created_at" : "2015-04-22 12:27:02 +0000",
    "user" : {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "protected" : false,
      "id_str" : "10411062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775404265976332288\/LOoVpSln_normal.jpg",
      "id" : 10411062,
      "verified" : false
    }
  },
  "id" : 590868129452007424,
  "created_at" : "2015-04-22 13:21:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StumbleUpon",
      "screen_name" : "StumbleUpon",
      "indices" : [ 10, 22 ],
      "id_str" : "15395087",
      "id" : 15395087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/CYzhAhIB3z",
      "expanded_url" : "http:\/\/www.stumbleupon.com\/su\/27FPtP\/131z.FXRP:8QlivtY\/www.funnyordie.com\/articles\/84b0f19f4f\/21-best-gifs-of-all-time-of-the-week-volume-87",
      "display_url" : "stumbleupon.com\/su\/27FPtP\/131z\u2026"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zi1c7tsueB",
      "expanded_url" : "http:\/\/p.fod4.com\/p\/media\/84b0f19f4f\/iEB7yUniRBSBdcFM4ro9_Dog%20Butt%20Window%20Fall.gif",
      "display_url" : "p.fod4.com\/p\/media\/84b0f1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590370418416058368",
  "text" : "Thank you @stumbleupon for the funny gifs at http:\/\/t.co\/CYzhAhIB3z, esp. this one which may be NSFW for some: http:\/\/t.co\/zi1c7tsueB",
  "id" : 590370418416058368,
  "created_at" : "2015-04-21 04:24:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katherine Cross",
      "screen_name" : "Quinnae_Moon",
      "indices" : [ 3, 16 ],
      "id_str" : "213169226",
      "id" : 213169226
    }, {
      "name" : "Vijaya Gadde",
      "screen_name" : "vijaya",
      "indices" : [ 37, 44 ],
      "id_str" : "29018269",
      "id" : 29018269
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588906784263434240",
  "text" : "RT @Quinnae_Moon: This WaPo op-ed by @vijaya about Twitter's newfound commitment to dealing with abuse is tremendously encouraging: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vijaya Gadde",
        "screen_name" : "vijaya",
        "indices" : [ 19, 26 ],
        "id_str" : "29018269",
        "id" : 29018269
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/v1VLYlZRzI",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/posteverything\/wp\/2015\/04\/16\/twitter-executive-heres-how-were-trying-to-stop-abuse-while-preserving-free-speech\/?postshare=5481429186286118",
        "display_url" : "washingtonpost.com\/posteverything\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588840685421338626",
    "text" : "This WaPo op-ed by @vijaya about Twitter's newfound commitment to dealing with abuse is tremendously encouraging: http:\/\/t.co\/v1VLYlZRzI",
    "id" : 588840685421338626,
    "created_at" : "2015-04-16 23:05:34 +0000",
    "user" : {
      "name" : "Katherine Cross",
      "screen_name" : "Quinnae_Moon",
      "protected" : false,
      "id_str" : "213169226",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660895458362044416\/CXthyGCV_normal.jpg",
      "id" : 213169226,
      "verified" : true
    }
  },
  "id" : 588906784263434240,
  "created_at" : "2015-04-17 03:28:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 1, 8 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "588147939148754946",
  "geo" : { },
  "id_str" : "588209227807723521",
  "in_reply_to_user_id" : 260907612,
  "text" : ".@united According to that info, flights leaving after 8:01 PM would get just a snack, even if the flight duration is &gt; 8 hours, right?",
  "id" : 588209227807723521,
  "in_reply_to_status_id" : 588147939148754946,
  "created_at" : "2015-04-15 05:16:22 +0000",
  "in_reply_to_screen_name" : "united",
  "in_reply_to_user_id_str" : "260907612",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 1, 8 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588129204971134978",
  "text" : ".@united My friend flew Houston -&gt; Honolulu -&gt; Guam and got no food because it's considered a domestic flight?  Is that really your policy?",
  "id" : 588129204971134978,
  "created_at" : "2015-04-14 23:58:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "nVisium",
      "screen_name" : "nVisium",
      "indices" : [ 10, 18 ],
      "id_str" : "101121180",
      "id" : 101121180
    }, {
      "name" : "District Taco",
      "screen_name" : "districttaco",
      "indices" : [ 19, 32 ],
      "id_str" : "55859591",
      "id" : 55859591
    }, {
      "name" : "District Taco",
      "screen_name" : "districttaco",
      "indices" : [ 43, 56 ],
      "id_str" : "55859591",
      "id" : 55859591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "587753574182039553",
  "geo" : { },
  "id_str" : "587775304850137088",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton @nVisium @districttaco Sadly, no @districttaco outside the Beltway. We do have a @RotiUSA at Tyson's but it's far from Herndon.",
  "id" : 587775304850137088,
  "in_reply_to_status_id" : 587753574182039553,
  "created_at" : "2015-04-14 00:32:07 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nVisium",
      "screen_name" : "nVisium",
      "indices" : [ 14, 22 ],
      "id_str" : "101121180",
      "id" : 101121180
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/587749448123580417\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HHbTcgYDpO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCgbANeXIAAtal7.jpg",
      "id_str" : "587749441802805248",
      "id" : 587749441802805248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCgbANeXIAAtal7.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/HHbTcgYDpO"
    } ],
    "hashtags" : [ {
      "text" : "elixir",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587749448123580417",
  "text" : "Food wheel at @nVisium, host of our #elixir meetup in Herndon, Virginia. http:\/\/t.co\/HHbTcgYDpO",
  "id" : 587749448123580417,
  "created_at" : "2015-04-13 22:49:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/MkmGhlWGW8",
      "expanded_url" : "http:\/\/osxdaily.com\/2011\/08\/18\/disable-spelling-auto-correct-safari-mac-os-x\/",
      "display_url" : "osxdaily.com\/2011\/08\/18\/dis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587305088068235265",
  "text" : "Safari browser replaces \"meetup\" with \"metope\" as I type; never even heard of the word.  Here's how to disable: http:\/\/t.co\/MkmGhlWGW8",
  "id" : 587305088068235265,
  "created_at" : "2015-04-12 17:23:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donna Dickens",
      "screen_name" : "MildlyAmused",
      "indices" : [ 3, 16 ],
      "id_str" : "21219240",
      "id" : 21219240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586717757196083201",
  "text" : "RT @MildlyAmused: We thought the future would be flying cars but it's actually arguing with a motion sensor about whether or not your hands\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585833086480449536",
    "text" : "We thought the future would be flying cars but it's actually arguing with a motion sensor about whether or not your hands are in the sink.",
    "id" : 585833086480449536,
    "created_at" : "2015-04-08 15:54:26 +0000",
    "user" : {
      "name" : "Donna Dickens",
      "screen_name" : "MildlyAmused",
      "protected" : false,
      "id_str" : "21219240",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804005554582593536\/1QCLLnWr_normal.jpg",
      "id" : 21219240,
      "verified" : true
    }
  },
  "id" : 586717757196083201,
  "created_at" : "2015-04-11 02:29:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "F\u00EDona",
      "screen_name" : "FionaCuffed",
      "indices" : [ 3, 15 ],
      "id_str" : "40319403",
      "id" : 40319403
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FionaCuffed\/status\/586571279064555520\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/WD4Qs9WLqr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPrd4UWAAEEmKo.jpg",
      "id_str" : "586571275054743553",
      "id" : 586571275054743553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPrd4UWAAEEmKo.jpg",
      "sizes" : [ {
        "h" : 304,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 167,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 304,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 294,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WD4Qs9WLqr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586714528135716865",
  "text" : "RT @FionaCuffed: Baby sure does. http:\/\/t.co\/WD4Qs9WLqr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FionaCuffed\/status\/586571279064555520\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/WD4Qs9WLqr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCPrd4UWAAEEmKo.jpg",
        "id_str" : "586571275054743553",
        "id" : 586571275054743553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCPrd4UWAAEEmKo.jpg",
        "sizes" : [ {
          "h" : 304,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/WD4Qs9WLqr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586571279064555520",
    "text" : "Baby sure does. http:\/\/t.co\/WD4Qs9WLqr",
    "id" : 586571279064555520,
    "created_at" : "2015-04-10 16:47:45 +0000",
    "user" : {
      "name" : "F\u00EDona",
      "screen_name" : "FionaCuffed",
      "protected" : false,
      "id_str" : "40319403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809776560236597248\/weQQwXOg_normal.jpg",
      "id" : 40319403,
      "verified" : false
    }
  },
  "id" : 586714528135716865,
  "created_at" : "2015-04-11 02:16:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "indices" : [ 3, 10 ],
      "id_str" : "167533114",
      "id" : 167533114
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 117, 131 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retroruby",
      "indices" : [ 44, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584528258970038272",
  "text" : "RT @6ftdan: I just gave a lightning talk at #retroruby on \"Believing in others, teaching, and growing the community\" @arlingtonruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Ruby",
        "screen_name" : "arlingtonruby",
        "indices" : [ 105, 119 ],
        "id_str" : "284339167",
        "id" : 284339167
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "retroruby",
        "indices" : [ 32, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584428060843315201",
    "text" : "I just gave a lightning talk at #retroruby on \"Believing in others, teaching, and growing the community\" @arlingtonruby",
    "id" : 584428060843315201,
    "created_at" : "2015-04-04 18:51:22 +0000",
    "user" : {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "protected" : false,
      "id_str" : "167533114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000545692325\/7b2ae5a114d3cce5450f757db9007a77_normal.jpeg",
      "id" : 167533114,
      "verified" : false
    }
  },
  "id" : 584528258970038272,
  "created_at" : "2015-04-05 01:29:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tinkerer",
      "screen_name" : "neurodynamicdev",
      "indices" : [ 0, 16 ],
      "id_str" : "2450031492",
      "id" : 2450031492
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "584473029712961536",
  "geo" : { },
  "id_str" : "584473327101673473",
  "in_reply_to_user_id" : 14401983,
  "text" : "@neurodynamicdev",
  "id" : 584473327101673473,
  "in_reply_to_status_id" : 584473029712961536,
  "created_at" : "2015-04-04 21:51:14 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim M",
      "screen_name" : "tmorton",
      "indices" : [ 24, 32 ],
      "id_str" : "4766781",
      "id" : 4766781
    }, {
      "name" : "Casey Watts!",
      "screen_name" : "kyloma",
      "indices" : [ 33, 40 ],
      "id_str" : "13656282",
      "id" : 13656282
    }, {
      "name" : "Dave Aronson",
      "screen_name" : "davearonson",
      "indices" : [ 41, 53 ],
      "id_str" : "78068017",
      "id" : 78068017
    }, {
      "name" : "Dax Nikki Liz \uD83D\uDCAB\u262D \u2728",
      "screen_name" : "NikkiLizMurray",
      "indices" : [ 54, 69 ],
      "id_str" : "1351947746",
      "id" : 1351947746
    }, {
      "name" : "betsythemuffin",
      "screen_name" : "betsythemuffin",
      "indices" : [ 70, 85 ],
      "id_str" : "18904758",
      "id" : 18904758
    }, {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 86, 97 ],
      "id_str" : "520859958",
      "id" : 520859958
    }, {
      "name" : "William Atkinson",
      "screen_name" : "AtkinsWJ",
      "indices" : [ 98, 107 ],
      "id_str" : "1020186002",
      "id" : 1020186002
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/584473029712961536\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ieNYtUi9Xl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBx3Hk5WAAEAxs-.jpg",
      "id_str" : "584473023698305025",
      "id" : 584473023698305025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBx3Hk5WAAEAxs-.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ieNYtUi9Xl"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "retroruby",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584473029712961536",
  "text" : "#rubyfriends #retroruby @tmorton @kyloma @davearonson @NikkiLizMurray @betsythemuffin @cupakromer @AtkinsWJ http:\/\/t.co\/ieNYtUi9Xl",
  "id" : 584473029712961536,
  "created_at" : "2015-04-04 21:50:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RetroRuby",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584432852588175360",
  "text" : "#RetroRuby If anyone wants to continue the lambda conversation after the program ends today, look for me, we can use a classrom (prob. 120).",
  "id" : 584432852588175360,
  "created_at" : "2015-04-04 19:10:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim M",
      "screen_name" : "tmorton",
      "indices" : [ 5, 13 ],
      "id_str" : "4766781",
      "id" : 4766781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retroruby",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584429947709759493",
  "text" : "Said @tmorton at #retroruby: \"If someone complains about your code 10 years after you wrote it, you've succeeded wildly.\"  Heh.",
  "id" : 584429947709759493,
  "created_at" : "2015-04-04 18:58:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retroruby",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/5w4WaJHPe3",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas-functional-conf-bangalore-oct-2014",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/01zB4YfmCL",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nGEy-vFJCSE",
      "display_url" : "youtube.com\/watch?v=nGEy-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "584429705606123520",
  "text" : "#retroruby My Ruby Lambdas slide presentation is available at https:\/\/t.co\/5w4WaJHPe3. India pres. video at https:\/\/t.co\/01zB4YfmCL.",
  "id" : 584429705606123520,
  "created_at" : "2015-04-04 18:57:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]