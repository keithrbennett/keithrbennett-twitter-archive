Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "git",
      "indices" : [ 68, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30828431834877952",
  "text" : "Great instructions on setting up p4merge, great diff\/merge tool for #git (p4merge) at http:\/\/www.andymcintosh.com\/?p=33.",
  "id" : 30828431834877952,
  "created_at" : "2011-01-28 03:24:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28929971577683968",
  "geo" : { },
  "id_str" : "28991861624406016",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Thanks for pointing me to http:\/\/zenhabits.net\/.",
  "id" : 28991861624406016,
  "in_reply_to_status_id" : 28929971577683968,
  "created_at" : "2011-01-23 01:46:13 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28986314661564416",
  "text" : "Dragged my butt to the gym, telling myself just do 10 minutes.  Stayed for 2 hours.  Feel better. Victory over winter slump today.",
  "id" : 28986314661564416,
  "created_at" : "2011-01-23 01:24:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Barry",
      "screen_name" : "pjb3",
      "indices" : [ 0, 5 ],
      "id_str" : "14306648",
      "id" : 14306648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28899781879271424",
  "geo" : { },
  "id_str" : "28899977543553024",
  "in_reply_to_user_id" : 14306648,
  "text" : "@pjb3 Maybe mint.com won't  be free forever?  (Pivotal Tracker)",
  "id" : 28899977543553024,
  "in_reply_to_status_id" : 28899781879271424,
  "created_at" : "2011-01-22 19:41:06 +0000",
  "in_reply_to_screen_name" : "pjb3",
  "in_reply_to_user_id_str" : "14306648",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28517329499324416",
  "geo" : { },
  "id_str" : "28858839147225089",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight  Check out this inexpensive and excellent Aerobie coffee\/espresso maker:  http:\/\/tinyurl.com\/4anejvb",
  "id" : 28858839147225089,
  "in_reply_to_status_id" : 28517329499324416,
  "created_at" : "2011-01-22 16:57:38 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28844297415557120",
  "text" : "4 minute Rube Goldberg-esque video at  http:\/\/tinyurl.com\/48l843x.",
  "id" : 28844297415557120,
  "created_at" : "2011-01-22 15:59:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "profound",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26490375434670080",
  "text" : "RT @nashjain: Top 10 Mistakes in Behavior Change http:\/\/slidesha.re\/gq3czy #profound!",
  "id" : 26490375434670080,
  "created_at" : "2011-01-16 04:06:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24161160760655872",
  "text" : "I meant \" *I* recommend http:\/\/tinyurl.com\/27m2cd5 if intrstd.\"",
  "id" : 24161160760655872,
  "created_at" : "2011-01-09 17:50:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24154360468475904",
  "text" : "Woohoo! bought 1 yr Economist sub, $49 @ http:\/\/tinyurl.com\/29sxoo8, incl. article audios.  Recommend http:\/\/tinyurl.com\/27m2cd5 if intrstd.",
  "id" : 24154360468475904,
  "created_at" : "2011-01-09 17:23:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 3, 11 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24152255980634113",
  "text" : "RT @timbray: Heart-warming news out of the Middle East? Yes, it can happen: http:\/\/is.gd\/koZF1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "23939762465280000",
    "text" : "Heart-warming news out of the Middle East? Yes, it can happen: http:\/\/is.gd\/koZF1",
    "id" : 23939762465280000,
    "created_at" : "2011-01-09 03:10:58 +0000",
    "user" : {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "protected" : false,
      "id_str" : "1235521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421637246\/Tim_normal.jpg",
      "id" : 1235521,
      "verified" : true
    }
  },
  "id" : 24152255980634113,
  "created_at" : "2011-01-09 17:15:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "indices" : [ 3, 12 ],
      "id_str" : "20173708",
      "id" : 20173708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24149731827523585",
  "text" : "RT @adomokos: Reading \"Bash to Z Shell\" http:\/\/www.bash2zsh.com\/ - Need to brush up on my shell scripting skills.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "23865983244439552",
    "text" : "Reading \"Bash to Z Shell\" http:\/\/www.bash2zsh.com\/ - Need to brush up on my shell scripting skills.",
    "id" : 23865983244439552,
    "created_at" : "2011-01-08 22:17:48 +0000",
    "user" : {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "protected" : false,
      "id_str" : "20173708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1660852491\/adomokos_bw_normal.png",
      "id" : 20173708,
      "verified" : false
    }
  },
  "id" : 24149731827523585,
  "created_at" : "2011-01-09 17:05:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]