Grailbird.data.tweets_2010_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "15559596278",
  "geo" : { },
  "id_str" : "15629283189",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja There are Paneras in Queens, though none near subway stations.  Queens is NYC too. ;)",
  "id" : 15629283189,
  "in_reply_to_status_id" : 15559596278,
  "created_at" : "2010-06-07 00:00:00 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]