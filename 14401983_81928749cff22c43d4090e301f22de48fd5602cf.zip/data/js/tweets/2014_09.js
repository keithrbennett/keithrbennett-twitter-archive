Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/cREt4GR4Bm",
      "expanded_url" : "https:\/\/github.com\/osxfuse\/osxfuse\/wiki\/SSHFS",
      "display_url" : "github.com\/osxfuse\/osxfus\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516691122077577216",
  "text" : "Wow, this is going to humongously simplify my work.  SSHFS mounts an ssh-accessible host onto my local filesystem: https:\/\/t.co\/cREt4GR4Bm",
  "id" : 516691122077577216,
  "created_at" : "2014-09-29 20:48:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/biv5eytwBG",
      "expanded_url" : "http:\/\/www.eventbrite.com\/e\/develop-hampton-roads-hackathon-registration-13022184705",
      "display_url" : "eventbrite.com\/e\/develop-hamp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516678209195507712",
  "text" : "Hampton Roads, Virginia is having a Code for America hackathon Thursday &amp; Friday, Oct. 16-17. http:\/\/t.co\/biv5eytwBG",
  "id" : 516678209195507712,
  "created_at" : "2014-09-29 19:57:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516358782205820928",
  "text" : "I have found the center of the universe, and it is Brooklyn. ;)",
  "id" : 516358782205820928,
  "created_at" : "2014-09-28 22:48:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516358576231940097",
  "text" : "Going home from NYC I drove city streets through Brooklyn from the Queens border to the Verrazano Bridge.  So much vitality, so many people.",
  "id" : 516358576231940097,
  "created_at" : "2014-09-28 22:47:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pup",
      "screen_name" : "duckinator",
      "indices" : [ 3, 14 ],
      "id_str" : "28650670",
      "id" : 28650670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515702215479398401",
  "text" : "RT @duckinator: Dear software developers,\n\nIt is okay to have blank lines in your source code.\n\nI promise.\n\nWe aren't running low.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515685412862705664",
    "text" : "Dear software developers,\n\nIt is okay to have blank lines in your source code.\n\nI promise.\n\nWe aren't running low.",
    "id" : 515685412862705664,
    "created_at" : "2014-09-27 02:12:38 +0000",
    "user" : {
      "name" : "pup",
      "screen_name" : "duckinator",
      "protected" : false,
      "id_str" : "28650670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795767414231277568\/UtahY5Yy_normal.jpg",
      "id" : 28650670,
      "verified" : false
    }
  },
  "id" : 515702215479398401,
  "created_at" : "2014-09-27 03:19:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacob Goldstein",
      "screen_name" : "jacobgoldstein",
      "indices" : [ 3, 18 ],
      "id_str" : "16303211",
      "id" : 16303211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515505942679810048",
  "text" : "RT @jacobgoldstein: \"orangutans...developed a habit of stealing canoes, paddling them downriver, and abandoning them at thr destinations\" h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/coXe49tYf0",
        "expanded_url" : "http:\/\/nyr.kr\/1ujBtmM",
        "display_url" : "nyr.kr\/1ujBtmM"
      } ]
    },
    "geo" : { },
    "id_str" : "513017523038846978",
    "text" : "\"orangutans...developed a habit of stealing canoes, paddling them downriver, and abandoning them at thr destinations\" http:\/\/t.co\/coXe49tYf0",
    "id" : 513017523038846978,
    "created_at" : "2014-09-19 17:31:23 +0000",
    "user" : {
      "name" : "Jacob Goldstein",
      "screen_name" : "jacobgoldstein",
      "protected" : false,
      "id_str" : "16303211",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484366892652437505\/wbT4oMkt_normal.jpeg",
      "id" : 16303211,
      "verified" : false
    }
  },
  "id" : 515505942679810048,
  "created_at" : "2014-09-26 14:19:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "cubiclegraffiti",
      "screen_name" : "cubiclegraffiti",
      "indices" : [ 53, 69 ],
      "id_str" : "858921008",
      "id" : 858921008
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513448421907496961",
  "geo" : { },
  "id_str" : "515195787475947521",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Sorry, that should have been an '@'.  @cubiclegraffiti",
  "id" : 515195787475947521,
  "in_reply_to_status_id" : 513448421907496961,
  "created_at" : "2014-09-25 17:47:02 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/yRh6KvOw8y",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/JHixeIr_6BM?rel=0&autoplay=1&iv_load_policy=3",
      "display_url" : "youtube.com\/embed\/JHixeIr_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513772131642245122",
  "text" : "Excellent\/creative way to make a point we all need to heed. Theater tells patrons to leave their mobile phones *on*. https:\/\/t.co\/yRh6KvOw8y",
  "id" : 513772131642245122,
  "created_at" : "2014-09-21 19:29:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/513448421907496961\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lcAu3fnB80",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByAinPXCcAAaZ1r.jpg",
      "id_str" : "513448415053639680",
      "id" : 513448415053639680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByAinPXCcAAaZ1r.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/lcAu3fnB80"
    } ],
    "hashtags" : [ {
      "text" : "beconf",
      "indices" : [ 35, 42 ]
    }, {
      "text" : "cubiclegraffiti",
      "indices" : [ 44, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513448421907496961",
  "text" : "Thank you for another year's great #beconf, #cubiclegraffiti and company! (Photo of session board attached.) http:\/\/t.co\/lcAu3fnB80",
  "id" : 513448421907496961,
  "created_at" : "2014-09-20 22:03:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "becamp",
      "indices" : [ 6, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513397906020515840",
  "text" : "OH at #becamp: \"The bus factor is zero because *nobody* knows how the code works.\"",
  "id" : 513397906020515840,
  "created_at" : "2014-09-20 18:42:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "becamp",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513320825538482176",
  "text" : "Today I'll be at #becamp, Charlottesville's super excellent annual open space conference.",
  "id" : 513320825538482176,
  "created_at" : "2014-09-20 13:36:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 3, 8 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "strangeloop",
      "indices" : [ 37, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513048279274512384",
  "text" : "RT @_ZPH: Language authors abound at #strangeloop, it\u2019s wonderful &amp; they\u2019re all engaged and humble.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "strangeloop",
        "indices" : [ 27, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513015993677787136",
    "text" : "Language authors abound at #strangeloop, it\u2019s wonderful &amp; they\u2019re all engaged and humble.",
    "id" : 513015993677787136,
    "created_at" : "2014-09-19 17:25:18 +0000",
    "user" : {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "protected" : true,
      "id_str" : "737649619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684598254613364738\/foWoE2fB_normal.jpg",
      "id" : 737649619,
      "verified" : false
    }
  },
  "id" : 513048279274512384,
  "created_at" : "2014-09-19 19:33:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 1, 8 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/sSt3EW4jUf",
      "expanded_url" : "http:\/\/choosealicense.com\/",
      "display_url" : "choosealicense.com"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iQOrf7XSIX",
      "expanded_url" : "http:\/\/choosealicense.com\/licenses\/",
      "display_url" : "choosealicense.com\/licenses\/"
    } ]
  },
  "geo" : { },
  "id_str" : "512991173523558400",
  "text" : ".@github Thanks for the great site comparing open source licenses: http:\/\/t.co\/sSt3EW4jUf and detail page  http:\/\/t.co\/iQOrf7XSIX.",
  "id" : 512991173523558400,
  "created_at" : "2014-09-19 15:46:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/lVtHC4sE2v",
      "expanded_url" : "http:\/\/www.costco.com\/CatalogSearch?langId=-1&storeId=10301&catalogId=10701&keyword=HONSEPT14&sortBy=PriceMax|1&EMID=B2C_2014_0918_Special_Solo_office",
      "display_url" : "costco.com\/CatalogSearch?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512824655246159872",
  "text" : "Organize your home office! Costco sale on high quality Hon file cabinets, incl. 4 drawer for $165: http:\/\/t.co\/lVtHC4sE2v",
  "id" : 512824655246159872,
  "created_at" : "2014-09-19 04:45:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Xxn1bNT0c6",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/events\/scotland-decides\/results",
      "display_url" : "bbc.com\/news\/events\/sc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512803083089231872",
  "text" : "RT @headius: Watch the Scottish independence referendum results live, thanks to JRuby :-) http:\/\/t.co\/Xxn1bNT0c6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Xxn1bNT0c6",
        "expanded_url" : "http:\/\/www.bbc.com\/news\/events\/scotland-decides\/results",
        "display_url" : "bbc.com\/news\/events\/sc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512763328511238144",
    "text" : "Watch the Scottish independence referendum results live, thanks to JRuby :-) http:\/\/t.co\/Xxn1bNT0c6",
    "id" : 512763328511238144,
    "created_at" : "2014-09-19 00:41:18 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736361495756480513\/U0H_Wfk4_normal.jpg",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 512803083089231872,
  "created_at" : "2014-09-19 03:19:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500489009785995264",
  "geo" : { },
  "id_str" : "512602992630304768",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH Sorry, somehow I just saw this tweet for the first time.  Yes, I look forward to it.  What's Island.gem?",
  "id" : 512602992630304768,
  "in_reply_to_status_id" : 500489009785995264,
  "created_at" : "2014-09-18 14:04:11 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fernando Perez",
      "screen_name" : "fperez_org",
      "indices" : [ 0, 11 ],
      "id_str" : "244991150",
      "id" : 244991150
    }, {
      "name" : "IPython Developers",
      "screen_name" : "IPythonDev",
      "indices" : [ 12, 23 ],
      "id_str" : "860076704",
      "id" : 860076704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512450067803160576",
  "geo" : { },
  "id_str" : "512461181475647488",
  "in_reply_to_user_id" : 244991150,
  "text" : "@fperez_org @IPythonDev My apologies.  I wish I had known about it then.",
  "id" : 512461181475647488,
  "in_reply_to_status_id" : 512450067803160576,
  "created_at" : "2014-09-18 04:40:41 +0000",
  "in_reply_to_screen_name" : "fperez_org",
  "in_reply_to_user_id_str" : "244991150",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IPython Developers",
      "screen_name" : "IPythonDev",
      "indices" : [ 97, 108 ],
      "id_str" : "860076704",
      "id" : 860076704
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/US7BhOmAgT",
      "expanded_url" : "http:\/\/ipython.org\/",
      "display_url" : "ipython.org"
    } ]
  },
  "geo" : { },
  "id_str" : "512348613607817218",
  "text" : "TIL The Python world now has a much better REPL than when I used Python last about 10 years ago: @IPythonDev http:\/\/t.co\/US7BhOmAgT",
  "id" : 512348613607817218,
  "created_at" : "2014-09-17 21:13:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barcamp Chiang Mai",
      "screen_name" : "barcampcm",
      "indices" : [ 94, 104 ],
      "id_str" : "54895666",
      "id" : 54895666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Jhoui3xwF4",
      "expanded_url" : "http:\/\/barcampchiangmai.org",
      "display_url" : "barcampchiangmai.org"
    } ]
  },
  "geo" : { },
  "id_str" : "511730773385555968",
  "text" : "Woohoo!  My schedule was just right for me to make Barcamp Chiang Mai next month!  Thank you, @barcampcm! http:\/\/t.co\/Jhoui3xwF4",
  "id" : 511730773385555968,
  "created_at" : "2014-09-16 04:18:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511556532384063488",
  "text" : "Forgot to start a new git branch? My favorite solution: git stash; git stash branch my-new-branch",
  "id" : 511556532384063488,
  "created_at" : "2014-09-15 16:45:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 46, 53 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/mqgWStKGq9",
      "expanded_url" : "http:\/\/functionalconf.com\/",
      "display_url" : "functionalconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "511368819760443392",
  "text" : "If you can get to Bangalore in early October, @FuConf looks really interesting.  I'll be speaking on Ruby Lambdas. http:\/\/t.co\/mqgWStKGq9",
  "id" : 511368819760443392,
  "created_at" : "2014-09-15 04:20:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "L54",
      "indices" : [ 16, 20 ]
    }, {
      "text" : "github",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/sbaX5LJC9g",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/collections\/collection_access.rb#L54-56",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510456645424787457",
  "text" : "TIL you can add #L54-56 to the end of a Github file URL to see lines 54-56 highlighted, e.g. https:\/\/t.co\/sbaX5LJC9g. #github",
  "id" : 510456645424787457,
  "created_at" : "2014-09-12 15:55:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 0, 8 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "507434743294877696",
  "geo" : { },
  "id_str" : "507530590384840704",
  "in_reply_to_user_id" : 11374142,
  "text" : "@bphogan Also, I suggest using the 'os' gem to determine the OS that's running.",
  "id" : 507530590384840704,
  "in_reply_to_status_id" : 507434743294877696,
  "created_at" : "2014-09-04 14:08:16 +0000",
  "in_reply_to_screen_name" : "bphogan",
  "in_reply_to_user_id_str" : "11374142",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "indices" : [ 3, 11 ],
      "id_str" : "11374142",
      "id" : 11374142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507530280417378305",
  "text" : "RT @bphogan: On OSX? Use `pbcopy` from Ruby:\n\nyour_text = \u201CHello world\u201D\nIO.popen('pbcopy', 'w') \u007B |f| f &lt;&lt; your_text \u007D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507434743294877696",
    "text" : "On OSX? Use `pbcopy` from Ruby:\n\nyour_text = \u201CHello world\u201D\nIO.popen('pbcopy', 'w') \u007B |f| f &lt;&lt; your_text \u007D",
    "id" : 507434743294877696,
    "created_at" : "2014-09-04 07:47:25 +0000",
    "user" : {
      "name" : "Brian P. Hogan",
      "screen_name" : "bphogan",
      "protected" : false,
      "id_str" : "11374142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734785459373498368\/uNTsAMkF_normal.jpg",
      "id" : 11374142,
      "verified" : false
    }
  },
  "id" : 507530280417378305,
  "created_at" : "2014-09-04 14:07:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linuxjournal",
      "screen_name" : "linuxjournal",
      "indices" : [ 0, 13 ],
      "id_str" : "9799222",
      "id" : 9799222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "huh",
      "indices" : [ 131, 135 ]
    }, {
      "text" : "wtf",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506487011684126720",
  "geo" : { },
  "id_str" : "506487153938153474",
  "in_reply_to_user_id" : 14401983,
  "text" : "@linuxjournal Strange that a tech magazine publisher would not see value in issue file names that include the month\/year of issue. #huh #wtf",
  "id" : 506487153938153474,
  "in_reply_to_status_id" : 506487011684126720,
  "created_at" : "2014-09-01 17:02:02 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linuxjournal",
      "screen_name" : "linuxjournal",
      "indices" : [ 0, 13 ],
      "id_str" : "9799222",
      "id" : 9799222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484362813788663808",
  "geo" : { },
  "id_str" : "506487011684126720",
  "in_reply_to_user_id" : 9799222,
  "text" : "@linuxjournal No month\/year in this month's Linux Journal issue file name either.",
  "id" : 506487011684126720,
  "in_reply_to_status_id" : 484362813788663808,
  "created_at" : "2014-09-01 17:01:28 +0000",
  "in_reply_to_screen_name" : "linuxjournal",
  "in_reply_to_user_id_str" : "9799222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]