Grailbird.data.tweets_2016_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rodney Perez",
      "screen_name" : "Rodney_Perez",
      "indices" : [ 1, 14 ],
      "id_str" : "338905620",
      "id" : 338905620
    }, {
      "name" : "Javier Perez",
      "screen_name" : "TweetsbyJavi",
      "indices" : [ 21, 34 ],
      "id_str" : "2788220688",
      "id" : 2788220688
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/771193054401138688\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/5Z5nYZC7nd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CrPT-niUEAEARTc.jpg",
      "id_str" : "771193033928740865",
      "id" : 771193033928740865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CrPT-niUEAEARTc.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/5Z5nYZC7nd"
    } ],
    "hashtags" : [ {
      "text" : "elixirconf",
      "indices" : [ 39, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "771193054401138688",
  "text" : ".@rodney_perez &amp; @TweetsbyJavi at  #elixirconf karaoke at Kimono's in Orlando. Let's do it again tomorrow! https:\/\/t.co\/5Z5nYZC7nd",
  "id" : 771193054401138688,
  "created_at" : "2016-09-01 03:48:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769032601185218560",
  "geo" : { },
  "id_str" : "769032972871864320",
  "in_reply_to_user_id" : 14401983,
  "text" : "@evanphx @raganwald it doesn't matter whether the break is executed or not. That line never results in breaking out of the outer loop.",
  "id" : 769032972871864320,
  "in_reply_to_status_id" : 769032601185218560,
  "created_at" : "2016-08-26 04:45:23 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "769031473722712064",
  "geo" : { },
  "id_str" : "769032601185218560",
  "in_reply_to_user_id" : 14401983,
  "text" : "@evanphx @raganwald i.e. the break breaks out of the `until` loop, not the enclosing `loop` loop. Since nothing else is in that inner loop,",
  "id" : 769032601185218560,
  "in_reply_to_status_id" : 769031473722712064,
  "created_at" : "2016-08-26 04:43:54 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768906501624737793",
  "geo" : { },
  "id_str" : "769031473722712064",
  "in_reply_to_user_id" : 14401983,
  "text" : "@evanphx @raganwald In 'break until foo()', a loop is created apart from any enclosing loop.  That inner loop is broken or not to no effect.",
  "id" : 769031473722712064,
  "in_reply_to_status_id" : 768906501624737793,
  "created_at" : "2016-08-26 04:39:25 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768954122636709888",
  "geo" : { },
  "id_str" : "768981453900161024",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @raganwald Yeah, but that's the worst kind. Unintended but doesn't gen. an error so you don't know it's wrong unless it's tested.",
  "id" : 768981453900161024,
  "in_reply_to_status_id" : 768954122636709888,
  "created_at" : "2016-08-26 01:20:40 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    }, {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 11, 19 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768913052359987200",
  "geo" : { },
  "id_str" : "768946352239718400",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald @evanphx Are you sure? Did you put something like a print in the loop to see how many times it iterated?",
  "id" : 768946352239718400,
  "in_reply_to_status_id" : 768913052359987200,
  "created_at" : "2016-08-25 23:01:11 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/VHduiO7gaK",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/4a36710e9e9ce1b52b1fe9f791b2957d",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "768907548657233921",
  "geo" : { },
  "id_str" : "768910031093772289",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @raganwald But that isn't what I observed when I hard coded false, it never ended: https:\/\/t.co\/VHduiO7gaK",
  "id" : 768910031093772289,
  "in_reply_to_status_id" : 768907548657233921,
  "created_at" : "2016-08-25 20:36:51 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 79, 89 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "768861463293243393",
  "geo" : { },
  "id_str" : "768907147002249216",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx I think your interpretation would require an `if` or `unless`, no? cc @raganwald",
  "id" : 768907147002249216,
  "in_reply_to_status_id" : 768861463293243393,
  "created_at" : "2016-08-25 20:25:24 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 9, 19 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VHduiO7gaK",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/4a36710e9e9ce1b52b1fe9f791b2957d",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "768861463293243393",
  "geo" : { },
  "id_str" : "768906501624737793",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @raganwald One might think that, but my loops never end whether 'until true' or 'until false' (see https:\/\/t.co\/VHduiO7gaK).",
  "id" : 768906501624737793,
  "in_reply_to_status_id" : 768861463293243393,
  "created_at" : "2016-08-25 20:22:50 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyKaigi",
      "screen_name" : "rubykaigi",
      "indices" : [ 39, 49 ],
      "id_str" : "13346162",
      "id" : 13346162
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaigi",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "768494219036065792",
  "text" : "Sadly I will not be able to make it to @rubykaigi. Anyone interested in buying my registration for US$100? They are ok with this. #rubykaigi",
  "id" : 768494219036065792,
  "created_at" : "2016-08-24 17:04:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 0, 16 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767051314849275904",
  "geo" : { },
  "id_str" : "767839181108240384",
  "in_reply_to_user_id" : 3959977216,
  "text" : "@abstractionscon No offense to my fellow humans, but I'm really sorry I had to miss those dogs!",
  "id" : 767839181108240384,
  "in_reply_to_status_id" : 767051314849275904,
  "created_at" : "2016-08-22 21:41:41 +0000",
  "in_reply_to_screen_name" : "abstractionscon",
  "in_reply_to_user_id_str" : "3959977216",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    }, {
      "name" : "Mario Vilas",
      "screen_name" : "MarioVilas",
      "indices" : [ 8, 19 ],
      "id_str" : "37139784",
      "id" : 37139784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767100515075387392",
  "geo" : { },
  "id_str" : "767366498633539584",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse @MarioVilas But for me the most persuasive reason to convert to metric is *to join the rest of the world*.",
  "id" : 767366498633539584,
  "in_reply_to_status_id" : 767100515075387392,
  "created_at" : "2016-08-21 14:23:24 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    }, {
      "name" : "Mario Vilas",
      "screen_name" : "MarioVilas",
      "indices" : [ 8, 19 ],
      "id_str" : "37139784",
      "id" : 37139784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "767100515075387392",
  "geo" : { },
  "id_str" : "767366225303330816",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse @MarioVilas  Much less to remember\/look up, enabling better understanding of &amp; focus on the problem, not the rate.  It's a UX thing.",
  "id" : 767366225303330816,
  "in_reply_to_status_id" : 767100515075387392,
  "created_at" : "2016-08-21 14:22:19 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Estrada",
      "screen_name" : "hugoestr",
      "indices" : [ 0, 9 ],
      "id_str" : "33578369",
      "id" : 33578369
    }, {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 10, 26 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 27, 34 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766444382501294081",
  "geo" : { },
  "id_str" : "767056420655202305",
  "in_reply_to_user_id" : 33578369,
  "text" : "@hugoestr @abstractionscon @bryanl Diverse subjects, including the use of bots at Digital Ocean to simplify workflow, and helping teammates.",
  "id" : 767056420655202305,
  "in_reply_to_status_id" : 766444382501294081,
  "created_at" : "2016-08-20 17:51:16 +0000",
  "in_reply_to_screen_name" : "hugoestr",
  "in_reply_to_user_id_str" : "33578369",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 74, 90 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "4moms",
      "screen_name" : "4moms",
      "indices" : [ 110, 116 ],
      "id_str" : "30026404",
      "id" : 30026404
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766836359181045760\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/BgBltooghw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqRZl6XWcAAlq-r.jpg",
      "id_str" : "766836344417054720",
      "id" : 766836344417054720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqRZl6XWcAAlq-r.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/BgBltooghw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766836359181045760",
  "text" : "Sadly, all good parties must end. Grand finale Total Eclipse of My Heart. @abstractionscon Best. Party. Ever. @4moms https:\/\/t.co\/BgBltooghw",
  "id" : 766836359181045760,
  "created_at" : "2016-08-20 03:16:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 25, 41 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766823288798674944\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/VmJ4FXZW2A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqRNtXXWIAARGZM.jpg",
      "id_str" : "766823278321213440",
      "id" : 766823278321213440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqRNtXXWIAARGZM.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VmJ4FXZW2A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766823288798674944",
  "text" : "Bottle cap soccer at the @abstractionscon karaoke party. A game of extreme skill. Hopefully. https:\/\/t.co\/VmJ4FXZW2A",
  "id" : 766823288798674944,
  "created_at" : "2016-08-20 02:24:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4moms",
      "screen_name" : "4moms",
      "indices" : [ 23, 29 ],
      "id_str" : "30026404",
      "id" : 30026404
    }, {
      "name" : "Abstractions",
      "screen_name" : "Abstractions",
      "indices" : [ 74, 87 ],
      "id_str" : "405045144",
      "id" : 405045144
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766818016726310912\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/tFC3NmPE84",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqRI6bOWEAAPxnd.jpg",
      "id_str" : "766818005137362944",
      "id" : 766818005137362944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqRI6bOWEAAPxnd.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tFC3NmPE84"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766818016726310912",
  "text" : "Stunning view from the @4moms office in Pittsburgh where we're having our @abstractions karaoke party. https:\/\/t.co\/tFC3NmPE84",
  "id" : 766818016726310912,
  "created_at" : "2016-08-20 02:03:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ThisIsNotNormal",
      "screen_name" : "schneems",
      "indices" : [ 0, 9 ],
      "id_str" : "23621187",
      "id" : 23621187
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766806838511669248",
  "geo" : { },
  "id_str" : "766808291284516864",
  "in_reply_to_user_id" : 23621187,
  "text" : "@schneems Already sang He Ain't Heavy. Next is My Girl, then maybe duet of Unforgettable &amp; if there's time Lean OnMe.",
  "id" : 766808291284516864,
  "in_reply_to_status_id" : 766806838511669248,
  "created_at" : "2016-08-20 01:25:17 +0000",
  "in_reply_to_screen_name" : "schneems",
  "in_reply_to_user_id_str" : "23621187",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 15, 31 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "Kelauni J.",
      "screen_name" : "Kelauni_J",
      "indices" : [ 82, 92 ],
      "id_str" : "130985182",
      "id" : 130985182
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766806424655716353\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/KhtdRkf1JP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqQ-XYsWcAAfsf_.jpg",
      "id_str" : "766806408046211072",
      "id" : 766806408046211072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqQ-XYsWcAAfsf_.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/KhtdRkf1JP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766806424655716353",
  "text" : "Great times at @abstractionscon karaoke in Pittsburgh. So many great singers like @Kelauni_J  here. https:\/\/t.co\/KhtdRkf1JP",
  "id" : 766806424655716353,
  "created_at" : "2016-08-20 01:17:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 1, 17 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 18, 29 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abstractionscon",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766721095663747073",
  "geo" : { },
  "id_str" : "766793672864169984",
  "in_reply_to_user_id" : 14401983,
  "text" : ".@abstractionscon @tenderlove Entrance is on the river side of the 4Moms building. We're on the 10th floor. #abstractionscon",
  "id" : 766793672864169984,
  "in_reply_to_status_id" : 766721095663747073,
  "created_at" : "2016-08-20 00:27:12 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 1, 17 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 90, 101 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766721095663747073",
  "text" : ".@abstractionscon , karaoke is at 4Moms, 912 Fort Duquesne Blvd, at 7:00-9:00+, right? cc @tenderlove",
  "id" : 766721095663747073,
  "created_at" : "2016-08-19 19:38:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 19, 35 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    }, {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 68, 75 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766335299416973313",
  "text" : "1 reason I came to @abstractionscon was to hear the always-engaging @bryanl speak. Up at 4:15 - Embracing Your Pending Obsolescence.",
  "id" : 766335299416973313,
  "created_at" : "2016-08-18 18:05:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allie_p",
      "screen_name" : "allie_p",
      "indices" : [ 62, 70 ],
      "id_str" : "15954702",
      "id" : 15954702
    }, {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 110, 126 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766333160665808897",
  "text" : "Informative and interesting presentation by our own DC area's @allie_p about BDD (baby driven development) at @abstractionscon.",
  "id" : 766333160665808897,
  "created_at" : "2016-08-18 17:57:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766322023769468929\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/U11mDjd6ux",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqKFy_NWgAA5XzL.jpg",
      "id_str" : "766321997613793280",
      "id" : 766321997613793280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqKFy_NWgAA5XzL.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/U11mDjd6ux"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766322023769468929",
  "text" : "Wandering around downtown Pittsburgh looking for a lunch place I found the full-of-wonders Market Square. https:\/\/t.co\/U11mDjd6ux",
  "id" : 766322023769468929,
  "created_at" : "2016-08-18 17:13:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 1, 11 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elixir",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "abstractionscon",
      "indices" : [ 125, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766295102746603521",
  "text" : ".@josevalim illustrates power of 'observer' (like Mac Activity Monitor) for inspecting &amp; troubleshooting #elixir apps at #abstractionscon.",
  "id" : 766295102746603521,
  "created_at" : "2016-08-18 15:26:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "abstractionscon",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "766265117143076866",
  "geo" : { },
  "id_str" : "766271367205511168",
  "in_reply_to_user_id" : 14401983,
  "text" : "#abstractionscon  I forgot to mention that it was the famous *Cray* supercomputer.",
  "id" : 766271367205511168,
  "in_reply_to_status_id" : 766265117143076866,
  "created_at" : "2016-08-18 13:51:45 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 116, 132 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766265117143076866",
  "text" : "Joe Armstrong points out power multiples of 1975 multi-ton multimillion $ supercomputer of 1975: Raspberry Pi, 15x. @abstractionscon",
  "id" : 766265117143076866,
  "created_at" : "2016-08-18 13:26:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 32, 48 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/766260912806367233\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/8IfjLSwZ0o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CqJOOBNXEAA3NhU.jpg",
      "id_str" : "766260889356013568",
      "id" : 766260889356013568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CqJOOBNXEAA3NhU.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/8IfjLSwZ0o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "766260912806367233",
  "text" : "Joe Armstrong giving keynote at @abstractionscon . Sadly, bad audio and difficult to hear. https:\/\/t.co\/8IfjLSwZ0o",
  "id" : 766260912806367233,
  "created_at" : "2016-08-18 13:10:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765381841201213441",
  "geo" : { },
  "id_str" : "765568070588837888",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler There is so much more to say about this subject.  Happy to talk about it if you like, but Twitter is a lousy medium for that.",
  "id" : 765568070588837888,
  "in_reply_to_status_id" : 765381841201213441,
  "created_at" : "2016-08-16 15:17:06 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "765381841201213441",
  "geo" : { },
  "id_str" : "765567170952638464",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler Always sad but understandable when there is reasonable expectation of substantial suffering and little joy in their future.",
  "id" : 765567170952638464,
  "in_reply_to_status_id" : 765381841201213441,
  "created_at" : "2016-08-16 15:13:31 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/tNWWMvvt8P",
      "expanded_url" : "https:\/\/github.com\/lenazun\/working-remotely\/blob\/master\/ideas.md",
      "display_url" : "github.com\/lenazun\/workin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "763882787493572608",
  "text" : "RT @elight: This is a terrific document on working remotely! https:\/\/t.co\/tNWWMvvt8P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/tNWWMvvt8P",
        "expanded_url" : "https:\/\/github.com\/lenazun\/working-remotely\/blob\/master\/ideas.md",
        "display_url" : "github.com\/lenazun\/workin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "763831433576218624",
    "text" : "This is a terrific document on working remotely! https:\/\/t.co\/tNWWMvvt8P",
    "id" : 763831433576218624,
    "created_at" : "2016-08-11 20:16:19 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 763882787493572608,
  "created_at" : "2016-08-11 23:40:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbnb Help",
      "screen_name" : "AirbnbHelp",
      "indices" : [ 0, 11 ],
      "id_str" : "2688148651",
      "id" : 2688148651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "763437534034526209",
  "in_reply_to_user_id" : 2688148651,
  "text" : "@AirbnbHelp How can I communicate w\/a human?  Canned answers do not address my problems.",
  "id" : 763437534034526209,
  "created_at" : "2016-08-10 18:11:06 +0000",
  "in_reply_to_screen_name" : "AirbnbHelp",
  "in_reply_to_user_id_str" : "2688148651",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 1, 8 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "762773615121141761",
  "geo" : { },
  "id_str" : "762911776354611201",
  "in_reply_to_user_id" : 8864512,
  "text" : ".@marick Pet peeve of mine too.  Along w\/hidden controls that only appear when you move your mouse to a region, as in Skype Mac app.",
  "id" : 762911776354611201,
  "in_reply_to_status_id" : 762773615121141761,
  "created_at" : "2016-08-09 07:21:56 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 1, 11 ],
      "id_str" : "15067554",
      "id" : 15067554
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 80, 87 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761958543029178368",
  "text" : ".@sandimetz I recommended your POODR book to a client. It's selling for $224 on @amazon but regular price elsewhere.  What's up with that?",
  "id" : 761958543029178368,
  "created_at" : "2016-08-06 16:14:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abstractions",
      "screen_name" : "abstractionscon",
      "indices" : [ 16, 32 ],
      "id_str" : "3959977216",
      "id" : 3959977216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/BV5RyuiGrc",
      "expanded_url" : "https:\/\/www.showclix.com\/event\/abstractions",
      "display_url" : "showclix.com\/event\/abstract\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "761723980570963968",
  "text" : "Great lineup at @abstractionscon conf in Pittsburgh Aug 18-20. If you go, pls use coupon 486ca04f06 for 10% off @ https:\/\/t.co\/BV5RyuiGrc",
  "id" : 761723980570963968,
  "created_at" : "2016-08-06 00:42:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "761427878701436928",
  "text" : "Thinking it would be nice to reconnect with a good friend from college, I googled him. I found his obituary. Don't wait like I did.",
  "id" : 761427878701436928,
  "created_at" : "2016-08-05 05:05:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 0, 14 ],
      "id_str" : "284339167",
      "id" : 284339167
    }, {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 15, 24 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/FzrY4QtLYG",
      "expanded_url" : "https:\/\/clyp.it\/hgeka401",
      "display_url" : "clyp.it\/hgeka401"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/dTDsfXirGx",
      "expanded_url" : "https:\/\/gist.githubusercontent.com\/keithrbennett\/b6a7d1c0c8653526e131012e99cba101\/raw\/0a072c941294a1032078cc25fa1ac5c5470e9eb5\/gistfile1.txt",
      "display_url" : "gist.githubusercontent.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "760977141697622016",
  "in_reply_to_user_id" : 284339167,
  "text" : "@arlingtonruby @crsexton My status re: tonight's coding meetup as a limerick: Voice: https:\/\/t.co\/FzrY4QtLYG, Text: https:\/\/t.co\/dTDsfXirGx",
  "id" : 760977141697622016,
  "created_at" : "2016-08-03 23:14:23 +0000",
  "in_reply_to_screen_name" : "arlingtonruby",
  "in_reply_to_user_id_str" : "284339167",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 12, 21 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 22, 36 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760891570249994242",
  "geo" : { },
  "id_str" : "760893337842900992",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia @crsexton @arlingtonruby Good point. ;)",
  "id" : 760893337842900992,
  "in_reply_to_status_id" : 760891570249994242,
  "created_at" : "2016-08-03 17:41:23 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "Tim M",
      "screen_name" : "tmorton",
      "indices" : [ 10, 18 ],
      "id_str" : "4766781",
      "id" : 4766781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760891146268712961",
  "geo" : { },
  "id_str" : "760893250202898432",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton @tmorton Sure, I've got stories and photos whenever you want to hear and see them.",
  "id" : 760893250202898432,
  "in_reply_to_status_id" : 760891146268712961,
  "created_at" : "2016-08-03 17:41:02 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 10, 24 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/9AUPUsIDUp",
      "expanded_url" : "http:\/\/abstractions.io\/",
      "display_url" : "abstractions.io"
    } ]
  },
  "in_reply_to_status_id_str" : "760876365486886912",
  "geo" : { },
  "id_str" : "760891605062656000",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton @arlingtonruby By the way, do you all know about https:\/\/t.co\/9AUPUsIDUp, a conf in Pittsburgh Aug 18-20? Great lineup. I'm going.",
  "id" : 760891605062656000,
  "in_reply_to_status_id" : 760876365486886912,
  "created_at" : "2016-08-03 17:34:29 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 10, 24 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760876365486886912",
  "geo" : { },
  "id_str" : "760890622559543296",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton @arlingtonruby I would love to join you guys (believe me!) :), but I only got 2 hours sleep on the redeye last night.  I'll see...",
  "id" : 760890622559543296,
  "in_reply_to_status_id" : 760876365486886912,
  "created_at" : "2016-08-03 17:30:35 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "760842163777265665",
  "text" : "Today I ended my 4-1\/2 month Asia journey and am now home. Ready to hit the ground running w\/lots to do. Open to part time work, prob. Ruby.",
  "id" : 760842163777265665,
  "created_at" : "2016-08-03 14:18:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]