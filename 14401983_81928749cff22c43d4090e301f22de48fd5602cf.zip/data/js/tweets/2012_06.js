Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/WjzNyyS9",
      "expanded_url" : "http:\/\/fairfaxcountyemergency.wordpress.com\/2012\/06\/30\/9-1-1-call-center-down-report-emergencies-to-police-or-fire-station\/",
      "display_url" : "fairfaxcountyemergency.wordpress.com\/2012\/06\/30\/9-1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "219083238054961152",
  "text" : "911 Call Center in Fairfax County, Virginia is down, call police or fire stations: http:\/\/t.co\/WjzNyyS9.  I assume the storm caused this.",
  "id" : 219083238054961152,
  "created_at" : "2012-06-30 15:01:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Tong",
      "screen_name" : "gundamwing4132",
      "indices" : [ 3, 18 ],
      "id_str" : "16287390",
      "id" : 16287390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/tp2p0eqm",
      "expanded_url" : "http:\/\/fb.me\/20ymh3Ewq",
      "display_url" : "fb.me\/20ymh3Ewq"
    } ]
  },
  "geo" : { },
  "id_str" : "218915356000002048",
  "text" : "RT @gundamwing4132: The fastest and best way of folding t-shirts. Japanese way of folding T-shirts! http:\/\/t.co\/tp2p0eqm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/tp2p0eqm",
        "expanded_url" : "http:\/\/fb.me\/20ymh3Ewq",
        "display_url" : "fb.me\/20ymh3Ewq"
      } ]
    },
    "geo" : { },
    "id_str" : "218867175354667008",
    "text" : "The fastest and best way of folding t-shirts. Japanese way of folding T-shirts! http:\/\/t.co\/tp2p0eqm",
    "id" : 218867175354667008,
    "created_at" : "2012-06-30 00:42:55 +0000",
    "user" : {
      "name" : "Jeff Tong",
      "screen_name" : "gundamwing4132",
      "protected" : false,
      "id_str" : "16287390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3667414418\/30717eb67c1ed4a1ca72c8e3ac888506_normal.jpeg",
      "id" : 16287390,
      "verified" : false
    }
  },
  "id" : 218915356000002048,
  "created_at" : "2012-06-30 03:54:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/0F5LYG6w",
      "expanded_url" : "http:\/\/html2haml.heroku.com\/",
      "display_url" : "html2haml.heroku.com"
    } ]
  },
  "geo" : { },
  "id_str" : "218820963008122882",
  "text" : "Cool HTML to HAML converter at http:\/\/t.co\/0F5LYG6w. That page also has links to JavaScript &lt;--&gt; CoffeeScript converters.",
  "id" : 218820963008122882,
  "created_at" : "2012-06-29 21:39:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Work Cities",
      "screen_name" : "nwc",
      "indices" : [ 73, 77 ],
      "id_str" : "14204194",
      "id" : 14204194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/218811551145136128\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/3mS2KiQS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Awlf8ksCEAITvQ2.jpg",
      "id_str" : "218811551149330434",
      "id" : 218811551149330434,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Awlf8ksCEAITvQ2.jpg",
      "sizes" : [ {
        "h" : 277,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 676,
        "resize" : "fit",
        "w" : 2499
      }, {
        "h" : 162,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3mS2KiQS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218811551145136128",
  "text" : "Nice to be back at coworking space New Work City after a long time away. @nwc http:\/\/t.co\/3mS2KiQS",
  "id" : 218811551145136128,
  "created_at" : "2012-06-29 21:01:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218769850338775040",
  "text" : "'rvm list known' shows which rubies are available for install by rvm; 'rvm install 1.9.3-head' will install the lastest patch of 1.9.3.",
  "id" : 218769850338775040,
  "created_at" : "2012-06-29 18:16:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217329499325464578",
  "text" : "On work Mac (OS 10.7.2), I'm given choice of XCode 4.3 or 4.1. Which is better?  I remember problems w\/a new ver, re: gcc version incompat.",
  "id" : 217329499325464578,
  "created_at" : "2012-06-25 18:52:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vim Links",
      "screen_name" : "VimLinks",
      "indices" : [ 21, 30 ],
      "id_str" : "200249685",
      "id" : 200249685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 92 ],
      "url" : "https:\/\/t.co\/kx4HOXhn",
      "expanded_url" : "https:\/\/github.com\/alevchuk\/vim-clutch",
      "display_url" : "github.com\/alevchuk\/vim-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "216930532267798530",
  "text" : "Awesome innovation! \"@VimLinks: Vim Clutch - A hardware pedal for Vim: https:\/\/t.co\/kx4HOXhn\"",
  "id" : 216930532267798530,
  "created_at" : "2012-06-24 16:27:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "practicegratitude",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216376200887676928",
  "text" : "3 hr train ride took 6 but I'm lucky tonight. The tree that fell on the tracks did so when I wasn't passing under it. #practicegratitude",
  "id" : 216376200887676928,
  "created_at" : "2012-06-23 03:44:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "216338035170738176",
  "text" : "On Amtrak train. Storm between Balt. &amp; DC caused downed power lines &amp; trees on tracks.  Don't know how long we'll be stuck in Baltimore.",
  "id" : 216338035170738176,
  "created_at" : "2012-06-23 01:13:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 0, 9 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "214775000715108352",
  "geo" : { },
  "id_str" : "214924674910523392",
  "in_reply_to_user_id" : 91333167,
  "text" : "@climagic Also, you can use ctrl-L instead of 'clear' to clear the screen.",
  "id" : 214924674910523392,
  "in_reply_to_status_id" : 214775000715108352,
  "created_at" : "2012-06-19 03:36:50 +0000",
  "in_reply_to_screen_name" : "climagic",
  "in_reply_to_user_id_str" : "91333167",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andras Kristof",
      "screen_name" : "akomba",
      "indices" : [ 19, 26 ],
      "id_str" : "18129898",
      "id" : 18129898
    }, {
      "name" : "Viki",
      "screen_name" : "Viki",
      "indices" : [ 52, 57 ],
      "id_str" : "110377642",
      "id" : 110377642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Y6ohzpg6",
      "expanded_url" : "http:\/\/yfrog.com\/nwhtcgjfj",
      "display_url" : "yfrog.com\/nwhtcgjfj"
    } ]
  },
  "geo" : { },
  "id_str" : "214920461820243968",
  "text" : "Congrats, Andras! \"@akomba: Galaxy S III comes with @viki preinstalled. Great to see our products getting exposure. http:\/\/t.co\/Y6ohzpg6\"",
  "id" : 214920461820243968,
  "created_at" : "2012-06-19 03:20:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/214455992254078976\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Kd3gzyMs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AvnmlraCIAAL4CT.jpg",
      "id_str" : "214455992258273280",
      "id" : 214455992258273280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AvnmlraCIAAL4CT.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Kd3gzyMs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "214455992254078976",
  "text" : "In New York City for my new Rails gig. Photo is, of course, Grand Central Station. http:\/\/t.co\/Kd3gzyMs",
  "id" : 214455992254078976,
  "created_at" : "2012-06-17 20:34:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/C5A6YuUR",
      "expanded_url" : "http:\/\/health.msn.com\/healthy-living\/happiness\/articlepage.aspx?cp-documentid=100282117",
      "display_url" : "health.msn.com\/healthy-living\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "213258068945944576",
  "text" : "Practice gratitude, cultivate happiness. - Mayo Clinic, http:\/\/t.co\/C5A6YuUR",
  "id" : 213258068945944576,
  "created_at" : "2012-06-14 13:14:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 7, 14 ],
      "id_str" : "17416571",
      "id" : 17416571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "211937157512822784",
  "text" : "C'mon, @airbnb, why still no one page printable invoice? And why no access to invoices from my online web account, only email?",
  "id" : 211937157512822784,
  "created_at" : "2012-06-10 21:45:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210527980794036226",
  "text" : "5 hours Chiang Mai to Seoul, 14 more hours to IAD (DC) soon. Lovin' the Incheon (Seoul) airport - free wifi, showers, and massage chairs.",
  "id" : 210527980794036226,
  "created_at" : "2012-06-07 00:25:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 108, 122 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210390679078191105",
  "text" : "RT @avdi: Wide Teams podcast #35 is up! This time, an interview from the Phillipines by field correspondent @keithrbennett http:\/\/t.co\/w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 98, 112 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/w0sdWac1",
        "expanded_url" : "http:\/\/ow.ly\/boMnQ",
        "display_url" : "ow.ly\/boMnQ"
      } ]
    },
    "geo" : { },
    "id_str" : "210381022167183362",
    "text" : "Wide Teams podcast #35 is up! This time, an interview from the Phillipines by field correspondent @keithrbennett http:\/\/t.co\/w0sdWac1",
    "id" : 210381022167183362,
    "created_at" : "2012-06-06 14:41:59 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 210390679078191105,
  "created_at" : "2012-06-06 15:20:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210354320191922177",
  "text" : "Flying home from Chiang Mai in 3 hours after a great 6 weeks in Thailand, Singapore, and Malaysia.  Regret I couldn't make the Philippines.",
  "id" : 210354320191922177,
  "created_at" : "2012-06-06 12:55:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Burns",
      "screen_name" : "rpburns",
      "indices" : [ 20, 28 ],
      "id_str" : "19177085",
      "id" : 19177085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "210353899939438592",
  "text" : "A belated thanks to @rpburns for the favor of a great JavaScript\/CoffeeScript tutorial in Chiang Mai.",
  "id" : 210353899939438592,
  "created_at" : "2012-06-06 12:54:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "209240077690339328",
  "text" : "Finished \"JS The Good Parts\".  Grim view of JS...how wise is it to use it as much as we do? How many of us limit code to the Good Parts?",
  "id" : 209240077690339328,
  "created_at" : "2012-06-03 11:08:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]