Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Van Vleet",
      "screen_name" : "Vleet",
      "indices" : [ 0, 6 ],
      "id_str" : "18730536",
      "id" : 18730536
    }, {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 7, 16 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sdtconf",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29308115178",
  "in_reply_to_user_id" : 18730536,
  "text" : "@Vleet @nashjain Thank you everyone for yet another awesome #sdtconf Simple Design and Testing Conference (http:\/\/www.sdtconf.com).",
  "id" : 29308115178,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "Vleet",
  "in_reply_to_user_id_str" : "18730536",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]