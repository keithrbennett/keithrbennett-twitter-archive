Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/LFRhAG64QN",
      "expanded_url" : "http:\/\/www.omgubuntu.co.uk\/2014\/12\/ubuntu-in-2014-news-highlights",
      "display_url" : "omgubuntu.co.uk\/2014\/12\/ubuntu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "550316463715008512",
  "text" : "RT @avdi: Wow, Ubuntu had a super boring year \nhttp:\/\/t.co\/LFRhAG64QN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/LFRhAG64QN",
        "expanded_url" : "http:\/\/www.omgubuntu.co.uk\/2014\/12\/ubuntu-in-2014-news-highlights",
        "display_url" : "omgubuntu.co.uk\/2014\/12\/ubuntu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "550295398972420097",
    "text" : "Wow, Ubuntu had a super boring year \nhttp:\/\/t.co\/LFRhAG64QN",
    "id" : 550295398972420097,
    "created_at" : "2014-12-31 14:20:21 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 550316463715008512,
  "created_at" : "2014-12-31 15:44:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/8jKoVHEsxZ",
      "expanded_url" : "https:\/\/support.mozilla.org\/en-US\/kb\/reset-firefox-easily-fix-most-problems",
      "display_url" : "support.mozilla.org\/en-US\/kb\/reset\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "548189225381015552",
  "text" : "Firefox would hang on YouTube pages, but this Reset did wonders, fixing the problem and speeding up the browser: https:\/\/t.co\/8jKoVHEsxZ",
  "id" : 548189225381015552,
  "created_at" : "2014-12-25 18:51:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/546781872928210944\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3QVdDblthF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B5aPNz8CIAApYsc.png",
      "id_str" : "546781872215171072",
      "id" : 546781872215171072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B5aPNz8CIAApYsc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 85,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 977
      }, {
        "h" : 244,
        "resize" : "fit",
        "w" : 977
      } ],
      "display_url" : "pic.twitter.com\/3QVdDblthF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546781872928210944",
  "text" : "Sometimes I play around and set my language preference to Swedish or French, but I've never seen both!!!  What the..? http:\/\/t.co\/3QVdDblthF",
  "id" : 546781872928210944,
  "created_at" : "2014-12-21 21:38:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545766965097529344",
  "text" : "If pry doesn't work to pause and get interactive in your Ruby\n code, you can use ripl: require 'ripl'; Ripl.start :binding =&gt; binding",
  "id" : 545766965097529344,
  "created_at" : "2014-12-19 02:25:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 3, 9 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Slate\/status\/543563796808466432\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/AgfYlWUhGW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4sgZKlIMAEumwV.jpg",
      "id_str" : "543563796737175553",
      "id" : 543563796737175553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4sgZKlIMAEumwV.jpg",
      "sizes" : [ {
        "h" : 346,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 207,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 568
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 568
      } ],
      "display_url" : "pic.twitter.com\/AgfYlWUhGW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/yDHiIPPZ4p",
      "expanded_url" : "http:\/\/slate.me\/1GvAgOm",
      "display_url" : "slate.me\/1GvAgOm"
    } ]
  },
  "geo" : { },
  "id_str" : "543614938548535296",
  "text" : "RT @Slate: Why food drives are a terrible idea: http:\/\/t.co\/yDHiIPPZ4p http:\/\/t.co\/AgfYlWUhGW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Slate\/status\/543563796808466432\/photo\/1",
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/AgfYlWUhGW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4sgZKlIMAEumwV.jpg",
        "id_str" : "543563796737175553",
        "id" : 543563796737175553,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4sgZKlIMAEumwV.jpg",
        "sizes" : [ {
          "h" : 346,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 568
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 568
        } ],
        "display_url" : "pic.twitter.com\/AgfYlWUhGW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/yDHiIPPZ4p",
        "expanded_url" : "http:\/\/slate.me\/1GvAgOm",
        "display_url" : "slate.me\/1GvAgOm"
      } ]
    },
    "geo" : { },
    "id_str" : "543563796808466432",
    "text" : "Why food drives are a terrible idea: http:\/\/t.co\/yDHiIPPZ4p http:\/\/t.co\/AgfYlWUhGW",
    "id" : 543563796808466432,
    "created_at" : "2014-12-13 00:31:22 +0000",
    "user" : {
      "name" : "Slate",
      "screen_name" : "Slate",
      "protected" : false,
      "id_str" : "15164565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785838392336678913\/UP9SKq0X_normal.jpg",
      "id" : 15164565,
      "verified" : true
    }
  },
  "id" : 543614938548535296,
  "created_at" : "2014-12-13 03:54:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/pjcyGXdTee",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/List_of_TCP_and_UDP_port_numbers",
      "display_url" : "en.wikipedia.org\/wiki\/List_of_T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "540914684183207936",
  "text" : "Suggestion: When you choose a port for custom\/internal use, try to use one not in this list: http:\/\/t.co\/pjcyGXdTee.",
  "id" : 540914684183207936,
  "created_at" : "2014-12-05 17:04:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540260336189067264",
  "geo" : { },
  "id_str" : "540382467954577408",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl Understandable and awful that you feel this way.  I too am outraged and saddened. Hopefully the obvious lunacy will trigger change.",
  "id" : 540382467954577408,
  "in_reply_to_status_id" : 540260336189067264,
  "created_at" : "2014-12-04 05:49:54 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "540234781636972544",
  "geo" : { },
  "id_str" : "540235744498171904",
  "in_reply_to_user_id" : 14401983,
  "text" : "Before I was pasting markdown text in a gist to preview it.  In Atom, do ctrl-shift-M on an .md file to open a preview.",
  "id" : 540235744498171904,
  "in_reply_to_status_id" : 540234781636972544,
  "created_at" : "2014-12-03 20:06:53 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yasir Saleem",
      "screen_name" : "yas2000",
      "indices" : [ 8, 16 ],
      "id_str" : "23583257",
      "id" : 23583257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/W68yMgcEtx",
      "expanded_url" : "https:\/\/atom.io\/",
      "display_url" : "atom.io"
    } ]
  },
  "geo" : { },
  "id_str" : "540234781636972544",
  "text" : "Thanks, @yas2000, for telling me about the Atom editor (https:\/\/t.co\/W68yMgcEtx). I like my editor, but Atom does Markdown preview great!",
  "id" : 540234781636972544,
  "created_at" : "2014-12-03 20:03:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baltimore",
      "indices" : [ 4, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SOHYKgPdyi",
      "expanded_url" : "http:\/\/www.meetup.com\/bmore-on-rails\/suggestion\/",
      "display_url" : "meetup.com\/bmore-on-rails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "539686120330911744",
  "text" : "The #baltimore Ruby\/Rails Meetup needs a new venue that will support 30+ people.  Any suggestions?  Send to http:\/\/t.co\/SOHYKgPdyi.",
  "id" : 539686120330911744,
  "created_at" : "2014-12-02 07:42:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 3, 14 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539499921272221696",
  "text" : "RT @RubyConfPH: CFP and early bird tickets sale end on Thursday! Don't wait until the last day to buy. Tickets are limited.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539320837992509440",
    "text" : "CFP and early bird tickets sale end on Thursday! Don't wait until the last day to buy. Tickets are limited.",
    "id" : 539320837992509440,
    "created_at" : "2014-12-01 07:31:22 +0000",
    "user" : {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "protected" : false,
      "id_str" : "1920753961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776092333389385728\/tZpJR9bc_normal.jpg",
      "id" : 1920753961,
      "verified" : false
    }
  },
  "id" : 539499921272221696,
  "created_at" : "2014-12-01 19:22:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/539487544963256320\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/VJrDi1nhQN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3ykUzaIQAETrTu.jpg",
      "id_str" : "539486732681756673",
      "id" : 539486732681756673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3ykUzaIQAETrTu.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/VJrDi1nhQN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539487544963256320",
  "text" : "On my coworker Conrad's desk. It's a coffee cup! http:\/\/t.co\/VJrDi1nhQN",
  "id" : 539487544963256320,
  "created_at" : "2014-12-01 18:33:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 1, 12 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539321015776845825",
  "text" : ".@rubytaiwan Will there be a RubyConf Taiwan in 2015?  Any idea when?",
  "id" : 539321015776845825,
  "created_at" : "2014-12-01 07:32:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]