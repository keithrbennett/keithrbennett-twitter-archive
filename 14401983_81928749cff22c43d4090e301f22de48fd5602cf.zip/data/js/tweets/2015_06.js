Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Westman",
      "screen_name" : "westmaaan",
      "indices" : [ 3, 13 ],
      "id_str" : "21426674",
      "id" : 21426674
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/westmaaan\/status\/615801407048847360\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/M7IqySo43e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIvEECOUYAERsE2.jpg",
      "id_str" : "615801347661651969",
      "id" : 615801347661651969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIvEECOUYAERsE2.jpg",
      "sizes" : [ {
        "h" : 487,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 461,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 634
      } ],
      "display_url" : "pic.twitter.com\/M7IqySo43e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615880528487677953",
  "text" : "RT @westmaaan: why did the chicken cross with fruit? http:\/\/t.co\/M7IqySo43e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/westmaaan\/status\/615801407048847360\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/M7IqySo43e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIvEECOUYAERsE2.jpg",
        "id_str" : "615801347661651969",
        "id" : 615801347661651969,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIvEECOUYAERsE2.jpg",
        "sizes" : [ {
          "h" : 487,
          "resize" : "fit",
          "w" : 634
        }, {
          "h" : 261,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 461,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 634
        } ],
        "display_url" : "pic.twitter.com\/M7IqySo43e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615801407048847360",
    "text" : "why did the chicken cross with fruit? http:\/\/t.co\/M7IqySo43e",
    "id" : 615801407048847360,
    "created_at" : "2015-06-30 08:37:51 +0000",
    "user" : {
      "name" : "Christian Westman",
      "screen_name" : "westmaaan",
      "protected" : false,
      "id_str" : "21426674",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/806175315160694784\/SOqluI4t_normal.jpg",
      "id" : 21426674,
      "verified" : false
    }
  },
  "id" : 615880528487677953,
  "created_at" : "2015-06-30 13:52:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "indices" : [ 3, 14 ],
      "id_str" : "36691457",
      "id" : 36691457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/czMWkI8iWR",
      "expanded_url" : "https:\/\/twitter.com\/dliebreich\/status\/614301141891837952",
      "display_url" : "twitter.com\/dliebreich\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614978785788739584",
  "text" : "RT @gdinwiddie: A testing mindset. https:\/\/t.co\/czMWkI8iWR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/czMWkI8iWR",
        "expanded_url" : "https:\/\/twitter.com\/dliebreich\/status\/614301141891837952",
        "display_url" : "twitter.com\/dliebreich\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "614956044830285824",
    "text" : "A testing mindset. https:\/\/t.co\/czMWkI8iWR",
    "id" : 614956044830285824,
    "created_at" : "2015-06-28 00:38:41 +0000",
    "user" : {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "protected" : false,
      "id_str" : "36691457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/492297045563023360\/0RBTAzQ0_normal.png",
      "id" : 36691457,
      "verified" : false
    }
  },
  "id" : 614978785788739584,
  "created_at" : "2015-06-28 02:09:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazing Maps",
      "screen_name" : "Amazing_Maps",
      "indices" : [ 3, 16 ],
      "id_str" : "1571270053",
      "id" : 1571270053
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Amazing_Maps\/status\/613410308636418049\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/36O6qGsru5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CINFbM4W8AAJIq5.jpg",
      "id_str" : "613410307868913664",
      "id" : 613410307868913664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINFbM4W8AAJIq5.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/36O6qGsru5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613430382319534080",
  "text" : "RT @Amazing_Maps: What's on the other side of the Earth? http:\/\/t.co\/36O6qGsru5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Amazing_Maps\/status\/613410308636418049\/photo\/1",
        "indices" : [ 39, 61 ],
        "url" : "http:\/\/t.co\/36O6qGsru5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CINFbM4W8AAJIq5.jpg",
        "id_str" : "613410307868913664",
        "id" : 613410307868913664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINFbM4W8AAJIq5.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/36O6qGsru5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613410308636418049",
    "text" : "What's on the other side of the Earth? http:\/\/t.co\/36O6qGsru5",
    "id" : 613410308636418049,
    "created_at" : "2015-06-23 18:16:28 +0000",
    "user" : {
      "name" : "Amazing Maps",
      "screen_name" : "Amazing_Maps",
      "protected" : false,
      "id_str" : "1571270053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/670261890233311232\/AI4OcoZM_normal.jpg",
      "id" : 1571270053,
      "verified" : false
    }
  },
  "id" : 613430382319534080,
  "created_at" : "2015-06-23 19:36:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/609845987822161920\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/xeapCqbEhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHabsCGUYAAv7t2.jpg",
      "id_str" : "609845980335202304",
      "id" : 609845980335202304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHabsCGUYAAv7t2.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/xeapCqbEhN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609845987822161920",
  "text" : "Sad...the Tropical Ice Cream shop in Silver Spring, MD, open since my move to this area from NYC in 1989, has closed. http:\/\/t.co\/xeapCqbEhN",
  "id" : 609845987822161920,
  "created_at" : "2015-06-13 22:13:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Godfrey Chan",
      "screen_name" : "chancancode",
      "indices" : [ 0, 12 ],
      "id_str" : "55032805",
      "id" : 55032805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "609789287496859648",
  "geo" : { },
  "id_str" : "609800721886789633",
  "in_reply_to_user_id" : 55032805,
  "text" : "@chancancode Very well done! Interesting and fun play with code.",
  "id" : 609800721886789633,
  "in_reply_to_status_id" : 609789287496859648,
  "created_at" : "2015-06-13 19:13:16 +0000",
  "in_reply_to_screen_name" : "chancancode",
  "in_reply_to_user_id_str" : "55032805",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609178583215566848",
  "text" : "@radiomorillo I read &amp; write Hangul but only know very basic Korean. But I know people. \u263A What exactly do you want to do?",
  "id" : 609178583215566848,
  "created_at" : "2015-06-12 02:01:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brown's Manassas Kia",
      "screen_name" : "brownskia",
      "indices" : [ 116, 126 ],
      "id_str" : "613617067",
      "id" : 613617067
    }, {
      "name" : "Brown's Manassas Kia",
      "screen_name" : "ManassasKia",
      "indices" : [ 127, 139 ],
      "id_str" : "814957734",
      "id" : 814957734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608137525866188800",
  "text" : "I hate it when companies I've told not to call me still call me...with robocalls! For example, Brown's Kia Manassas @brownskia @ManassasKia",
  "id" : 608137525866188800,
  "created_at" : "2015-06-09 05:04:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "indices" : [ 3, 13 ],
      "id_str" : "14770578",
      "id" : 14770578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/joewalnes\/status\/606890814648614912\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/f3ubh7nStf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwb-aWUIAAJxmR.jpg",
      "id_str" : "606890808826929152",
      "id" : 606890808826929152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwb-aWUIAAJxmR.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/f3ubh7nStf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Fi3NONYgZB",
      "expanded_url" : "https:\/\/medium.com\/@joewalnes\/handy-bash-feature-process-substitution-8eb6dce68133",
      "display_url" : "medium.com\/@joewalnes\/han\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "607052016268001280",
  "text" : "RT @joewalnes: This one weird Bash trick will make you a command line hero: https:\/\/t.co\/Fi3NONYgZB http:\/\/t.co\/f3ubh7nStf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/joewalnes\/status\/606890814648614912\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/f3ubh7nStf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwb-aWUIAAJxmR.jpg",
        "id_str" : "606890808826929152",
        "id" : 606890808826929152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwb-aWUIAAJxmR.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/f3ubh7nStf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/Fi3NONYgZB",
        "expanded_url" : "https:\/\/medium.com\/@joewalnes\/handy-bash-feature-process-substitution-8eb6dce68133",
        "display_url" : "medium.com\/@joewalnes\/han\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606890814648614912",
    "text" : "This one weird Bash trick will make you a command line hero: https:\/\/t.co\/Fi3NONYgZB http:\/\/t.co\/f3ubh7nStf",
    "id" : 606890814648614912,
    "created_at" : "2015-06-05 18:30:20 +0000",
    "user" : {
      "name" : "Joe Walnes",
      "screen_name" : "joewalnes",
      "protected" : false,
      "id_str" : "14770578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1947402120\/joewalnes-photo_normal.jpg",
      "id" : 14770578,
      "verified" : false
    }
  },
  "id" : 607052016268001280,
  "created_at" : "2015-06-06 05:10:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606904297205329921",
  "text" : "@radiomorillo Tekserve, 119 West 23rd Street, 212.929.3645. I just called, they're in stock and cost $19.",
  "id" : 606904297205329921,
  "created_at" : "2015-06-05 19:23:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FFmpeg",
      "screen_name" : "FFmpeg",
      "indices" : [ 7, 14 ],
      "id_str" : "1283902819",
      "id" : 1283902819
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/IB0ZfzhSLS",
      "expanded_url" : "http:\/\/breakthebit.org\/post\/53570840966\/how-to-increase-volume-in-a-video-without",
      "display_url" : "breakthebit.org\/post\/535708409\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606165587023110145",
  "text" : "I used @ffmpeg to increase the volume of a screencast MP4 file (see http:\/\/t.co\/IB0ZfzhSLS for how to do it).",
  "id" : 606165587023110145,
  "created_at" : "2015-06-03 18:28:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ffmpeg",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/IhzjbrjkLl",
      "expanded_url" : "https:\/\/www.ffmpeg.org\/",
      "display_url" : "ffmpeg.org"
    } ]
  },
  "geo" : { },
  "id_str" : "606165308391358464",
  "text" : "#ffmpeg Super useful utility to record, convert and stream audio and video (https:\/\/t.co\/IhzjbrjkLl).",
  "id" : 606165308391358464,
  "created_at" : "2015-06-03 18:27:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]