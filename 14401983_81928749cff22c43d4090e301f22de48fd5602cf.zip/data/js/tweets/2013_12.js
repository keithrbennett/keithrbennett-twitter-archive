Grailbird.data.tweets_2013_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Whalen",
      "screen_name" : "invisiblefunnel",
      "indices" : [ 0, 16 ],
      "id_str" : "131323095",
      "id" : 131323095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 49 ],
      "url" : "https:\/\/t.co\/D7J9iF71GM",
      "expanded_url" : "https:\/\/github.com\/dkubb\/equalizer",
      "display_url" : "github.com\/dkubb\/equalizer"
    } ]
  },
  "in_reply_to_status_id_str" : "417788832348520449",
  "geo" : { },
  "id_str" : "418057688426094592",
  "in_reply_to_user_id" : 131323095,
  "text" : "@invisiblefunnel Thanks!  https:\/\/t.co\/D7J9iF71GM looks like something I'll want to add to my toolkit.",
  "id" : 418057688426094592,
  "in_reply_to_status_id" : 417788832348520449,
  "created_at" : "2013-12-31 16:34:54 +0000",
  "in_reply_to_screen_name" : "invisiblefunnel",
  "in_reply_to_user_id_str" : "131323095",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ruby",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417745438612000768",
  "text" : "Another PSA (aka note to self): When implementing a #Ruby class that may be used in a hash, implement hash() and eql?().",
  "id" : 417745438612000768,
  "created_at" : "2013-12-30 19:54:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psa",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "417693114782855169",
  "text" : "When writing numeric constants in Ruby, please use _ separators, e.g. 1_000_000, 0x8000_0000.   #psa",
  "id" : 417693114782855169,
  "created_at" : "2013-12-30 16:26:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 23, 36 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OB3logYZ7P",
      "expanded_url" : "http:\/\/pragprog.com\/book\/dccar2\/build-awesome-command-line-applications-in-ruby-2",
      "display_url" : "pragprog.com\/book\/dccar2\/bu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416637894854316032",
  "text" : "Now to reread parts of @davetron5000's \"Build Awesome Command Line Applications in Ruby\" book too (see http:\/\/t.co\/OB3logYZ7P).",
  "id" : 416637894854316032,
  "created_at" : "2013-12-27 18:33:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 10, 23 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/XRqg6G4y6K",
      "expanded_url" : "http:\/\/www.naildrivin5.com\/blog\/2012\/04\/01\/the-nine-facets-of-an-awesome-command-line-app.html",
      "display_url" : "naildrivin5.com\/blog\/2012\/04\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "416637120887795712",
  "text" : "Just read @davetron5000's super excellent article at http:\/\/t.co\/XRqg6G4y6K about awesome command line apps. I'm now using his hl gem too.",
  "id" : 416637120887795712,
  "created_at" : "2013-12-27 18:30:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Foust",
      "screen_name" : "jeff_foust",
      "indices" : [ 3, 14 ],
      "id_str" : "6374602",
      "id" : 6374602
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 40, 45 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DSN50",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/c5CrdRy9Ho",
      "expanded_url" : "http:\/\/bit.ly\/19g28eW",
      "display_url" : "bit.ly\/19g28eW"
    } ]
  },
  "geo" : { },
  "id_str" : "414438414994657280",
  "text" : "RT @jeff_foust: \"We taste terrible.\" RT @NASA: If you could send a message to space, what would it say? #DSN50 \u00A0 http:\/\/t.co\/c5CrdRy9Ho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 24, 29 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DSN50",
        "indices" : [ 88, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/c5CrdRy9Ho",
        "expanded_url" : "http:\/\/bit.ly\/19g28eW",
        "display_url" : "bit.ly\/19g28eW"
      } ]
    },
    "geo" : { },
    "id_str" : "413802440820260864",
    "text" : "\"We taste terrible.\" RT @NASA: If you could send a message to space, what would it say? #DSN50 \u00A0 http:\/\/t.co\/c5CrdRy9Ho",
    "id" : 413802440820260864,
    "created_at" : "2013-12-19 22:46:04 +0000",
    "user" : {
      "name" : "Jeff Foust",
      "screen_name" : "jeff_foust",
      "protected" : false,
      "id_str" : "6374602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509029699322793984\/zWjKFe63_normal.jpeg",
      "id" : 6374602,
      "verified" : false
    }
  },
  "id" : 414438414994657280,
  "created_at" : "2013-12-21 16:53:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnar Sveen",
      "screen_name" : "magnars",
      "indices" : [ 0, 8 ],
      "id_str" : "13816362",
      "id" : 13816362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413687827365625857",
  "geo" : { },
  "id_str" : "413699461714440192",
  "in_reply_to_user_id" : 13816362,
  "text" : "@magnars  I understand that, thanks.  There's more to discuss, but IMO Twitter is a lousy medium for that discussion.",
  "id" : 413699461714440192,
  "in_reply_to_status_id" : 413687827365625857,
  "created_at" : "2013-12-19 15:56:52 +0000",
  "in_reply_to_screen_name" : "magnars",
  "in_reply_to_user_id_str" : "13816362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnar Sveen",
      "screen_name" : "magnars",
      "indices" : [ 0, 8 ],
      "id_str" : "13816362",
      "id" : 13816362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413680719102099457",
  "geo" : { },
  "id_str" : "413685652970934272",
  "in_reply_to_user_id" : 13816362,
  "text" : "@magnars Same as any other func. reorganization, change the tests. It's analagous to a public &amp; private method. Did I understand you right?",
  "id" : 413685652970934272,
  "in_reply_to_status_id" : 413680719102099457,
  "created_at" : "2013-12-19 15:02:00 +0000",
  "in_reply_to_screen_name" : "magnars",
  "in_reply_to_user_id_str" : "13816362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnar Sveen",
      "screen_name" : "magnars",
      "indices" : [ 0, 8 ],
      "id_str" : "13816362",
      "id" : 13816362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413546253516300289",
  "geo" : { },
  "id_str" : "413676602111692801",
  "in_reply_to_user_id" : 13816362,
  "text" : "@magnars Maybe, but isn't that true of any function that uses other functions? Should we religiously avoid testing func's that call others?",
  "id" : 413676602111692801,
  "in_reply_to_status_id" : 413546253516300289,
  "created_at" : "2013-12-19 14:26:02 +0000",
  "in_reply_to_screen_name" : "magnars",
  "in_reply_to_user_id_str" : "13816362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magnar Sveen",
      "screen_name" : "magnars",
      "indices" : [ 0, 8 ],
      "id_str" : "13816362",
      "id" : 13816362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "413442946210742272",
  "geo" : { },
  "id_str" : "413533945938972672",
  "in_reply_to_user_id" : 13816362,
  "text" : "@magnars For the same reason I would unit test it if it were a regular method -- to ensure correctness with different inputs.",
  "id" : 413533945938972672,
  "in_reply_to_status_id" : 413442946210742272,
  "created_at" : "2013-12-19 04:59:10 +0000",
  "in_reply_to_screen_name" : "magnars",
  "in_reply_to_user_id_str" : "13816362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "indices" : [ 3, 9 ],
      "id_str" : "14375110",
      "id" : 14375110
    }, {
      "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B sdo\u0279\u01DD\u01DDq",
      "screen_name" : "beerops",
      "indices" : [ 107, 115 ],
      "id_str" : "260044118",
      "id" : 260044118
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413391516275863553",
  "text" : "RT @fogus: Little known fact: For every Yak hair that you shave, three more will come to its funeral. (thx @beerops)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "(\u256F\u00B0\u25A1\u00B0\uFF09\u256F\uFE35 \u253B\u2501\u253B sdo\u0279\u01DD\u01DDq",
        "screen_name" : "beerops",
        "indices" : [ 96, 104 ],
        "id_str" : "260044118",
        "id" : 260044118
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "413390575136538624",
    "text" : "Little known fact: For every Yak hair that you shave, three more will come to its funeral. (thx @beerops)",
    "id" : 413390575136538624,
    "created_at" : "2013-12-18 19:29:28 +0000",
    "user" : {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "protected" : false,
      "id_str" : "14375110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536324498552012801\/asymlEs9_normal.jpeg",
      "id" : 14375110,
      "verified" : false
    }
  },
  "id" : 413391516275863553,
  "created_at" : "2013-12-18 19:33:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Myers",
      "screen_name" : "antiheroine",
      "indices" : [ 0, 12 ],
      "id_str" : "588743",
      "id" : 588743
    }, {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 13, 22 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/g9axQTU4yF",
      "expanded_url" : "http:\/\/railsgirls.com\/dc",
      "display_url" : "railsgirls.com\/dc"
    } ]
  },
  "in_reply_to_status_id_str" : "413383819404664832",
  "geo" : { },
  "id_str" : "413389709314760704",
  "in_reply_to_user_id" : 588743,
  "text" : "@antiheroine @zspencer Maybe Rails Girls DC could provide leads? http:\/\/t.co\/g9axQTU4yF",
  "id" : 413389709314760704,
  "in_reply_to_status_id" : 413383819404664832,
  "created_at" : "2013-12-18 19:26:01 +0000",
  "in_reply_to_screen_name" : "antiheroine",
  "in_reply_to_user_id_str" : "588743",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413389220774821888",
  "text" : "In other words, perhaps, we need an OO language that gives functions a stature equal to that of classes.",
  "id" : 413389220774821888,
  "created_at" : "2013-12-18 19:24:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413382007591170049",
  "text" : "Ruby lambdas assigned to local vars in a method are not visible to unit tests. We need a language that can expose them, like inner classes.",
  "id" : 413382007591170049,
  "created_at" : "2013-12-18 18:55:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "413381708273049600",
  "text" : "I wish mainstream languages had inner functions. If a method is only used by 1 method, why would I want class scope? Ruby's lambdas help but",
  "id" : 413381708273049600,
  "created_at" : "2013-12-18 18:54:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gdcr13",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "412025731036639232",
  "text" : "Enjoyed coding Ruby, Elixir, and Java at the #gdcr13 code retreat in Reston, Virginia, USA.",
  "id" : 412025731036639232,
  "created_at" : "2013-12-15 01:06:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 0, 6 ],
      "id_str" : "18001417",
      "id" : 18001417
    }, {
      "name" : "Alamo Rent A Car",
      "screen_name" : "alamocares",
      "indices" : [ 113, 124 ],
      "id_str" : "89721114",
      "id" : 89721114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410559889698594816",
  "in_reply_to_user_id" : 18001417,
  "text" : "@hertz Major fail by both MIA loc. &amp; nat'l cust svc.  Never renting from you again if I can help it. Thanks, @alamocares for saving me.",
  "id" : 410559889698594816,
  "created_at" : "2013-12-11 00:01:20 +0000",
  "in_reply_to_screen_name" : "Hertz",
  "in_reply_to_user_id_str" : "18001417",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Taiwan",
      "screen_name" : "rubytaiwan",
      "indices" : [ 0, 11 ],
      "id_str" : "110385172",
      "id" : 110385172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "410075840148295681",
  "in_reply_to_user_id" : 110385172,
  "text" : "@rubytaiwan What % of the presentations will be in English, if any?  I'm thinking of attending but don't speak Mandarin.",
  "id" : 410075840148295681,
  "created_at" : "2013-12-09 15:57:53 +0000",
  "in_reply_to_screen_name" : "rubytaiwan",
  "in_reply_to_user_id_str" : "110385172",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franck Verrot",
      "screen_name" : "franckverrot",
      "indices" : [ 0, 13 ],
      "id_str" : "48102727",
      "id" : 48102727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "409785298562723840",
  "geo" : { },
  "id_str" : "409861671088181248",
  "in_reply_to_user_id" : 48102727,
  "text" : "@franckverrot I had already read that, but I don't see how it helps. I need before\/after 'feature', not 'all'.  Why, what do *you* think?",
  "id" : 409861671088181248,
  "in_reply_to_status_id" : 409785298562723840,
  "created_at" : "2013-12-09 01:46:51 +0000",
  "in_reply_to_screen_name" : "franckverrot",
  "in_reply_to_user_id_str" : "48102727",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cucumber",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/3ewbimzW9G",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/cukes\/gTKZeUS_7dI",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "409771731385978880",
  "text" : "Any current\/former #cucumber users care to weigh in on adding a before\/after feature capability? https:\/\/t.co\/3ewbimzW9G",
  "id" : 409771731385978880,
  "created_at" : "2013-12-08 19:49:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]