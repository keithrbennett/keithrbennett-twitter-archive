Grailbird.data.tweets_2009_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1460533586",
  "geo" : { },
  "id_str" : "1460729951",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl Thank you for answering the question, When do I test?, at http:\/\/whendoitest.com\/ ;)",
  "id" : 1460729951,
  "in_reply_to_status_id" : 1460533586,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1460177203",
  "geo" : { },
  "id_str" : "1460744816",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse Rejoice in small victories, when you can improve on your prior performance even a little.  The success is in the effort.",
  "id" : 1460744816,
  "in_reply_to_status_id" : 1460177203,
  "created_at" : "2009-04-06 00:00:00 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1457461666",
  "text" : "Great geek sculptures at Arlington Central Library (1015 N Quincy St\nArlington, VA 22201\n\nGet Directions\n(703) 228-5990)",
  "id" : 1457461666,
  "created_at" : "2009-04-05 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]