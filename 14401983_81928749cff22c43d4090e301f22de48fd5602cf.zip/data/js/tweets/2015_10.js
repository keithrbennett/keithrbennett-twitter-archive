Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/9R0FYtq6yz",
      "expanded_url" : "http:\/\/ruby-doc.org\/core-2.2.3\/String.html#method-i-casecmp",
      "display_url" : "ruby-doc.org\/core-2.2.3\/Str\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658725124359757824",
  "text" : "#ruby ists, 'casecmp' does case insensitive string comparisons: https:\/\/t.co\/9R0FYtq6yz Prob. more efficient than up\/downcase instances.",
  "id" : 658725124359757824,
  "created_at" : "2015-10-26 19:21:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becamp_info",
      "screen_name" : "becamp_info",
      "indices" : [ 121, 133 ],
      "id_str" : "2168804167",
      "id" : 2168804167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/wSD7vp8OcY",
      "expanded_url" : "http:\/\/www.techhumans.com\/",
      "display_url" : "techhumans.com"
    } ]
  },
  "geo" : { },
  "id_str" : "658323066230054912",
  "text" : "The article discussing the Random Four lunch meeting idea I discussed at my lightning talk is at https:\/\/t.co\/wSD7vp8OcY @becamp_info",
  "id" : 658323066230054912,
  "created_at" : "2015-10-25 16:43:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becamp_info",
      "screen_name" : "becamp_info",
      "indices" : [ 127, 139 ],
      "id_str" : "2168804167",
      "id" : 2168804167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 61 ],
      "url" : "https:\/\/t.co\/5w4WaJHPe3",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas-functional-conf-bangalore-oct-2014",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    }, {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/FyBgxU7yjq",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=hyRgf6Qc5pw",
      "display_url" : "youtube.com\/watch?v=hyRgf6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658042953638744064",
  "text" : "My Functional Ruby talk slides are at https:\/\/t.co\/5w4WaJHPe3, and a video of the Bangalore talk is at https:\/\/t.co\/FyBgxU7yjq @becamp_info",
  "id" : 658042953638744064,
  "created_at" : "2015-10-24 22:10:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becamp_info",
      "screen_name" : "becamp_info",
      "indices" : [ 35, 47 ],
      "id_str" : "2168804167",
      "id" : 2168804167
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/657715440454602752\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/d4KTPzCz3Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSCssRjUkAA1E6C.jpg",
      "id_str" : "657715422221864960",
      "id" : 657715422221864960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSCssRjUkAA1E6C.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/d4KTPzCz3Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657715440454602752",
  "text" : "Organizing the session schedule at @becamp_info, open space tech conference in Charlottesville, Virginia. https:\/\/t.co\/d4KTPzCz3Z",
  "id" : 657715440454602752,
  "created_at" : "2015-10-24 00:29:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/657715088028246016\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/SH7GCXp6XH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSCsX2gVAAAFjn7.jpg",
      "id_str" : "657715071364169728",
      "id" : 657715071364169728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSCsX2gVAAAFjn7.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/SH7GCXp6XH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657715088028246016",
  "text" : "Great idea! North Side Library in Charlottesville, Virginia has a cafe. https:\/\/t.co\/SH7GCXp6XH",
  "id" : 657715088028246016,
  "created_at" : "2015-10-24 00:27:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/wSD7voRcOo",
      "expanded_url" : "http:\/\/www.techhumans.com\/",
      "display_url" : "techhumans.com"
    } ]
  },
  "geo" : { },
  "id_str" : "656710564589113345",
  "text" : "Published a blog article \"Random Four \u2014 Making Strangers Friends in Your Large Organization\" at https:\/\/t.co\/wSD7voRcOo.  Feedback welcome.",
  "id" : 656710564589113345,
  "created_at" : "2015-10-21 05:56:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta Assist",
      "screen_name" : "DeltaAssist",
      "indices" : [ 0, 12 ],
      "id_str" : "137460929",
      "id" : 137460929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655908037920694272",
  "geo" : { },
  "id_str" : "655962719498076160",
  "in_reply_to_user_id" : 137460929,
  "text" : "@DeltaAssist On further thought, ignore my email suggestion and just put prominent signs in the terminal in several strategic places.",
  "id" : 655962719498076160,
  "in_reply_to_status_id" : 655908037920694272,
  "created_at" : "2015-10-19 04:24:34 +0000",
  "in_reply_to_screen_name" : "DeltaAssist",
  "in_reply_to_user_id_str" : "137460929",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta Assist",
      "screen_name" : "DeltaAssist",
      "indices" : [ 0, 12 ],
      "id_str" : "137460929",
      "id" : 137460929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655908037920694272",
  "geo" : { },
  "id_str" : "655961598759182337",
  "in_reply_to_user_id" : 137460929,
  "text" : "@DeltaAssist And of 2 passengers with whom I discussed this, neither were aware of the shuttles -- so this is likely an issue for many.",
  "id" : 655961598759182337,
  "in_reply_to_status_id" : 655908037920694272,
  "created_at" : "2015-10-19 04:20:06 +0000",
  "in_reply_to_screen_name" : "DeltaAssist",
  "in_reply_to_user_id_str" : "137460929",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta Assist",
      "screen_name" : "DeltaAssist",
      "indices" : [ 0, 12 ],
      "id_str" : "137460929",
      "id" : 137460929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655908037920694272",
  "geo" : { },
  "id_str" : "655961275042832384",
  "in_reply_to_user_id" : 137460929,
  "text" : "@DeltaAssist Thank you. I also suggest prominent signs when passengers disembark into that terminal. I did the 20 min walk when arriving too",
  "id" : 655961275042832384,
  "in_reply_to_status_id" : 655908037920694272,
  "created_at" : "2015-10-19 04:18:49 +0000",
  "in_reply_to_screen_name" : "DeltaAssist",
  "in_reply_to_user_id_str" : "137460929",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta Assist",
      "screen_name" : "DeltaAssist",
      "indices" : [ 1, 13 ],
      "id_str" : "137460929",
      "id" : 137460929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "655906382911262720",
  "geo" : { },
  "id_str" : "655907241925701632",
  "in_reply_to_user_id" : 137460929,
  "text" : ".@DeltaAssist This information should be included prominently in the confirmation email. Else how would I know to look, and where?",
  "id" : 655907241925701632,
  "in_reply_to_status_id" : 655906382911262720,
  "created_at" : "2015-10-19 00:44:07 +0000",
  "in_reply_to_screen_name" : "DeltaAssist",
  "in_reply_to_user_id_str" : "137460929",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Delta",
      "screen_name" : "Delta",
      "indices" : [ 1, 7 ],
      "id_str" : "5920532",
      "id" : 5920532
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DL4254",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655905436609224706",
  "text" : ".@delta Major fail not to inform your customers of bus that eliminates the 20 minute walk in huge JFK terminal to the gate. #DL4254",
  "id" : 655905436609224706,
  "created_at" : "2015-10-19 00:36:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/ZVOO6L6jyD",
      "expanded_url" : "http:\/\/Array.new",
      "display_url" : "Array.new"
    } ]
  },
  "geo" : { },
  "id_str" : "652171887687172096",
  "text" : "Rubyists, rand can take a Range object: http:\/\/t.co\/ZVOO6L6jyD(5) \u007B rand(1..10) \u007D\n =&gt; [3, 7, 9, 4, 4]  #ruby",
  "id" : 652171887687172096,
  "created_at" : "2015-10-08 17:21:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elevated Jeff Hodges",
      "screen_name" : "jmhodges",
      "indices" : [ 0, 9 ],
      "id_str" : "9267272",
      "id" : 9267272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651915513044594688",
  "in_reply_to_user_id" : 9267272,
  "text" : "@jmhodges Are you the author of the Avro Ruby gem?  If so, where can I post comments\/suggestions (publicly if available)?  Pull requests?",
  "id" : 651915513044594688,
  "created_at" : "2015-10-08 00:22:24 +0000",
  "in_reply_to_screen_name" : "jmhodges",
  "in_reply_to_user_id_str" : "9267272",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darshan Shankar",
      "screen_name" : "DShankar",
      "indices" : [ 3, 12 ],
      "id_str" : "7179142",
      "id" : 7179142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/nyWwbPuz1O",
      "expanded_url" : "http:\/\/krebsonsecurity.com\/2015\/10\/whats-in-a-boarding-pass-barcode-a-lot\/",
      "display_url" : "krebsonsecurity.com\/2015\/10\/whats-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651889058621198336",
  "text" : "RT @DShankar: Airplane boarding pass barcodes contain a lot of sensitive information. Shred them next time! http:\/\/t.co\/nyWwbPuz1O http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DShankar\/status\/651525492823056384\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PCynxDu0x6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQqu-6jVEAAUk-h.png",
        "id_str" : "651525492001017856",
        "id" : 651525492001017856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQqu-6jVEAAUk-h.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 1034
        } ],
        "display_url" : "pic.twitter.com\/PCynxDu0x6"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/nyWwbPuz1O",
        "expanded_url" : "http:\/\/krebsonsecurity.com\/2015\/10\/whats-in-a-boarding-pass-barcode-a-lot\/",
        "display_url" : "krebsonsecurity.com\/2015\/10\/whats-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651525492823056384",
    "text" : "Airplane boarding pass barcodes contain a lot of sensitive information. Shred them next time! http:\/\/t.co\/nyWwbPuz1O http:\/\/t.co\/PCynxDu0x6",
    "id" : 651525492823056384,
    "created_at" : "2015-10-06 22:32:36 +0000",
    "user" : {
      "name" : "Darshan Shankar",
      "screen_name" : "DShankar",
      "protected" : false,
      "id_str" : "7179142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/802334484628504576\/Rz7R8cc2_normal.jpg",
      "id" : 7179142,
      "verified" : true
    }
  },
  "id" : 651889058621198336,
  "created_at" : "2015-10-07 22:37:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "651800252035416065",
  "geo" : { },
  "id_str" : "651887601931059200",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius \"Thanks! \" * 1_000_000",
  "id" : 651887601931059200,
  "in_reply_to_status_id" : 651800252035416065,
  "created_at" : "2015-10-07 22:31:30 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/GYGnruKhyz",
      "expanded_url" : "https:\/\/codepoints.net\/",
      "display_url" : "codepoints.net"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/rG70Cp1TDA",
      "expanded_url" : "https:\/\/codepoints.net\/U+26F5",
      "display_url" : "codepoints.net\/U+26F5"
    } ]
  },
  "geo" : { },
  "id_str" : "651605747239784448",
  "text" : "Neat web site and REST API for Unicode code points at https:\/\/t.co\/GYGnruKhyz. \u26F5This sailboat is described at https:\/\/t.co\/rG70Cp1TDA.",
  "id" : 651605747239784448,
  "created_at" : "2015-10-07 03:51:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred@Bootstrap",
      "screen_name" : "FredAtBootstrap",
      "indices" : [ 1, 17 ],
      "id_str" : "2176429368",
      "id" : 2176429368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/1QnJV6ffJZ",
      "expanded_url" : "http:\/\/www.sitepoint.com\/how-to-solve-coding-anti-patterns-for-ruby-rookies\/",
      "display_url" : "sitepoint.com\/how-to-solve-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651491400362655748",
  "text" : ".@FredAtBootstrap Thanks for the great article on Ruby Rookie Antipatterns at http:\/\/t.co\/1QnJV6ffJZ. I used it as a teaching tool.",
  "id" : 651491400362655748,
  "created_at" : "2015-10-06 20:17:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Apple",
      "screen_name" : "Apple",
      "indices" : [ 1, 7 ],
      "id_str" : "380749300",
      "id" : 380749300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650748526838706177",
  "text" : ".@apple, UX superstar, gives my friend a 'bad security code' error when signing up for Apple Store.  The error was in another field.",
  "id" : 650748526838706177,
  "created_at" : "2015-10-04 19:05:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83E\uDD8D",
      "screen_name" : "derdrache",
      "indices" : [ 3, 13 ],
      "id_str" : "14599963",
      "id" : 14599963
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/derdrache\/status\/650101526866866178\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/N5bJ5BTghZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWf5OrWoAApnTz.jpg",
      "id_str" : "650101526766198784",
      "id" : 650101526766198784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWf5OrWoAApnTz.jpg",
      "sizes" : [ {
        "h" : 97,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 353,
        "resize" : "fit",
        "w" : 1242
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 291,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/N5bJ5BTghZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650417962235486208",
  "text" : "RT @derdrache: Oh my god. Mind blown. http:\/\/t.co\/N5bJ5BTghZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/derdrache\/status\/650101526866866178\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/N5bJ5BTghZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQWf5OrWoAApnTz.jpg",
        "id_str" : "650101526766198784",
        "id" : 650101526766198784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQWf5OrWoAApnTz.jpg",
        "sizes" : [ {
          "h" : 97,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 353,
          "resize" : "fit",
          "w" : 1242
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/N5bJ5BTghZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650101526866866178",
    "text" : "Oh my god. Mind blown. http:\/\/t.co\/N5bJ5BTghZ",
    "id" : 650101526866866178,
    "created_at" : "2015-10-03 00:14:16 +0000",
    "user" : {
      "name" : "\uD83E\uDD8D",
      "screen_name" : "derdrache",
      "protected" : false,
      "id_str" : "14599963",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770663049468403712\/NDMZCYQT_normal.jpg",
      "id" : 14599963,
      "verified" : false
    }
  },
  "id" : 650417962235486208,
  "created_at" : "2015-10-03 21:11:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]