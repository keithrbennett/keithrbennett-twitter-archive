Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "indices" : [ 3, 10 ],
      "id_str" : "107837944",
      "id" : 107837944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637748739340414976",
  "text" : "RT @_tessr: twitter dot com, where people think they're brands and brands think they're people",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "636649966371344384",
    "text" : "twitter dot com, where people think they're brands and brands think they're people",
    "id" : 636649966371344384,
    "created_at" : "2015-08-26 21:22:35 +0000",
    "user" : {
      "name" : "Tess Rinearson",
      "screen_name" : "_tessr",
      "protected" : false,
      "id_str" : "107837944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799412813747798016\/I9UloZ44_normal.jpg",
      "id" : 107837944,
      "verified" : true
    }
  },
  "id" : 637748739340414976,
  "created_at" : "2015-08-29 22:08:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637666874210316288",
  "text" : "Filing tip: in file\/p'flex folders, for info you need over time, paper clip it to the front face of the *rear* flap. Readable and permanent.",
  "id" : 637666874210316288,
  "created_at" : "2015-08-29 16:43:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Risley",
      "screen_name" : "spliggle",
      "indices" : [ 3, 12 ],
      "id_str" : "19962990",
      "id" : 19962990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "636569490084507648",
  "text" : "RT @spliggle: I have now watched this for approximately 17 minutes straight and I can confidently say it's the Best Vine Ever: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/sBuo9WLBQ2",
        "expanded_url" : "https:\/\/vine.co\/v\/O3l3rI5I0YX",
        "display_url" : "vine.co\/v\/O3l3rI5I0YX"
      } ]
    },
    "geo" : { },
    "id_str" : "582586081637453824",
    "text" : "I have now watched this for approximately 17 minutes straight and I can confidently say it's the Best Vine Ever: https:\/\/t.co\/sBuo9WLBQ2",
    "id" : 582586081637453824,
    "created_at" : "2015-03-30 16:52:00 +0000",
    "user" : {
      "name" : "Matt Risley",
      "screen_name" : "spliggle",
      "protected" : false,
      "id_str" : "19962990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810449658459914240\/ovr2_a8f_normal.jpg",
      "id" : 19962990,
      "verified" : false
    }
  },
  "id" : 636569490084507648,
  "created_at" : "2015-08-26 16:02:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/vINUBEkdaH",
      "expanded_url" : "http:\/\/www.wired.co.uk\/news\/archive\/2010-10\/21\/blest-machine",
      "display_url" : "wired.co.uk\/news\/archive\/2\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/90h4DKV8lI",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/qGGabrorRS8?rel=0",
      "display_url" : "youtube.com\/embed\/qGGabror\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "635572397027008512",
  "text" : "Japanese man invents machine to turn plastic (garbage) into oil. article: http:\/\/t.co\/vINUBEkdaH, video: https:\/\/t.co\/90h4DKV8lI .",
  "id" : 635572397027008512,
  "created_at" : "2015-08-23 22:00:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consumer Reports",
      "screen_name" : "ConsumerReports",
      "indices" : [ 1, 17 ],
      "id_str" : "16193528",
      "id" : 16193528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635210018288103425",
  "text" : ".@consumerreports I thought you were the *good* guys.",
  "id" : 635210018288103425,
  "created_at" : "2015-08-22 22:00:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consumer Reports",
      "screen_name" : "ConsumerReports",
      "indices" : [ 120, 136 ],
      "id_str" : "16193528",
      "id" : 16193528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 138, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635209959555231744",
  "text" : "Ominous \"Second Notice\" in red&amp;white envelope came in my mail to renew gift sub's for people I don't even know from @consumerreports! #wtf",
  "id" : 635209959555231744,
  "created_at" : "2015-08-22 22:00:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/634506728919465989\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/BkYLnMnJcR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CM44fNrW8AEUJ_s.jpg",
      "id_str" : "634506706404438017",
      "id" : 634506706404438017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CM44fNrW8AEUJ_s.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/BkYLnMnJcR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634506728919465989",
  "text" : "Beautiful rainbow this evening. http:\/\/t.co\/BkYLnMnJcR",
  "id" : 634506728919465989,
  "created_at" : "2015-08-20 23:26:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634402331635904512",
  "geo" : { },
  "id_str" : "634476471671721984",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Congrats, my friend. May you share many happy years there together.",
  "id" : 634476471671721984,
  "in_reply_to_status_id" : 634402331635904512,
  "created_at" : "2015-08-20 21:25:53 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "634157132619902976",
  "geo" : { },
  "id_str" : "634236426331234304",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Yes!",
  "id" : 634236426331234304,
  "in_reply_to_status_id" : 634157132619902976,
  "created_at" : "2015-08-20 05:32:02 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/IOIRprB4xI",
      "expanded_url" : "https:\/\/flic.kr\/s\/aHsjpLKAb2",
      "display_url" : "flic.kr\/s\/aHsjpLKAb2"
    } ]
  },
  "geo" : { },
  "id_str" : "634154841636499456",
  "text" : "An oldie but goodie (for me at least). Chilling with the tigers at Tiger Kingdom near Chiang Mai, Thailand, in 2010: https:\/\/t.co\/IOIRprB4xI",
  "id" : 634154841636499456,
  "created_at" : "2015-08-20 00:07:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 1, 8 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631813467759116288",
  "text" : ".@FuConf FP conf in Bangalore Sept. 10-13 is open for registration &amp; needs sponsors. This is a great conference, pls support it if you can.",
  "id" : 631813467759116288,
  "created_at" : "2015-08-13 13:04:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PUR",
      "screen_name" : "PURtweets",
      "indices" : [ 56, 66 ],
      "id_str" : "79094374",
      "id" : 79094374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/iNjEs40t3t",
      "expanded_url" : "http:\/\/www.pur.com\/recycle",
      "display_url" : "pur.com\/recycle"
    } ]
  },
  "in_reply_to_status_id_str" : "630495467927957504",
  "geo" : { },
  "id_str" : "630603535252590592",
  "in_reply_to_user_id" : 14401983,
  "text" : "Forgot to provide the URL for anyone wanting to recycle @PURtweets products: http:\/\/t.co\/iNjEs40t3t",
  "id" : 630603535252590592,
  "in_reply_to_status_id" : 630495467927957504,
  "created_at" : "2015-08-10 04:56:13 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PUR",
      "screen_name" : "PURtweets",
      "indices" : [ 11, 21 ],
      "id_str" : "79094374",
      "id" : 79094374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "630495467927957504",
  "text" : "Great that @PURtweets offers free recycling of filters, pitchers, etc.  Does the environmental benefit exceed the env. cost of the shipping?",
  "id" : 630495467927957504,
  "created_at" : "2015-08-09 21:46:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    }, {
      "name" : "LaserShip",
      "screen_name" : "LaserShip",
      "indices" : [ 104, 114 ],
      "id_str" : "33485516",
      "id" : 33485516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629653251495849984",
  "geo" : { },
  "id_str" : "629653892268101633",
  "in_reply_to_user_id" : 14401983,
  "text" : "@atonse They have a history of lying about deliveries, mishandling packages, exploiting drivers. Search @lasership &amp; Google to see more.",
  "id" : 629653892268101633,
  "in_reply_to_status_id" : 629653251495849984,
  "created_at" : "2015-08-07 14:02:40 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629610377941225472",
  "geo" : { },
  "id_str" : "629653251495849984",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse In my current case, I need daytime delivery, and they arrive late evening when I'm not home &amp; my rental office is closed.  Also...",
  "id" : 629653251495849984,
  "in_reply_to_status_id" : 629610377941225472,
  "created_at" : "2015-08-07 14:00:08 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Help",
      "screen_name" : "AmazonHelp",
      "indices" : [ 26, 37 ],
      "id_str" : "85741735",
      "id" : 85741735
    }, {
      "name" : "LaserShip",
      "screen_name" : "LaserShip",
      "indices" : [ 96, 106 ],
      "id_str" : "33485516",
      "id" : 33485516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629436241159827456",
  "geo" : { },
  "id_str" : "629508617830551552",
  "in_reply_to_user_id" : 14401983,
  "text" : "Left feedback and spoke w\/@AmazonHelp on phone. They made a notation on my account never to use @lasership to ship to me!  Woohoo!",
  "id" : 629508617830551552,
  "in_reply_to_status_id" : 629436241159827456,
  "created_at" : "2015-08-07 04:25:24 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Help",
      "screen_name" : "AmazonHelp",
      "indices" : [ 0, 11 ],
      "id_str" : "85741735",
      "id" : 85741735
    }, {
      "name" : "LaserShip",
      "screen_name" : "LaserShip",
      "indices" : [ 96, 106 ],
      "id_str" : "33485516",
      "id" : 33485516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "629436779259674624",
  "geo" : { },
  "id_str" : "629505145022361601",
  "in_reply_to_user_id" : 85741735,
  "text" : "@AmazonHelp It's not about my individual case, it's about your co. subjecting your customers to @lasership despite its reputation\/behavior.",
  "id" : 629505145022361601,
  "in_reply_to_status_id" : 629436779259674624,
  "created_at" : "2015-08-07 04:11:36 +0000",
  "in_reply_to_screen_name" : "AmazonHelp",
  "in_reply_to_user_id_str" : "85741735",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 0, 5 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "LaserShip",
      "screen_name" : "LaserShip",
      "indices" : [ 12, 22 ],
      "id_str" : "33485516",
      "id" : 33485516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629445236197072897",
  "in_reply_to_user_id" : 19103481,
  "text" : "@uber &amp; @lasership worst contractor exploitation is the hidden but huge amortization cost of purchase price + maintenance cost of vehicles.",
  "id" : 629445236197072897,
  "created_at" : "2015-08-07 00:13:33 +0000",
  "in_reply_to_screen_name" : "Uber",
  "in_reply_to_user_id_str" : "19103481",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Help",
      "screen_name" : "AmazonHelp",
      "indices" : [ 1, 12 ],
      "id_str" : "85741735",
      "id" : 85741735
    }, {
      "name" : "LaserShip",
      "screen_name" : "LaserShip",
      "indices" : [ 62, 72 ],
      "id_str" : "33485516",
      "id" : 33485516
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "629436241159827456",
  "text" : ".@amazonhelp Your customers deserve to know when you will use @lasership so they can shop elsewhere. Stop using them!",
  "id" : 629436241159827456,
  "created_at" : "2015-08-06 23:37:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby for Good",
      "screen_name" : "RubyforGood",
      "indices" : [ 3, 15 ],
      "id_str" : "2474347308",
      "id" : 2474347308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/F9z71uzw9H",
      "expanded_url" : "http:\/\/www.booster.com\/rubyforgood",
      "display_url" : "booster.com\/rubyforgood"
    } ]
  },
  "geo" : { },
  "id_str" : "628347158543011840",
  "text" : "RT @RubyforGood: Want to help support scholarship tickets for next Ruby for Good? Get a shirt! http:\/\/t.co\/F9z71uzw9H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/F9z71uzw9H",
        "expanded_url" : "http:\/\/www.booster.com\/rubyforgood",
        "display_url" : "booster.com\/rubyforgood"
      } ]
    },
    "geo" : { },
    "id_str" : "628206784738652160",
    "text" : "Want to help support scholarship tickets for next Ruby for Good? Get a shirt! http:\/\/t.co\/F9z71uzw9H",
    "id" : 628206784738652160,
    "created_at" : "2015-08-03 14:12:23 +0000",
    "user" : {
      "name" : "Ruby for Good",
      "screen_name" : "RubyforGood",
      "protected" : false,
      "id_str" : "2474347308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697258268054450176\/MzErtpn0_normal.png",
      "id" : 2474347308,
      "verified" : false
    }
  },
  "id" : 628347158543011840,
  "created_at" : "2015-08-03 23:30:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PowerToFly",
      "screen_name" : "powertofly",
      "indices" : [ 1, 12 ],
      "id_str" : "2221695594",
      "id" : 2221695594
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/qZZHFBNKGv",
      "expanded_url" : "https:\/\/www.powertofly.com\/jobs\/detail\/833",
      "display_url" : "powertofly.com\/jobs\/detail\/833"
    }, {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/3qyvaSe3EL",
      "expanded_url" : "https:\/\/www.crunchbase.com\/organization\/powertofly-2",
      "display_url" : "crunchbase.com\/organization\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627917073889525760",
  "text" : ".@powertofly, a women in tech remote work matching service, is looking for a CTO: https:\/\/t.co\/qZZHFBNKGv, https:\/\/t.co\/3qyvaSe3EL",
  "id" : 627917073889525760,
  "created_at" : "2015-08-02 19:01:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "627573611986055168",
  "geo" : { },
  "id_str" : "627607153608491008",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms Amazing. Many congratulations. Goes to show how important it is to question and advocate.",
  "id" : 627607153608491008,
  "in_reply_to_status_id" : 627573611986055168,
  "created_at" : "2015-08-01 22:29:40 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]