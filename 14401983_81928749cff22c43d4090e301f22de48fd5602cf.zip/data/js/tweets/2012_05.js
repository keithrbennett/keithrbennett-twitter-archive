Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Seibel",
      "screen_name" : "peterseibel",
      "indices" : [ 3, 15 ],
      "id_str" : "40684667",
      "id" : 40684667
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207755009339817984",
  "text" : "RT @peterseibel: My favorite Mythical Man Month story: a team in which each developer bought the manager a copy of MMM. So he could read ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207480004102193152",
    "text" : "My favorite Mythical Man Month story: a team in which each developer bought the manager a copy of MMM. So he could read it faster.",
    "id" : 207480004102193152,
    "created_at" : "2012-05-29 14:34:22 +0000",
    "user" : {
      "name" : "Peter Seibel",
      "screen_name" : "peterseibel",
      "protected" : false,
      "id_str" : "40684667",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523508406548963328\/tryZDeEs_normal.jpeg",
      "id" : 40684667,
      "verified" : false
    }
  },
  "id" : 207755009339817984,
  "created_at" : "2012-05-30 08:47:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "207577755892727809",
  "geo" : { },
  "id_str" : "207753392213331968",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Wouldnt 500,000,000 bits be 62.5 (500\/8) MB, not 500?  So maybe it's a way of exaggerating the quantity?  Or was that your point?",
  "id" : 207753392213331968,
  "in_reply_to_status_id" : 207577755892727809,
  "created_at" : "2012-05-30 08:40:43 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206598503865131009",
  "text" : "Back in Chiang Mai, for the last leg of SE Asia journey.  Staying in new (for me) part of town, a serene spot on east side of Ping River.",
  "id" : 206598503865131009,
  "created_at" : "2012-05-27 04:11:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/Q0N1tviS",
      "expanded_url" : "http:\/\/www.cleancoders.com\/codecast\/clean-code-episode-6-part-1\/show",
      "display_url" : "cleancoders.com\/codecast\/clean\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206585972417232896",
  "text" : "Fun photos of Uncle Bob Martin at his screencast page at http:\/\/t.co\/Q0N1tviS.",
  "id" : 206585972417232896,
  "created_at" : "2012-05-27 03:21:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 9, 19 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/AcVutBnd",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Netflix",
      "display_url" : "en.wikipedia.org\/wiki\/Netflix"
    } ]
  },
  "geo" : { },
  "id_str" : "206585543134412801",
  "text" : "Reply to @ngauthier http:\/\/t.co\/AcVutBnd says Netflix is available in Canada but title selection is based on country (det. by IP address). ?",
  "id" : 206585543134412801,
  "created_at" : "2012-05-27 03:20:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 3, 15 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "notEvenHard",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206580711233306625",
  "text" : "RT @RonJeffries: Manage scope, not quality, to meet any deadline with best possible result. #notEvenHard",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "notEvenHard",
        "indices" : [ 75, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206401613118709760",
    "text" : "Manage scope, not quality, to meet any deadline with best possible result. #notEvenHard",
    "id" : 206401613118709760,
    "created_at" : "2012-05-26 15:09:13 +0000",
    "user" : {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "protected" : false,
      "id_str" : "14979481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479052206260244480\/WQA0NXQT_normal.jpeg",
      "id" : 14979481,
      "verified" : false
    }
  },
  "id" : 206580711233306625,
  "created_at" : "2012-05-27 03:00:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wtf",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205989661133373440",
  "text" : "Can't buy Crockford JavaScript PDF from Amazon in Thailand, but can download it illegally for free. #wtf",
  "id" : 205989661133373440,
  "created_at" : "2012-05-25 11:52:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 3, 7 ],
      "id_str" : "8076192",
      "id" : 8076192
    }, {
      "name" : "Ilya Grigorik",
      "screen_name" : "igrigorik",
      "indices" : [ 26, 36 ],
      "id_str" : "9980812",
      "id" : 9980812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/8Zc06Oir",
      "expanded_url" : "http:\/\/bit.ly\/JOvhjG",
      "display_url" : "bit.ly\/JOvhjG"
    } ]
  },
  "geo" : { },
  "id_str" : "205950690722455553",
  "text" : "RT @shr: This is handy RT @igrigorik: pipe viewer: http:\/\/t.co\/8Zc06Oir ... where have you been all my life?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ilya Grigorik",
        "screen_name" : "igrigorik",
        "indices" : [ 17, 27 ],
        "id_str" : "9980812",
        "id" : 9980812
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/8Zc06Oir",
        "expanded_url" : "http:\/\/bit.ly\/JOvhjG",
        "display_url" : "bit.ly\/JOvhjG"
      } ]
    },
    "geo" : { },
    "id_str" : "205912881068376064",
    "text" : "This is handy RT @igrigorik: pipe viewer: http:\/\/t.co\/8Zc06Oir ... where have you been all my life?",
    "id" : 205912881068376064,
    "created_at" : "2012-05-25 06:47:11 +0000",
    "user" : {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "protected" : false,
      "id_str" : "8076192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317218980\/bc_1_normal.jpg",
      "id" : 8076192,
      "verified" : false
    }
  },
  "id" : 205950690722455553,
  "created_at" : "2012-05-25 09:17:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 8, 28 ],
      "url" : "http:\/\/t.co\/2Vot44N8",
      "expanded_url" : "http:\/\/bit.ly\/mhL90P",
      "display_url" : "bit.ly\/mhL90P"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/uujlaYo9",
      "expanded_url" : "http:\/\/laughnet.net\/lesser-known-programming-languages-p-170.html",
      "display_url" : "laughnet.net\/lesser-known-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205891399789445122",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight http:\/\/t.co\/2Vot44N8 is great, thanks! Reminds me of the SIMPLE language from the 90's described at http:\/\/t.co\/uujlaYo9.",
  "id" : 205891399789445122,
  "created_at" : "2012-05-25 05:21:49 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 13, 21 ],
      "id_str" : "612473",
      "id" : 612473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205882286183424001",
  "text" : "Grateful for @BBCNews everywhere I travel.  Watching in Pattaya hotel room while packing for the 12 hour bus ride to Chiang Mai.",
  "id" : 205882286183424001,
  "created_at" : "2012-05-25 04:45:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agoda.com",
      "screen_name" : "agoda",
      "indices" : [ 0, 6 ],
      "id_str" : "18797910",
      "id" : 18797910
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205593711009210368",
  "in_reply_to_user_id" : 18797910,
  "text" : "@agoda Thanks for removing the popups.  Next could you put only target hotel on the map? Other hotels can obscure whole sections of the map.",
  "id" : 205593711009210368,
  "created_at" : "2012-05-24 09:38:55 +0000",
  "in_reply_to_screen_name" : "agoda",
  "in_reply_to_user_id_str" : "18797910",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/lExIiiGc",
      "expanded_url" : "http:\/\/bit.ly\/JPgeXT",
      "display_url" : "bit.ly\/JPgeXT"
    } ]
  },
  "geo" : { },
  "id_str" : "205188618791301120",
  "text" : "Singapore's Red Dot Ruby Conf wrap-up, with slide links and interesting nationality demographics, at http:\/\/t.co\/lExIiiGc.  #reddot",
  "id" : 205188618791301120,
  "created_at" : "2012-05-23 06:49:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Croll",
      "screen_name" : "andycroll",
      "indices" : [ 3, 13 ],
      "id_str" : "635863",
      "id" : 635863
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 45, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/YwJMxS1F",
      "expanded_url" : "http:\/\/bit.ly\/JPgeXT",
      "display_url" : "bit.ly\/JPgeXT"
    } ]
  },
  "geo" : { },
  "id_str" : "205187645029105664",
  "text" : "RT @andycroll: RedDotRubyconf 2012: Wrap up. #reddot http:\/\/t.co\/YwJMxS1F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "reddot",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/YwJMxS1F",
        "expanded_url" : "http:\/\/bit.ly\/JPgeXT",
        "display_url" : "bit.ly\/JPgeXT"
      } ]
    },
    "geo" : { },
    "id_str" : "205083455330062336",
    "text" : "RedDotRubyconf 2012: Wrap up. #reddot http:\/\/t.co\/YwJMxS1F",
    "id" : 205083455330062336,
    "created_at" : "2012-05-22 23:51:20 +0000",
    "user" : {
      "name" : "Andy Croll",
      "screen_name" : "andycroll",
      "protected" : false,
      "id_str" : "635863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1883092999\/Screen_Shot_2012-03-09_at_1.12.00_PM_normal.png",
      "id" : 635863,
      "verified" : false
    }
  },
  "id" : 205187645029105664,
  "created_at" : "2012-05-23 06:45:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/204806443419963393\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/PdVge1lU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AteeYAxCEAESPPz.jpg",
      "id_str" : "204806443428352001",
      "id" : 204806443428352001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AteeYAxCEAESPPz.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/PdVge1lU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204806443419963393",
  "text" : "Dog captures bird, Jomtien Beach, Thailand.  Wanted to save bird.  I eat chickens every day.  What a hyprocrite I am. http:\/\/t.co\/PdVge1lU",
  "id" : 204806443419963393,
  "created_at" : "2012-05-22 05:30:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204457042864390145",
  "text" : "Studying Rails for Zombies. Have studied Rails before, so it feels basic, but the online exercises are great at paving those brain paths.",
  "id" : 204457042864390145,
  "created_at" : "2012-05-21 06:22:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Croll",
      "screen_name" : "andycroll",
      "indices" : [ 51, 61 ],
      "id_str" : "635863",
      "id" : 635863
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/203991989383991297\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/QzZGFEAM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtS5ojCCEAE2_FB.jpg",
      "id_str" : "203991989388185601",
      "id" : 203991989388185601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtS5ojCCEAE2_FB.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/QzZGFEAM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203991989383991297",
  "text" : "Some of us helped out a bit, but major kudos go to @andycroll for organizing Red Dot Ruby Conf. Great melting pot! http:\/\/t.co\/QzZGFEAM",
  "id" : 203991989383991297,
  "created_at" : "2012-05-19 23:34:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Coryell-Martin",
      "screen_name" : "carlcoryell",
      "indices" : [ 15, 27 ],
      "id_str" : "14058655",
      "id" : 14058655
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/203990701954957312\/photo\/1",
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/aAK3Gy7S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtS4dm_CAAEIafo.jpg",
      "id_str" : "203990701959151617",
      "id" : 203990701959151617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtS4dm_CAAEIafo.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/aAK3Gy7S"
    } ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203990701954957312",
  "text" : "Really enjoyed @carlcoryell's talk today at Red Dot Ruby Conf in Singapore. #reddot http:\/\/t.co\/aAK3Gy7S",
  "id" : 203990701954957312,
  "created_at" : "2012-05-19 23:29:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203447197797318656",
  "text" : "Finished the first day of Red Dot Ruby Conference in Singapore.  Great to reconnect with old friends and make new ones. #reddot",
  "id" : 203447197797318656,
  "created_at" : "2012-05-18 11:29:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 0, 4 ],
      "id_str" : "8076192",
      "id" : 8076192
    }, {
      "name" : "Tim Oxley",
      "screen_name" : "secoif",
      "indices" : [ 5, 12 ],
      "id_str" : "17609423",
      "id" : 17609423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 69, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/calv6jVe",
      "expanded_url" : "http:\/\/www.sportsfunny.com\/funny-wrestling.html",
      "display_url" : "sportsfunny.com\/funny-wrestlin\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "203404804385542145",
  "geo" : { },
  "id_str" : "203446734247034880",
  "in_reply_to_user_id" : 8076192,
  "text" : "@shr @secoif Burned into the retinas indeed... http:\/\/t.co\/calv6jVe  #reddot",
  "id" : 203446734247034880,
  "in_reply_to_status_id" : 203404804385542145,
  "created_at" : "2012-05-18 11:27:35 +0000",
  "in_reply_to_screen_name" : "shr",
  "in_reply_to_user_id_str" : "8076192",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202959208193335296",
  "text" : "Thanks to the people of Kuala Lumpur for an interesting and pleasant stay.  Taking bus back to Singapore this afternoon for #reddot.",
  "id" : 202959208193335296,
  "created_at" : "2012-05-17 03:10:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202958871390715904",
  "text" : "Kuala Lumpur taxi driver informed me that \"thumbs up\" gesture is ok in Malaysia.  Whew!",
  "id" : 202958871390715904,
  "created_at" : "2012-05-17 03:09:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202435327846125568",
  "text" : "A Russian friend translates Dostoyevsky: \"An idiot who admits he's an idiot is no longer an idiot.\"",
  "id" : 202435327846125568,
  "created_at" : "2012-05-15 16:28:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/202391315986649088\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Ujpj99Sz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As8J1F-CEAAHW0b.jpg",
      "id_str" : "202391315995037696",
      "id" : 202391315995037696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As8J1F-CEAAHW0b.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Ujpj99Sz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202391315986649088",
  "text" : "The Petronas Twin Towers in Kuala Lumpur, taken today while getting tickets to see it tomorrow. http:\/\/t.co\/Ujpj99Sz",
  "id" : 202391315986649088,
  "created_at" : "2012-05-15 13:33:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lifehack",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202388492267954176",
  "text" : "Hotel washcloths are really good for cleaning mobile devices and laptops while on the road. #lifehack",
  "id" : 202388492267954176,
  "created_at" : "2012-05-15 13:22:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Agoda.com",
      "screen_name" : "agoda",
      "indices" : [ 0, 6 ],
      "id_str" : "18797910",
      "id" : 18797910
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "agoda",
      "indices" : [ 138, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202388306586107905",
  "in_reply_to_user_id" : 18797910,
  "text" : "@agoda PLEASE get rid of those useless &amp; obstructive popups \"There are n users looking at this hotel\" and \"Most recent booking was..\" #agoda",
  "id" : 202388306586107905,
  "created_at" : "2012-05-15 13:21:47 +0000",
  "in_reply_to_screen_name" : "agoda",
  "in_reply_to_user_id_str" : "18797910",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202115314098507778",
  "text" : "Gave the hotel desk clerk in Kuala Lumpur a thumbs up after seeing my nice room, but not sure, that may be an offensive gesture here.",
  "id" : 202115314098507778,
  "created_at" : "2012-05-14 19:17:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201965428535345153",
  "text" : "Singapore taxi driver awesome. Rushed me to bus station, waited for me to buy ticket, and refused a tip.",
  "id" : 201965428535345153,
  "created_at" : "2012-05-14 09:21:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201964820227047424",
  "text" : "On bus Singapore to Kuala Lumpur. Just exited Singapore immigration. Now for Malaysia immigration.",
  "id" : 201964820227047424,
  "created_at" : "2012-05-14 09:19:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsBridge",
      "screen_name" : "railsbridge",
      "indices" : [ 64, 76 ],
      "id_str" : "37201113",
      "id" : 37201113
    }, {
      "name" : "desi",
      "screen_name" : "desi",
      "indices" : [ 85, 90 ],
      "id_str" : "11857702",
      "id" : 11857702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201585438685798401",
  "text" : "Helped out Rails for Ladies at the Singapore New Context ofc by @railsbridge, led by @desi.  Great to see that aha moment in new learners.",
  "id" : 201585438685798401,
  "created_at" : "2012-05-13 08:11:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampsg8",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/131KcpF4",
      "expanded_url" : "https:\/\/speakerdeck.com\/u\/keithrbennett",
      "display_url" : "speakerdeck.com\/u\/keithrbennett"
    } ]
  },
  "geo" : { },
  "id_str" : "201236009973850112",
  "text" : "Gave Ruby, JRuby, and Unix talks at #barcampsg8.  Slides are all at https:\/\/t.co\/131KcpF4. Thanks, everyone!",
  "id" : 201236009973850112,
  "created_at" : "2012-05-12 09:02:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HackerspaceSG",
      "screen_name" : "hackerspacesg",
      "indices" : [ 0, 14 ],
      "id_str" : "71136691",
      "id" : 71136691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200777301858856960",
  "in_reply_to_user_id" : 71136691,
  "text" : "@hackerspacesg Any tips for affordable lodging near you (or anywhere in SG) for today through next Sunday?",
  "id" : 200777301858856960,
  "created_at" : "2012-05-11 02:40:13 +0000",
  "in_reply_to_screen_name" : "hackerspacesg",
  "in_reply_to_user_id_str" : "71136691",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/nCAsnvyl",
      "expanded_url" : "http:\/\/youtu.be\/Bxl-LufRoKw",
      "display_url" : "youtu.be\/Bxl-LufRoKw"
    } ]
  },
  "geo" : { },
  "id_str" : "200650776585060353",
  "text" : "Motorbike toured Chiang Mai tonight, last night I'm here -- found a spot with really loud animal noises.  Hear them at http:\/\/t.co\/nCAsnvyl.",
  "id" : 200650776585060353,
  "created_at" : "2012-05-10 18:17:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampsg8",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "reddotrubyconf",
      "indices" : [ 67, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200532160657104896",
  "text" : "Got my air ticket from Chiang Mai to Singapore for #barcampsg8 and #reddotrubyconf. Any advice on affordable lodging in SG?",
  "id" : 200532160657104896,
  "created_at" : "2012-05-10 10:26:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "speakerdeck",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "200137507982155777",
  "geo" : { },
  "id_str" : "200530263447580672",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Thanks so much for the pointer to #speakerdeck.  WAY better than slideshare.  Opened my acct and got my slides up there in 5 minutes.",
  "id" : 200530263447580672,
  "in_reply_to_status_id" : 200137507982155777,
  "created_at" : "2012-05-10 10:18:35 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 0, 4 ],
      "id_str" : "8076192",
      "id" : 8076192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/kIjppWRj",
      "expanded_url" : "http:\/\/speakerdeck.com\/u\/keithrbennett\/p\/jruby-the-synergy-of-ruby-and-the-jvm",
      "display_url" : "speakerdeck.com\/u\/keithrbennet\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "200274054618427393",
  "geo" : { },
  "id_str" : "200529823452512256",
  "in_reply_to_user_id" : 8076192,
  "text" : "@shr You're very welcome.  It was fun being with you guys.  Slides are at http:\/\/t.co\/kIjppWRj.",
  "id" : 200529823452512256,
  "in_reply_to_status_id" : 200274054618427393,
  "created_at" : "2012-05-10 10:16:50 +0000",
  "in_reply_to_screen_name" : "shr",
  "in_reply_to_user_id_str" : "8076192",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/dj137Fvd",
      "expanded_url" : "http:\/\/slideshare.net",
      "display_url" : "slideshare.net"
    } ]
  },
  "geo" : { },
  "id_str" : "200137027902124032",
  "text" : "Getting really fed up with http:\/\/t.co\/dj137Fvd.  Alternatives?",
  "id" : 200137027902124032,
  "created_at" : "2012-05-09 08:16:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "199756858297298944",
  "geo" : { },
  "id_str" : "200093447577800704",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius I wish you were here too.  Thanks again for JRuby, and I'll be sure to mention you tonight (\"writes Java so we don't have to\" ;) )",
  "id" : 200093447577800704,
  "in_reply_to_status_id" : 199756858297298944,
  "created_at" : "2012-05-09 05:22:50 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199717567965827072",
  "text" : "Looking forward to reconnecting with the Chiang Mai developer community, and presenting JRuby to them at a meeting tomorrow night.",
  "id" : 199717567965827072,
  "created_at" : "2012-05-08 04:29:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ilovethailand",
      "indices" : [ 127, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199717468250447872",
  "text" : "Overnight luxury bus tonight, Bangkok to Chiang Mai, w\/reclining massage seats, food &amp; stewardess service.  9.5 hrs, $20.  #ilovethailand",
  "id" : 199717468250447872,
  "created_at" : "2012-05-08 04:28:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197620286407983104",
  "text" : "RT @JimGaffigan: People on this plane got so uptight when I used the bathroom to change into my PJs. Llike they've never seen a man in a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197180401276567553",
    "text" : "People on this plane got so uptight when I used the bathroom to change into my PJs. Llike they've never seen a man in a nightgown before.",
    "id" : 197180401276567553,
    "created_at" : "2012-05-01 04:27:25 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 197620286407983104,
  "created_at" : "2012-05-02 09:35:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197614804385542144",
  "text" : "RT @elight: Just discovered that we have a route 404 on the Eastern Shore\u2026 but I can't find it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197492422811463682",
    "text" : "Just discovered that we have a route 404 on the Eastern Shore\u2026 but I can't find it.",
    "id" : 197492422811463682,
    "created_at" : "2012-05-02 01:07:17 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 197614804385542144,
  "created_at" : "2012-05-02 09:13:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whowouldathunkit",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197611487865470976",
  "text" : "A great place in Bangkok for vegetarians -- Sizzler Steak House -- great salad bar! #whowouldathunkit",
  "id" : 197611487865470976,
  "created_at" : "2012-05-02 09:00:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldrituals",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197271743482695680",
  "text" : "In Thailand, no one says \"God bless you\" when I sneeze.  I think I like it better this way. #firstworldrituals",
  "id" : 197271743482695680,
  "created_at" : "2012-05-01 10:30:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]