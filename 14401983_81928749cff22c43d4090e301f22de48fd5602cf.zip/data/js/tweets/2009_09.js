Grailbird.data.tweets_2009_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4134937108",
  "geo" : { },
  "id_str" : "4139447995",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi You're welcome, and thanks for sharing your formidable Unix knowledge with us.",
  "id" : 4139447995,
  "in_reply_to_status_id" : 4134937108,
  "created_at" : "2009-09-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4126453566",
  "text" : "#rubydcamp The Unix command line slides are at http:\/\/bit.ly\/Qbaoy.",
  "id" : 4126453566,
  "created_at" : "2009-09-20 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4127370987",
  "geo" : { },
  "id_str" : "4131895287",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano You're welcome...I actually added some unit tests (imagine that ;)) and issued a new pull request.",
  "id" : 4131895287,
  "in_reply_to_status_id" : 4127370987,
  "created_at" : "2009-09-20 00:00:00 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "4042370149",
  "geo" : { },
  "id_str" : "4092400765",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg re: timecube.com, funniest part was scrolling all the way to bottom of page and seeing a \"Next Page\" link.",
  "id" : 4092400765,
  "in_reply_to_status_id" : 4042370149,
  "created_at" : "2009-09-19 00:00:00 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 99, 106 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "4096052306",
  "text" : "#rubydcamp is great.  I was skeptical about the park idea, but it turned out beautifully.  Thanks, @elight, for your vision & effort.",
  "id" : 4096052306,
  "created_at" : "2009-09-19 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3956067475",
  "text" : "Desperately need English speakers for ESL conversation meeting in Chantilly, VA, Tuesday evening 7:30-9.  Pls contact me for more info.",
  "id" : 3956067475,
  "created_at" : "2009-09-13 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]