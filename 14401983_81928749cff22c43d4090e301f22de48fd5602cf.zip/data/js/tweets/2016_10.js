Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jeffpearlman",
      "screen_name" : "jeffpearlman",
      "indices" : [ 3, 16 ],
      "id_str" : "15445129",
      "id" : 15445129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792629038170853376",
  "text" : "RT @jeffpearlman: My daughter is Jewish. Her best pal is Muslim. For Halloween they created a superhero team: The Juslims. I've rarely been\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeffpearlman\/status\/792553544045858816\/photo\/1",
        "indices" : [ 141, 164 ],
        "url" : "https:\/\/t.co\/zqPCCwzshR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv-3OYeUMAAomuu.jpg",
        "id_str" : "792553517156151296",
        "id" : 792553517156151296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv-3OYeUMAAomuu.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 673
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 741
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 741
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 741
        } ],
        "display_url" : "pic.twitter.com\/zqPCCwzshR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "792553544045858816",
    "text" : "My daughter is Jewish. Her best pal is Muslim. For Halloween they created a superhero team: The Juslims. I've rarely been more proud. Truly. https:\/\/t.co\/zqPCCwzshR",
    "id" : 792553544045858816,
    "created_at" : "2016-10-30 02:27:44 +0000",
    "user" : {
      "name" : "jeffpearlman",
      "screen_name" : "jeffpearlman",
      "protected" : false,
      "id_str" : "15445129",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/811969719049666560\/D87xE69g_normal.jpg",
      "id" : 15445129,
      "verified" : true
    }
  },
  "id" : 792629038170853376,
  "created_at" : "2016-10-30 07:27:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hessler",
      "screen_name" : "spune",
      "indices" : [ 0, 6 ],
      "id_str" : "14197941",
      "id" : 14197941
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 7, 15 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Benjamin Tan Wei Hao",
      "screen_name" : "bentanweihao",
      "indices" : [ 16, 29 ],
      "id_str" : "54950832",
      "id" : 54950832
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 80, 88 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792342198465560576",
  "geo" : { },
  "id_str" : "792349251867074560",
  "in_reply_to_user_id" : 14197941,
  "text" : "@spune @headius @bentanweihao I hope they're good guys.  I'd hate to think that @headius was a bad guy. JRuby superhero by day... ;)",
  "id" : 792349251867074560,
  "in_reply_to_status_id" : 792342198465560576,
  "created_at" : "2016-10-29 12:55:57 +0000",
  "in_reply_to_screen_name" : "spune",
  "in_reply_to_user_id_str" : "14197941",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "792204805313744896",
  "geo" : { },
  "id_str" : "792341287374512128",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Forgive my ignorance, I'm not very cultured -- who are those guys? :)",
  "id" : 792341287374512128,
  "in_reply_to_status_id" : 792204805313744896,
  "created_at" : "2016-10-29 12:24:18 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/SCpzZG6DFO",
      "expanded_url" : "http:\/\/imgur.com\/gallery\/ySYQO",
      "display_url" : "imgur.com\/gallery\/ySYQO"
    } ]
  },
  "geo" : { },
  "id_str" : "792245136168103936",
  "text" : "Dog Food Diet (humor, I got a good laugh from this one): https:\/\/t.co\/SCpzZG6DFO",
  "id" : 792245136168103936,
  "created_at" : "2016-10-29 06:02:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "792206807041126400",
  "text" : "60-70 db thunderstorm last night. Lightning knocked out hotel's power line. On generator but no elevator svc. Lucky for me I'm on 3rd floor.",
  "id" : 792206807041126400,
  "created_at" : "2016-10-29 03:29:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/791984878111694848\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/x0B4zjhXnV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cv2yB1tVMAEoryL.jpg",
      "id_str" : "791984854153900033",
      "id" : 791984854153900033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cv2yB1tVMAEoryL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/x0B4zjhXnV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791984878111694848",
  "text" : "Thailand is 1 of the safest places in SE Asia to eat fresh fruits &amp; vegetables. These greens seem like they were picked today. https:\/\/t.co\/x0B4zjhXnV",
  "id" : 791984878111694848,
  "created_at" : "2016-10-28 12:48:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791276976224907270",
  "text" : "If you're going to #rubyconf, and wanted the conference hotel rate but couldn't get it, try again. I just cancelled my reservation.",
  "id" : 791276976224907270,
  "created_at" : "2016-10-26 13:55:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyConf",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "791273611772375041",
  "text" : "Got my 30-day Thai tourist visa extension today and plan to stay in Chiang Mai.  Anyone want to buy my #RubyConf ticket from me?",
  "id" : 791273611772375041,
  "created_at" : "2016-10-26 13:41:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt McCullar",
      "screen_name" : "TalesofMatteh",
      "indices" : [ 0, 14 ],
      "id_str" : "30960808",
      "id" : 30960808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791119047567945728",
  "geo" : { },
  "id_str" : "791153281108156416",
  "in_reply_to_user_id" : 30960808,
  "text" : "@TalesofMatteh Chicken blood!  To be honest, I only had a little bit of that. Is it better or worse for health than chicken meat?",
  "id" : 791153281108156416,
  "in_reply_to_status_id" : 791119047567945728,
  "created_at" : "2016-10-26 05:43:35 +0000",
  "in_reply_to_screen_name" : "TalesofMatteh",
  "in_reply_to_user_id_str" : "30960808",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "791034584733458432",
  "geo" : { },
  "id_str" : "791110497097560064",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse I would love that! I may be spending serious amounts of time here in the future.",
  "id" : 791110497097560064,
  "in_reply_to_status_id" : 791034584733458432,
  "created_at" : "2016-10-26 02:53:35 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/790987339988250624\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/XPkunjJY7w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CvomjcCVIAABVUD.jpg",
      "id_str" : "790987074820186112",
      "id" : 790987074820186112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CvomjcCVIAABVUD.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/XPkunjJY7w"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "790987339988250624",
  "text" : "Midnight motorbike rides exploring Chiang Mai are great. No traffic! Then this tasty meal at a tiny streetside restaurant for about $0.85. https:\/\/t.co\/XPkunjJY7w",
  "id" : 790987339988250624,
  "created_at" : "2016-10-25 18:44:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789471794646306816",
  "text" : "I asked about this a few months ago, but am wondering if there's any new information.",
  "id" : 789471794646306816,
  "created_at" : "2016-10-21 14:21:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789471456493080576",
  "text" : "Re: static blog site generators, I value actively maintained, well documented, ideally Ruby. Briefly looked at jekyll, octopress, middleman.",
  "id" : 789471456493080576,
  "created_at" : "2016-10-21 14:20:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "789470994930860032",
  "text" : "WordPress stores much configuration in the DB. Harder to automate\/manage. Looking at static blog site generators again. Recommendations?",
  "id" : 789470994930860032,
  "created_at" : "2016-10-21 14:18:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Logan",
      "screen_name" : "jlloganiii",
      "indices" : [ 0, 11 ],
      "id_str" : "97340565",
      "id" : 97340565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "787653457540943872",
  "geo" : { },
  "id_str" : "787874566227894272",
  "in_reply_to_user_id" : 97340565,
  "text" : "@jlloganiii IMO, not in the short term, but my knowledge is limited. Need a &gt; bandwidth comm. medium than Twitter to discuss further.",
  "id" : 787874566227894272,
  "in_reply_to_status_id" : 787653457540943872,
  "created_at" : "2016-10-17 04:35:09 +0000",
  "in_reply_to_screen_name" : "jlloganiii",
  "in_reply_to_user_id_str" : "97340565",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 82, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/a8FvsumeL3",
      "expanded_url" : "http:\/\/www.lifebuzz.com\/5-regrets\/",
      "display_url" : "lifebuzz.com\/5-regrets\/"
    } ]
  },
  "geo" : { },
  "id_str" : "787582750781939712",
  "text" : "RT @elight: I often find myself reflecting on this list. \"5 Regrets Of The Dying\" #fb https:\/\/t.co\/a8FvsumeL3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 70, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/a8FvsumeL3",
        "expanded_url" : "http:\/\/www.lifebuzz.com\/5-regrets\/",
        "display_url" : "lifebuzz.com\/5-regrets\/"
      } ]
    },
    "geo" : { },
    "id_str" : "787374253968678912",
    "text" : "I often find myself reflecting on this list. \"5 Regrets Of The Dying\" #fb https:\/\/t.co\/a8FvsumeL3",
    "id" : 787374253968678912,
    "created_at" : "2016-10-15 19:27:05 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 787582750781939712,
  "created_at" : "2016-10-16 09:15:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787195913345245185",
  "text" : "Thai TV playing old newsreels of the King. Starting to sink in how large a part of Thais' life he was; and for almost all, their whole life.",
  "id" : 787195913345245185,
  "created_at" : "2016-10-15 07:38:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/23FJP74IOO",
      "expanded_url" : "http:\/\/www.modernhealthcare.com\/article\/20161014\/NEWS\/161019940",
      "display_url" : "modernhealthcare.com\/article\/201610\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787181924548608000",
  "text" : "On health care pricing in the US: \"Ethically speaking, this is institutionalized fraud.\" https:\/\/t.co\/23FJP74IOO",
  "id" : 787181924548608000,
  "created_at" : "2016-10-15 06:42:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Logan",
      "screen_name" : "jlloganiii",
      "indices" : [ 3, 14 ],
      "id_str" : "97340565",
      "id" : 97340565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/Zso7ZHD5vc",
      "expanded_url" : "http:\/\/www.idownloadblog.com\/2014\/06\/15\/how-to-change-where-screenshots-are-saved-on-mac\/",
      "display_url" : "idownloadblog.com\/2014\/06\/15\/how\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "787023708279873536",
  "text" : "RT @jlloganiii: How to change where screenshots are saved on the Mac! https:\/\/t.co\/Zso7ZHD5vc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/Zso7ZHD5vc",
        "expanded_url" : "http:\/\/www.idownloadblog.com\/2014\/06\/15\/how-to-change-where-screenshots-are-saved-on-mac\/",
        "display_url" : "idownloadblog.com\/2014\/06\/15\/how\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "786966342477963265",
    "text" : "How to change where screenshots are saved on the Mac! https:\/\/t.co\/Zso7ZHD5vc",
    "id" : 786966342477963265,
    "created_at" : "2016-10-14 16:26:11 +0000",
    "user" : {
      "name" : "Jim Logan",
      "screen_name" : "jlloganiii",
      "protected" : false,
      "id_str" : "97340565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591006166\/me_normal.jpg",
      "id" : 97340565,
      "verified" : false
    }
  },
  "id" : 787023708279873536,
  "created_at" : "2016-10-14 20:14:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/786849141947195392\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/EFskzuW8Mi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CutzAKNVIAQDC08.jpg",
      "id_str" : "786849006483742724",
      "id" : 786849006483742724,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CutzAKNVIAQDC08.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EFskzuW8Mi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786849141947195392",
  "text" : "Swam today at the 700th Anniversary (of the city of Chiang Mai) 50m pool built for the 1995 Southeast Asian Games. https:\/\/t.co\/EFskzuW8Mi",
  "id" : 786849141947195392,
  "created_at" : "2016-10-14 08:40:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786814754530598912",
  "text" : "alias cd..=\"cd ..\" &amp;&amp; alias cd...=\"cd ..; cd ..\" &amp;&amp; alias cd....=\"cd ..; cd ..; cd ..\"\n-- for cd'ing up directories more easily.",
  "id" : 786814754530598912,
  "created_at" : "2016-10-14 06:23:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/786078563283992576\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/f3mP7dAh1s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cui2PADWgAAvc8s.jpg",
      "id_str" : "786078503804502016",
      "id" : 786078503804502016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cui2PADWgAAvc8s.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/f3mP7dAh1s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "786078563283992576",
  "text" : "Purr programming with one of the residents of Regina restaurant in Chiang Mai. https:\/\/t.co\/f3mP7dAh1s",
  "id" : 786078563283992576,
  "created_at" : "2016-10-12 05:38:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "785833523081011200",
  "geo" : { },
  "id_str" : "785842694966894592",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Yeah, or someone's apartment. ;)  There were several \"rooms\" in this place. Cappuccino was good too, and only 60 baht, about $1.70.",
  "id" : 785842694966894592,
  "in_reply_to_status_id" : 785833523081011200,
  "created_at" : "2016-10-11 14:01:13 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/785784094902788096\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/87asEauTbp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CueqaXAVUAAZR_O.jpg",
      "id_str" : "785784029828173824",
      "id" : 785784029828173824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CueqaXAVUAAZR_O.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/87asEauTbp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785784094902788096",
  "text" : "In a quaint Chiang Mai coffee shop. It's frickin' amazing how many creative establishments, especially coffee shops, there are here. https:\/\/t.co\/87asEauTbp",
  "id" : 785784094902788096,
  "created_at" : "2016-10-11 10:08:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/785551605542162433\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/cYtwcFgpnF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CubW35RVYAA7OQx.jpg",
      "id_str" : "785551440777404416",
      "id" : 785551440777404416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CubW35RVYAA7OQx.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/cYtwcFgpnF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785551605542162433",
  "text" : "Found a whole shelf of \"Bennett\" soaps at this Chiang Mai store. Sadly, in Thailand, almost all soaps bill themselves as \"whitening\" soaps. https:\/\/t.co\/cYtwcFgpnF",
  "id" : 785551605542162433,
  "created_at" : "2016-10-10 18:44:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/785551038040281088\/photo\/1",
      "indices" : [ 137, 160 ],
      "url" : "https:\/\/t.co\/CQ4J4g1Q3L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CubWV40VMAA0c6K.jpg",
      "id_str" : "785550856540205056",
      "id" : 785550856540205056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CubWV40VMAA0c6K.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CQ4J4g1Q3L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "785551038040281088",
  "text" : "Some Thai friends invited me to join them at this night club. There were multiple singers and bands. Many people danced at their tables. https:\/\/t.co\/CQ4J4g1Q3L",
  "id" : 785551038040281088,
  "created_at" : "2016-10-10 18:42:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/784754915440680961\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/3qVbdzUGQj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQBFuHUMAAuqJs.jpg",
      "id_str" : "784753432858996736",
      "id" : 784753432858996736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQBFuHUMAAuqJs.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/3qVbdzUGQj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784754915440680961",
  "text" : "...but don't worry, I didn't eat the cat! I had this fresh spinach sauteed with garlic, and banana\/cocoa\/coffee drink. https:\/\/t.co\/3qVbdzUGQj",
  "id" : 784754915440680961,
  "created_at" : "2016-10-08 13:58:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/784753008403894272\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/ZL1WdbG3ep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuQAnvDUsAAZNLy.jpg",
      "id_str" : "784752917714612224",
      "id" : 784752917714612224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuQAnvDUsAAZNLy.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ZL1WdbG3ep"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784753008403894272",
  "text" : "...but I was still hungry so I stopped at this other place for something more... https:\/\/t.co\/ZL1WdbG3ep",
  "id" : 784753008403894272,
  "created_at" : "2016-10-08 13:51:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/784706514053238784\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/q8cPn2GIMu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuPWYtOUMAAPOoS.jpg",
      "id_str" : "784706480037441536",
      "id" : 784706480037441536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuPWYtOUMAAPOoS.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/q8cPn2GIMu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784706514053238784",
  "text" : "Stopped by a restaurant where the locals eat, near my tai chi school. Khao soy pork with Coke, about $1.15. https:\/\/t.co\/q8cPn2GIMu",
  "id" : 784706514053238784,
  "created_at" : "2016-10-08 10:46:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/784186489617780736\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/PI2rDjIhfi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuH9ap-VIAAAEZm.jpg",
      "id_str" : "784186444524888064",
      "id" : 784186444524888064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuH9ap-VIAAAEZm.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PI2rDjIhfi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784186489617780736",
  "text" : "Mango shake *and* mango with sticky rice with my pad see ew pork. Love the fresh fruits and vegetables here. https:\/\/t.co\/PI2rDjIhfi",
  "id" : 784186489617780736,
  "created_at" : "2016-10-07 00:20:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/784015699777695748\/photo\/1",
      "indices" : [ 131, 154 ],
      "url" : "https:\/\/t.co\/hBUnQmrX9u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CuFiExEVYAA031_.jpg",
      "id_str" : "784015644169691136",
      "id" : 784015644169691136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CuFiExEVYAA031_.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1836,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/hBUnQmrX9u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "784015699777695748",
  "text" : "One of my favorite activities in Chiang Mai is the biweekly \"Beercamp\", an evening with tech folks and their partners and friends. https:\/\/t.co\/hBUnQmrX9u",
  "id" : 784015699777695748,
  "created_at" : "2016-10-06 13:01:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]