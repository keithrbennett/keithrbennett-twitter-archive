Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Aronson",
      "screen_name" : "davearonson",
      "indices" : [ 10, 22 ],
      "id_str" : "78068017",
      "id" : 78068017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyDayCamp",
      "indices" : [ 27, 39 ]
    }, {
      "text" : "RubyDCamp",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "384526973881839616",
  "text" : "Thanks to @davearonson for #RubyDayCamp, a weekend Ruby retreat in the park, \u00E0 la #RubyDCamp.",
  "id" : 384526973881839616,
  "created_at" : "2013-09-30 03:55:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lqVrmFH07M",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/6743744",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "383991516315660288",
  "text" : "When I run the Unix utility 'cal' as 'CAL' on my Mac, I get a rotated calendar https:\/\/t.co\/lqVrmFH07M. No CAL on path, cal must check ARGV.",
  "id" : 383991516315660288,
  "created_at" : "2013-09-28 16:28:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "383546716886011905",
  "geo" : { },
  "id_str" : "383562718047141888",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius How can we help?  Is there a way to vote for the feature request? Is it appropriate to post a comment with one's support?",
  "id" : 383562718047141888,
  "in_reply_to_status_id" : 383546716886011905,
  "created_at" : "2013-09-27 12:04:12 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aslak Helles\u00F8y",
      "screen_name" : "aslak_hellesoy",
      "indices" : [ 32, 47 ],
      "id_str" : "4994591",
      "id" : 4994591
    }, {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 49, 54 ],
      "id_str" : "14816059",
      "id" : 14816059
    }, {
      "name" : "Ian Dees",
      "screen_name" : "undees",
      "indices" : [ 56, 63 ],
      "id_str" : "5483362",
      "id" : 5483362
    }, {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "indices" : [ 65, 76 ],
      "id_str" : "36691457",
      "id" : 36691457
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cukeupnyc",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/F2a6VdOkD9",
      "expanded_url" : "http:\/\/img.ly\/wAEd",
      "display_url" : "img.ly\/wAEd"
    } ]
  },
  "geo" : { },
  "id_str" : "381783762423783424",
  "text" : "Enjoyed #cukeupnyc last Tues w\/ @aslak_hellesoy, @chzy, @undees, @gdinwiddie under Manhattan Bridge in Brooklyn, NY. http:\/\/t.co\/F2a6VdOkD9",
  "id" : 381783762423783424,
  "created_at" : "2013-09-22 14:15:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/dN8gJkXldE",
      "expanded_url" : "http:\/\/img.ly\/wAD",
      "display_url" : "img.ly\/wAD"
    } ]
  },
  "geo" : { },
  "id_str" : "381781950564139008",
  "text" : "An especially high quality and fun BeCamp open space conference at Charlottesville yesterday. http:\/\/t.co\/dN8gJkXldE",
  "id" : 381781950564139008,
  "created_at" : "2013-09-22 14:08:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Mountcastle",
      "screen_name" : "smountcastle",
      "indices" : [ 10, 23 ],
      "id_str" : "8273202",
      "id" : 8273202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/724MMq7GTf",
      "expanded_url" : "http:\/\/www.kitchensoap.com\/2012\/10\/25\/on-being-a-senior-engineer\/",
      "display_url" : "kitchensoap.com\/2012\/10\/25\/on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "379648723384401920",
  "text" : "Thanks to @smountcastle for pointing our team to a great article on being a (truly) senior software engineer (http:\/\/t.co\/724MMq7GTf).",
  "id" : 379648723384401920,
  "created_at" : "2013-09-16 16:51:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "376850071964221441",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf Approx. what times Nov 8th and  10th does the conference begin and end?  I want to book flights and need to know.  Thanks.",
  "id" : 376850071964221441,
  "created_at" : "2013-09-08 23:30:33 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ElisabethHendrickson",
      "screen_name" : "testobsessed",
      "indices" : [ 0, 13 ],
      "id_str" : "12614742",
      "id" : 12614742
    }, {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 14, 23 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "376752611140984832",
  "geo" : { },
  "id_str" : "376760477889478656",
  "in_reply_to_user_id" : 12614742,
  "text" : "@testobsessed @wndxlori Thanks!",
  "id" : 376760477889478656,
  "in_reply_to_status_id" : 376752611140984832,
  "created_at" : "2013-09-08 17:34:32 +0000",
  "in_reply_to_screen_name" : "testobsessed",
  "in_reply_to_user_id_str" : "12614742",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ElisabethHendrickson",
      "screen_name" : "testobsessed",
      "indices" : [ 3, 16 ],
      "id_str" : "12614742",
      "id" : 12614742
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 18, 32 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 33, 42 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/xN3XrHNriY",
      "expanded_url" : "http:\/\/starwest.techwell.com\/",
      "display_url" : "starwest.techwell.com"
    }, {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/vE7LavZTyj",
      "expanded_url" : "http:\/\/www.pnsqc.org\/",
      "display_url" : "pnsqc.org"
    } ]
  },
  "geo" : { },
  "id_str" : "376760340844797952",
  "text" : "RT @testobsessed: @keithrbennett @wndxlori Lots:\n- SQE's STAR confs http:\/\/t.co\/xN3XrHNriY\n- PNSQC http:\/\/t.co\/vE7LavZTyj\n- CAST http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "Lori M Olson",
        "screen_name" : "wndxlori",
        "indices" : [ 15, 24 ],
        "id_str" : "30369946",
        "id" : 30369946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/xN3XrHNriY",
        "expanded_url" : "http:\/\/starwest.techwell.com\/",
        "display_url" : "starwest.techwell.com"
      }, {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/vE7LavZTyj",
        "expanded_url" : "http:\/\/www.pnsqc.org\/",
        "display_url" : "pnsqc.org"
      }, {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/KktxpSAD5z",
        "expanded_url" : "http:\/\/www.associationforsoftwaretesting.org\/conference\/cast-2013\/",
        "display_url" : "associationforsoftwaretesting.org\/conference\/cas\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "376745545714262017",
    "geo" : { },
    "id_str" : "376752611140984832",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett @wndxlori Lots:\n- SQE's STAR confs http:\/\/t.co\/xN3XrHNriY\n- PNSQC http:\/\/t.co\/vE7LavZTyj\n- CAST http:\/\/t.co\/KktxpSAD5z",
    "id" : 376752611140984832,
    "in_reply_to_status_id" : 376745545714262017,
    "created_at" : "2013-09-08 17:03:16 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "ElisabethHendrickson",
      "screen_name" : "testobsessed",
      "protected" : false,
      "id_str" : "12614742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737651812161855488\/r090dPpX_normal.jpg",
      "id" : 12614742,
      "verified" : false
    }
  },
  "id" : 376760340844797952,
  "created_at" : "2013-09-08 17:33:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/YYUZap9pF6",
      "expanded_url" : "http:\/\/sdtconf.com\/",
      "display_url" : "sdtconf.com"
    }, {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GNpeL4sDhF",
      "expanded_url" : "http:\/\/skillsmatter.com\/event\/javaee\/cukeup-nyc",
      "display_url" : "skillsmatter.com\/event\/javaee\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376745545714262017",
  "text" : "Anyone know of any testing conferences besides http:\/\/t.co\/YYUZap9pF6 and http:\/\/t.co\/GNpeL4sDhF?",
  "id" : 376745545714262017,
  "created_at" : "2013-09-08 16:35:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cukeupnyc",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GNpeL4sDhF",
      "expanded_url" : "http:\/\/skillsmatter.com\/event\/javaee\/cukeup-nyc",
      "display_url" : "skillsmatter.com\/event\/javaee\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "376745072085049344",
  "text" : "Looking forward to #cukeupnyc 1-day Cucumber conference on Sept. 17.  Talks look to be really interesting (see http:\/\/t.co\/GNpeL4sDhF)",
  "id" : 376745072085049344,
  "created_at" : "2013-09-08 16:33:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NickelCityRuby",
      "screen_name" : "nickelcityruby",
      "indices" : [ 0, 15 ],
      "id_str" : "1067596351",
      "id" : 1067596351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/8tB6wcEK0F",
      "expanded_url" : "http:\/\/nickelcityruby.com\/bus\/",
      "display_url" : "nickelcityruby.com\/bus\/"
    } ]
  },
  "geo" : { },
  "id_str" : "375209281810743297",
  "in_reply_to_user_id" : 1067596351,
  "text" : "@nickelcityruby has wifi and power enabled bus from NYC to Buffalo for their Ruby Conf, &amp; only $125 for bus + conf: http:\/\/t.co\/8tB6wcEK0F",
  "id" : 375209281810743297,
  "created_at" : "2013-09-04 10:50:38 +0000",
  "in_reply_to_screen_name" : "nickelcityruby",
  "in_reply_to_user_id_str" : "1067596351",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "374707026770669568",
  "text" : "To play an MP3 endlessly on a Mac using its command line player: \"while; do afplay x.mp3; done\" Great for studying singing parts.",
  "id" : 374707026770669568,
  "created_at" : "2013-09-03 01:34:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 0, 5 ],
      "id_str" : "14816059",
      "id" : 14816059
    }, {
      "name" : "Skills Matter",
      "screen_name" : "skillsmatter",
      "indices" : [ 6, 19 ],
      "id_str" : "16345873",
      "id" : 16345873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "374169325029965825",
  "geo" : { },
  "id_str" : "374648266446876672",
  "in_reply_to_user_id" : 14816059,
  "text" : "@chzy @skillsmatter Thanks, I just signed up for Cuke Up and look forward to seeing you again. We met at a Simple Design &amp;Testing conf.",
  "id" : 374648266446876672,
  "in_reply_to_status_id" : 374169325029965825,
  "created_at" : "2013-09-02 21:41:22 +0000",
  "in_reply_to_screen_name" : "chzy",
  "in_reply_to_user_id_str" : "14816059",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]