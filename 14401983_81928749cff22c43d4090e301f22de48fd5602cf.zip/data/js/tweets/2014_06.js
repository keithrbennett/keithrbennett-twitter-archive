Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rails School",
      "screen_name" : "RailsSchool",
      "indices" : [ 3, 15 ],
      "id_str" : "753738169",
      "id" : 753738169
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cville",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483692508124180480",
  "text" : "RT @RailsSchool: Learn Ruby on Rails at Rails School #cville.  This week it's all about JRuby and how it connects to Java http:\/\/t.co\/fW8Mb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.railsschool.org\" rel=\"nofollow\"\u003ERails School SF\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cville",
        "indices" : [ 36, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/fW8MbezBG1",
        "expanded_url" : "http:\/\/www.railsschool.org\/l\/jruby-bringing-the-power-of-java-to-rails",
        "display_url" : "railsschool.org\/l\/jruby-bringi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483619740855054337",
    "text" : "Learn Ruby on Rails at Rails School #cville.  This week it's all about JRuby and how it connects to Java http:\/\/t.co\/fW8MbezBG1",
    "id" : 483619740855054337,
    "created_at" : "2014-06-30 14:35:06 +0000",
    "user" : {
      "name" : "Rails School",
      "screen_name" : "RailsSchool",
      "protected" : false,
      "id_str" : "753738169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707297228130377728\/nFiFfcXW_normal.jpg",
      "id" : 753738169,
      "verified" : false
    }
  },
  "id" : 483692508124180480,
  "created_at" : "2014-06-30 19:24:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Manning Publications",
      "screen_name" : "ManningBooks",
      "indices" : [ 0, 13 ],
      "id_str" : "24914741",
      "id" : 24914741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483013937680506880",
  "in_reply_to_user_id" : 24914741,
  "text" : "@manningbooks Thanks for shipping my book but the package was so difficult to open I had to use a box cutter and slashed the cover page.",
  "id" : 483013937680506880,
  "created_at" : "2014-06-28 22:27:51 +0000",
  "in_reply_to_screen_name" : "ManningBooks",
  "in_reply_to_user_id_str" : "24914741",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/SqjKcJtL8G",
      "expanded_url" : "http:\/\/www.nolo.com\/",
      "display_url" : "nolo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482949277853814785",
  "text" : "I recommend Nolo Press for legal self help books, etc. 40% off until July 7 w\/\"JULY4\" promo code. http:\/\/t.co\/SqjKcJtL8G",
  "id" : 482949277853814785,
  "created_at" : "2014-06-28 18:10:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482531483291504640",
  "geo" : { },
  "id_str" : "482532319774134272",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett ...and our external behaviors.",
  "id" : 482532319774134272,
  "in_reply_to_status_id" : 482531483291504640,
  "created_at" : "2014-06-27 14:34:04 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/wh9WzKqiJL",
      "expanded_url" : "http:\/\/www.techhumans.com\/",
      "display_url" : "techhumans.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482531483291504640",
  "text" : "Just posted an article \"Kaizen and Radical Helpfulness\" on http:\/\/t.co\/wh9WzKqiJL. Discusses exploring our internal motivations &amp; thoughts.",
  "id" : 482531483291504640,
  "created_at" : "2014-06-27 14:30:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "discoveredbyaccident",
      "indices" : [ 69, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481523348191862784",
  "text" : "In Mac Terminal, holding Alt key down enables rectangular selection. #discoveredbyaccident",
  "id" : 481523348191862784,
  "created_at" : "2014-06-24 19:44:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FhGLQrxn52",
      "expanded_url" : "http:\/\/www.hackerparadise.org\/",
      "display_url" : "hackerparadise.org"
    } ]
  },
  "geo" : { },
  "id_str" : "481201325250994177",
  "text" : "What an amazing idea. I wish I could do this.  Hacker Paradise, coworking on steroids, in Costa Rica for 3 months: http:\/\/t.co\/FhGLQrxn52",
  "id" : 481201325250994177,
  "created_at" : "2014-06-23 22:25:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/TGbYqPPcie",
      "expanded_url" : "http:\/\/www.isitdownrightnow.com",
      "display_url" : "isitdownrightnow.com"
    }, {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/raUPcqOLFm",
      "expanded_url" : "http:\/\/iidrn.com",
      "display_url" : "iidrn.com"
    } ]
  },
  "geo" : { },
  "id_str" : "481184985354084352",
  "text" : "Cool site for showing web site status, showing that Stack Exchange is down: http:\/\/t.co\/TGbYqPPcie or, for short, http:\/\/t.co\/raUPcqOLFm.",
  "id" : 481184985354084352,
  "created_at" : "2014-06-23 21:20:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478979405125931008",
  "text" : "Can JSON do back references (serialize an obj only once) like YAML? I want to create JSON w\/Ruby and consume it w\/JavaScript in a browser.",
  "id" : 478979405125931008,
  "created_at" : "2014-06-17 19:16:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "indices" : [ 3, 13 ],
      "id_str" : "9459332",
      "id" : 9459332
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 15, 23 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478656388894167040",
  "text" : "RT @svenfuchs: @headius just don\u2019t listen to them. your work is awesome and we love you for it! &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Nutter",
        "screen_name" : "headius",
        "indices" : [ 0, 8 ],
        "id_str" : "9989362",
        "id" : 9989362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "478133674710679552",
    "geo" : { },
    "id_str" : "478171018897666048",
    "in_reply_to_user_id" : 9989362,
    "text" : "@headius just don\u2019t listen to them. your work is awesome and we love you for it! &lt;3",
    "id" : 478171018897666048,
    "in_reply_to_status_id" : 478133674710679552,
    "created_at" : "2014-06-15 13:43:49 +0000",
    "in_reply_to_screen_name" : "headius",
    "in_reply_to_user_id_str" : "9989362",
    "user" : {
      "name" : "Sven Fuchs",
      "screen_name" : "svenfuchs",
      "protected" : false,
      "id_str" : "9459332",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/301443535\/sven.twitter_normal.jpg",
      "id" : 9459332,
      "verified" : false
    }
  },
  "id" : 478656388894167040,
  "created_at" : "2014-06-16 21:52:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/6hSDIwvlIY",
      "expanded_url" : "https:\/\/github.com\/EnterpriseQualityCoding\/FizzBuzzEnterpriseEdition",
      "display_url" : "github.com\/EnterpriseQual\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "477177487646916608",
  "text" : "The FizzBuzzEnterpriseEdition - a model for enterprise class software (not!).  Funny and sad at the same time: https:\/\/t.co\/6hSDIwvlIY",
  "id" : 477177487646916608,
  "created_at" : "2014-06-12 19:55:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rspec",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/jBqwxybYex",
      "expanded_url" : "http:\/\/myronmars.to\/n\/dev-blog\/2014\/05\/notable-changes-in-rspec-3",
      "display_url" : "myronmars.to\/n\/dev-blog\/201\u2026"
    }, {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/512OWdR0e4",
      "expanded_url" : "https:\/\/www.relishapp.com\/rspec\/rspec-expectations\/docs\/syntax-configuration",
      "display_url" : "relishapp.com\/rspec\/rspec-ex\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476410648503783425",
  "text" : "Massive improvements to #rspec in 3.0 (see http:\/\/t.co\/jBqwxybYex). I recommend disabling should (see https:\/\/t.co\/512OWdR0e4). Thanks devs!",
  "id" : 476410648503783425,
  "created_at" : "2014-06-10 17:08:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yoko Harada",
      "screen_name" : "yokolet",
      "indices" : [ 0, 8 ],
      "id_str" : "50913878",
      "id" : 50913878
    }, {
      "name" : "Erik Isaksen",
      "screen_name" : "eisaksen",
      "indices" : [ 9, 18 ],
      "id_str" : "32005018",
      "id" : 32005018
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476133081863032834",
  "geo" : { },
  "id_str" : "476180391615660032",
  "in_reply_to_user_id" : 50913878,
  "text" : "@yokolet @eisaksen @krof Very nice seeing you. Chatting is my favorite part of confs. We should do it more often, even without confs! :)",
  "id" : 476180391615660032,
  "in_reply_to_status_id" : 476133081863032834,
  "created_at" : "2014-06-10 01:53:47 +0000",
  "in_reply_to_screen_name" : "yokolet",
  "in_reply_to_user_id_str" : "50913878",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/LzZcYSljPR",
      "expanded_url" : "http:\/\/www.steelcityruby.org\/schedule",
      "display_url" : "steelcityruby.org\/schedule"
    } ]
  },
  "geo" : { },
  "id_str" : "473522339171553281",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby Steel City Ruby Conf schedule is out! http:\/\/t.co\/LzZcYSljPR",
  "id" : 473522339171553281,
  "created_at" : "2014-06-02 17:51:37 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]