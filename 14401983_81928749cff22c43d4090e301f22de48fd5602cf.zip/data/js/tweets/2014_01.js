Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Bellows",
      "screen_name" : "paulbellows",
      "indices" : [ 3, 15 ],
      "id_str" : "19775131",
      "id" : 19775131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429085500839059456",
  "text" : "RT @paulbellows: I just managed to pre-register a domain on the upcoming .construction TLD.  I got under.construction.  I plan to never bui\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429005962603552768",
    "text" : "I just managed to pre-register a domain on the upcoming .construction TLD.  I got under.construction.  I plan to never build the website.",
    "id" : 429005962603552768,
    "created_at" : "2014-01-30 21:39:26 +0000",
    "user" : {
      "name" : "Paul Bellows",
      "screen_name" : "paulbellows",
      "protected" : false,
      "id_str" : "19775131",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1863627382\/paul1a_normal.jpg",
      "id" : 19775131,
      "verified" : false
    }
  },
  "id" : 429085500839059456,
  "created_at" : "2014-01-31 02:55:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/pm1Y1x2d4V",
      "expanded_url" : "http:\/\/meetu.ps\/28bpYv",
      "display_url" : "meetu.ps\/28bpYv"
    } ]
  },
  "geo" : { },
  "id_str" : "428367687253647360",
  "text" : "Enjoyed speaking about Ruby lambdas tonight at Arlington Ruby http:\/\/t.co\/pm1Y1x2d4V.",
  "id" : 428367687253647360,
  "created_at" : "2014-01-29 03:23:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reza Primardiansyah",
      "screen_name" : "rprimar",
      "indices" : [ 0, 8 ],
      "id_str" : "136221945",
      "id" : 136221945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "427928067210608641",
  "geo" : { },
  "id_str" : "427936804256239617",
  "in_reply_to_user_id" : 136221945,
  "text" : "@rprimar Yes. In 'real life' it would be in a multiline -&gt; do\/end block. I would use it only in rare cases, like unit testing. Better way?",
  "id" : 427936804256239617,
  "in_reply_to_status_id" : 427928067210608641,
  "created_at" : "2014-01-27 22:50:59 +0000",
  "in_reply_to_screen_name" : "rprimar",
  "in_reply_to_user_id_str" : "136221945",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427884300042661888",
  "text" : "Then removing the class from the runtime: def undef_class(name); Object.send(:remove_const, name) if Object.const_defined?(name);   end",
  "id" : 427884300042661888,
  "created_at" : "2014-01-27 19:22:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427883763133997056",
  "text" : "I find it useful for testing sometimes to create classes on the fly.  Lambdas are great for that.  -&gt;\u007B class D; ...more_stuff... end \u007D.()",
  "id" : 427883763133997056,
  "created_at" : "2014-01-27 19:20:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427558434603401216",
  "text" : "OOD is powerful for organizing behavior, but without lambdas' code-as-data flexibility, fails to reduce solutions to their simplest form.",
  "id" : 427558434603401216,
  "created_at" : "2014-01-26 21:47:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interestingbutuseless",
      "indices" : [ 110, 132 ]
    }, {
      "text" : "sowhat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427543020800458753",
  "text" : "+++++++++++++++++++++++++++ and ---------------------------------- are valid unary numeric operators in Ruby. #interestingbutuseless #sowhat",
  "id" : 427543020800458753,
  "created_at" : "2014-01-26 20:46:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "426860121659310080",
  "geo" : { },
  "id_str" : "427144745123459072",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Welcome back, Evan.  It'll be nice to have you around again.",
  "id" : 427144745123459072,
  "in_reply_to_status_id" : 426860121659310080,
  "created_at" : "2014-01-25 18:23:37 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/GVPjmqNjRP",
      "expanded_url" : "https:\/\/foursquare.com\/cofficenearme\/list\/best-coffices-in-new-york",
      "display_url" : "foursquare.com\/cofficenearme\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427120056254742528",
  "text" : "Great coffee shops as places to work when in New York City: https:\/\/t.co\/GVPjmqNjRP",
  "id" : 427120056254742528,
  "created_at" : "2014-01-25 16:45:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/xU6X1c0eaD",
      "expanded_url" : "http:\/\/j.mp\/1fY14PA",
      "display_url" : "j.mp\/1fY14PA"
    } ]
  },
  "geo" : { },
  "id_str" : "426020110193930240",
  "text" : "RT @angelaharms: This is the Martin Luther King folks don't talk about, the one who changed lives, including mine. http:\/\/t.co\/xU6X1c0eaD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/xU6X1c0eaD",
        "expanded_url" : "http:\/\/j.mp\/1fY14PA",
        "display_url" : "j.mp\/1fY14PA"
      } ]
    },
    "geo" : { },
    "id_str" : "425990844802297856",
    "text" : "This is the Martin Luther King folks don't talk about, the one who changed lives, including mine. http:\/\/t.co\/xU6X1c0eaD",
    "id" : 425990844802297856,
    "created_at" : "2014-01-22 13:58:26 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 426020110193930240,
  "created_at" : "2014-01-22 15:54:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "peter purgathofer",
      "screen_name" : "peterpur",
      "indices" : [ 3, 12 ],
      "id_str" : "14112331",
      "id" : 14112331
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/peterpur\/status\/425551087509463040\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/fXrMN0bE6N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BefcdZQIMAAw6We.png",
      "id_str" : "425551087362650112",
      "id" : 425551087362650112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BefcdZQIMAAw6We.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fXrMN0bE6N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425954313358557184",
  "text" : "RT @peterpur: AAAHAHAHAHA ROFL  \/via +WolfgangSlany http:\/\/t.co\/fXrMN0bE6N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/peterpur\/status\/425551087509463040\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/fXrMN0bE6N",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BefcdZQIMAAw6We.png",
        "id_str" : "425551087362650112",
        "id" : 425551087362650112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BefcdZQIMAAw6We.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/fXrMN0bE6N"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425551087509463040",
    "text" : "AAAHAHAHAHA ROFL  \/via +WolfgangSlany http:\/\/t.co\/fXrMN0bE6N",
    "id" : 425551087509463040,
    "created_at" : "2014-01-21 08:51:00 +0000",
    "user" : {
      "name" : "peter purgathofer",
      "screen_name" : "peterpur",
      "protected" : false,
      "id_str" : "14112331",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1057731732\/minitotoro_normal.png",
      "id" : 14112331,
      "verified" : false
    }
  },
  "id" : 425954313358557184,
  "created_at" : "2014-01-22 11:33:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/WQBW79dK8i",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/19\/health\/patients-costs-skyrocket-specialists-incomes-soar.html?nl=todaysheadlines&emc=edit_th_20140119&_r=0",
      "display_url" : "nytimes.com\/2014\/01\/19\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "424958382521344000",
  "text" : "1 of several causes of the tremendous cost of medical care: http:\/\/t.co\/WQBW79dK8i. Economic frenzy in that industry hurts all of us.",
  "id" : 424958382521344000,
  "created_at" : "2014-01-19 17:35:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vince Wadhwani",
      "screen_name" : "vwadhwani",
      "indices" : [ 3, 13 ],
      "id_str" : "19808779",
      "id" : 19808779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yearslost",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424946022486274048",
  "text" : "RT @vwadhwani: Via HN: OSX Terminal: hold option and click a position in the current line to move your cursor to that position. #yearslost",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "yearslost",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424617501796728832",
    "text" : "Via HN: OSX Terminal: hold option and click a position in the current line to move your cursor to that position. #yearslost",
    "id" : 424617501796728832,
    "created_at" : "2014-01-18 19:01:16 +0000",
    "user" : {
      "name" : "Vince Wadhwani",
      "screen_name" : "vwadhwani",
      "protected" : false,
      "id_str" : "19808779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654322971075457024\/Nsw2o7kp_normal.jpg",
      "id" : 19808779,
      "verified" : false
    }
  },
  "id" : 424946022486274048,
  "created_at" : "2014-01-19 16:46:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Glover",
      "screen_name" : "ersatzryan",
      "indices" : [ 0, 11 ],
      "id_str" : "39614157",
      "id" : 39614157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423863917707026433",
  "geo" : { },
  "id_str" : "424061693522481152",
  "in_reply_to_user_id" : 39614157,
  "text" : "@ersatzryan Thanks for the heads up.",
  "id" : 424061693522481152,
  "in_reply_to_status_id" : 423863917707026433,
  "created_at" : "2014-01-17 06:12:41 +0000",
  "in_reply_to_screen_name" : "ersatzryan",
  "in_reply_to_user_id_str" : "39614157",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goozbach",
      "screen_name" : "goozbach",
      "indices" : [ 0, 9 ],
      "id_str" : "11816472",
      "id" : 11816472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "423104459476987904",
  "geo" : { },
  "id_str" : "424061590225178624",
  "in_reply_to_user_id" : 11816472,
  "text" : "@goozbach Confluence, installed on my Mac. $10 for 10 users, pretty full featured. Exports to XML so I can track with git.",
  "id" : 424061590225178624,
  "in_reply_to_status_id" : 423104459476987904,
  "created_at" : "2014-01-17 06:12:16 +0000",
  "in_reply_to_screen_name" : "goozbach",
  "in_reply_to_user_id_str" : "11816472",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/gSjQzACMnX",
      "expanded_url" : "https:\/\/bugs.ruby-lang.org\/projects\/ruby\/wiki\/ReleaseEngineering",
      "display_url" : "bugs.ruby-lang.org\/projects\/ruby\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "423863157711335424",
  "text" : "Wow, #ruby 1.9.3 regular maintenance end Feb. 2014, security maintenance end Feb. 2015.  Time to move to 2.0\/2.1! https:\/\/t.co\/gSjQzACMnX",
  "id" : 423863157711335424,
  "created_at" : "2014-01-16 17:03:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 17, 24 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/Wjor0Fkvav",
      "expanded_url" : "https:\/\/github.com\/github\/markup\/issues\/237",
      "display_url" : "github.com\/github\/markup\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422825402222931968",
  "text" : "Could someone at @github please take a look at my markup gem question\/issue at https:\/\/t.co\/Wjor0Fkvav?",
  "id" : 422825402222931968,
  "created_at" : "2014-01-13 20:20:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freegovinfo",
      "screen_name" : "freegovinfo",
      "indices" : [ 3, 15 ],
      "id_str" : "12006852",
      "id" : 12006852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/freegovinfo\/status\/421706670180282368\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/72hwv0J4kP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdoz-2lCEAA5qgG.jpg",
      "id_str" : "421706670008307712",
      "id" : 421706670008307712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdoz-2lCEAA5qgG.jpg",
      "sizes" : [ {
        "h" : 414,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 276,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 510
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 510
      } ],
      "display_url" : "pic.twitter.com\/72hwv0J4kP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422790002561781760",
  "text" : "RT @freegovinfo: bug or feature? http:\/\/t.co\/72hwv0J4kP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/freegovinfo\/status\/421706670180282368\/photo\/1",
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/72hwv0J4kP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdoz-2lCEAA5qgG.jpg",
        "id_str" : "421706670008307712",
        "id" : 421706670008307712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdoz-2lCEAA5qgG.jpg",
        "sizes" : [ {
          "h" : 414,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 276,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 510
        } ],
        "display_url" : "pic.twitter.com\/72hwv0J4kP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421706670180282368",
    "text" : "bug or feature? http:\/\/t.co\/72hwv0J4kP",
    "id" : 421706670180282368,
    "created_at" : "2014-01-10 18:14:39 +0000",
    "user" : {
      "name" : "Freegovinfo",
      "screen_name" : "freegovinfo",
      "protected" : false,
      "id_str" : "12006852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762700285902884864\/x8BjkqrR_normal.jpg",
      "id" : 12006852,
      "verified" : false
    }
  },
  "id" : 422790002561781760,
  "created_at" : "2014-01-13 17:59:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422493718130618368",
  "text" : "In Chipotle, angry at the mom who let her twin boys shriek, then remembering that I was a shrieking twin boy once. Spoke w\/her and saluted.",
  "id" : 422493718130618368,
  "created_at" : "2014-01-12 22:22:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/H0reedJoZx",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/8388759",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "422441157453307904",
  "text" : "I tried to gem install gollum but got build errors (see https:\/\/t.co\/H0reedJoZx) and don't know how to proceed.",
  "id" : 422441157453307904,
  "created_at" : "2014-01-12 18:53:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422439675463081984",
  "text" : "Any recommendations for a personal use wiki that is git-friendly, cross platform (mainly Mac\/Linux), self-hosting, and simple to set up?",
  "id" : 422439675463081984,
  "created_at" : "2014-01-12 18:47:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "indices" : [ 3, 16 ],
      "id_str" : "19768213",
      "id" : 19768213
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 78, 92 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/Srr0vqaLcf",
      "expanded_url" : "http:\/\/www.meetup.com\/bmore-on-rails\/events\/154984732\/",
      "display_url" : "meetup.com\/bmore-on-rails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421757553186705408",
  "text" : "RT @bmoreonrails: Ruby lambdas are pretty great. Find out just how great from @keithrbennett this Tues: http:\/\/t.co\/Srr0vqaLcf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 60, 74 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/Srr0vqaLcf",
        "expanded_url" : "http:\/\/www.meetup.com\/bmore-on-rails\/events\/154984732\/",
        "display_url" : "meetup.com\/bmore-on-rails\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421752198755012608",
    "text" : "Ruby lambdas are pretty great. Find out just how great from @keithrbennett this Tues: http:\/\/t.co\/Srr0vqaLcf",
    "id" : 421752198755012608,
    "created_at" : "2014-01-10 21:15:34 +0000",
    "user" : {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "protected" : false,
      "id_str" : "19768213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843097247\/logo64square_normal.png",
      "id" : 19768213,
      "verified" : false
    }
  },
  "id" : 421757553186705408,
  "created_at" : "2014-01-10 21:36:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/E3jQ0mgPYm",
      "expanded_url" : "https:\/\/bitbucket.org\/",
      "display_url" : "bitbucket.org"
    } ]
  },
  "in_reply_to_status_id_str" : "421377605439614977",
  "geo" : { },
  "id_str" : "421391902957502466",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi https:\/\/t.co\/E3jQ0mgPYm offers free private git repos.  I use them for my private repos and Github for my public ones.",
  "id" : 421391902957502466,
  "in_reply_to_status_id" : 421377605439614977,
  "created_at" : "2014-01-09 21:23:53 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitter.com\/#!\/joenrv\" rel=\"nofollow\"\u003EFalcon for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "421363644979765248",
  "geo" : { },
  "id_str" : "421364486180990976",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Absolutely, that would be great.",
  "id" : 421364486180990976,
  "in_reply_to_status_id" : 421363644979765248,
  "created_at" : "2014-01-09 19:34:56 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Kk6PAE3M9N",
      "expanded_url" : "http:\/\/www.meetup.com\/bmore-on-rails\/events\/154984732\/?_af_eid=154984732&a=uc1_vm&_af=event",
      "display_url" : "meetup.com\/bmore-on-rails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421350255620149248",
  "text" : "I'm speaking about Ruby lambdas at the Baltimore RUG next Tuesday (see http:\/\/t.co\/Kk6PAE3M9N). Still developing content, any suggestions?",
  "id" : 421350255620149248,
  "created_at" : "2014-01-09 18:38:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "About Programming",
      "screen_name" : "abt_programming",
      "indices" : [ 3, 19 ],
      "id_str" : "1606588254",
      "id" : 1606588254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420215506936037376",
  "text" : "RT @abt_programming: \"If we wish to count lines of code, we should not regard them as 'lines produced' but as 'lines spent'\" - Edsger Dijks\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420197573920825344",
    "text" : "\"If we wish to count lines of code, we should not regard them as 'lines produced' but as 'lines spent'\" - Edsger Dijkstra",
    "id" : 420197573920825344,
    "created_at" : "2014-01-06 14:18:03 +0000",
    "user" : {
      "name" : "About Programming",
      "screen_name" : "abt_programming",
      "protected" : false,
      "id_str" : "1606588254",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000232458460\/b5d097e08c63a6530e9751bcb0a13a57_normal.png",
      "id" : 1606588254,
      "verified" : false
    }
  },
  "id" : 420215506936037376,
  "created_at" : "2014-01-06 15:29:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pandoc",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419334794406035456",
  "geo" : { },
  "id_str" : "419936513770549248",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH with --self-contained flag, #pandoc will insert CSS for Ruby syntax highlighting, but, sadly for me, no Cucumber\/Gherkin.",
  "id" : 419936513770549248,
  "in_reply_to_status_id" : 419334794406035456,
  "created_at" : "2014-01-05 21:00:41 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Westman",
      "screen_name" : "westmaaan",
      "indices" : [ 0, 10 ],
      "id_str" : "21426674",
      "id" : 21426674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/QojvowF57O",
      "expanded_url" : "http:\/\/bitbucket.org",
      "display_url" : "bitbucket.org"
    } ]
  },
  "in_reply_to_status_id_str" : "419100944077303808",
  "geo" : { },
  "id_str" : "419519903024947200",
  "in_reply_to_user_id" : 21426674,
  "text" : "@westmaaan If you're paying Github for private repos, http:\/\/t.co\/QojvowF57O offers them for free.",
  "id" : 419519903024947200,
  "in_reply_to_status_id" : 419100944077303808,
  "created_at" : "2014-01-04 17:25:13 +0000",
  "in_reply_to_screen_name" : "westmaaan",
  "in_reply_to_user_id_str" : "21426674",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "419273733103427584",
  "geo" : { },
  "id_str" : "419278469617287168",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH It does do &lt;pre lang=\"ruby\"&gt;, but doesn't parse the code into spans. Pandoc makes spans w\/classes, but where is the CSS to render it?",
  "id" : 419278469617287168,
  "in_reply_to_status_id" : 419273733103427584,
  "created_at" : "2014-01-04 01:25:51 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419239849858568192",
  "text" : "I want to convert an .md file with ```ruby text to HTML. GitHub::Markdown.render_gfm sees the ``` but ignores the ruby. Ideas, other tools?",
  "id" : 419239849858568192,
  "created_at" : "2014-01-03 22:52:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]