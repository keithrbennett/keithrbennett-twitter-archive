Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tech Humans",
      "screen_name" : "TechHumans",
      "indices" : [ 3, 14 ],
      "id_str" : "719481968",
      "id" : 719481968
    }, {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 32, 44 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229709383880298496",
  "text" : "RT @TechHumans: Our first post: @coreyhaines discusses his pair programming journey and thoughts on s\/w engineering, at http:\/\/t.co\/qFyj ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
        "screen_name" : "coreyhaines",
        "indices" : [ 16, 28 ],
        "id_str" : "11458102",
        "id" : 11458102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/qFyjG4HN",
        "expanded_url" : "http:\/\/www.techhumans.com\/2012\/07\/27\/interview-with-corey-haines-august-2011\/",
        "display_url" : "techhumans.com\/2012\/07\/27\/int\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "229706824633421825",
    "text" : "Our first post: @coreyhaines discusses his pair programming journey and thoughts on s\/w engineering, at http:\/\/t.co\/qFyjG4HN.",
    "id" : 229706824633421825,
    "created_at" : "2012-07-29 22:35:49 +0000",
    "user" : {
      "name" : "Tech Humans",
      "screen_name" : "TechHumans",
      "protected" : false,
      "id_str" : "719481968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2446317296\/5m3fvb2q784ty53nmnas_normal.png",
      "id" : 719481968,
      "verified" : false
    }
  },
  "id" : 229709383880298496,
  "created_at" : "2012-07-29 22:45:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tech Humans",
      "screen_name" : "TechHumans",
      "indices" : [ 3, 14 ],
      "id_str" : "719481968",
      "id" : 719481968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/2EY6vmXD",
      "expanded_url" : "http:\/\/www.techhumans.com",
      "display_url" : "techhumans.com"
    } ]
  },
  "geo" : { },
  "id_str" : "229709268104921089",
  "text" : "RT @TechHumans: Welcome to our new blog at http:\/\/t.co\/2EY6vmXD where we discuss the human aspects of software engineering.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/2EY6vmXD",
        "expanded_url" : "http:\/\/www.techhumans.com",
        "display_url" : "techhumans.com"
      } ]
    },
    "geo" : { },
    "id_str" : "229705130109435905",
    "text" : "Welcome to our new blog at http:\/\/t.co\/2EY6vmXD where we discuss the human aspects of software engineering.",
    "id" : 229705130109435905,
    "created_at" : "2012-07-29 22:29:05 +0000",
    "user" : {
      "name" : "Tech Humans",
      "screen_name" : "TechHumans",
      "protected" : false,
      "id_str" : "719481968",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2446317296\/5m3fvb2q784ty53nmnas_normal.png",
      "id" : 719481968,
      "verified" : false
    }
  },
  "id" : 229709268104921089,
  "created_at" : "2012-07-29 22:45:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229698987756761089",
  "text" : "Putting final touches on the blog before the launch.",
  "id" : 229698987756761089,
  "created_at" : "2012-07-29 22:04:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Up7kkGXk",
      "expanded_url" : "http:\/\/vimeo.com\/album\/2009304",
      "display_url" : "vimeo.com\/album\/2009304"
    } ]
  },
  "geo" : { },
  "id_str" : "229296952272109568",
  "text" : "JRubyConf 2012 screencasts now available on vimeo at http:\/\/t.co\/Up7kkGXk.",
  "id" : 229296952272109568,
  "created_at" : "2012-07-28 19:27:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "229073311798292482",
  "text" : "RT @climagic: How many system administrators users does it take to change a lightbulb? None, there is a cronjob for that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228944857895424000",
    "text" : "How many system administrators users does it take to change a lightbulb? None, there is a cronjob for that.",
    "id" : 228944857895424000,
    "created_at" : "2012-07-27 20:08:02 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 229073311798292482,
  "created_at" : "2012-07-28 04:38:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228915380108791809",
  "text" : "Any thoughts\/strong feelings about having Google AdSense ads on a blog site? Would be nice to get even a homeopathic sized income from it.",
  "id" : 228915380108791809,
  "created_at" : "2012-07-27 18:10:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Barry",
      "screen_name" : "pjb3",
      "indices" : [ 0, 5 ],
      "id_str" : "14306648",
      "id" : 14306648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "228877235732484096",
  "geo" : { },
  "id_str" : "228914421194448896",
  "in_reply_to_user_id" : 14306648,
  "text" : "@pjb3 Absolutely, YYYY-MM-DD is the most locale-neutral date representation.  I'd go as far as declaring it the normalized date format.",
  "id" : 228914421194448896,
  "in_reply_to_status_id" : 228877235732484096,
  "created_at" : "2012-07-27 18:07:05 +0000",
  "in_reply_to_screen_name" : "pjb3",
  "in_reply_to_user_id_str" : "14306648",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sau Sheong",
      "screen_name" : "sausheong",
      "indices" : [ 3, 13 ],
      "id_str" : "11879822",
      "id" : 11879822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "228190067976450048",
  "text" : "RT @sausheong: Stunned moment when I saw my wife using my iPad then double-take as it's not turned on -- she was using it as a mirror!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "228128761646825472",
    "text" : "Stunned moment when I saw my wife using my iPad then double-take as it's not turned on -- she was using it as a mirror!",
    "id" : 228128761646825472,
    "created_at" : "2012-07-25 14:05:09 +0000",
    "user" : {
      "name" : "Sau Sheong",
      "screen_name" : "sausheong",
      "protected" : false,
      "id_str" : "11879822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586534241799766017\/jN4Y6OPR_normal.jpg",
      "id" : 11879822,
      "verified" : false
    }
  },
  "id" : 228190067976450048,
  "created_at" : "2012-07-25 18:08:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/D8x3f6p7",
      "expanded_url" : "http:\/\/krbtech.wordpress.com\/2012\/07\/25\/mailing-files-programmatically-with-gmail\/",
      "display_url" : "krbtech.wordpress.com\/2012\/07\/25\/mai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "228189880591724544",
  "text" : "Just posted a new blog article and source code, \"Mailing Files Programmatically with GMail\", at http:\/\/t.co\/D8x3f6p7.",
  "id" : 228189880591724544,
  "created_at" : "2012-07-25 18:08:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 0, 14 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyretro",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226739871711105024",
  "in_reply_to_user_id" : 284339167,
  "text" : "@arlingtonruby Happy to be at the open space conference Ruby Retrocession in Arlington, Virginia, USA. +1 for open space confs.  #rubyretro",
  "id" : 226739871711105024,
  "created_at" : "2012-07-21 18:06:12 +0000",
  "in_reply_to_screen_name" : "arlingtonruby",
  "in_reply_to_user_id_str" : "284339167",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Barry",
      "screen_name" : "pjb3",
      "indices" : [ 0, 5 ],
      "id_str" : "14306648",
      "id" : 14306648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226423226543247362",
  "geo" : { },
  "id_str" : "226426517469667328",
  "in_reply_to_user_id" : 14306648,
  "text" : "@pjb3 Thanks. I halved the output bit rate from 44100 to 22050 (same as input rate), but that only reduced output file size from 46 to 39M.",
  "id" : 226426517469667328,
  "in_reply_to_status_id" : 226423226543247362,
  "created_at" : "2012-07-20 21:21:03 +0000",
  "in_reply_to_screen_name" : "pjb3",
  "in_reply_to_user_id_str" : "14306648",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Troy",
      "screen_name" : "davetroy",
      "indices" : [ 0, 9 ],
      "id_str" : "4848301",
      "id" : 4848301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "226416482672852992",
  "geo" : { },
  "id_str" : "226423298421043201",
  "in_reply_to_user_id" : 4848301,
  "text" : "@davetroy How about \"haricots verts\"?  Both the noun and the adjective need to be pluralized.",
  "id" : 226423298421043201,
  "in_reply_to_status_id" : 226416482672852992,
  "created_at" : "2012-07-20 21:08:15 +0000",
  "in_reply_to_screen_name" : "davetroy",
  "in_reply_to_user_id_str" : "4848301",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "226422863966658561",
  "text" : "With 2 MP3 files totaling 17 MB as input, why does Audacity create a combined file that's 46 MB?  Is there a better way to combine them?",
  "id" : 226422863966658561,
  "created_at" : "2012-07-20 21:06:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "225619465654636545",
  "geo" : { },
  "id_str" : "225631260855386112",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Now they know what Linux users feel like. :-)",
  "id" : 225631260855386112,
  "in_reply_to_status_id" : 225619465654636545,
  "created_at" : "2012-07-18 16:40:59 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vyacheslav Egorov",
      "screen_name" : "mraleph",
      "indices" : [ 3, 11 ],
      "id_str" : "53010195",
      "id" : 53010195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225629531308949506",
  "text" : "RT @mraleph: No SciFi author foresaw this: we are building clans around languages we speak to the Machine.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225587192427327488",
    "text" : "No SciFi author foresaw this: we are building clans around languages we speak to the Machine.",
    "id" : 225587192427327488,
    "created_at" : "2012-07-18 13:45:52 +0000",
    "user" : {
      "name" : "Vyacheslav Egorov",
      "screen_name" : "mraleph",
      "protected" : false,
      "id_str" : "53010195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428865653903081472\/XqtZKTVu_normal.png",
      "id" : 53010195,
      "verified" : false
    }
  },
  "id" : 225629531308949506,
  "created_at" : "2012-07-18 16:34:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225257813218295808",
  "text" : "ADP web site colossal fail. IE tested only, others fail silently. Silly counterproductive password constraints. &lt;= 15 day processing times.",
  "id" : 225257813218295808,
  "created_at" : "2012-07-17 15:57:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Abis",
      "screen_name" : "capotribu",
      "indices" : [ 3, 13 ],
      "id_str" : "14830884",
      "id" : 14830884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/E74PhE88",
      "expanded_url" : "http:\/\/arcticready.com\/social\/gallery?sort_by=value&sort_order=DESC",
      "display_url" : "arcticready.com\/social\/gallery\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "224917795903778818",
  "text" : "RT @capotribu: \"hilarious\" screw-up by Shell at \"social media\" http:\/\/t.co\/E74PhE88 &lt; read the slogans people added to the images",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/E74PhE88",
        "expanded_url" : "http:\/\/arcticready.com\/social\/gallery?sort_by=value&sort_order=DESC",
        "display_url" : "arcticready.com\/social\/gallery\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "224880805938348032",
    "text" : "\"hilarious\" screw-up by Shell at \"social media\" http:\/\/t.co\/E74PhE88 &lt; read the slogans people added to the images",
    "id" : 224880805938348032,
    "created_at" : "2012-07-16 14:58:56 +0000",
    "user" : {
      "name" : "Marco Abis",
      "screen_name" : "capotribu",
      "protected" : false,
      "id_str" : "14830884",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675993369399730176\/XWb6MyjE_normal.png",
      "id" : 14830884,
      "verified" : false
    }
  },
  "id" : 224917795903778818,
  "created_at" : "2012-07-16 17:25:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/vZ4xwHWz",
      "expanded_url" : "http:\/\/wordpress.com",
      "display_url" : "wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "224676200839262209",
  "text" : "Recommendations for blog hosts\/software?  Been using http:\/\/t.co\/vZ4xwHWz. Looking for ease of use\/config, rich functionality, possibly ads.",
  "id" : 224676200839262209,
  "created_at" : "2012-07-16 01:25:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "dcrug",
      "screen_name" : "dcrug",
      "indices" : [ 0, 6 ],
      "id_str" : "16994623",
      "id" : 16994623
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223542661880098816",
  "in_reply_to_user_id" : 16994623,
  "text" : "@dcrug 'ers, I'm having some great bi bim bap with brown rice at \"Lighter\", 1400 I St. at the McPherson Sq metro, join me!",
  "id" : 223542661880098816,
  "created_at" : "2012-07-12 22:21:38 +0000",
  "in_reply_to_screen_name" : "dcrug",
  "in_reply_to_user_id_str" : "16994623",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/hCPNtql7",
      "expanded_url" : "http:\/\/www.fullcontact.com\/2012\/07\/10\/paid-paid-vacation\/",
      "display_url" : "fullcontact.com\/2012\/07\/10\/pai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "223116782339231745",
  "text" : "http:\/\/t.co\/hCPNtql7 paraphrased: \"Hero syndrome is not heroic; it is single point of failure.\"",
  "id" : 223116782339231745,
  "created_at" : "2012-07-11 18:09:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trustbutverify",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "223033717776596994",
  "text" : "Just used Fujitsu ScanSnap and Araxis Merge to verify that my copy and the rental office's copy of my lease are the same. #trustbutverify",
  "id" : 223033717776596994,
  "created_at" : "2012-07-11 12:39:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "indices" : [ 3, 14 ],
      "id_str" : "35954885",
      "id" : 35954885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/SrNG6EWG",
      "expanded_url" : "http:\/\/apod.nasa.gov\/apod\/ap120710.html",
      "display_url" : "apod.nasa.gov\/apod\/ap120710.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222680841090895873",
  "text" : "RT @joshsusser: Forget prime numbers, DNA, and hydrogen lines. This should be how we represent humanity to the stars. http:\/\/t.co\/SrNG6EWG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/SrNG6EWG",
        "expanded_url" : "http:\/\/apod.nasa.gov\/apod\/ap120710.html",
        "display_url" : "apod.nasa.gov\/apod\/ap120710.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "222592698601836544",
    "text" : "Forget prime numbers, DNA, and hydrogen lines. This should be how we represent humanity to the stars. http:\/\/t.co\/SrNG6EWG",
    "id" : 222592698601836544,
    "created_at" : "2012-07-10 07:26:49 +0000",
    "user" : {
      "name" : "Josh Susser",
      "screen_name" : "joshsusser",
      "protected" : false,
      "id_str" : "35954885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614490649711087616\/gjeg_6nP_normal.jpg",
      "id" : 35954885,
      "verified" : false
    }
  },
  "id" : 222680841090895873,
  "created_at" : "2012-07-10 13:17:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/5CTHYcFX",
      "expanded_url" : "http:\/\/reviews.cnet.com\/8301-13727_7-57423014-263\/how-to-install-and-uninstall-java-7-for-os-x\/",
      "display_url" : "reviews.cnet.com\/8301-13727_7-5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "222385907490226176",
  "text" : "Anyone have any feedback on using Java 7 on Mac OS?  Found this article for installing it (Lion only though): http:\/\/t.co\/5CTHYcFX.",
  "id" : 222385907490226176,
  "created_at" : "2012-07-09 17:45:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "androiddev",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221668097818509314",
  "text" : "#androiddev community -- why not incorporate HAML into your dev process to make XML less painful and reduce dependence on Eclipse?",
  "id" : 221668097818509314,
  "created_at" : "2012-07-07 18:12:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221663423904219136",
  "text" : "If u are in the E\/MidW US heat wave, pls offer your mail carrier a cold drink. No relief for them even in their trucks, which have no A\/C.",
  "id" : 221663423904219136,
  "created_at" : "2012-07-07 17:54:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan HorstmannAllen",
      "screen_name" : "bdha",
      "indices" : [ 3, 8 ],
      "id_str" : "21226447",
      "id" : 21226447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221647578813575168",
  "text" : "RT @bdha: \"You know why 90% of people don't feel fulfilled by the work they do? It's not the job, it's because we don't help each other  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "221395094387957760",
    "text" : "\"You know why 90% of people don't feel fulfilled by the work they do? It's not the job, it's because we don't help each other anymore.\"",
    "id" : 221395094387957760,
    "created_at" : "2012-07-07 00:07:58 +0000",
    "user" : {
      "name" : "Bryan HorstmannAllen",
      "screen_name" : "bdha",
      "protected" : false,
      "id_str" : "21226447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1290302189\/image_normal.jpg",
      "id" : 21226447,
      "verified" : false
    }
  },
  "id" : 221647578813575168,
  "created_at" : "2012-07-07 16:51:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker Deck",
      "screen_name" : "speakerdeck",
      "indices" : [ 10, 22 ],
      "id_str" : "144190968",
      "id" : 144190968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221391630136115200",
  "text" : "Thanks to @speakerdeck for the speedy and helpful tech support.  So glad I switched from slideshare.",
  "id" : 221391630136115200,
  "created_at" : "2012-07-06 23:54:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 0, 8 ],
      "id_str" : "38699900",
      "id" : 38699900
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 9, 14 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "John Wilger",
      "screen_name" : "jwilger",
      "indices" : [ 16, 24 ],
      "id_str" : "7299852",
      "id" : 7299852
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 59, 64 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "220552237288652800",
  "geo" : { },
  "id_str" : "220591820160249856",
  "in_reply_to_user_id" : 38699900,
  "text" : "@geeksam @avdi  @jwilger No, I'm still available.  I think @avdi was just retweeting for my benefit.",
  "id" : 220591820160249856,
  "in_reply_to_status_id" : 220552237288652800,
  "created_at" : "2012-07-04 18:56:02 +0000",
  "in_reply_to_screen_name" : "geeksam",
  "in_reply_to_user_id_str" : "38699900",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220489044507885568",
  "text" : "Anyone need some help, or interested in collaborating, coworking, or pair programming for a couple of hours?",
  "id" : 220489044507885568,
  "created_at" : "2012-07-04 12:07:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 3, 15 ],
      "id_str" : "14979481",
      "id" : 14979481
    }, {
      "name" : "Nayan Hajratwala",
      "screen_name" : "nhajratw",
      "indices" : [ 17, 26 ],
      "id_str" : "15012673",
      "id" : 15012673
    }, {
      "name" : "Kent Beck",
      "screen_name" : "KentBeck",
      "indices" : [ 54, 63 ],
      "id_str" : "16891384",
      "id" : 16891384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "219535991365566467",
  "text" : "RT @RonJeffries: @nhajratw among the many wise things @KentBeck said, one of the wisest is \"A comment is the code's way of asking to be  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nayan Hajratwala",
        "screen_name" : "nhajratw",
        "indices" : [ 0, 9 ],
        "id_str" : "15012673",
        "id" : 15012673
      }, {
        "name" : "Kent Beck",
        "screen_name" : "KentBeck",
        "indices" : [ 37, 46 ],
        "id_str" : "16891384",
        "id" : 16891384
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "206011083557830657",
    "geo" : { },
    "id_str" : "206011392111816704",
    "in_reply_to_user_id" : 15012673,
    "text" : "@nhajratw among the many wise things @KentBeck said, one of the wisest is \"A comment is the code's way of asking to be more clear\".",
    "id" : 206011392111816704,
    "in_reply_to_status_id" : 206011083557830657,
    "created_at" : "2012-05-25 13:18:38 +0000",
    "in_reply_to_screen_name" : "nhajratw",
    "in_reply_to_user_id_str" : "15012673",
    "user" : {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "protected" : false,
      "id_str" : "14979481",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479052206260244480\/WQA0NXQT_normal.jpeg",
      "id" : 14979481,
      "verified" : false
    }
  },
  "id" : 219535991365566467,
  "created_at" : "2012-07-01 21:00:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]