Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "108022669122867200",
  "geo" : { },
  "id_str" : "108024811363639297",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi  The businesses with the highest profit margins  can best afford to do a Groupon.  Most  useless to me, but some good (flying lesson).",
  "id" : 108024811363639297,
  "in_reply_to_status_id" : 108022669122867200,
  "created_at" : "2011-08-29 03:54:56 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107990798074773504",
  "geo" : { },
  "id_str" : "107993079637753856",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight  I'm glad to see that despite the storm you're back to your usual cheerful self. ;)",
  "id" : 107993079637753856,
  "in_reply_to_status_id" : 107990798074773504,
  "created_at" : "2011-08-29 01:48:51 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107983159110545408",
  "geo" : { },
  "id_str" : "107991217748443136",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms  I'm in a western DC suburb, well outside the cone. Strong winds and heavy rains, but  not nearly as bad as feared.",
  "id" : 107991217748443136,
  "in_reply_to_status_id" : 107983159110545408,
  "created_at" : "2011-08-29 01:41:27 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "107965773976317952",
  "geo" : { },
  "id_str" : "107979639523250176",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms  A functional open space conference is a great idea!  I'd probably attend.  Where, Columbus?",
  "id" : 107979639523250176,
  "in_reply_to_status_id" : 107965773976317952,
  "created_at" : "2011-08-29 00:55:26 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107975475837669376",
  "text" : "Even awesome technology cannot approach the beauty and majesty of the vast 3D hemispheric view of the lush green earth and blue sky.",
  "id" : 107975475837669376,
  "created_at" : "2011-08-29 00:38:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "indices" : [ 3, 12 ],
      "id_str" : "20173708",
      "id" : 20173708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 123 ],
      "url" : "http:\/\/t.co\/ziKODwZ",
      "expanded_url" : "http:\/\/bit.ly\/2eCPrF",
      "display_url" : "bit.ly\/2eCPrF"
    } ]
  },
  "geo" : { },
  "id_str" : "107518112252952577",
  "text" : "RT @adomokos: Steve Jobs' 2005 Stanford Commencement Address. Very inspirational, you need to watch it: http:\/\/t.co\/ziKODwZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 109 ],
        "url" : "http:\/\/t.co\/ziKODwZ",
        "expanded_url" : "http:\/\/bit.ly\/2eCPrF",
        "display_url" : "bit.ly\/2eCPrF"
      } ]
    },
    "geo" : { },
    "id_str" : "107140040001470464",
    "text" : "Steve Jobs' 2005 Stanford Commencement Address. Very inspirational, you need to watch it: http:\/\/t.co\/ziKODwZ",
    "id" : 107140040001470464,
    "created_at" : "2011-08-26 17:19:10 +0000",
    "user" : {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "protected" : false,
      "id_str" : "20173708",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1660852491\/adomokos_bw_normal.png",
      "id" : 20173708,
      "verified" : false
    }
  },
  "id" : 107518112252952577,
  "created_at" : "2011-08-27 18:21:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107203240709472256",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms Yes, I do remember you, and have been following your reflective tweets since then.  Greatly enjoyed karaoke with you and Tracy.",
  "id" : 107203240709472256,
  "created_at" : "2011-08-26 21:30:18 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Troy",
      "screen_name" : "davetroy",
      "indices" : [ 3, 12 ],
      "id_str" : "4848301",
      "id" : 4848301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 89 ],
      "url" : "http:\/\/t.co\/ktKwNld",
      "expanded_url" : "http:\/\/bit.ly\/neo7U4",
      "display_url" : "bit.ly\/neo7U4"
    } ]
  },
  "geo" : { },
  "id_str" : "106893777288957952",
  "text" : "RT @davetroy: Stormpulse looks to be a great tool for tracking Irene! http:\/\/t.co\/ktKwNld",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 75 ],
        "url" : "http:\/\/t.co\/ktKwNld",
        "expanded_url" : "http:\/\/bit.ly\/neo7U4",
        "display_url" : "bit.ly\/neo7U4"
      } ]
    },
    "geo" : { },
    "id_str" : "106873278316023808",
    "text" : "Stormpulse looks to be a great tool for tracking Irene! http:\/\/t.co\/ktKwNld",
    "id" : 106873278316023808,
    "created_at" : "2011-08-25 23:39:09 +0000",
    "user" : {
      "name" : "Dave Troy",
      "screen_name" : "davetroy",
      "protected" : false,
      "id_str" : "4848301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/603943033420124161\/QdeGTDEX_normal.jpg",
      "id" : 4848301,
      "verified" : false
    }
  },
  "id" : 106893777288957952,
  "created_at" : "2011-08-26 01:00:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106765415828566016",
  "text" : "Trying to teach myself that sometimes the best thing to say is nothing at all.",
  "id" : 106765415828566016,
  "created_at" : "2011-08-25 16:30:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scna2011",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "106089975099031552",
  "geo" : { },
  "id_str" : "106115417382199296",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano Bon Voyage and best of luck in your new life in Chicago.  Benefit for you: No air fare or hotel for #scna2011 -- you going?",
  "id" : 106115417382199296,
  "in_reply_to_status_id" : 106089975099031552,
  "created_at" : "2011-08-23 21:27:41 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris breish",
      "screen_name" : "cbreish",
      "indices" : [ 3, 11 ],
      "id_str" : "36370691",
      "id" : 36370691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 77 ],
      "url" : "http:\/\/t.co\/kaA6C5C",
      "expanded_url" : "http:\/\/bit.ly\/mXrKdy",
      "display_url" : "bit.ly\/mXrKdy"
    } ]
  },
  "geo" : { },
  "id_str" : "106071920713281536",
  "text" : "RT @cbreish: Pics from DC of the earthquake's destruction http:\/\/t.co\/kaA6C5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.metrotwit.com\/\" rel=\"nofollow\"\u003EMetroTwit\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 64 ],
        "url" : "http:\/\/t.co\/kaA6C5C",
        "expanded_url" : "http:\/\/bit.ly\/mXrKdy",
        "display_url" : "bit.ly\/mXrKdy"
      } ]
    },
    "geo" : { },
    "id_str" : "106067470867116032",
    "text" : "Pics from DC of the earthquake's destruction http:\/\/t.co\/kaA6C5C",
    "id" : 106067470867116032,
    "created_at" : "2011-08-23 18:17:10 +0000",
    "user" : {
      "name" : "chris breish",
      "screen_name" : "cbreish",
      "protected" : false,
      "id_str" : "36370691",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1622354275\/Ip42Dg4k_normal",
      "id" : 36370691,
      "verified" : false
    }
  },
  "id" : 106071920713281536,
  "created_at" : "2011-08-23 18:34:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106064497860546560",
  "text" : "RT @avdi: STOP TWEETING AND GET SOME FRESH AIR --God",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "106064143873867777",
    "text" : "STOP TWEETING AND GET SOME FRESH AIR --God",
    "id" : 106064143873867777,
    "created_at" : "2011-08-23 18:03:57 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 106064497860546560,
  "created_at" : "2011-08-23 18:05:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "106061916513906688",
  "text" : "Earthquake tremor in Reston Virginia. Office evacuated.",
  "id" : 106061916513906688,
  "created_at" : "2011-08-23 17:55:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 10, 15 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105632466840203264",
  "text" : "Link from @avdi:  http:\/\/ow.ly\/68ZqT;  Introducing the term \"refurbishing\" to  replace \"refactoring\" for extensive structural redevelopment.",
  "id" : 105632466840203264,
  "created_at" : "2011-08-22 13:28:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105487634129879040",
  "text" : "Saw the new nation of South Sudan on a map for the first time, on Google Earth -- is Texas next?",
  "id" : 105487634129879040,
  "created_at" : "2011-08-22 03:53:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "105100657140314112",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines I enjoyed the discussion and interview last Thursday. I look forward to SCNA. Ppl, Corey rocks. :)",
  "id" : 105100657140314112,
  "created_at" : "2011-08-21 02:15:23 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104974423592927232",
  "geo" : { },
  "id_str" : "105099603854098432",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer I majored in acctng -- basic and cost accntng are logical - financial and tax not so.",
  "id" : 105099603854098432,
  "in_reply_to_status_id" : 104974423592927232,
  "created_at" : "2011-08-21 02:11:12 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Tomhave",
      "screen_name" : "falconsview",
      "indices" : [ 3, 15 ],
      "id_str" : "28112807",
      "id" : 28112807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104661479143387136",
  "text" : "RT @falconsview: from a friend: \"I'd tell you a UDP joke, but you might not get it.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "104615882340319232",
    "text" : "from a friend: \"I'd tell you a UDP joke, but you might not get it.\"",
    "id" : 104615882340319232,
    "created_at" : "2011-08-19 18:09:04 +0000",
    "user" : {
      "name" : "Ben Tomhave",
      "screen_name" : "falconsview",
      "protected" : false,
      "id_str" : "28112807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1096400884\/Maine_023_normal.jpg",
      "id" : 28112807,
      "verified" : false
    }
  },
  "id" : 104661479143387136,
  "created_at" : "2011-08-19 21:10:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104577494212022272",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight My bad, you said MBA, I heard MBP.  Doh!!!",
  "id" : 104577494212022272,
  "created_at" : "2011-08-19 15:36:32 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104321960275742720",
  "geo" : { },
  "id_str" : "104345750514835457",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight I thought so too. Try this to find out: About this Mac, More Info, then select Graphics\/Displays. I have Intel, Nvidia.",
  "id" : 104345750514835457,
  "in_reply_to_status_id" : 104321960275742720,
  "created_at" : "2011-08-19 00:15:40 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104294910391361536",
  "text" : "Re: battery usage, Pandora was sitting in \"Are you listening?\" mode, and Flash was using 30% CPU doing nothing!",
  "id" : 104294910391361536,
  "created_at" : "2011-08-18 20:53:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "104269125236441088",
  "geo" : { },
  "id_str" : "104293350143836160",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl Do tell (comment on the article?), what about technical debt?",
  "id" : 104293350143836160,
  "in_reply_to_status_id" : 104269125236441088,
  "created_at" : "2011-08-18 20:47:27 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "104292709610696704",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight To preserve Mac battery, have u tried gfxCardStatus?  It lets u control which video adapter to use, and can double battery duration.",
  "id" : 104292709610696704,
  "created_at" : "2011-08-18 20:44:54 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 0, 8 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "102908787127627776",
  "geo" : { },
  "id_str" : "102915340501131264",
  "in_reply_to_user_id" : 1235521,
  "text" : "@timbray  Roombas are awesome.  That clean carpet look and feel with close to zero effort.",
  "id" : 102915340501131264,
  "in_reply_to_status_id" : 102908787127627776,
  "created_at" : "2011-08-15 01:31:43 +0000",
  "in_reply_to_screen_name" : "timbray",
  "in_reply_to_user_id_str" : "1235521",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "102885350434811904",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines Would be great to meet u in Reston. We met at SDTConf  ~ 2 yrs ago in Chicago, I blv. Maybe interview u re: your teaching exp.",
  "id" : 102885350434811904,
  "created_at" : "2011-08-14 23:32:33 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101279857161420800",
  "text" : "RT @avdi: Picking hardware based on OS support used to be a crazy Linux thing, but now all the Mac users have totally normalized it ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "101190390169862144",
    "text" : "Picking hardware based on OS support used to be a crazy Linux thing, but now all the Mac users have totally normalized it ;-)",
    "id" : 101190390169862144,
    "created_at" : "2011-08-10 07:17:23 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 101279857161420800,
  "created_at" : "2011-08-10 13:12:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99179856004251648",
  "text" : "JRuby's Profiler + the awesome free JVisualVM that comes with JDK, could be useful for inspecting C Ruby prog's temporarily run in JRuby.",
  "id" : 99179856004251648,
  "created_at" : "2011-08-04 18:08:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JRubyConf",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99177963660132353",
  "text" : "Listening to Nick Sieger's talk on JRuby tools at #JRubyConf -- JRuby's Profiler has an API and can produce text tables and graphs.",
  "id" : 99177963660132353,
  "created_at" : "2011-08-04 18:00:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]