Grailbird.data.tweets_2013_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emergency Kittens",
      "screen_name" : "EmrgencyKittens",
      "indices" : [ 3, 19 ],
      "id_str" : "1041346340",
      "id" : 1041346340
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EmrgencyKittens\/status\/351415907056250880\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/amKOSmYDPb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOB659TCcAAx9U-.jpg",
      "id_str" : "351415907060445184",
      "id" : 351415907060445184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOB659TCcAAx9U-.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/amKOSmYDPb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351530108865085441",
  "text" : "RT @EmrgencyKittens: http:\/\/t.co\/amKOSmYDPb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EmrgencyKittens\/status\/351415907056250880\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/amKOSmYDPb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOB659TCcAAx9U-.jpg",
        "id_str" : "351415907060445184",
        "id" : 351415907060445184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOB659TCcAAx9U-.jpg",
        "sizes" : [ {
          "h" : 405,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/amKOSmYDPb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351415907056250880",
    "text" : "http:\/\/t.co\/amKOSmYDPb",
    "id" : 351415907056250880,
    "created_at" : "2013-06-30 19:04:16 +0000",
    "user" : {
      "name" : "Emergency Kittens",
      "screen_name" : "EmrgencyKittens",
      "protected" : false,
      "id_str" : "1041346340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/562466745340817408\/_nIu8KHX_normal.jpeg",
      "id" : 1041346340,
      "verified" : false
    }
  },
  "id" : 351530108865085441,
  "created_at" : "2013-07-01 02:38:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "indices" : [ 3, 16 ],
      "id_str" : "103920270",
      "id" : 103920270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "350416085671084034",
  "text" : "RT @MrAlanCooper: Pavlov is having a drink at the bar when the phone rings. He jumps up and shouts, \"Damn, I forgot to feed the dog!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "350325465023643648",
    "text" : "Pavlov is having a drink at the bar when the phone rings. He jumps up and shouts, \"Damn, I forgot to feed the dog!\"",
    "id" : 350325465023643648,
    "created_at" : "2013-06-27 18:51:14 +0000",
    "user" : {
      "name" : "Alan Cooper",
      "screen_name" : "MrAlanCooper",
      "protected" : false,
      "id_str" : "103920270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800775398116048896\/Q4uvisnC_normal.jpg",
      "id" : 103920270,
      "verified" : false
    }
  },
  "id" : 350416085671084034,
  "created_at" : "2013-06-28 00:51:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marshall Osborne",
      "screen_name" : "MarshallOsborne",
      "indices" : [ 3, 19 ],
      "id_str" : "52400350",
      "id" : 52400350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349707852958543874",
  "text" : "RT @MarshallOsborne: It's hard to explain puns to kleptomaniacs because they always take things literally",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "349659597012873216",
    "text" : "It's hard to explain puns to kleptomaniacs because they always take things literally",
    "id" : 349659597012873216,
    "created_at" : "2013-06-25 22:45:18 +0000",
    "user" : {
      "name" : "Marshall Osborne",
      "screen_name" : "MarshallOsborne",
      "protected" : false,
      "id_str" : "52400350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758909265490784256\/HUvHGmu6_normal.jpg",
      "id" : 52400350,
      "verified" : false
    }
  },
  "id" : 349707852958543874,
  "created_at" : "2013-06-26 01:57:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "349681063536238592",
  "text" : "Anyone have any feedback + or - about Neat products such as Neat Cloud, Neat Desk, for simplifying mgmt of business receipts &amp; other docs?",
  "id" : 349681063536238592,
  "created_at" : "2013-06-26 00:10:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Haeffner",
      "screen_name" : "TourDeDave",
      "indices" : [ 0, 11 ],
      "id_str" : "16220257",
      "id" : 16220257
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qazAKGluyU",
      "expanded_url" : "http:\/\/tinyurl.com\/q3b9ng8",
      "display_url" : "tinyurl.com\/q3b9ng8"
    } ]
  },
  "geo" : { },
  "id_str" : "347451809868173313",
  "in_reply_to_user_id" : 16220257,
  "text" : "@tourdedave or anyone...I'm trying to build a Cucumber custom HTML formatter and have some questions at http:\/\/t.co\/qazAKGluyU . Can u help?",
  "id" : 347451809868173313,
  "created_at" : "2013-06-19 20:32:21 +0000",
  "in_reply_to_screen_name" : "TourDeDave",
  "in_reply_to_user_id_str" : "16220257",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/CIAUAFwE4t",
      "expanded_url" : "http:\/\/img.ly\/vqf2",
      "display_url" : "img.ly\/vqf2"
    } ]
  },
  "geo" : { },
  "id_str" : "346476960559534081",
  "text" : "Anyone in the DC area need inexpensive home organizing help? This is my linen closet after RIch was done with it: http:\/\/t.co\/CIAUAFwE4t",
  "id" : 346476960559534081,
  "created_at" : "2013-06-17 03:58:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyNation",
      "screen_name" : "rubynation",
      "indices" : [ 8, 19 ],
      "id_str" : "1556704207",
      "id" : 1556704207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/aYbibkMPdb",
      "expanded_url" : "http:\/\/img.ly\/vq6W",
      "display_url" : "img.ly\/vq6W"
    } ]
  },
  "geo" : { },
  "id_str" : "346392302786338817",
  "text" : "Enjoyed @RubyNation again, &amp; kudos on the Silver Spring venue. Photo was taken just outside at the Blues festival. http:\/\/t.co\/aYbibkMPdb",
  "id" : 346392302786338817,
  "created_at" : "2013-06-16 22:22:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "345949841228185601",
  "geo" : { },
  "id_str" : "346109549368971265",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi  Hey! I think durian is divine. Smells like hell but tastes like heaven, they say. :-)",
  "id" : 346109549368971265,
  "in_reply_to_status_id" : 345949841228185601,
  "created_at" : "2013-06-16 03:38:41 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "344114843168694273",
  "geo" : { },
  "id_str" : "344117620775202816",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori Seems Mail.app &amp; Outlook both use Spotlight to search, and that's not working for me...don't know why; it's on w\/no private areas.",
  "id" : 344117620775202816,
  "in_reply_to_status_id" : 344114843168694273,
  "created_at" : "2013-06-10 15:43:28 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "344111636791050240",
  "text" : "Anyone have a recommendation for a good Mac email client that can talk to an MS Exchange server?",
  "id" : 344111636791050240,
  "created_at" : "2013-06-10 15:19:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mykel Alvis",
      "screen_name" : "mykelalvis",
      "indices" : [ 71, 82 ],
      "id_str" : "14369399",
      "id" : 14369399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "self2013",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343508510102925313",
  "text" : "\"You implicitly pass 100% of all the tests that are never written.\" - \u200F@mykelalvis at #self2013",
  "id" : 343508510102925313,
  "created_at" : "2013-06-08 23:23:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/343497264804790272\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/wV8DPRpF3G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BMRY8UJCAAABK2U.jpg",
      "id_str" : "343497264808984576",
      "id" : 343497264808984576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BMRY8UJCAAABK2U.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 778,
        "resize" : "fit",
        "w" : 1037
      } ],
      "display_url" : "pic.twitter.com\/wV8DPRpF3G"
    } ],
    "hashtags" : [ {
      "text" : "self2013",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343497264804790272",
  "text" : "Lock picking this morning at #self2013 (Southeast Linuxfest, Charlotte, NC).  The connection?  Hardware security. http:\/\/t.co\/wV8DPRpF3G",
  "id" : 343497264804790272,
  "created_at" : "2013-06-08 22:38:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "__red__",
      "screen_name" : "noidd",
      "indices" : [ 14, 20 ],
      "id_str" : "17411264",
      "id" : 17411264
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "self2013",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343494209153683456",
  "text" : "Great talk by @noidd on dealing w\/ security breaches at #self2013.  He's like a CSI for computer hosts and systems.  Great content &amp; style.",
  "id" : 343494209153683456,
  "created_at" : "2013-06-08 22:26:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "goozbach",
      "screen_name" : "goozbach",
      "indices" : [ 20, 29 ],
      "id_str" : "11816472",
      "id" : 11816472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "self2013",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "343042707293364224",
  "text" : "Great bash prezo by @goozbach at #self2013. Faves: mkcd(), dotfiles git strategy, fun prompt that tweets each bash cmd (don't use it! :) ).",
  "id" : 343042707293364224,
  "created_at" : "2013-06-07 16:32:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gay",
      "screen_name" : "saturnflyer",
      "indices" : [ 0, 12 ],
      "id_str" : "6173562",
      "id" : 6173562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341311841298968576",
  "geo" : { },
  "id_str" : "341405125790810112",
  "in_reply_to_user_id" : 6173562,
  "text" : "@saturnflyer No, Google Translate. ;) Shikashi watashiwa nihongo-o skoshi hanashimasu\u2026and some French, Swedish, Korean, and Thai.",
  "id" : 341405125790810112,
  "in_reply_to_status_id" : 341311841298968576,
  "created_at" : "2013-06-03 04:04:59 +0000",
  "in_reply_to_screen_name" : "saturnflyer",
  "in_reply_to_user_id_str" : "6173562",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    }, {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 24, 39 ],
      "id_str" : "234656248",
      "id" : 234656248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341344932419731456",
  "geo" : { },
  "id_str" : "341352336058351618",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich Jim, that's @reddotrubyconf !  \u007B red_dirt: 'Oklahoma', red_dot: 'Singapore' \u007D",
  "id" : 341352336058351618,
  "in_reply_to_status_id" : 341344932419731456,
  "created_at" : "2013-06-03 00:35:13 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "341266767227785216",
  "geo" : { },
  "id_str" : "341268069781483525",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms Good idea...funny, I didn't realize how much that sounds like trace until I said it.  Also thinking about 'traze'.",
  "id" : 341268069781483525,
  "in_reply_to_status_id" : 341266767227785216,
  "created_at" : "2013-06-02 19:00:22 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "341266241283051521",
  "text" : "Using Ruby 'logging' gem, need to add 'trace' level, but method name 'trace' already used.  What to call it?  Esperanto 'pa\u016Dsi'?",
  "id" : 341266241283051521,
  "created_at" : "2013-06-02 18:53:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/jBr8iro92R",
      "expanded_url" : "http:\/\/blog.macromates.com\/2005\/key-bindings-for-switchers\/",
      "display_url" : "blog.macromates.com\/2005\/key-bindi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "341234468717211648",
  "text" : "Defeat OSX home\/end madness and configure them to go to beginning\/end of line: http:\/\/t.co\/jBr8iro92R",
  "id" : 341234468717211648,
  "created_at" : "2013-06-02 16:46:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/LPw2mzJTnG",
      "expanded_url" : "https:\/\/bugs.ruby-lang.org\/issues\/8468",
      "display_url" : "bugs.ruby-lang.org\/issues\/8468"
    } ]
  },
  "geo" : { },
  "id_str" : "341204235460952064",
  "text" : "RT @headius Ruby's $SAFE may finally go away. Help me (and others) get rid of it and define a proper security model: https:\/\/t.co\/LPw2mzJTnG",
  "id" : 341204235460952064,
  "created_at" : "2013-06-02 14:46:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]