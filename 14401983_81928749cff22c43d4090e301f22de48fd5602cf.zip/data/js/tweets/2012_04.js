Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barr",
      "screen_name" : "embeddedbarr",
      "indices" : [ 3, 16 ],
      "id_str" : "19116348",
      "id" : 19116348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196805447938875394",
  "text" : "RT @embeddedbarr: I'm really dreading the day a flight attendant comes out of the cockpit on a flight yelling, \"DOES ANYONE ONBOARD PROG ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "embedsys",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "196259162336919555",
    "text" : "I'm really dreading the day a flight attendant comes out of the cockpit on a flight yelling, \"DOES ANYONE ONBOARD PROGRAM C?\" #embedsys",
    "id" : 196259162336919555,
    "created_at" : "2012-04-28 15:26:45 +0000",
    "user" : {
      "name" : "Michael Barr",
      "screen_name" : "embeddedbarr",
      "protected" : false,
      "id_str" : "19116348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691713124689383424\/yP7LCLac_normal.png",
      "id" : 19116348,
      "verified" : false
    }
  },
  "id" : 196805447938875394,
  "created_at" : "2012-04-30 03:37:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/7QsUcohM",
      "expanded_url" : "http:\/\/www.slideshare.net\/keithrbennett\/jruby-synergyofrubyandjava",
      "display_url" : "slideshare.net\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "195043270651428864",
  "text" : "On a working vacation in SE Asia. Slides from my JRuby presentation for Bangkok's Rails and JavaScript Meetup are at http:\/\/t.co\/7QsUcohM.",
  "id" : 195043270651428864,
  "created_at" : "2012-04-25 06:55:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Declan Whelan",
      "screen_name" : "dwhelan",
      "indices" : [ 3, 11 ],
      "id_str" : "14650214",
      "id" : 14650214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "help",
      "indices" : [ 100, 105 ]
    }, {
      "text" : "agile",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191540778668003328",
  "text" : "RT @dwhelan: I believe the strongest indicator of a healthy team is when individuals freely ask for #help and freely provide it. #agile  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "help",
        "indices" : [ 87, 92 ]
      }, {
        "text" : "agile",
        "indices" : [ 116, 122 ]
      }, {
        "text" : "lean",
        "indices" : [ 123, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "191527201198448640",
    "text" : "I believe the strongest indicator of a healthy team is when individuals freely ask for #help and freely provide it. #agile #lean",
    "id" : 191527201198448640,
    "created_at" : "2012-04-15 14:03:37 +0000",
    "user" : {
      "name" : "Declan Whelan",
      "screen_name" : "dwhelan",
      "protected" : false,
      "id_str" : "14650214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/341591991\/Garden_photo_normal.jpg",
      "id" : 14650214,
      "verified" : false
    }
  },
  "id" : 191540778668003328,
  "created_at" : "2012-04-15 14:57:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JRubyConf",
      "screen_name" : "JRubyConf",
      "indices" : [ 0, 10 ],
      "id_str" : "71363379",
      "id" : 71363379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190865175807655937",
  "in_reply_to_user_id" : 71363379,
  "text" : "@jrubyconf Would appreciate if you could answer the question I posted to you via eventbrite on Monday.",
  "id" : 190865175807655937,
  "created_at" : "2012-04-13 18:12:58 +0000",
  "in_reply_to_screen_name" : "JRubyConf",
  "in_reply_to_user_id_str" : "71363379",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fairfax County",
      "screen_name" : "fairfaxcounty",
      "indices" : [ 0, 14 ],
      "id_str" : "16016705",
      "id" : 16016705
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189385757541138432",
  "in_reply_to_user_id" : 16016705,
  "text" : "@fairfaxcounty, @fairfaxcountyhealth, I recommend separate Twitter accounts for urgency\/emergency only.  More followers when it counts...",
  "id" : 189385757541138432,
  "created_at" : "2012-04-09 16:14:17 +0000",
  "in_reply_to_screen_name" : "fairfaxcounty",
  "in_reply_to_user_id_str" : "16016705",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FairfaxCounty Health",
      "screen_name" : "fairfaxhealth",
      "indices" : [ 0, 14 ],
      "id_str" : "117134352",
      "id" : 117134352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188374802862575616",
  "in_reply_to_user_id" : 117134352,
  "text" : "@fairfaxhealth Great that you're on twitter, but is there a different Twitter account for urgent messages only? Too much noise on this one.",
  "id" : 188374802862575616,
  "created_at" : "2012-04-06 21:17:07 +0000",
  "in_reply_to_screen_name" : "fairfaxhealth",
  "in_reply_to_user_id_str" : "117134352",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "188370782597021696",
  "text" : "Just saw a guy in a hot sports car with an awesome sound system with music blaring...classical music!  A nice change...",
  "id" : 188370782597021696,
  "created_at" : "2012-04-06 21:01:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/O7CDByCa",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/04\/05\/opinion\/kristof-arsenic-in-our-chicken.html",
      "display_url" : "nytimes.com\/2012\/04\/05\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188113840741957633",
  "text" : "Poultry on factory farms fed caffeine, active ingredients of Tylenol and Benadryl, banned antibiotics and arsenic: http:\/\/t.co\/O7CDByCa",
  "id" : 188113840741957633,
  "created_at" : "2012-04-06 04:00:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187642737162592257",
  "text" : "Google Maps pointed Meetup attendees to the wrong location in DC several blocks off -- for an Android developers meetup!  Many no-shows.",
  "id" : 187642737162592257,
  "created_at" : "2012-04-04 20:48:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186873963509583872",
  "text" : "Can anyone recommend a good book on Rails 3's design & arch., not a tutorial, but a K&R type reference, that *does* assume Ruby expertise?",
  "id" : 186873963509583872,
  "created_at" : "2012-04-02 17:53:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/186592870575243267\/photo\/1",
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/TeVfYVYl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApbpOijCAAEm5Kv.jpg",
      "id_str" : "186592870583631873",
      "id" : 186592870583631873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApbpOijCAAEm5Kv.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/TeVfYVYl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186592870575243267",
  "text" : "160 or so drink flavors in cool machine at The Burger Joint. http:\/\/t.co\/TeVfYVYl",
  "id" : 186592870575243267,
  "created_at" : "2012-04-01 23:16:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]