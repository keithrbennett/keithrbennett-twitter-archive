Grailbird.data.tweets_2016_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/xePWWbVJFH",
      "expanded_url" : "http:\/\/www.newyorker.com\/cartoons\/a20602",
      "display_url" : "newyorker.com\/cartoons\/a20602"
    } ]
  },
  "geo" : { },
  "id_str" : "803512424158478336",
  "text" : "A New Yorker cartoon that's a spot-on accurate satire of communication style of much of America these days: https:\/\/t.co\/xePWWbVJFH",
  "id" : 803512424158478336,
  "created_at" : "2016-11-29 08:14:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allie_p",
      "screen_name" : "allie_p",
      "indices" : [ 0, 8 ],
      "id_str" : "15954702",
      "id" : 15954702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "802873647467810816",
  "geo" : { },
  "id_str" : "802894092262785024",
  "in_reply_to_user_id" : 15954702,
  "text" : "@allie_p He was a very lucky man to have a granddaughter who loved him so much.",
  "id" : 802894092262785024,
  "in_reply_to_status_id" : 802873647467810816,
  "created_at" : "2016-11-27 15:17:23 +0000",
  "in_reply_to_screen_name" : "allie_p",
  "in_reply_to_user_id_str" : "15954702",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/802780303949320192\/photo\/1",
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/FBbpRHAOpI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyQMaI6UkAEP18a.jpg",
      "id_str" : "802780276787023873",
      "id" : 802780276787023873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyQMaI6UkAEP18a.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/FBbpRHAOpI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802780303949320192",
  "text" : "A gaming theater at Pantip Plaza! https:\/\/t.co\/FBbpRHAOpI",
  "id" : 802780303949320192,
  "created_at" : "2016-11-27 07:45:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/802776135369048064\/photo\/1",
      "indices" : [ 140, 163 ],
      "url" : "https:\/\/t.co\/GKb2YjjuZj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyQInLqUcAAaZsh.jpg",
      "id_str" : "802776102817001472",
      "id" : 802776102817001472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyQInLqUcAAaZsh.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GKb2YjjuZj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802776135369048064",
  "text" : "Man and man's best friend on a motorcycle in central Bangkok, as seen on a motorcycle taxi en route to Pantip Plaza, the tech shopping hub. https:\/\/t.co\/GKb2YjjuZj",
  "id" : 802776135369048064,
  "created_at" : "2016-11-27 07:28:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/802518625328345088\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/4GJjvEvTBj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyMeaggVIAAtCiC.jpg",
      "id_str" : "802518599353049088",
      "id" : 802518599353049088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyMeaggVIAAtCiC.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/4GJjvEvTBj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802518625328345088",
  "text" : "Evening football game just outside of National Stadium, Bangkok. https:\/\/t.co\/4GJjvEvTBj",
  "id" : 802518625328345088,
  "created_at" : "2016-11-26 14:25:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/802473167390244864\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/mbXecZqs9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyL1D8uUQAEmKf4.jpg",
      "id_str" : "802473131814174721",
      "id" : 802473131814174721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyL1D8uUQAEmKf4.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/mbXecZqs9m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "802473167390244864",
  "text" : "Bangkok Skytrain well named -- 91 stair steps from the street to the platform. https:\/\/t.co\/mbXecZqs9m",
  "id" : 802473167390244864,
  "created_at" : "2016-11-26 11:24:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "801722491815088128",
  "geo" : { },
  "id_str" : "801777218598772736",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Correction: American, Chinese, and British.",
  "id" : 801777218598772736,
  "in_reply_to_status_id" : 801722491815088128,
  "created_at" : "2016-11-24 13:19:19 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/801722491815088128\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/cBhfVz2d74",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CyBKVFqUAAAFaDG.jpg",
      "id_str" : "801722459829305344",
      "id" : 801722459829305344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CyBKVFqUAAAFaDG.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/cBhfVz2d74"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "801722491815088128",
  "text" : "Midday Thanksgiving dinner with some American and Chinese expat friends in Chiang Mai. https:\/\/t.co\/cBhfVz2d74",
  "id" : 801722491815088128,
  "created_at" : "2016-11-24 09:41:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/800707546281627652\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/jK0rwTDOgd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxyvQVoUsAA6fmh.jpg",
      "id_str" : "800707528984145920",
      "id" : 800707528984145920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxyvQVoUsAA6fmh.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/jK0rwTDOgd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800707546281627652",
  "text" : "Beautiful Hong Kong as viewed from the ferry to Kowloon. Here for a couple of days for a Thai visa run. https:\/\/t.co\/jK0rwTDOgd",
  "id" : 800707546281627652,
  "created_at" : "2016-11-21 14:28:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/SYL8FRPiUT",
      "expanded_url" : "https:\/\/www.gnu.org\/fun\/jokes\/eternal-flame.ogg",
      "display_url" : "gnu.org\/fun\/jokes\/eter\u2026"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/fALGZEjzK9",
      "expanded_url" : "https:\/\/www.gnu.org\/fun\/jokes\/eternal-flame.en.html",
      "display_url" : "gnu.org\/fun\/jokes\/eter\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "800360294341971968",
  "text" : "A coder's ballad sung beautifully (and satirically) in the style of Joan Baez\/ Mary Travers. https:\/\/t.co\/SYL8FRPiUT https:\/\/t.co\/fALGZEjzK9",
  "id" : 800360294341971968,
  "created_at" : "2016-11-20 15:28:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/800334603449868288\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/8fQ9XQvOw7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CxtcDGZVQAENzXo.jpg",
      "id_str" : "800334567114620929",
      "id" : 800334567114620929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CxtcDGZVQAENzXo.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/8fQ9XQvOw7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "800334603449868288",
  "text" : "Shavers, we can help the environment a little and get a better shave by using tubes like this instead of cans. https:\/\/t.co\/8fQ9XQvOw7",
  "id" : 800334603449868288,
  "created_at" : "2016-11-20 13:46:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "799343343000027137",
  "geo" : { },
  "id_str" : "799357055404359681",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler How has your sleep been lately? Could be the result of inadequate quantity and\/or quality of sleep. Sleep apnea maybe?",
  "id" : 799357055404359681,
  "in_reply_to_status_id" : 799343343000027137,
  "created_at" : "2016-11-17 21:02:28 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "russolsen",
      "screen_name" : "russolsen",
      "indices" : [ 45, 55 ],
      "id_str" : "15740685",
      "id" : 15740685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/zyXhCM5Nei",
      "expanded_url" : "http:\/\/blog.cognitect.com\/blog\/2016\/11\/14\/works-on-my-machine-how-we-work-distributed",
      "display_url" : "blog.cognitect.com\/blog\/2016\/11\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "799106436949110784",
  "text" : "Excellent article about distributed teams by @russolsen : https:\/\/t.co\/zyXhCM5Nei",
  "id" : 799106436949110784,
  "created_at" : "2016-11-17 04:26:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "797194034699784192",
  "geo" : { },
  "id_str" : "797307683372023808",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Maybe ask a Korean restaurant, they might know of norae bangs in the area or host you themselves. Check song selection though.",
  "id" : 797307683372023808,
  "in_reply_to_status_id" : 797194034699784192,
  "created_at" : "2016-11-12 05:18:59 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Ed Finkler)))",
      "screen_name" : "funkatron",
      "indices" : [ 3, 13 ],
      "id_str" : "65583",
      "id" : 65583
    }, {
      "name" : "ACLU Indiana",
      "screen_name" : "ACLUIndiana",
      "indices" : [ 43, 55 ],
      "id_str" : "159103207",
      "id" : 159103207
    }, {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "indices" : [ 56, 61 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/funkatron\/status\/795661931264753665\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/hs2y3DBbL1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwrCSh3UsAAaS_Z.jpg",
      "id_str" : "795661907768160256",
      "id" : 795661907768160256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwrCSh3UsAAaS_Z.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/hs2y3DBbL1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795955725822349312",
  "text" : "RT @funkatron: Just so you have some info. @ACLUIndiana @ACLU is looking out for you. https:\/\/t.co\/hs2y3DBbL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ACLU Indiana",
        "screen_name" : "ACLUIndiana",
        "indices" : [ 28, 40 ],
        "id_str" : "159103207",
        "id" : 159103207
      }, {
        "name" : "ACLU National",
        "screen_name" : "ACLU",
        "indices" : [ 41, 46 ],
        "id_str" : "13393052",
        "id" : 13393052
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/funkatron\/status\/795661931264753665\/photo\/1",
        "indices" : [ 71, 94 ],
        "url" : "https:\/\/t.co\/hs2y3DBbL1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CwrCSh3UsAAaS_Z.jpg",
        "id_str" : "795661907768160256",
        "id" : 795661907768160256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwrCSh3UsAAaS_Z.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/hs2y3DBbL1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "795661931264753665",
    "text" : "Just so you have some info. @ACLUIndiana @ACLU is looking out for you. https:\/\/t.co\/hs2y3DBbL1",
    "id" : 795661931264753665,
    "created_at" : "2016-11-07 16:19:21 +0000",
    "user" : {
      "name" : "(((Ed Finkler)))",
      "screen_name" : "funkatron",
      "protected" : false,
      "id_str" : "65583",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777178802417836033\/IJ-Smy-7_normal.jpg",
      "id" : 65583,
      "verified" : false
    }
  },
  "id" : 795955725822349312,
  "created_at" : "2016-11-08 11:46:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/795636119157149696\/photo\/1",
      "indices" : [ 139, 162 ],
      "url" : "https:\/\/t.co\/L0tEWO1bxH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cwqqz91VEAAvVIE.jpg",
      "id_str" : "795636093932605440",
      "id" : 795636093932605440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cwqqz91VEAAvVIE.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/L0tEWO1bxH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795636119157149696",
  "text" : "Visited 579 yr old Wat Pha Kao. Eerily realistic wax replicas of deceased monks, changing colored lights, and a very welcoming young monk. https:\/\/t.co\/L0tEWO1bxH",
  "id" : 795636119157149696,
  "created_at" : "2016-11-07 14:36:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NAACP",
      "screen_name" : "NAACP",
      "indices" : [ 3, 9 ],
      "id_str" : "44988185",
      "id" : 44988185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795244189491425280",
  "text" : "RT @NAACP: If someone tries to stop you from voting, take their picture and call 1-866-OUR-VOTE. Lawyers will be ready. https:\/\/t.co\/IsA6nG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/IsA6nGUn0E",
        "expanded_url" : "http:\/\/politi.co\/2f8n5jS",
        "display_url" : "politi.co\/2f8n5jS"
      } ]
    },
    "geo" : { },
    "id_str" : "794285580444192777",
    "text" : "If someone tries to stop you from voting, take their picture and call 1-866-OUR-VOTE. Lawyers will be ready. https:\/\/t.co\/IsA6nGUn0E",
    "id" : 794285580444192777,
    "created_at" : "2016-11-03 21:10:14 +0000",
    "user" : {
      "name" : "NAACP",
      "screen_name" : "NAACP",
      "protected" : false,
      "id_str" : "44988185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722461858251321344\/DFUbQhxC_normal.jpg",
      "id" : 44988185,
      "verified" : true
    }
  },
  "id" : 795244189491425280,
  "created_at" : "2016-11-06 12:39:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/MQvECMiWIW",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dsq_jZiB1_U",
      "display_url" : "youtube.com\/watch?v=dsq_jZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "795178691064000512",
  "text" : "This is awesome...cowboy lassos bike thief in Walmart parking lot: https:\/\/t.co\/MQvECMiWIW",
  "id" : 795178691064000512,
  "created_at" : "2016-11-06 08:19:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "795098666948239361",
  "text" : "My fellow Americans: Please VOTE, even if your state is decided.  The entire world is counting on you to defend decency, sanity, and reason.",
  "id" : 795098666948239361,
  "created_at" : "2016-11-06 03:01:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "Google",
      "indices" : [ 86, 93 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/794893086732128256\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/xECgjMEDrv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwgHAOrVIAAWhwK.jpg",
      "id_str" : "794893034752122880",
      "id" : 794893034752122880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwgHAOrVIAAWhwK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 917,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/xECgjMEDrv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794481310068654080",
  "geo" : { },
  "id_str" : "794893086732128256",
  "in_reply_to_user_id" : 14401983,
  "text" : "And here's a panoramic view Google Photos created for me without my asking (Thank you @google!). https:\/\/t.co\/xECgjMEDrv",
  "id" : 794893086732128256,
  "in_reply_to_status_id" : 794481310068654080,
  "created_at" : "2016-11-05 13:24:14 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 8, 17 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Isleta Technologies",
      "screen_name" : "isletatech",
      "indices" : [ 34, 45 ],
      "id_str" : "844204038",
      "id" : 844204038
    }, {
      "name" : "Jacquelyn Ma",
      "screen_name" : "jacquelynma",
      "indices" : [ 89, 101 ],
      "id_str" : "93277175",
      "id" : 93277175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794560416194015232",
  "text" : "Sold my @RubyConf registration to @isletatech. Thanks everyone for all the retweets! cc: @jacquelynma",
  "id" : 794560416194015232,
  "created_at" : "2016-11-04 15:22:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/794481310068654080\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/eIntAM67KR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CwaQgFaVIAAY9PJ.jpg",
      "id_str" : "794481265160298496",
      "id" : 794481265160298496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CwaQgFaVIAAY9PJ.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eIntAM67KR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794481310068654080",
  "text" : "Rode my motorbike over winding roads to the top of Doi (Mount) Suthep today. This is the view of Chiang Mai. https:\/\/t.co\/eIntAM67KR",
  "id" : 794481310068654080,
  "created_at" : "2016-11-04 10:07:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jacquelyn Ma",
      "screen_name" : "jacquelynma",
      "indices" : [ 0, 12 ],
      "id_str" : "93277175",
      "id" : 93277175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "794293559289446400",
  "geo" : { },
  "id_str" : "794323938612346880",
  "in_reply_to_user_id" : 93277175,
  "text" : "@jacquelynma Yes.  Please DM me your email address, ok?",
  "id" : 794323938612346880,
  "in_reply_to_status_id" : 794293559289446400,
  "created_at" : "2016-11-03 23:42:39 +0000",
  "in_reply_to_screen_name" : "jacquelynma",
  "in_reply_to_user_id_str" : "93277175",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 14, 23 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "794121812938346496",
  "text" : "Want to go to @RubyConf for less? I'm looking to sell my registration and will accept $200, half of what I paid, for it.  Anyone interested?",
  "id" : 794121812938346496,
  "created_at" : "2016-11-03 10:19:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 63, 78 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/fEoICCobTC",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/the-optimist\/",
      "display_url" : "washingtonpost.com\/the-optimist\/"
    } ]
  },
  "geo" : { },
  "id_str" : "793683316679389184",
  "text" : "For good news to counteract the massive bad news in the media: @washingtonpost Optimist: https:\/\/t.co\/fEoICCobTC. Good for the soul.",
  "id" : 793683316679389184,
  "created_at" : "2016-11-02 05:17:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/pxTympbPZc",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/early-lead\/wp\/2016\/10\/26\/tim-tebows-response-to-critics-of-his-baseball-dream-will-make-you-want-to-quit-your-job\/?wpisrc=nl_optimist&wpmm=1",
      "display_url" : "washingtonpost.com\/news\/early-lea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "793678284051521536",
  "text" : "Tim Tebow on transcending personal inertia and living your dream (quoted at end of article): https:\/\/t.co\/pxTympbPZc",
  "id" : 793678284051521536,
  "created_at" : "2016-11-02 04:57:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]