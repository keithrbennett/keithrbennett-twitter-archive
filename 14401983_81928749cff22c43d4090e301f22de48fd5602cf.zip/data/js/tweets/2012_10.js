Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 3, 13 ],
      "id_str" : "6264782",
      "id" : 6264782
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 18, 27 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262781085576986624",
  "text" : "RT @grossberg: Hi @rubyconf what is your policy regarding schedule and refunds, with people who can\u2019t fly to Denver on time, bc of Sandy?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rubyconf",
        "screen_name" : "rubyconf",
        "indices" : [ 3, 12 ],
        "id_str" : "16222737",
        "id" : 16222737
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262752562128764928",
    "text" : "Hi @rubyconf what is your policy regarding schedule and refunds, with people who can\u2019t fly to Denver on time, bc of Sandy?",
    "id" : 262752562128764928,
    "created_at" : "2012-10-29 03:07:47 +0000",
    "user" : {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "protected" : false,
      "id_str" : "6264782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544224243622223872\/EEBEN2zY_normal.png",
      "id" : 6264782,
      "verified" : false
    }
  },
  "id" : 262781085576986624,
  "created_at" : "2012-10-29 05:01:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyConf",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "sandy",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262780986037788672",
  "text" : "Anyone interested in buying my #RubyConf ticket? Not sure I'll be able to make it due to #sandy. (I'm in the DC area.)",
  "id" : 262780986037788672,
  "created_at" : "2012-10-29 05:00:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carin Meier",
      "screen_name" : "carinmeier",
      "indices" : [ 3, 14 ],
      "id_str" : "2257154185",
      "id" : 2257154185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261945355334205440",
  "text" : "RT @carinmeier: OMG I just realized that I can hack an AR-Drone too.  This means I can have air support for my Roombas.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261828814882082817",
    "text" : "OMG I just realized that I can hack an AR-Drone too.  This means I can have air support for my Roombas.",
    "id" : 261828814882082817,
    "created_at" : "2012-10-26 13:57:08 +0000",
    "user" : {
      "name" : "Gigasquid",
      "screen_name" : "gigasquid",
      "protected" : false,
      "id_str" : "115557940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617133806424821760\/1wFR7ZBe_normal.jpg",
      "id" : 115557940,
      "verified" : false
    }
  },
  "id" : 261945355334205440,
  "created_at" : "2012-10-26 21:40:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Glover",
      "screen_name" : "ersatzryan",
      "indices" : [ 0, 11 ],
      "id_str" : "39614157",
      "id" : 39614157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261930722854584320",
  "geo" : { },
  "id_str" : "261936851886157824",
  "in_reply_to_user_id" : 39614157,
  "text" : "@ersatzryan Doh!  RTFM!  To be fair, though, it was a way down, far from its first reference, and anyone aliasing should always beware, no?",
  "id" : 261936851886157824,
  "in_reply_to_status_id" : 261930722854584320,
  "created_at" : "2012-10-26 21:06:26 +0000",
  "in_reply_to_screen_name" : "ersatzryan",
  "in_reply_to_user_id_str" : "39614157",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 89 ],
      "url" : "https:\/\/t.co\/cPYIAZXj",
      "expanded_url" : "https:\/\/rvm.io\/rvm\/install\/",
      "display_url" : "rvm.io\/rvm\/install\/"
    } ]
  },
  "geo" : { },
  "id_str" : "261930190333157376",
  "text" : "Why is there a backslash before curl at rvm's install instructions (https:\/\/t.co\/cPYIAZXj)?",
  "id" : 261930190333157376,
  "created_at" : "2012-10-26 20:39:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261502209747984384",
  "text" : "I guess it was less pronounced in my previous car, a Honda Accord, and the difference surprised me.",
  "id" : 261502209747984384,
  "created_at" : "2012-10-25 16:19:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia Motors America",
      "screen_name" : "Kia",
      "indices" : [ 0, 4 ],
      "id_str" : "23689478",
      "id" : 23689478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261501908877987841",
  "in_reply_to_user_id" : 23689478,
  "text" : "@kia My apologies.  According to my trusted mechanic, the braking behavior that concerned me is not unusual and is within safety guidelines.",
  "id" : 261501908877987841,
  "created_at" : "2012-10-25 16:18:08 +0000",
  "in_reply_to_screen_name" : "Kia",
  "in_reply_to_user_id_str" : "23689478",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261220478193123328",
  "text" : "RT @elight: I\u2019ve some availability coming up.  My speciality is rescue\/legacy apps with an eye toward improving your team\u2019s technique.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "261217337628307457",
    "text" : "I\u2019ve some availability coming up.  My speciality is rescue\/legacy apps with an eye toward improving your team\u2019s technique.",
    "id" : 261217337628307457,
    "created_at" : "2012-10-24 21:27:21 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 261220478193123328,
  "created_at" : "2012-10-24 21:39:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 47, 53 ],
      "id_str" : "709433",
      "id" : 709433
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 113, 119 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261216747959504896",
  "text" : "Just finished an afternoon remote pairing with @peeja, receiving lots of great Rails mentoring. Used TeamViewer. @peeja.thanks!(1_000_000)",
  "id" : 261216747959504896,
  "created_at" : "2012-10-24 21:25:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/V6Techua",
      "expanded_url" : "http:\/\/ballotpedia.org\/wiki\/index.php\/Virginia_Eminent_Domain_Amendment,_Question_1_%282012%29",
      "display_url" : "ballotpedia.org\/wiki\/index.php\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260474767684030464",
  "text" : "Interesting referendum on prohibiting exercise of eminent domain for private gain on Virginia's ballot (http:\/\/t.co\/V6Techua).",
  "id" : 260474767684030464,
  "created_at" : "2012-10-22 20:16:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260407944313704448",
  "text" : "Got a high quality tv antenna for broadcast (free) HD TV reception.  Still using Tivo!",
  "id" : 260407944313704448,
  "created_at" : "2012-10-22 15:51:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260407433938214913",
  "text" : "Buying my daughter a MacBook Air.  AmEx card gives an extra year warranty. Thinking of settling for 2 yrs, not buying Applecare. Thoughts?",
  "id" : 260407433938214913,
  "created_at" : "2012-10-22 15:49:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/PxTvG4O5",
      "expanded_url" : "http:\/\/www.amazon.com\/Logitech-Wireless-Keyboard-Multi-Touch-920-003070\/dp\/B005DKZTMG\/ref=sr_1_1?ie=UTF8&qid=1350768297&sr=8-1&keywords=logitech+k400",
      "display_url" : "amazon.com\/Logitech-Wirel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "259767666229800960",
  "text" : "I connect the laptop at the tv and use a Logitech K400 (http:\/\/t.co\/PxTvG4O5) as a remote control. Total freedom of content.",
  "id" : 259767666229800960,
  "created_at" : "2012-10-20 21:26:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259759197196001280",
  "text" : "Cancelled overpriced Comcast tv service, will rely on Netflix, Hulu Plus, and content I get from an old Windows laptop attached to my TV.",
  "id" : 259759197196001280,
  "created_at" : "2012-10-20 20:53:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McNamee",
      "screen_name" : "Piecomic",
      "indices" : [ 3, 12 ],
      "id_str" : "63509872",
      "id" : 63509872
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259508806990561280",
  "text" : "RT @Piecomic: The creator of Mad Libs died. His friends described him as a warm and pulpy man who loved his wife and pelicans. He will b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "259341661547687936",
    "text" : "The creator of Mad Libs died. His friends described him as a warm and pulpy man who loved his wife and pelicans. He will be deeply pooped.",
    "id" : 259341661547687936,
    "created_at" : "2012-10-19 17:14:05 +0000",
    "user" : {
      "name" : "John McNamee",
      "screen_name" : "Piecomic",
      "protected" : false,
      "id_str" : "63509872",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1231505463\/tumblr_l90m05ISuO1qa2d9eo1_r1_500_normal.jpg",
      "id" : 63509872,
      "verified" : false
    }
  },
  "id" : 259508806990561280,
  "created_at" : "2012-10-20 04:18:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/259427240822059009\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0Gbsix1l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A5mrs3bCMAAZxTM.jpg",
      "id_str" : "259427240830447616",
      "id" : 259427240830447616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A5mrs3bCMAAZxTM.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/0Gbsix1l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "259427240822059009",
  "text" : "Explored neighborhood bike paths this eve. and planned my route with Google Maps. Guess they didn't know it rained. :-) http:\/\/t.co\/0Gbsix1l",
  "id" : 259427240822059009,
  "created_at" : "2012-10-19 22:54:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 0, 8 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/GiGU2dl6",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/12955845\/irb-noprompt-error-with-autoindent-on",
      "display_url" : "stackoverflow.com\/questions\/1295\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "258695466894639104",
  "geo" : { },
  "id_str" : "258922699382984704",
  "in_reply_to_user_id" : 121639673,
  "text" : "@snuggsi I've posted a question about the irb startup error on StackOverflow at http:\/\/t.co\/GiGU2dl6.",
  "id" : 258922699382984704,
  "in_reply_to_status_id" : 258695466894639104,
  "created_at" : "2012-10-18 13:29:16 +0000",
  "in_reply_to_screen_name" : "snuggsi",
  "in_reply_to_user_id_str" : "121639673",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 0, 8 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "258695466894639104",
  "geo" : { },
  "id_str" : "258739740117987328",
  "in_reply_to_user_id" : 121639673,
  "text" : "@snuggsi I had the same problem (ruby &amp; jruby) when my .irbrc had: IRB.conf[:AUTO_INDENT] = true. Problem went away when I removed it. (?)",
  "id" : 258739740117987328,
  "in_reply_to_status_id" : 258695466894639104,
  "created_at" : "2012-10-18 01:22:15 +0000",
  "in_reply_to_screen_name" : "snuggsi",
  "in_reply_to_user_id_str" : "121639673",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/1yEvFD5A",
      "expanded_url" : "http:\/\/www.bordom.net\/",
      "display_url" : "bordom.net"
    } ]
  },
  "geo" : { },
  "id_str" : "258561721055195136",
  "text" : "Just discovered http:\/\/t.co\/1yEvFD5A.  Hilarious stuff, but a potential black hole for time if you're (I'm) not careful.",
  "id" : 258561721055195136,
  "created_at" : "2012-10-17 13:34:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258298394882236416",
  "text" : "In a Starbucks, a mom quieted her screaming baby by giving him a straw to play with.  Can't believe that's all it took, he was a terror.",
  "id" : 258298394882236416,
  "created_at" : "2012-10-16 20:08:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257983675118006272",
  "text" : "Ruby Tip: To play with code in irb, then copy\/paste it somewhere else, use irb --noprompt option. No pesky prompt text to delete.",
  "id" : 257983675118006272,
  "created_at" : "2012-10-15 23:17:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scribd",
      "screen_name" : "Scribd",
      "indices" : [ 0, 7 ],
      "id_str" : "14167997",
      "id" : 14167997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257584652074745856",
  "in_reply_to_user_id" : 14167997,
  "text" : "@scribd office amazing toys: go carts, zip line, pogo stick. Prob'ly wouldn't use them much, but I'd like to work in that kind of env'ment.",
  "id" : 257584652074745856,
  "created_at" : "2012-10-14 20:52:21 +0000",
  "in_reply_to_screen_name" : "Scribd",
  "in_reply_to_user_id_str" : "14167997",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Myers",
      "screen_name" : "rachelmyers",
      "indices" : [ 18, 30 ],
      "id_str" : "17204571",
      "id" : 17204571
    }, {
      "name" : "RailsBridge",
      "screen_name" : "railsbridge",
      "indices" : [ 46, 58 ],
      "id_str" : "37201113",
      "id" : 37201113
    }, {
      "name" : "Scribd",
      "screen_name" : "Scribd",
      "indices" : [ 62, 69 ],
      "id_str" : "14167997",
      "id" : 14167997
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257583130968469504",
  "text" : "Enjoyed assisting @rachelmyers teach #ruby at @railsbridge at @scribd HQ in San Francisco this weekend.",
  "id" : 257583130968469504,
  "created_at" : "2012-10-14 20:46:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257554988547600385",
  "text" : "RT @JimGaffigan: Whoever invented the public restroom toilet paper dispenser that only allows one square at a time should be paid in pen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257551479949361152",
    "text" : "Whoever invented the public restroom toilet paper dispenser that only allows one square at a time should be paid in pennies.",
    "id" : 257551479949361152,
    "created_at" : "2012-10-14 18:40:32 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 257554988547600385,
  "created_at" : "2012-10-14 18:54:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsBridge",
      "screen_name" : "railsbridge",
      "indices" : [ 0, 12 ],
      "id_str" : "37201113",
      "id" : 37201113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256946908537434112",
  "in_reply_to_user_id" : 37201113,
  "text" : "@railsbridge To create alias to open Komodo Edit from a Mac command line, put in .bashrc: alias komodo='open -a \"Komodo Edit\"'",
  "id" : 256946908537434112,
  "created_at" : "2012-10-13 02:38:11 +0000",
  "in_reply_to_screen_name" : "railsbridge",
  "in_reply_to_user_id_str" : "37201113",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256435077347672064",
  "text" : "@(me) However, for more than occasional drop-in, a paid coworking space can be a wise investment, much better than a library.",
  "id" : 256435077347672064,
  "created_at" : "2012-10-11 16:44:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256223516398080000",
  "text" : "San Francisco's Citizen Space coworking is nice, but the public library at Civic Center is spacious and free (&amp; covered drinks are ok).",
  "id" : 256223516398080000,
  "created_at" : "2012-10-11 02:43:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/9iaZ80Sr",
      "expanded_url" : "http:\/\/img.ly\/okWy",
      "display_url" : "img.ly\/okWy"
    } ]
  },
  "geo" : { },
  "id_str" : "256195304553074688",
  "text" : "Enjoyed the eXtreme Tuesday meetup at Pivotal Labs in SFO last night.  Lots of smart folks, and I love their kitchen... http:\/\/t.co\/9iaZ80Sr",
  "id" : 256195304553074688,
  "created_at" : "2012-10-11 00:51:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255405235089051651",
  "text" : "RT @angelaharms: Seems I learn more when I try to prove myself wrong, rather than trying to prove myself right.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "255404007768604673",
    "text" : "Seems I learn more when I try to prove myself wrong, rather than trying to prove myself right.",
    "id" : 255404007768604673,
    "created_at" : "2012-10-08 20:27:15 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 255405235089051651,
  "created_at" : "2012-10-08 20:32:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Casey Rosenthal",
      "screen_name" : "caseyrosenthal",
      "indices" : [ 8, 23 ],
      "id_str" : "17850415",
      "id" : 17850415
    }, {
      "name" : "Ryan Sandridge",
      "screen_name" : "dissolved",
      "indices" : [ 24, 34 ],
      "id_str" : "14941192",
      "id" : 14941192
    }, {
      "name" : "Ryan Singer",
      "screen_name" : "rjs",
      "indices" : [ 35, 39 ],
      "id_str" : "10079052",
      "id" : 10079052
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 40, 45 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/zw0uYg45",
      "expanded_url" : "http:\/\/www.ft.com\/intl\/cms\/s\/2\/d9cb7940-ebea-11e1-985a-00144feab49a.html#axzz24teKmDi8",
      "display_url" : "ft.com\/intl\/cms\/s\/2\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "255092058103111681",
  "geo" : { },
  "id_str" : "255394946331332610",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @caseyrosenthal @dissolved @rjs @avdi Awesome, meditating with coworkers! Maybe then I could stay with it. http:\/\/t.co\/zw0uYg45",
  "id" : 255394946331332610,
  "in_reply_to_status_id" : 255092058103111681,
  "created_at" : "2012-10-08 19:51:14 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sanfrancisco",
      "indices" : [ 7, 20 ]
    }, {
      "text" : "ruby",
      "indices" : [ 103, 108 ]
    }, {
      "text" : "jruby",
      "indices" : [ 113, 119 ]
    }, {
      "text" : "rails",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254978789426229248",
  "text" : "I'm in #sanfrancisco bay area for the week. Seeking ongoing mostly remote Ruby work. Specialty in core #ruby and #jruby. New to #rails.",
  "id" : 254978789426229248,
  "created_at" : "2012-10-07 16:17:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "ruby_dcamp",
      "screen_name" : "ruby_dcamp",
      "indices" : [ 65, 76 ],
      "id_str" : "15386856",
      "id" : 15386856
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254104865784094720",
  "text" : "RT @avdi: Fantastic write-up of the utterly unique beast that is @ruby_dcamp. Read it and be inspired to attend next year. http:\/\/t.co\/Q ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ruby_dcamp",
        "screen_name" : "ruby_dcamp",
        "indices" : [ 55, 66 ],
        "id_str" : "15386856",
        "id" : 15386856
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/QbXMwbje",
        "expanded_url" : "http:\/\/ow.ly\/eeOdr",
        "display_url" : "ow.ly\/eeOdr"
      } ]
    },
    "geo" : { },
    "id_str" : "254075571913519104",
    "text" : "Fantastic write-up of the utterly unique beast that is @ruby_dcamp. Read it and be inspired to attend next year. http:\/\/t.co\/QbXMwbje",
    "id" : 254075571913519104,
    "created_at" : "2012-10-05 04:28:31 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 254104865784094720,
  "created_at" : "2012-10-05 06:24:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 12, 19 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 26, 37 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyhangout",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253979208374681602",
  "text" : "Appreciated @elight's and @chadfowler's talks on #rubyhangout last night, esp. regarding the human aspects of our careers and lives.",
  "id" : 253979208374681602,
  "created_at" : "2012-10-04 22:05:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253584583864508416",
  "text" : "Anyone interested in coming to my place in Reston for the 7:00 Ruby Hangout virtual meeting, and the debate?  I've got wifi and wine. ;)",
  "id" : 253584583864508416,
  "created_at" : "2012-10-03 19:57:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Runkeeper",
      "screen_name" : "Runkeeper",
      "indices" : [ 0, 10 ],
      "id_str" : "15445811",
      "id" : 15445811
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "inappropriate_permissions",
      "indices" : [ 111, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253527990464548864",
  "in_reply_to_user_id" : 15445811,
  "text" : "@runkeeper, I would love to use your app but will not install it because you demand access to my address book. #inappropriate_permissions",
  "id" : 253527990464548864,
  "created_at" : "2012-10-03 16:12:37 +0000",
  "in_reply_to_screen_name" : "Runkeeper",
  "in_reply_to_user_id_str" : "15445811",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Ferguson",
      "screen_name" : "allenderlaura",
      "indices" : [ 102, 116 ],
      "id_str" : "15009170",
      "id" : 15009170
    }, {
      "name" : "Brad Herrup",
      "screen_name" : "bradpudding",
      "indices" : [ 121, 133 ],
      "id_str" : "842668130",
      "id" : 842668130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252954215931068416",
  "text" : "Thanks to those who put the group's needs above their own at #rubydcamp, esp. the kitchen folks, esp. @allenderlaura and @bradpudding.",
  "id" : 252954215931068416,
  "created_at" : "2012-10-02 02:12:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]