Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/1Xzba4YT",
      "expanded_url" : "http:\/\/www.vintage.org\/2012\/east\/",
      "display_url" : "vintage.org\/2012\/east\/"
    } ]
  },
  "geo" : { },
  "id_str" : "164047106879930369",
  "text" : "Vintage Computer Festival East in Wall, NJ (near NYC) on weekend of May 5-6: http:\/\/t.co\/1Xzba4YT",
  "id" : 164047106879930369,
  "created_at" : "2012-01-30 18:07:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/8w2cq4Ow",
      "expanded_url" : "http:\/\/wp.me\/pnNgC-8c",
      "display_url" : "wp.me\/pnNgC-8c"
    } ]
  },
  "geo" : { },
  "id_str" : "163370058670800896",
  "text" : "class_eval, instance_eval, eval http:\/\/t.co\/8w2cq4Ow",
  "id" : 163370058670800896,
  "created_at" : "2012-01-28 21:17:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Trupiano",
      "screen_name" : "jtrupiano",
      "indices" : [ 0, 10 ],
      "id_str" : "14736332",
      "id" : 14736332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/qXBpzhFy",
      "expanded_url" : "http:\/\/airbnb.com",
      "display_url" : "airbnb.com"
    } ]
  },
  "in_reply_to_status_id_str" : "159709650659454976",
  "geo" : { },
  "id_str" : "159812280144498689",
  "in_reply_to_user_id" : 14736332,
  "text" : "@jtrupiano I recommend checking out http:\/\/t.co\/qXBpzhFy.  Many listings do monthly rentals too.",
  "id" : 159812280144498689,
  "in_reply_to_status_id" : 159709650659454976,
  "created_at" : "2012-01-19 01:39:51 +0000",
  "in_reply_to_screen_name" : "jtrupiano",
  "in_reply_to_user_id_str" : "14736332",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Chan-Norris",
      "screen_name" : "jcn",
      "indices" : [ 3, 7 ],
      "id_str" : "10921",
      "id" : 10921
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sopa",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "nytmsos",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/BzNnv7sY",
      "expanded_url" : "http:\/\/flic.kr\/p\/beVNyF",
      "display_url" : "flic.kr\/p\/beVNyF"
    } ]
  },
  "geo" : { },
  "id_str" : "159810216156856320",
  "text" : "RT @jcn: The nerdiest anti #sopa sign ever. #nytmsos http:\/\/t.co\/BzNnv7sY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/flickr.com\/services\/twitter\/\" rel=\"nofollow\"\u003EFlickr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sopa",
        "indices" : [ 18, 23 ]
      }, {
        "text" : "nytmsos",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/BzNnv7sY",
        "expanded_url" : "http:\/\/flic.kr\/p\/beVNyF",
        "display_url" : "flic.kr\/p\/beVNyF"
      } ]
    },
    "geo" : { },
    "id_str" : "159697266209337344",
    "text" : "The nerdiest anti #sopa sign ever. #nytmsos http:\/\/t.co\/BzNnv7sY",
    "id" : 159697266209337344,
    "created_at" : "2012-01-18 18:02:49 +0000",
    "user" : {
      "name" : "Jesse Chan-Norris",
      "screen_name" : "jcn",
      "protected" : false,
      "id_str" : "10921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549299048948039681\/VXHREHdn_normal.jpeg",
      "id" : 10921,
      "verified" : false
    }
  },
  "id" : 159810216156856320,
  "created_at" : "2012-01-19 01:31:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]