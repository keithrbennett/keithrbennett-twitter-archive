Grailbird.data.tweets_2016_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 38, 52 ],
      "id_str" : "76972977",
      "id" : 76972977
    }, {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 92, 103 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "701099146514554880",
  "text" : "Very excited that I will be attending @rubyconfindia in Kochi, Kerala, India next month and @RubyConfPH in Manila, Philippines in April!",
  "id" : 701099146514554880,
  "created_at" : "2016-02-20 17:40:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Agee",
      "screen_name" : "MarkAgee",
      "indices" : [ 3, 12 ],
      "id_str" : "70775995",
      "id" : 70775995
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkAgee\/status\/648235967434719232\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/OV7GCloNBv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP7_KhoUsAAW_IU.jpg",
      "id_str" : "648235952679202816",
      "id" : 648235952679202816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP7_KhoUsAAW_IU.jpg",
      "sizes" : [ {
        "h" : 390,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 390
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 390,
        "resize" : "fit",
        "w" : 390
      } ],
      "display_url" : "pic.twitter.com\/OV7GCloNBv"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/MarkAgee\/status\/648235967434719232\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/OV7GCloNBv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CP7_KgiVEAAWn1F.jpg",
      "id_str" : "648235952385626112",
      "id" : 648235952385626112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP7_KgiVEAAWn1F.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OV7GCloNBv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "696820207679975424",
  "text" : "RT @MarkAgee: I like to think these bears were supposed to meet for lunch but one got the wrong park http:\/\/t.co\/OV7GCloNBv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkAgee\/status\/648235967434719232\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/OV7GCloNBv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP7_KhoUsAAW_IU.jpg",
        "id_str" : "648235952679202816",
        "id" : 648235952679202816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP7_KhoUsAAW_IU.jpg",
        "sizes" : [ {
          "h" : 390,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 390
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 390,
          "resize" : "fit",
          "w" : 390
        } ],
        "display_url" : "pic.twitter.com\/OV7GCloNBv"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/MarkAgee\/status\/648235967434719232\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/OV7GCloNBv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CP7_KgiVEAAWn1F.jpg",
        "id_str" : "648235952385626112",
        "id" : 648235952385626112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CP7_KgiVEAAWn1F.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OV7GCloNBv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "648235967434719232",
    "text" : "I like to think these bears were supposed to meet for lunch but one got the wrong park http:\/\/t.co\/OV7GCloNBv",
    "id" : 648235967434719232,
    "created_at" : "2015-09-27 20:41:12 +0000",
    "user" : {
      "name" : "Mark Agee",
      "screen_name" : "MarkAgee",
      "protected" : false,
      "id_str" : "70775995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2256413506\/twitter_pic_normal.jpg",
      "id" : 70775995,
      "verified" : false
    }
  },
  "id" : 696820207679975424,
  "created_at" : "2016-02-08 22:17:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fritz",
      "screen_name" : "gotofritz",
      "indices" : [ 119, 129 ],
      "id_str" : "17187971",
      "id" : 17187971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/zjh7dDSJ1I",
      "expanded_url" : "http:\/\/gotofritz.net\/blog\/howto\/joining-pdf-files-in-os-x-from-the-command-line\/",
      "display_url" : "gotofritz.net\/blog\/howto\/joi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696819772202336257",
  "text" : "Combine PDF's on a Mac in Preview *or on the command line!!!*: https:\/\/t.co\/zjh7dDSJ1I  This is super useful.  Thanks, @gotofritz!",
  "id" : 696819772202336257,
  "created_at" : "2016-02-08 22:15:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 58, 68 ],
      "id_str" : "14498747",
      "id" : 14498747
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 74, 82 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf2015",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/Hwjua8hlWT",
      "expanded_url" : "https:\/\/goo.gl\/photos\/wQxy6AxGkfpnVPvU6",
      "display_url" : "goo.gl\/photos\/wQxy6Ax\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "696395807084249088",
  "text" : "Man, those were good times. Karaoke at #rubyconf2015 with @tom_enebo  and @headius.   https:\/\/t.co\/Hwjua8hlWT",
  "id" : 696395807084249088,
  "created_at" : "2016-02-07 18:11:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]