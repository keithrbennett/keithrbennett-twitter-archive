Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob Miller",
      "screen_name" : "robmil",
      "indices" : [ 23, 30 ],
      "id_str" : "13514472",
      "id" : 13514472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/dWtO0XGKBD",
      "expanded_url" : "http:\/\/robm.me.uk\/ruby\/2013\/11\/20\/ruby-enp.html",
      "display_url" : "robm.me.uk\/ruby\/2013\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406317908684316674",
  "text" : "Interesting article by @robmil, 'Ruby's -e, -n and -p switches', about using Ruby as a command line filter, at http:\/\/t.co\/dWtO0XGKBD.",
  "id" : 406317908684316674,
  "created_at" : "2013-11-29 07:05:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rails Girls Manila",
      "screen_name" : "railsgirlsMLA",
      "indices" : [ 3, 17 ],
      "id_str" : "609853281",
      "id" : 609853281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/GH4zhflFYk",
      "expanded_url" : "http:\/\/goo.gl\/kRdFSi",
      "display_url" : "goo.gl\/kRdFSi"
    }, {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ucsQ2yZldT",
      "expanded_url" : "http:\/\/fb.me\/2NAyRzW9u",
      "display_url" : "fb.me\/2NAyRzW9u"
    } ]
  },
  "geo" : { },
  "id_str" : "406098284328263680",
  "text" : "RT @railsgirlsMLA: The \"Learn Ruby on Rails\" by Daniel Kehoe book is free today! http:\/\/t.co\/GH4zhflFYk http:\/\/t.co\/ucsQ2yZldT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/GH4zhflFYk",
        "expanded_url" : "http:\/\/goo.gl\/kRdFSi",
        "display_url" : "goo.gl\/kRdFSi"
      }, {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/ucsQ2yZldT",
        "expanded_url" : "http:\/\/fb.me\/2NAyRzW9u",
        "display_url" : "fb.me\/2NAyRzW9u"
      } ]
    },
    "geo" : { },
    "id_str" : "405748371400712192",
    "text" : "The \"Learn Ruby on Rails\" by Daniel Kehoe book is free today! http:\/\/t.co\/GH4zhflFYk http:\/\/t.co\/ucsQ2yZldT",
    "id" : 405748371400712192,
    "created_at" : "2013-11-27 17:22:04 +0000",
    "user" : {
      "name" : "Rails Girls Manila",
      "screen_name" : "railsgirlsMLA",
      "protected" : false,
      "id_str" : "609853281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2697225901\/30328635d34c39353e802efc66c9974e_normal.png",
      "id" : 609853281,
      "verified" : false
    }
  },
  "id" : 406098284328263680,
  "created_at" : "2013-11-28 16:32:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PragmaticProgrammers",
      "screen_name" : "pragprog",
      "indices" : [ 0, 9 ],
      "id_str" : "26576418",
      "id" : 26576418
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JSveUESTlF",
      "expanded_url" : "http:\/\/pragprog.com\/",
      "display_url" : "pragprog.com"
    } ]
  },
  "geo" : { },
  "id_str" : "405926887064494081",
  "in_reply_to_user_id" : 26576418,
  "text" : "@pragprog is offering a 50% discount on all their ebooks for Thanksgiving: http:\/\/t.co\/JSveUESTlF",
  "id" : 405926887064494081,
  "created_at" : "2013-11-28 05:11:26 +0000",
  "in_reply_to_screen_name" : "pragprog",
  "in_reply_to_user_id_str" : "26576418",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/lUxyxLPmwz",
      "expanded_url" : "http:\/\/h10025.www1.hp.com\/ewfrf\/wc\/document?cc=us&lc=en&docname=c03976994",
      "display_url" : "h10025.www1.hp.com\/ewfrf\/wc\/docum\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405915511814250496",
  "text" : "If you upgrade to OS X Maverick &amp; have *any* HP driver-related printer issues, install updated HP software. See: http:\/\/t.co\/lUxyxLPmwz",
  "id" : 405915511814250496,
  "created_at" : "2013-11-28 04:26:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/1lXS8udYix",
      "expanded_url" : "http:\/\/www.amazon.com\/Learning-Program-C-Thomas-Plum\/dp\/0911537082",
      "display_url" : "amazon.com\/Learning-Progr\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "405802456027639808",
  "geo" : { },
  "id_str" : "405824081745809408",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius  [For learning C,] K&amp;R, plus I think I remember Tom Plum's book as being excellent (http:\/\/t.co\/1lXS8udYix).",
  "id" : 405824081745809408,
  "in_reply_to_status_id" : 405802456027639808,
  "created_at" : "2013-11-27 22:22:55 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "snipe",
      "screen_name" : "snipeyhead",
      "indices" : [ 3, 14 ],
      "id_str" : "14246782",
      "id" : 14246782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "relatable",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/ctl6KgpEL4",
      "expanded_url" : "http:\/\/snipe.ly\/18osOd6",
      "display_url" : "snipe.ly\/18osOd6"
    } ]
  },
  "geo" : { },
  "id_str" : "405818305308803072",
  "text" : "RT @snipeyhead: I Hope My Father Dies Soon: http:\/\/t.co\/ctl6KgpEL4 - very powerful and sad piece by Scott Adams. #relatable (thx, @uberbrad\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lethal Weapon ftw",
        "screen_name" : "uberbrady",
        "indices" : [ 114, 124 ],
        "id_str" : "14088627",
        "id" : 14088627
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "relatable",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/ctl6KgpEL4",
        "expanded_url" : "http:\/\/snipe.ly\/18osOd6",
        "display_url" : "snipe.ly\/18osOd6"
      } ]
    },
    "geo" : { },
    "id_str" : "405778052690755584",
    "text" : "I Hope My Father Dies Soon: http:\/\/t.co\/ctl6KgpEL4 - very powerful and sad piece by Scott Adams. #relatable (thx, @uberbrady)",
    "id" : 405778052690755584,
    "created_at" : "2013-11-27 19:20:01 +0000",
    "user" : {
      "name" : "snipe",
      "screen_name" : "snipeyhead",
      "protected" : false,
      "id_str" : "14246782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545415835675033600\/gDuSi44o_normal.jpeg",
      "id" : 14246782,
      "verified" : true
    }
  },
  "id" : 405818305308803072,
  "created_at" : "2013-11-27 21:59:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "405472465758859264",
  "geo" : { },
  "id_str" : "405487286726295552",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Good man! ;) I've called #77 (State Police) many times to report road hazards, weaving drivers, &amp; even a car fire once.",
  "id" : 405487286726295552,
  "in_reply_to_status_id" : 405472465758859264,
  "created_at" : "2013-11-27 00:04:37 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/405211795591155713\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/oYBqJnmPOC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZ-Z-y_CUAAt7h_.jpg",
      "id_str" : "405211795603738624",
      "id" : 405211795603738624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZ-Z-y_CUAAt7h_.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oYBqJnmPOC"
    } ],
    "hashtags" : [ {
      "text" : "LinuxMint",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405211795591155713",
  "text" : "#LinuxMint 16 on a USB stick now bootable on a Mac!  Use 'mintstick' app to make bootable USB stick from ISO easily. http:\/\/t.co\/oYBqJnmPOC",
  "id" : 405211795591155713,
  "created_at" : "2013-11-26 05:49:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DRiOlRRA5R",
      "expanded_url" : "http:\/\/www.philnews.com\/",
      "display_url" : "philnews.com"
    } ]
  },
  "geo" : { },
  "id_str" : "404457477950812161",
  "text" : "A gracious editorial from the Philippines thanking the world for the aid sent in response to Typhoon Haiyan\/Yolanda: http:\/\/t.co\/DRiOlRRA5R",
  "id" : 404457477950812161,
  "created_at" : "2013-11-24 03:52:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyTapas",
      "screen_name" : "rubytapas",
      "indices" : [ 0, 10 ],
      "id_str" : "309845557",
      "id" : 309845557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nbIn47Ikue",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/11\/22\/rubys-injectreduce-and-each_with_object\/",
      "display_url" : "bbs-software.com\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403897705765695488",
  "in_reply_to_user_id" : 309845557,
  "text" : "@rubytapas Regarding our discussion of inject\/reduce and each_with_object, I posted an article with more detail at http:\/\/t.co\/nbIn47Ikue.",
  "id" : 403897705765695488,
  "created_at" : "2013-11-22 14:48:11 +0000",
  "in_reply_to_screen_name" : "rubytapas",
  "in_reply_to_user_id_str" : "309845557",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/nbIn47Ikue",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/11\/22\/rubys-injectreduce-and-each_with_object\/",
      "display_url" : "bbs-software.com\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403772479220371456",
  "text" : "Just posted \"Ruby's inject\/reduce and each_with_object\" on my blog at   http:\/\/t.co\/nbIn47Ikue.",
  "id" : 403772479220371456,
  "created_at" : "2013-11-22 06:30:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 8, 16 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "403569242311639040",
  "geo" : { },
  "id_str" : "403627602570919936",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @bokmann JVisualVM?",
  "id" : 403627602570919936,
  "in_reply_to_status_id" : 403569242311639040,
  "created_at" : "2013-11-21 20:54:54 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 97, 108 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/lLHSJA2i2N",
      "expanded_url" : "http:\/\/rubyconf.ph\/",
      "display_url" : "rubyconf.ph"
    } ]
  },
  "geo" : { },
  "id_str" : "403524747167670273",
  "text" : "First ever Ruby conference in Philippines will be in March 2014!  They're calling for proposals. @RubyConfPH http:\/\/t.co\/lLHSJA2i2N",
  "id" : 403524747167670273,
  "created_at" : "2013-11-21 14:06:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/sY7jVlEVF6",
      "expanded_url" : "http:\/\/www.weather.com\/news\/weather-hurricanes\/photos-typhoon-haiyan-western-pacific-20131107",
      "display_url" : "weather.com\/news\/weather-h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "402268971480928256",
  "text" : "400+ dramatic photos of Typhoon Haiyan destruction, displacement, and grief in the Philippines, at http:\/\/t.co\/sY7jVlEVF6.",
  "id" : 402268971480928256,
  "created_at" : "2013-11-18 02:56:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400430312057868288",
  "geo" : { },
  "id_str" : "400468798446112769",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori ...is that usually ||= is used for a 1-time init, and when x gets a falsy value the assignment would be done next time too. Weird.",
  "id" : 400468798446112769,
  "in_reply_to_status_id" : 400430312057868288,
  "created_at" : "2013-11-13 03:42:56 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400430312057868288",
  "geo" : { },
  "id_str" : "400468089906544640",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori x ||= false is a cryptic way of saying x = false if x.nil?, right? Seems like the latter would be much clearer. Also, the surprise",
  "id" : 400468089906544640,
  "in_reply_to_status_id" : 400430312057868288,
  "created_at" : "2013-11-13 03:40:07 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400430312057868288",
  "geo" : { },
  "id_str" : "400467537445392384",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori Doh! You're right. May I claim dyslexic moment? ;) I saw x ||= false in code and it didn't make sense to me, but for wrong reason.",
  "id" : 400467537445392384,
  "in_reply_to_status_id" : 400430312057868288,
  "created_at" : "2013-11-13 03:37:55 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400395555324428288",
  "text" : "I would have thought an assignment would only be performed if the lval was falsy. Instead, 'x = nil; x ||= false is doing 'x = x || false'.",
  "id" : 400395555324428288,
  "created_at" : "2013-11-12 22:51:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/4Db2jGKGRz",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/7440066",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400391674494341120",
  "text" : "Big surprise to me...Ruby assigns a falsy rval to a falsy lval in ||= (see my gist at https:\/\/t.co\/4Db2jGKGRz).",
  "id" : 400391674494341120,
  "created_at" : "2013-11-12 22:36:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399941007883505664",
  "text" : "Finished reading \"The Phoenix Project\" last night.  Interesting read about rescuing a company from an epic fail technical debt morass.",
  "id" : 399941007883505664,
  "created_at" : "2013-11-11 16:45:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 64, 73 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/399938659241050112\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/QrmH4U4XMS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYzeF3RCQAA7YwC.jpg",
      "id_str" : "399938659245244416",
      "id" : 399938659245244416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYzeF3RCQAA7YwC.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QrmH4U4XMS"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 5, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399938659241050112",
  "text" : "With #rubyfriends Pablo and Forrest on Miami Beach yesterday at @rubyconf. http:\/\/t.co\/QrmH4U4XMS",
  "id" : 399938659241050112,
  "created_at" : "2013-11-11 16:36:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399680827552190464",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf If you're going to the airport, leave a lot of extra time. Traffic is horrendous.",
  "id" : 399680827552190464,
  "created_at" : "2013-11-10 23:31:49 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399670724102983680",
  "geo" : { },
  "id_str" : "399671076093165568",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf trash it. Thanks.",
  "id" : 399671076093165568,
  "in_reply_to_status_id" : 399670724102983680,
  "created_at" : "2013-11-10 22:53:04 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haiyan",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MJriLrfITw",
      "expanded_url" : "http:\/\/www.cnn.com\/2013\/11\/09\/world\/asia\/philippines-typhoon-us-assistance\/index.html?hpt=hp_t1",
      "display_url" : "cnn.com\/2013\/11\/09\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399664768098660352",
  "text" : "Already 10K deaths from #Haiyan, 2.5x toll of 9\/11.  Climate change deniers, how much more evidence do you need? http:\/\/t.co\/MJriLrfITw",
  "id" : 399664768098660352,
  "created_at" : "2013-11-10 22:28:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399661696337604608",
  "geo" : { },
  "id_str" : "399662608317702144",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Nice seeing you too and thanks for your awesome work on #jruby. Hope to see you next year in San Diego if not sooner.",
  "id" : 399662608317702144,
  "in_reply_to_status_id" : 399661696337604608,
  "created_at" : "2013-11-10 22:19:25 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Dewitt",
      "screen_name" : "abrandoned",
      "indices" : [ 0, 11 ],
      "id_str" : "167377571",
      "id" : 167377571
    }, {
      "name" : "Tony Arcieri",
      "screen_name" : "bascule",
      "indices" : [ 12, 20 ],
      "id_str" : "6083342",
      "id" : 6083342
    }, {
      "name" : "TCS",
      "screen_name" : "halorgium",
      "indices" : [ 21, 31 ],
      "id_str" : "5881482",
      "id" : 5881482
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 32, 40 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 41, 51 ],
      "id_str" : "14498747",
      "id" : 14498747
    }, {
      "name" : "Paul Elliott",
      "screen_name" : "p_elliott",
      "indices" : [ 52, 62 ],
      "id_str" : "18047782",
      "id" : 18047782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399656896590012416",
  "geo" : { },
  "id_str" : "399658169200570368",
  "in_reply_to_user_id" : 167377571,
  "text" : "@abrandoned @bascule @halorgium @headius @tom_enebo @p_elliott Thanks so much but I'm leaving momentarily for the airport. Next year in SD!",
  "id" : 399658169200570368,
  "in_reply_to_status_id" : 399656896590012416,
  "created_at" : "2013-11-10 22:01:47 +0000",
  "in_reply_to_screen_name" : "abrandoned",
  "in_reply_to_user_id_str" : "167377571",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399627208152453121",
  "text" : "If you ever get an \"Out of Range\" error while displaying on a projector, make sure your frequency is not too high (60 MHz is prob. ok).",
  "id" : 399627208152453121,
  "created_at" : "2013-11-10 19:58:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399608067077066752",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf I have a car and am thinking of leaving for MIA at 5, stopping in Little Havana for dinner on the way.  Anyone want to join me?",
  "id" : 399608067077066752,
  "created_at" : "2013-11-10 18:42:42 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/nWCBRuaB4b",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/sing-sing-karaoke-miami-beach-2",
      "display_url" : "yelp.com\/biz\/sing-sing-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "399300347207753728",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf Anyone interested in karaoke at Sing Sing (http:\/\/t.co\/nWCBRuaB4b) at about 9:30? They have public space and private rooms.",
  "id" : 399300347207753728,
  "created_at" : "2013-11-09 22:19:56 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 23, 32 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/399292512365723648\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/83JkXvgDQo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYqSbInIUAAQnBd.jpg",
      "id_str" : "399292511841439744",
      "id" : 399292511841439744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYqSbInIUAAQnBd.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/83JkXvgDQo"
    } ],
    "hashtags" : [ {
      "text" : "JRuby",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399292512365723648",
  "text" : "MRI \/ #JRuby summit at @rubyconf. http:\/\/t.co\/83JkXvgDQo",
  "id" : 399292512365723648,
  "created_at" : "2013-11-09 21:48:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YAML Clark",
      "screen_name" : "jasonrclark",
      "indices" : [ 3, 15 ],
      "id_str" : "10423752",
      "id" : 10423752
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 101, 112 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399282529787973632",
  "text" : "RT @jasonrclark: \"If you make your diagrams too pretty you might be inclined to keep them too long.\" @jimweirich #rubyconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Weirich",
        "screen_name" : "jimweirich",
        "indices" : [ 84, 95 ],
        "id_str" : "9070452",
        "id" : 9070452
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rubyconf",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 25.7890902863, -80.129151391 ]
    },
    "id_str" : "399259922774241280",
    "text" : "\"If you make your diagrams too pretty you might be inclined to keep them too long.\" @jimweirich #rubyconf",
    "id" : 399259922774241280,
    "created_at" : "2013-11-09 19:39:18 +0000",
    "user" : {
      "name" : "YAML Clark",
      "screen_name" : "jasonrclark",
      "protected" : false,
      "id_str" : "10423752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796422765913862144\/FQ2IVB60_normal.jpg",
      "id" : 10423752,
      "verified" : false
    }
  },
  "id" : 399282529787973632,
  "created_at" : "2013-11-09 21:09:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 23, 32 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398536599266263041",
  "text" : "Woohoo!!! On my way to @rubyconf! I'll be driving from MIA to the hotel at about 12:30 AM tonight if anyone would like a ride.",
  "id" : 398536599266263041,
  "created_at" : "2013-11-07 19:45:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Kehoe",
      "screen_name" : "rails_apps",
      "indices" : [ 1, 12 ],
      "id_str" : "209711777",
      "id" : 209711777
    }, {
      "name" : "Jaco Pretorius",
      "screen_name" : "JacoPretorius",
      "indices" : [ 40, 54 ],
      "id_str" : "17149750",
      "id" : 17149750
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/yF0UAkRBNP",
      "expanded_url" : "http:\/\/j.mp\/1b9jy7v",
      "display_url" : "j.mp\/1b9jy7v"
    } ]
  },
  "geo" : { },
  "id_str" : "398083112342925312",
  "text" : "\"@rails_apps: 'RSpec Best Practices' by @JacoPretorius http:\/\/t.co\/yF0UAkRBNP\" Great article!",
  "id" : 398083112342925312,
  "created_at" : "2013-11-06 13:43:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]