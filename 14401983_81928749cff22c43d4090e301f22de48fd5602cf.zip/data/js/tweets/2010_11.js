Grailbird.data.tweets_2010_11 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yokolet",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "rubyconf2010",
      "indices" : [ 22, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "3885511378731008",
  "text" : "#yokolet showed us at #rubyconf2010 how simple it is to call Ruby code from Clojure, Groovy, Scala, Jython (http:\/\/tinyurl.com\/34kqbyc).",
  "id" : 3885511378731008,
  "created_at" : "2010-11-14 19:02:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]