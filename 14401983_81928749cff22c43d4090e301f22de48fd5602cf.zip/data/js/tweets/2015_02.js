Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/3SjOBC5has",
      "expanded_url" : "https:\/\/www.youtube.com\/embed\/h3LeVGOBjSg?feature=player_embeddedhttps:\/\/www.youtube.com\/embed\/h3LeVGOBjSg?feature=player_embedded",
      "display_url" : "youtube.com\/embed\/h3LeVGOB\u2026"
    }, {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/TVyPzHyfkZ",
      "expanded_url" : "http:\/\/www.airpano.com\/?set_language=2",
      "display_url" : "airpano.com\/?set_language=2"
    } ]
  },
  "geo" : { },
  "id_str" : "569554925602131968",
  "text" : "Stunning 3D Panoramic Views: YouTube video at https:\/\/t.co\/3SjOBC5has, main site w\/many places at http:\/\/t.co\/TVyPzHyfkZ.",
  "id" : 569554925602131968,
  "created_at" : "2015-02-22 17:50:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia Motors America",
      "screen_name" : "Kia",
      "indices" : [ 0, 4 ],
      "id_str" : "23689478",
      "id" : 23689478
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/569353563228528640\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/rYybIBbbiE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-bADIRIAAA3QSL.png",
      "id_str" : "569353562900398080",
      "id" : 569353562900398080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-bADIRIAAA3QSL.png",
      "sizes" : [ {
        "h" : 169,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 886
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 298,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 886
      } ],
      "display_url" : "pic.twitter.com\/rYybIBbbiE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569353563228528640",
  "in_reply_to_user_id" : 23689478,
  "text" : "@kia I like my Optima, but your mileage dashboard display overstates the mileage by 15-30% (see attached worksheet). http:\/\/t.co\/rYybIBbbiE",
  "id" : 569353563228528640,
  "created_at" : "2015-02-22 04:30:42 +0000",
  "in_reply_to_screen_name" : "Kia",
  "in_reply_to_user_id_str" : "23689478",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doug Hellmann",
      "screen_name" : "doughellmann",
      "indices" : [ 3, 16 ],
      "id_str" : "17407556",
      "id" : 17407556
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 18, 32 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "goozbach",
      "screen_name" : "goozbach",
      "indices" : [ 33, 42 ],
      "id_str" : "11816472",
      "id" : 11816472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/iP6STqpAAN",
      "expanded_url" : "https:\/\/pypi.python.org\/pypi\/cliff",
      "display_url" : "pypi.python.org\/pypi\/cliff"
    } ]
  },
  "geo" : { },
  "id_str" : "569298124658892800",
  "text" : "RT @doughellmann: @keithrbennett @goozbach that's why we added both to cliff to make it easy! https:\/\/t.co\/iP6STqpAAN https:\/\/t.co\/EYwPZWtQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "goozbach",
        "screen_name" : "goozbach",
        "indices" : [ 15, 24 ],
        "id_str" : "11816472",
        "id" : 11816472
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/iP6STqpAAN",
        "expanded_url" : "https:\/\/pypi.python.org\/pypi\/cliff",
        "display_url" : "pypi.python.org\/pypi\/cliff"
      }, {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/EYwPZWtQDf",
        "expanded_url" : "https:\/\/pypi.python.org\/pypi\/cliff-tablib",
        "display_url" : "pypi.python.org\/pypi\/cliff-tab\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "569191093478273025",
    "geo" : { },
    "id_str" : "569274213598679040",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett @goozbach that's why we added both to cliff to make it easy! https:\/\/t.co\/iP6STqpAAN https:\/\/t.co\/EYwPZWtQDf",
    "id" : 569274213598679040,
    "in_reply_to_status_id" : 569191093478273025,
    "created_at" : "2015-02-21 23:15:23 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "Doug Hellmann",
      "screen_name" : "doughellmann",
      "protected" : false,
      "id_str" : "17407556",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000638199863\/2a96a5b72719e702d58543c65773f61c_normal.jpeg",
      "id" : 17407556,
      "verified" : false
    }
  },
  "id" : 569298124658892800,
  "created_at" : "2015-02-22 00:50:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569191093478273025",
  "text" : "Writing a command line app that outputs info? Consider adding options for JSON and\/or YAML output. Makes use by scripts trivially simple.",
  "id" : 569191093478273025,
  "created_at" : "2015-02-21 17:45:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/569186216987533313\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/yzDr8bvO9x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Yn2OtCMAAy3Ue.png",
      "id_str" : "569186215522349056",
      "id" : 569186215522349056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Yn2OtCMAAy3Ue.png",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 302,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/yzDr8bvO9x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569186216987533313",
  "text" : "Thank you medical, police, fire, ambulance, retail, and other workers who serve us despite weather\/traffic. http:\/\/t.co\/yzDr8bvO9x",
  "id" : 569186216987533313,
  "created_at" : "2015-02-21 17:25:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Epps",
      "screen_name" : "meppstimist",
      "indices" : [ 0, 12 ],
      "id_str" : "285157838",
      "id" : 285157838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "568405886777094144",
  "geo" : { },
  "id_str" : "568414913279987712",
  "in_reply_to_user_id" : 285157838,
  "text" : "@meppstimist You're very welcome.  Let me know if I can help.",
  "id" : 568414913279987712,
  "in_reply_to_status_id" : 568405886777094144,
  "created_at" : "2015-02-19 14:20:50 +0000",
  "in_reply_to_screen_name" : "meppstimist",
  "in_reply_to_user_id_str" : "285157838",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Epps",
      "screen_name" : "meppstimist",
      "indices" : [ 3, 15 ],
      "id_str" : "285157838",
      "id" : 285157838
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 17, 31 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dcrug",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "ruby",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568414708136607744",
  "text" : "RT @meppstimist: @keithrbennett Thanks for a great #dcrug talk last week! I'm trying to implement #ruby lambdas in our salesforce_model gem.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dcrug",
        "indices" : [ 34, 40 ]
      }, {
        "text" : "ruby",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568405886777094144",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett Thanks for a great #dcrug talk last week! I'm trying to implement #ruby lambdas in our salesforce_model gem.",
    "id" : 568405886777094144,
    "created_at" : "2015-02-19 13:44:58 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "Maggie Epps",
      "screen_name" : "meppstimist",
      "protected" : false,
      "id_str" : "285157838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000412040667\/c5afd0affaddcfd423a2fba6eda1cd3a_normal.jpeg",
      "id" : 285157838,
      "verified" : false
    }
  },
  "id" : 568414708136607744,
  "created_at" : "2015-02-19 14:20:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Sankey",
      "screen_name" : "WSankey",
      "indices" : [ 3, 11 ],
      "id_str" : "23907916",
      "id" : 23907916
    }, {
      "name" : "dcrug",
      "screen_name" : "dcrug",
      "indices" : [ 43, 49 ],
      "id_str" : "16994623",
      "id" : 16994623
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 95, 109 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "Piotr Steininger",
      "screen_name" : "polishprince",
      "indices" : [ 110, 123 ],
      "id_str" : "14539054",
      "id" : 14539054
    }, {
      "name" : "Social Driver",
      "screen_name" : "SocialDriver",
      "indices" : [ 124, 137 ],
      "id_str" : "309849736",
      "id" : 309849736
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/vv73AmeDby",
      "expanded_url" : "http:\/\/bit.ly\/1ElukaL",
      "display_url" : "bit.ly\/1ElukaL"
    } ]
  },
  "geo" : { },
  "id_str" : "566377214019928064",
  "text" : "RT @WSankey: Thanks for yesterday's meetup @dcrug I wrote about it here http:\/\/t.co\/vv73AmeDby @keithrbennett @polishprince @socialdriver",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "dcrug",
        "screen_name" : "dcrug",
        "indices" : [ 30, 36 ],
        "id_str" : "16994623",
        "id" : 16994623
      }, {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 82, 96 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "Piotr Steininger",
        "screen_name" : "polishprince",
        "indices" : [ 97, 110 ],
        "id_str" : "14539054",
        "id" : 14539054
      }, {
        "name" : "Social Driver",
        "screen_name" : "SocialDriver",
        "indices" : [ 111, 124 ],
        "id_str" : "309849736",
        "id" : 309849736
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/vv73AmeDby",
        "expanded_url" : "http:\/\/bit.ly\/1ElukaL",
        "display_url" : "bit.ly\/1ElukaL"
      } ]
    },
    "geo" : { },
    "id_str" : "566371340412665857",
    "text" : "Thanks for yesterday's meetup @dcrug I wrote about it here http:\/\/t.co\/vv73AmeDby @keithrbennett @polishprince @socialdriver",
    "id" : 566371340412665857,
    "created_at" : "2015-02-13 23:00:24 +0000",
    "user" : {
      "name" : "William Sankey",
      "screen_name" : "WSankey",
      "protected" : false,
      "id_str" : "23907916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/660266011531210752\/d_XjGZfN_normal.jpg",
      "id" : 23907916,
      "verified" : false
    }
  },
  "id" : 566377214019928064,
  "created_at" : "2015-02-13 23:23:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Orcutt",
      "screen_name" : "suavemint",
      "indices" : [ 0, 10 ],
      "id_str" : "77905323",
      "id" : 77905323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "566219198939271168",
  "geo" : { },
  "id_str" : "566246474732691456",
  "in_reply_to_user_id" : 77905323,
  "text" : "@suavemint Thanks!  I'm glad you found it helpful.",
  "id" : 566246474732691456,
  "in_reply_to_status_id" : 566219198939271168,
  "created_at" : "2015-02-13 14:44:14 +0000",
  "in_reply_to_screen_name" : "suavemint",
  "in_reply_to_user_id_str" : "77905323",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Q80aNnrgKs",
      "expanded_url" : "http:\/\/www.meetup.com\/dcruby\/events\/200934272\/",
      "display_url" : "meetup.com\/dcruby\/events\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565696928483393538",
  "text" : "I'll be giving a presentation on Ruby Lambdas tomorrow at the DC Ruby User Group (see http:\/\/t.co\/Q80aNnrgKs).",
  "id" : 565696928483393538,
  "created_at" : "2015-02-12 02:20:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gary Kriebel",
      "screen_name" : "GaryKriebel",
      "indices" : [ 17, 29 ],
      "id_str" : "12074812",
      "id" : 12074812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/LO73gaz2t9",
      "expanded_url" : "http:\/\/www.engadget.com\/2015\/02\/07\/treadmill-desks-make-you-clevererer\/",
      "display_url" : "engadget.com\/2015\/02\/07\/tre\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "564435838831173632",
  "geo" : { },
  "id_str" : "564472979506352128",
  "in_reply_to_user_id" : 12074812,
  "text" : "Thanks for this, @GaryKriebel.  Researchers say treadmill desks make you smarter: http:\/\/t.co\/LO73gaz2t9",
  "id" : 564472979506352128,
  "in_reply_to_status_id" : 564435838831173632,
  "created_at" : "2015-02-08 17:17:00 +0000",
  "in_reply_to_screen_name" : "GaryKriebel",
  "in_reply_to_user_id_str" : "12074812",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CenterForOpenScience",
      "screen_name" : "OSFramework",
      "indices" : [ 26, 38 ],
      "id_str" : "404946566",
      "id" : 404946566
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/564172783345995776\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Js7Rw4RaBC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RYJrtCIAAVSoh.jpg",
      "id_str" : "564172776701829120",
      "id" : 564172776701829120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RYJrtCIAAVSoh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/Js7Rw4RaBC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564172783345995776",
  "text" : "Treadmill workstations at @OSFramework in Charlottesville. http:\/\/t.co\/Js7Rw4RaBC",
  "id" : 564172783345995776,
  "created_at" : "2015-02-07 21:24:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harper trow",
      "screen_name" : "harpertrow",
      "indices" : [ 0, 11 ],
      "id_str" : "4533481",
      "id" : 4533481
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/564167810906345473\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/8fxW1DUxsk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RTojgCAAANmGh.jpg",
      "id_str" : "564167809517617152",
      "id" : 564167809517617152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RTojgCAAANmGh.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/8fxW1DUxsk"
    } ],
    "hashtags" : [ {
      "text" : "beswarm",
      "indices" : [ 54, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564167810906345473",
  "in_reply_to_user_id" : 4533481,
  "text" : "@harpertrow shows us an infrared hand sensor setup at #beswarm. http:\/\/t.co\/8fxW1DUxsk",
  "id" : 564167810906345473,
  "created_at" : "2015-02-07 21:04:22 +0000",
  "in_reply_to_screen_name" : "harpertrow",
  "in_reply_to_user_id_str" : "4533481",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Feminella",
      "screen_name" : "jxxf",
      "indices" : [ 3, 8 ],
      "id_str" : "19463693",
      "id" : 19463693
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 31, 45 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jxxf\/status\/564163606800269313\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/7CClmyakyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RPzcoCMAAxSty.jpg",
      "id_str" : "564163598604185600",
      "id" : 564163598604185600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RPzcoCMAAxSty.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7CClmyakyX"
    } ],
    "hashtags" : [ {
      "text" : "beSwarm",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564163959759327232",
  "text" : "RT @jxxf: On deck at #beSwarm: @keithrbennett tells us about minimizing complexity by extracting methods. http:\/\/t.co\/7CClmyakyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 21, 35 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jxxf\/status\/564163606800269313\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/7CClmyakyX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9RPzcoCMAAxSty.jpg",
        "id_str" : "564163598604185600",
        "id" : 564163598604185600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9RPzcoCMAAxSty.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7CClmyakyX"
      } ],
      "hashtags" : [ {
        "text" : "beSwarm",
        "indices" : [ 11, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564163606800269313",
    "text" : "On deck at #beSwarm: @keithrbennett tells us about minimizing complexity by extracting methods. http:\/\/t.co\/7CClmyakyX",
    "id" : 564163606800269313,
    "created_at" : "2015-02-07 20:47:40 +0000",
    "user" : {
      "name" : "John Feminella",
      "screen_name" : "jxxf",
      "protected" : false,
      "id_str" : "19463693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3348427561\/9d7f08f1e103a16c8debd169301b9944_normal.jpeg",
      "id" : 19463693,
      "verified" : false
    }
  },
  "id" : 564163959759327232,
  "created_at" : "2015-02-07 20:49:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tim miano",
      "screen_name" : "tjmiano",
      "indices" : [ 3, 11 ],
      "id_str" : "2818113395",
      "id" : 2818113395
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 28, 42 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tjmiano\/status\/564162187787501569\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JhuokDRbsc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ROgMUIMAA7-aN.jpg",
      "id_str" : "564162168296583168",
      "id" : 564162168296583168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ROgMUIMAA7-aN.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JhuokDRbsc"
    } ],
    "hashtags" : [ {
      "text" : "beSwarm",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564163939379204097",
  "text" : "RT @tjmiano: Great #beSwarm @keithrbennett lightning talk on Ruby Lambdas! http:\/\/t.co\/JhuokDRbsc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 15, 29 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tjmiano\/status\/564162187787501569\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/JhuokDRbsc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ROgMUIMAA7-aN.jpg",
        "id_str" : "564162168296583168",
        "id" : 564162168296583168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ROgMUIMAA7-aN.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JhuokDRbsc"
      } ],
      "hashtags" : [ {
        "text" : "beSwarm",
        "indices" : [ 6, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564162187787501569",
    "text" : "Great #beSwarm @keithrbennett lightning talk on Ruby Lambdas! http:\/\/t.co\/JhuokDRbsc",
    "id" : 564162187787501569,
    "created_at" : "2015-02-07 20:42:01 +0000",
    "user" : {
      "name" : "tim miano",
      "screen_name" : "tjmiano",
      "protected" : false,
      "id_str" : "2818113395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776432723120521216\/1DBtqwVs_normal.jpg",
      "id" : 2818113395,
      "verified" : false
    }
  },
  "id" : 564163939379204097,
  "created_at" : "2015-02-07 20:48:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "harper trow",
      "screen_name" : "harpertrow",
      "indices" : [ 8, 19 ],
      "id_str" : "4533481",
      "id" : 4533481
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/564103468781035520\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/vPZRg1zxsE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9QZHHiIYAEVl_Q.jpg",
      "id_str" : "564103463400136705",
      "id" : 564103463400136705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9QZHHiIYAEVl_Q.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vPZRg1zxsE"
    } ],
    "hashtags" : [ {
      "text" : "beswarm",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564103468781035520",
  "text" : "Thanks, @harpertrow, for letting me experience Oculus Rift virtual reality at #beswarm in Charlottesville. http:\/\/t.co\/vPZRg1zxsE",
  "id" : 564103468781035520,
  "created_at" : "2015-02-07 16:48:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/nzqLlruUl9",
      "expanded_url" : "http:\/\/smile.amazon.com\/gp\/product\/B0046H56JS\/ref=oh_aui_detailpage_o01_s00?ie=UTF8&psc=1",
      "display_url" : "smile.amazon.com\/gp\/product\/B00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561957402615230465",
  "text" : "No need to spend 100's on a back chair.  I'm quite happy with this $133 office chair: http:\/\/t.co\/nzqLlruUl9.",
  "id" : 561957402615230465,
  "created_at" : "2015-02-01 18:41:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consumer Reports",
      "screen_name" : "ConsumerReports",
      "indices" : [ 8, 24 ],
      "id_str" : "16193528",
      "id" : 16193528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/SpeYOrqjBI",
      "expanded_url" : "http:\/\/www.consumerreports.org\/cro\/magazine\/2015\/01\/the-surprising-dangers-of-ct-sans-and-x-rays\/index.htm?EXTKEY=NH51S00H",
      "display_url" : "consumerreports.org\/cro\/magazine\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561954925211828225",
  "text" : "As per  @ConsumerReports  at http:\/\/t.co\/SpeYOrqjBI : question the need for CT scans -- they have a high cost in cancer risk.",
  "id" : 561954925211828225,
  "created_at" : "2015-02-01 18:31:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]