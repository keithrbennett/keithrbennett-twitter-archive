Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81215150203486208",
  "text" : "Dependency Inversion, Ruby Style http:\/\/wp.me\/pnNgC-7g",
  "id" : 81215150203486208,
  "created_at" : "2011-06-16 04:22:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SouthEast LinuxFest",
      "screen_name" : "SELinuxFest",
      "indices" : [ 0, 12 ],
      "id_str" : "34671194",
      "id" : 34671194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79346834178453504",
  "in_reply_to_user_id" : 34671194,
  "text" : "@selinuxfest 'ers: For dinner tomorrow in Spartanburg I recommend the $4.99 Chinese buffet at Sun King, 1915 E. Main St.",
  "id" : 79346834178453504,
  "created_at" : "2011-06-11 00:38:54 +0000",
  "in_reply_to_screen_name" : "SELinuxFest",
  "in_reply_to_user_id_str" : "34671194",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SouthEast LinuxFest",
      "screen_name" : "SELinuxFest",
      "indices" : [ 0, 12 ],
      "id_str" : "34671194",
      "id" : 34671194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79024069114208256",
  "in_reply_to_user_id" : 34671194,
  "text" : "@SELinuxFest Ruby is a great scripting language for Linux. I can do an intro to Ruby if interested, based on http:\/\/tinyurl.com\/664aw6u.",
  "id" : 79024069114208256,
  "created_at" : "2011-06-10 03:16:20 +0000",
  "in_reply_to_screen_name" : "SELinuxFest",
  "in_reply_to_user_id_str" : "34671194",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sau Sheong",
      "screen_name" : "sausheong",
      "indices" : [ 0, 10 ],
      "id_str" : "11879822",
      "id" : 11879822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "77368715569676288",
  "geo" : { },
  "id_str" : "77377598723850240",
  "in_reply_to_user_id" : 11879822,
  "text" : "@sausheong For large data sets, check out http:\/\/www.quora.com\/Data\/Where-can-I-get-large-datasets-open-to-the-public.",
  "id" : 77377598723850240,
  "in_reply_to_status_id" : 77368715569676288,
  "created_at" : "2011-06-05 14:13:51 +0000",
  "in_reply_to_screen_name" : "sausheong",
  "in_reply_to_user_id_str" : "11879822",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stjohnc",
      "screen_name" : "stjohnc",
      "indices" : [ 0, 8 ],
      "id_str" : "11252172",
      "id" : 11252172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76638664045764608",
  "in_reply_to_user_id" : 11252172,
  "text" : "@stjohnc Thanks to you too, for writing cli-colorize (https:\/\/github.com\/stjohncj\/cli-colorize) for printing colored output to stdout.",
  "id" : 76638664045764608,
  "created_at" : "2011-06-03 13:17:36 +0000",
  "in_reply_to_screen_name" : "stjohnc",
  "in_reply_to_user_id_str" : "11252172",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]