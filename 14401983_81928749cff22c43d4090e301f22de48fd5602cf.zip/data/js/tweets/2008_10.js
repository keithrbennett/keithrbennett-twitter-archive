Grailbird.data.tweets_2008_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "985714568",
  "text" : "Just paid 2 women to come over to my place and make me feel good -- they cleaned my apartment. ;)",
  "id" : 985714568,
  "created_at" : "2008-11-01 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Thomas",
      "screen_name" : "pragdave",
      "indices" : [ 0, 9 ],
      "id_str" : "6186692",
      "id" : 6186692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "983911571",
  "geo" : { },
  "id_str" : "983916648",
  "in_reply_to_user_id" : 6186692,
  "text" : "@pragdave was it Churchill who said 'all that is necessary for evil to triumph is for good men to do nothing.\"?",
  "id" : 983916648,
  "in_reply_to_status_id" : 983911571,
  "created_at" : "2008-10-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "pragdave",
  "in_reply_to_user_id_str" : "6186692",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "voodootikigod",
      "indices" : [ 0, 14 ],
      "id_str" : "637763",
      "id" : 637763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "980775489",
  "geo" : { },
  "id_str" : "980778087",
  "in_reply_to_user_id" : 637763,
  "text" : "@voodootikigod Even the *waiting list* for RubyConf is closed.",
  "id" : 980778087,
  "in_reply_to_status_id" : 980775489,
  "created_at" : "2008-10-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "voodootikigod",
  "in_reply_to_user_id_str" : "637763",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hessler",
      "screen_name" : "spune",
      "indices" : [ 0, 6 ],
      "id_str" : "14197941",
      "id" : 14197941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "975089284",
  "geo" : { },
  "id_str" : "975101100",
  "in_reply_to_user_id" : 14197941,
  "text" : "@Spune Nathan, if you don't already have a scanning solution, I recommend Fujitsu ScanSnap (thanks, Evan).",
  "id" : 975101100,
  "in_reply_to_status_id" : 975089284,
  "created_at" : "2008-10-25 00:00:00 +0000",
  "in_reply_to_screen_name" : "spune",
  "in_reply_to_user_id_str" : "14197941",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "972675908",
  "geo" : { },
  "id_str" : "972679674",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick Good idea.  IMHO A large percentage of Twitters are not worth the context switch.  S\/b: informative, interesting, and\/or inspiring.",
  "id" : 972679674,
  "in_reply_to_status_id" : 972675908,
  "created_at" : "2008-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 8, 15 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "972703672",
  "geo" : { },
  "id_str" : "972716623",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight @Marick Regarding tweets...: http:\/\/pastie.org\/299304",
  "id" : 972716623,
  "in_reply_to_status_id" : 972703672,
  "created_at" : "2008-10-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "970693395",
  "text" : "VMWare Fusion has 'take snapshot', 'revert to snapshot' making it easier to test Win installations on Mac than in native Windows.",
  "id" : 970693395,
  "created_at" : "2008-10-22 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 0, 11 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "970721742",
  "geo" : { },
  "id_str" : "970728834",
  "in_reply_to_user_id" : 9070452,
  "text" : "@jimweirich Showoff! :)  I was too late to register.  Boo hoo!",
  "id" : 970728834,
  "in_reply_to_status_id" : 970721742,
  "created_at" : "2008-10-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "jimweirich",
  "in_reply_to_user_id_str" : "9070452",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "966897832",
  "text" : "Kris Rousey at Raleigh Ruby Camp showed me this very cool Ruby one liner to test number primeness using regex:\nhttp:\/\/pastie.org\/296024",
  "id" : 966897832,
  "created_at" : "2008-10-20 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raleighrubycamp",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "965114335",
  "text" : "#raleighrubycamp At Raleigh Ruby Camp listening to Jason Rudolph start off our refactotum session.",
  "id" : 965114335,
  "created_at" : "2008-10-18 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Odio",
      "screen_name" : "sodio",
      "indices" : [ 0, 6 ],
      "id_str" : "14205130",
      "id" : 14205130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "960922390",
  "geo" : { },
  "id_str" : "961005001",
  "in_reply_to_user_id" : 14205130,
  "text" : "@sodio Actually, going to Raleigh Ruby BarCamp instead of BarCamp DC.  I want to see the Raleigh area and meet the community there.",
  "id" : 961005001,
  "in_reply_to_status_id" : 960922390,
  "created_at" : "2008-10-15 00:00:00 +0000",
  "in_reply_to_screen_name" : "sodio",
  "in_reply_to_user_id_str" : "14205130",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "959756874",
  "text" : "Just paid $2.69 a gallon for gas at Costco.  It seems like a long time since I've seen gas this low...",
  "id" : 959756874,
  "created_at" : "2008-10-14 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "956903956",
  "text" : "Ruby DCamp ended well.  People seemed to enjoy and appreciate the experience.  I know I did.",
  "id" : 956903956,
  "created_at" : "2008-10-12 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "955124550",
  "text" : "Just finished checking out and setting up the Holdiay Inn w\/Evan for Ruby DCamp.  Everything's ready to go!  Now to rest up for tomorrow...",
  "id" : 955124550,
  "created_at" : "2008-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "955238600",
  "text" : "Ruby DCamp'ers: Please bring masking tape, power strips, extension cords, multipliers if you have any.  We have some but could use more.",
  "id" : 955238600,
  "created_at" : "2008-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "955367948",
  "text" : "DCampers: You can park behind at spots marked \"Hotel\", or in garage accessible on right side of hotel, but *not* in \"Parking Permit Only\"...",
  "id" : 955367948,
  "created_at" : "2008-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "955368363",
  "text" : "DCampers, cont'd: \n...spaces outside of garage.  Welcome!",
  "id" : 955368363,
  "created_at" : "2008-10-11 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]