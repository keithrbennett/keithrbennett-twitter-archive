Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 0, 10 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "581886400137580544",
  "geo" : { },
  "id_str" : "581898174064906240",
  "in_reply_to_user_id" : 18137723,
  "text" : "@raganwald Yes!  And in Ruby too, with lambdas:\n\ndoubler = -&gt;(n) \u007B 2 * n \u007D\n\nWhen you use functions\/lambdas a lot, it's much clearer.",
  "id" : 581898174064906240,
  "in_reply_to_status_id" : 581886400137580544,
  "created_at" : "2015-03-28 19:18:30 +0000",
  "in_reply_to_screen_name" : "raganwald",
  "in_reply_to_user_id_str" : "18137723",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KiaConsumerCare",
      "screen_name" : "KiaConsumerCare",
      "indices" : [ 0, 16 ],
      "id_str" : "2283937020",
      "id" : 2283937020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/gUVsZBdmbt",
      "expanded_url" : "https:\/\/docs.google.com\/spreadsheets\/d\/1jfdkXvARnrfJHGbdtLqaQX1EKFL7LL5tv3JSySRlEmI\/edit?usp=sharing",
      "display_url" : "docs.google.com\/spreadsheets\/d\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "581869338380132352",
  "geo" : { },
  "id_str" : "581896252343873536",
  "in_reply_to_user_id" : 14401983,
  "text" : "@KiaConsumerCare A publicly viewable version of the spreadsheet is available on Google Drive at https:\/\/t.co\/gUVsZBdmbt. Feedback welcome.",
  "id" : 581896252343873536,
  "in_reply_to_status_id" : 581869338380132352,
  "created_at" : "2015-03-28 19:10:52 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Pease",
      "screen_name" : "pea53",
      "indices" : [ 113, 119 ],
      "id_str" : "17429985",
      "id" : 17429985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/bpSRR2oRz8",
      "expanded_url" : "https:\/\/github.com\/TwP\/logging\/pull\/80",
      "display_url" : "github.com\/TwP\/logging\/pu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "581875220035837952",
  "text" : "Got a public thanks: \"Thank your for this PR - it has inspired cleaner code all around.\" https:\/\/t.co\/bpSRR2oRz8 @pea53 Thank you too!",
  "id" : 581875220035837952,
  "created_at" : "2015-03-28 17:47:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KiaConsumerCare",
      "screen_name" : "KiaConsumerCare",
      "indices" : [ 0, 16 ],
      "id_str" : "2283937020",
      "id" : 2283937020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/581869338380132352\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ldXNXBLsn0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBM3FFVU0AEOz7j.png",
      "id_str" : "581869337331421185",
      "id" : 581869337331421185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBM3FFVU0AEOz7j.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 1223
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ldXNXBLsn0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572149635575361536",
  "geo" : { },
  "id_str" : "581869338380132352",
  "in_reply_to_user_id" : 14401983,
  "text" : "@KiaConsumerCare MPG is still overstated by 11.77%. The Kia Optima is a great car, but this is deceptive. http:\/\/t.co\/ldXNXBLsn0",
  "id" : 581869338380132352,
  "in_reply_to_status_id" : 572149635575361536,
  "created_at" : "2015-03-28 17:23:55 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zsh",
      "indices" : [ 11, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/EQFFJNbhQF",
      "expanded_url" : "http:\/\/superuser.com\/questions\/742171\/zsh-z-shell-numpad-numlock-doesnt-work",
      "display_url" : "superuser.com\/questions\/7421\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "580747227754270720",
  "text" : "If you use #zsh &amp; an external keyboard on a Mac, check out this link for a way to enable use of your numeric keypad: http:\/\/t.co\/EQFFJNbhQF",
  "id" : 580747227754270720,
  "created_at" : "2015-03-25 15:05:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Herrup",
      "screen_name" : "B4Some1Hears",
      "indices" : [ 3, 16 ],
      "id_str" : "15600381",
      "id" : 15600381
    }, {
      "name" : "Brave UX",
      "screen_name" : "Brave_UX",
      "indices" : [ 113, 122 ],
      "id_str" : "2342124048",
      "id" : 2342124048
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leandc",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "580526370637422592",
  "text" : "RT @B4Some1Hears: You can either use a sledgehammer at the construction site or an eraser at the drafting table. @Brave_UX #leandc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brave UX",
        "screen_name" : "Brave_UX",
        "indices" : [ 95, 104 ],
        "id_str" : "2342124048",
        "id" : 2342124048
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leandc",
        "indices" : [ 105, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "580514862821937153",
    "text" : "You can either use a sledgehammer at the construction site or an eraser at the drafting table. @Brave_UX #leandc",
    "id" : 580514862821937153,
    "created_at" : "2015-03-24 23:41:43 +0000",
    "user" : {
      "name" : "Bradley Herrup",
      "screen_name" : "B4Some1Hears",
      "protected" : false,
      "id_str" : "15600381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463705400756285440\/ChimvSeo_normal.png",
      "id" : 15600381,
      "verified" : false
    }
  },
  "id" : 580526370637422592,
  "created_at" : "2015-03-25 00:27:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maggie Epps",
      "screen_name" : "meppstimist",
      "indices" : [ 0, 12 ],
      "id_str" : "285157838",
      "id" : 285157838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/HQ7Of1xF6N",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/d4e48d860b35cd5b6d79",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "578924815916134400",
  "geo" : { },
  "id_str" : "578940506106892288",
  "in_reply_to_user_id" : 285157838,
  "text" : "@meppstimist Here is a gist with references to some kinds of uses of lambdas in Ruby: https:\/\/t.co\/HQ7Of1xF6N . Any questions, let me know.",
  "id" : 578940506106892288,
  "in_reply_to_status_id" : 578924815916134400,
  "created_at" : "2015-03-20 15:25:47 +0000",
  "in_reply_to_screen_name" : "meppstimist",
  "in_reply_to_user_id_str" : "285157838",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New Work Cities",
      "screen_name" : "nwc",
      "indices" : [ 0, 4 ],
      "id_str" : "14204194",
      "id" : 14204194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dqEe7CJQ08",
      "expanded_url" : "http:\/\/nwc.co\/3\/",
      "display_url" : "nwc.co\/3\/"
    } ]
  },
  "geo" : { },
  "id_str" : "577127318386286593",
  "in_reply_to_user_id" : 14204194,
  "text" : "@nwc, my favorite coworking place in New York City, is looking for partners. More than a workplace, it's a community. http:\/\/t.co\/dqEe7CJQ08",
  "id" : 577127318386286593,
  "created_at" : "2015-03-15 15:20:49 +0000",
  "in_reply_to_screen_name" : "nwc",
  "in_reply_to_user_id_str" : "14204194",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83D\uDE21 BAD HOMBRE \uD83D\uDE21",
      "screen_name" : "mandoescamilla",
      "indices" : [ 3, 18 ],
      "id_str" : "774234",
      "id" : 774234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576934539085422594",
  "text" : "RT @mandoescamilla: My son picked a Windows phone as his birthday present.\n\nUnrelated, now selling one 14 yr old boy. Any reasonable offers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "574308368510152707",
    "text" : "My son picked a Windows phone as his birthday present.\n\nUnrelated, now selling one 14 yr old boy. Any reasonable offers accepted.",
    "id" : 574308368510152707,
    "created_at" : "2015-03-07 20:39:19 +0000",
    "user" : {
      "name" : "\uD83D\uDE21 BAD HOMBRE \uD83D\uDE21",
      "screen_name" : "mandoescamilla",
      "protected" : false,
      "id_str" : "774234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/968902013\/rehearsal_normal.jpg",
      "id" : 774234,
      "verified" : false
    }
  },
  "id" : 576934539085422594,
  "created_at" : "2015-03-15 02:34:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (UK)",
      "screen_name" : "BBCNews",
      "indices" : [ 11, 19 ],
      "id_str" : "612473",
      "id" : 612473
    }, {
      "name" : "NPR",
      "screen_name" : "nprnews",
      "indices" : [ 21, 29 ],
      "id_str" : "3386439610",
      "id" : 3386439610
    }, {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 31, 44 ],
      "id_str" : "5988062",
      "id" : 5988062
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 46, 54 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/HNSiw2eIwm",
      "expanded_url" : "http:\/\/www.pewresearch.org\/quiz\/the-news-iq-quiz\/",
      "display_url" : "pewresearch.org\/quiz\/the-news-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "576839380658171905",
  "text" : "Thank you, @bbcnews, @nprnews, @TheEconomist, @nytimes.  I got a perfect score at http:\/\/t.co\/HNSiw2eIwm.",
  "id" : 576839380658171905,
  "created_at" : "2015-03-14 20:16:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 6, 16 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "firstworldproblems",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576833015021772800",
  "text" : "Worst @starbucks experience ever.  Colder inside than out, fan blowing cold air. No caffeinated capuccino.  Admittedly #firstworldproblems.",
  "id" : 576833015021772800,
  "created_at" : "2015-03-14 19:51:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meetup",
      "screen_name" : "Meetup",
      "indices" : [ 1, 8 ],
      "id_str" : "14591071",
      "id" : 14591071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576577709196910592",
  "text" : ".@meetup Please be transparent about organizer dues.  Do you have a web page with *details*, not just \"starting at...\"?",
  "id" : 576577709196910592,
  "created_at" : "2015-03-14 02:56:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "576071886876090368",
  "text" : "Anyone know of cheap or free software that can be used for membership management of a community swimming pool?  For a coworker.",
  "id" : 576071886876090368,
  "created_at" : "2015-03-12 17:26:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575733274871365633",
  "text" : "TIL: git show-ref --tags  Also, annotated tags get their own commits. To see commit to which one refers, do: git log --parents [sha or tag]",
  "id" : 575733274871365633,
  "created_at" : "2015-03-11 19:01:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574000063451635712",
  "text" : "RT @JimGaffigan: Anyone got plans for daylight savings? I'm having a party Saturday from 2am to 3am.  Don't be late!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "573964169378185216",
    "text" : "Anyone got plans for daylight savings? I'm having a party Saturday from 2am to 3am.  Don't be late!",
    "id" : 573964169378185216,
    "created_at" : "2015-03-06 21:51:36 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 574000063451635712,
  "created_at" : "2015-03-07 00:14:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "indices" : [ 0, 11 ],
      "id_str" : "36691457",
      "id" : 36691457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "573284279351947264",
  "geo" : { },
  "id_str" : "573340263067746304",
  "in_reply_to_user_id" : 36691457,
  "text" : "@gdinwiddie You're just like me. ;)",
  "id" : 573340263067746304,
  "in_reply_to_status_id" : 573284279351947264,
  "created_at" : "2015-03-05 04:32:25 +0000",
  "in_reply_to_screen_name" : "gdinwiddie",
  "in_reply_to_user_id_str" : "36691457",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "indices" : [ 0, 11 ],
      "id_str" : "36691457",
      "id" : 36691457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "572799140083732481",
  "geo" : { },
  "id_str" : "573261638758866946",
  "in_reply_to_user_id" : 36691457,
  "text" : "@gdinwiddie Artistic license, I guess. :)",
  "id" : 573261638758866946,
  "in_reply_to_status_id" : 572799140083732481,
  "created_at" : "2015-03-04 23:20:00 +0000",
  "in_reply_to_screen_name" : "gdinwiddie",
  "in_reply_to_user_id_str" : "36691457",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KiaConsumerCare",
      "screen_name" : "KiaConsumerCare",
      "indices" : [ 13, 29 ],
      "id_str" : "2283937020",
      "id" : 2283937020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/dFJ0ENjJCt",
      "expanded_url" : "http:\/\/www.toptiergas.com\/",
      "display_url" : "toptiergas.com"
    } ]
  },
  "geo" : { },
  "id_str" : "573261354565386240",
  "text" : "Today Ali at @KiaConsumerCare taught me about top tier gasolines (http:\/\/t.co\/dFJ0ENjJCt). Exxon, Mobil, BP are top tier; Sunoco, Shell not.",
  "id" : 573261354565386240,
  "created_at" : "2015-03-04 23:18:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/572795659675422720\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/mjzuBbbxHK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B_L6mzvU8AAbegS.jpg",
      "id_str" : "572795647260160000",
      "id" : 572795647260160000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B_L6mzvU8AAbegS.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/mjzuBbbxHK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "572795659675422720",
  "text" : "I love this cartoon. http:\/\/t.co\/mjzuBbbxHK",
  "id" : 572795659675422720,
  "created_at" : "2015-03-03 16:28:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KiaConsumerCare",
      "screen_name" : "KiaConsumerCare",
      "indices" : [ 0, 16 ],
      "id_str" : "2283937020",
      "id" : 2283937020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "569920106358284289",
  "geo" : { },
  "id_str" : "572149635575361536",
  "in_reply_to_user_id" : 2283937020,
  "text" : "@KiaConsumerCare Thanks for correcting me, I set my mpg meter to manual reset.  Restarted the testing &amp; at 1 obs, mpg overstatement is 9%.",
  "id" : 572149635575361536,
  "in_reply_to_status_id" : 569920106358284289,
  "created_at" : "2015-03-01 21:41:17 +0000",
  "in_reply_to_screen_name" : "KiaConsumerCare",
  "in_reply_to_user_id_str" : "2283937020",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]