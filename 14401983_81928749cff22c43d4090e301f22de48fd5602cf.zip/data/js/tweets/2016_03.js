Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/714417356026437633\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/ZsawGfZZue",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeoezCzW4AAk2sQ.jpg",
      "id_str" : "714417353166086144",
      "id" : 714417353166086144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeoezCzW4AAk2sQ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      } ],
      "display_url" : "pic.twitter.com\/ZsawGfZZue"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714417356026437633",
  "text" : "One of my neighbors at Athreya Ayurvedic Resort in Kottalam, India.  This calf was born here a week ago. https:\/\/t.co\/ZsawGfZZue",
  "id" : 714417356026437633,
  "created_at" : "2016-03-28 11:42:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/V4qzd9kfWu",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/f5c7169b3e57516e6c47",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714119625491910657",
  "text" : "Mac OS X's say command is very cool.  Lots of international voices! This Ruby script gives all of them a voice:  https:\/\/t.co\/V4qzd9kfWu",
  "id" : 714119625491910657,
  "created_at" : "2016-03-27 15:59:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jatin Puri",
      "screen_name" : "purijatin7",
      "indices" : [ 0, 11 ],
      "id_str" : "195712486",
      "id" : 195712486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/b0skUCp78e",
      "expanded_url" : "http:\/\/www.theathreya.com\/",
      "display_url" : "theathreya.com"
    } ]
  },
  "in_reply_to_status_id_str" : "711905847681654784",
  "geo" : { },
  "id_str" : "711907484659625984",
  "in_reply_to_user_id" : 195712486,
  "text" : "@purijatin7 I'm at Athreya Ayurvedic Resort in Kottalam, Kerala: https:\/\/t.co\/b0skUCp78e.",
  "id" : 711907484659625984,
  "in_reply_to_status_id" : 711905847681654784,
  "created_at" : "2016-03-21 13:29:05 +0000",
  "in_reply_to_screen_name" : "purijatin7",
  "in_reply_to_user_id_str" : "195712486",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/711899719186800640\/photo\/1",
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/zDxQoGpU0p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeEs88_UkAAFzCq.jpg",
      "id_str" : "711899641776738304",
      "id" : 711899641776738304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeEs88_UkAAFzCq.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zDxQoGpU0p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711899719186800640",
  "text" : "After 1st day of Ayurvedic treatments in India, I went outside &amp; saw this &amp; heard myself say \"Holy Cow!\". How true. https:\/\/t.co\/zDxQoGpU0p",
  "id" : 711899719186800640,
  "created_at" : "2016-03-21 12:58:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "TeamViewer",
      "screen_name" : "TeamViewer",
      "indices" : [ 26, 37 ],
      "id_str" : "15726073",
      "id" : 15726073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711656491556556800",
  "geo" : { },
  "id_str" : "711763407158915072",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH I'm very happy with @TeamViewer.  Free and excellent software.  I use it for remote tutoring and any time remote control is necessary.",
  "id" : 711763407158915072,
  "in_reply_to_status_id" : 711656491556556800,
  "created_at" : "2016-03-21 03:56:34 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gautam Rege",
      "screen_name" : "gautamrege",
      "indices" : [ 0, 11 ],
      "id_str" : "64960831",
      "id" : 64960831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconfindia",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711762466892419072",
  "in_reply_to_user_id" : 64960831,
  "text" : "@gautamrege Great job mc'ing #rubyconfindia (and your other conference work, of course).",
  "id" : 711762466892419072,
  "created_at" : "2016-03-21 03:52:50 +0000",
  "in_reply_to_screen_name" : "gautamrege",
  "in_reply_to_user_id_str" : "64960831",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prathamesh Sonpatki",
      "screen_name" : "_cha1tanya",
      "indices" : [ 0, 11 ],
      "id_str" : "633603670",
      "id" : 633603670
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711239831691595776",
  "geo" : { },
  "id_str" : "711755213095309314",
  "in_reply_to_user_id" : 633603670,
  "text" : "@_cha1tanya You're very welcome, and congratulations on your Ruby Hero award!",
  "id" : 711755213095309314,
  "in_reply_to_status_id" : 711239831691595776,
  "created_at" : "2016-03-21 03:24:01 +0000",
  "in_reply_to_screen_name" : "_cha1tanya",
  "in_reply_to_user_id_str" : "633603670",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wungmathing Shaiza",
      "screen_name" : "wung_s",
      "indices" : [ 0, 7 ],
      "id_str" : "138415955",
      "id" : 138415955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "devhappiness",
      "indices" : [ 108, 121 ]
    }, {
      "text" : "radicalhelpfulness",
      "indices" : [ 128, 147 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711360812997173248",
  "geo" : { },
  "id_str" : "711729994804756484",
  "in_reply_to_user_id" : 138415955,
  "text" : "@wung_s Thanks to you &amp; others for your kind words.  Great to meet you all.  All, let's talk more about #devhappiness &amp; #radicalhelpfulness.",
  "id" : 711729994804756484,
  "in_reply_to_status_id" : 711360812997173248,
  "created_at" : "2016-03-21 01:43:48 +0000",
  "in_reply_to_screen_name" : "wung_s",
  "in_reply_to_user_id_str" : "138415955",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/711570411314487296\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/fnT1Ajuqq1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeABfsOUAAA1nYs.jpg",
      "id_str" : "711570385083301888",
      "id" : 711570385083301888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeABfsOUAAA1nYs.jpg",
      "sizes" : [ {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fnT1Ajuqq1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711570411314487296",
  "text" : "Humongous clock in the Kochi Marriott lobby. https:\/\/t.co\/fnT1Ajuqq1",
  "id" : 711570411314487296,
  "created_at" : "2016-03-20 15:09:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 11, 25 ],
      "id_str" : "76972977",
      "id" : 76972977
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/711570063451500545\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/TkCvVy4gnB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeABLJOUEAAmPes.jpg",
      "id_str" : "711570032090681344",
      "id" : 711570032090681344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeABLJOUEAAmPes.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TkCvVy4gnB"
    } ],
    "hashtags" : [ {
      "text" : "rubyconfindia",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711570063451500545",
  "text" : "Thank you, @rubyconfindia for a great conf and a great time. Hope to see you again next year. #rubyconfindia https:\/\/t.co\/TkCvVy4gnB",
  "id" : 711570063451500545,
  "created_at" : "2016-03-20 15:08:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 0, 11 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711523928515031041",
  "in_reply_to_user_id" : 1920753961,
  "text" : "@RubyConfPH Looking forward to the conference! Question...is the Thursday a full day or just an evening get together, or something else?",
  "id" : 711523928515031041,
  "created_at" : "2016-03-20 12:04:58 +0000",
  "in_reply_to_screen_name" : "RubyConfPH",
  "in_reply_to_user_id_str" : "1920753961",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 51, 65 ],
      "id_str" : "76972977",
      "id" : 76972977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "radicalhelpfulness",
      "indices" : [ 77, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/XN8776PESe",
      "expanded_url" : "http:\/\/www.techhumans.com\/2016\/03\/19\/we-humans\/",
      "display_url" : "techhumans.com\/2016\/03\/19\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "711235643938971648",
  "text" : "The text of my \"We Humans\" lightning talk today at @rubyconfindia discussing #radicalhelpfulness is up at https:\/\/t.co\/XN8776PESe.",
  "id" : 711235643938971648,
  "created_at" : "2016-03-19 16:59:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sidu Ponnappa",
      "screen_name" : "ponnappa",
      "indices" : [ 3, 12 ],
      "id_str" : "21295041",
      "id" : 21295041
    }, {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 18, 32 ],
      "id_str" : "76972977",
      "id" : 76972977
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ponnappa\/status\/711208993473998848\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/pgWFeZiyte",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd64yp7UYAAraFU.jpg",
      "id_str" : "711208971558739968",
      "id" : 711208971558739968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd64yp7UYAAraFU.jpg",
      "sizes" : [ {
        "h" : 590,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 590,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pgWFeZiyte"
    } ],
    "hashtags" : [ {
      "text" : "Cochin",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711228552344182785",
  "text" : "RT @ponnappa: The @RubyconfIndia 2016 party in full swing. #Cochin https:\/\/t.co\/pgWFeZiyte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RubyConfIndia 2017",
        "screen_name" : "rubyconfindia",
        "indices" : [ 4, 18 ],
        "id_str" : "76972977",
        "id" : 76972977
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ponnappa\/status\/711208993473998848\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/pgWFeZiyte",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd64yp7UYAAraFU.jpg",
        "id_str" : "711208971558739968",
        "id" : 711208971558739968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd64yp7UYAAraFU.jpg",
        "sizes" : [ {
          "h" : 590,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 346,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 196,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 590,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pgWFeZiyte"
      } ],
      "hashtags" : [ {
        "text" : "Cochin",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711208993473998848",
    "text" : "The @RubyconfIndia 2016 party in full swing. #Cochin https:\/\/t.co\/pgWFeZiyte",
    "id" : 711208993473998848,
    "created_at" : "2016-03-19 15:13:32 +0000",
    "user" : {
      "name" : "Sidu Ponnappa",
      "screen_name" : "ponnappa",
      "protected" : false,
      "id_str" : "21295041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1985503839\/rubyconindiatalk2012_normal.png",
      "id" : 21295041,
      "verified" : false
    }
  },
  "id" : 711228552344182785,
  "created_at" : "2016-03-19 16:31:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 27, 41 ],
      "id_str" : "76972977",
      "id" : 76972977
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/711047542650241024\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/l3vmS85Ue5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cd4l9rmVIAAMyIa.jpg",
      "id_str" : "711047532776857600",
      "id" : 711047532776857600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cd4l9rmVIAAMyIa.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/l3vmS85Ue5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711047542650241024",
  "text" : "Matz giving the keynote at @rubyconfindia in Kochi, Kerala, India. https:\/\/t.co\/l3vmS85Ue5",
  "id" : 711047542650241024,
  "created_at" : "2016-03-19 04:31:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/cPDvGaidtT",
      "expanded_url" : "https:\/\/goo.gl\/photos\/DV9958WGWd5eLmJp9",
      "display_url" : "goo.gl\/photos\/DV9958W\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710610026088402944",
  "text" : "Billboard in Kochi, India.  What a great way to demonstrate compassion and transcend petty rivalry and hatred. https:\/\/t.co\/cPDvGaidtT",
  "id" : 710610026088402944,
  "created_at" : "2016-03-17 23:33:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/fg737xPtgt",
      "expanded_url" : "https:\/\/goo.gl\/photos\/LSR2BE59PnvtA2fu9",
      "display_url" : "goo.gl\/photos\/LSR2BE5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710609188989198336",
  "text" : "These solar panels power the 1st solar powered airport in the world: Kochi, India. https:\/\/t.co\/fg737xPtgt",
  "id" : 710609188989198336,
  "created_at" : "2016-03-17 23:30:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 0, 9 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "RubyConfIndia 2017",
      "screen_name" : "rubyconfindia",
      "indices" : [ 10, 24 ],
      "id_str" : "76972977",
      "id" : 76972977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/kmxJVj27Xm",
      "expanded_url" : "http:\/\/rubyconfindia.org\/talk-schedule\/",
      "display_url" : "rubyconfindia.org\/talk-schedule\/"
    } ]
  },
  "in_reply_to_status_id_str" : "710317896220540928",
  "geo" : { },
  "id_str" : "710462208023654400",
  "in_reply_to_user_id" : 14164724,
  "text" : "@sarahmei @rubyconfindia I just arrived today.  Aren't you speaking on Saturday?: https:\/\/t.co\/kmxJVj27Xm",
  "id" : 710462208023654400,
  "in_reply_to_status_id" : 710317896220540928,
  "created_at" : "2016-03-17 13:46:04 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/BhRkrOGVr6",
      "expanded_url" : "https:\/\/keithrbennett.wordpress.com\/2010\/09\/12\/painful-patriotism\/",
      "display_url" : "keithrbennett.wordpress.com\/2010\/09\/12\/pai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "710460478531588096",
  "text" : "Now that Trump is a thing, what I said in this \"Painful Patriotism\" article in 2010 needs to be said again: https:\/\/t.co\/BhRkrOGVr6",
  "id" : 710460478531588096,
  "created_at" : "2016-03-17 13:39:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "709958978642579456",
  "geo" : { },
  "id_str" : "710014581876400128",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Nah, attending RubyConf India &amp; RubyConf Philippines.  In Frankfurt now, then 9 hrs to Bangalore then 1 hr to Kochi. Yes, pics!",
  "id" : 710014581876400128,
  "in_reply_to_status_id" : 709958978642579456,
  "created_at" : "2016-03-16 08:07:22 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/709873240844271616\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/vFy3UtXVZc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cdn57-OW4AED9MC.jpg",
      "id_str" : "709873224998379521",
      "id" : 709873224998379521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cdn57-OW4AED9MC.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/vFy3UtXVZc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709873240844271616",
  "text" : "Bucket list item: fly business class to India, courtesy of credit card signup bonuses. I even have both seats! https:\/\/t.co\/vFy3UtXVZc",
  "id" : 709873240844271616,
  "created_at" : "2016-03-15 22:45:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709050461601583104",
  "text" : "I'm considering visiting an ayurvedic spa\/resort for a few days while in India.  Anyone have any opinions about ayurvedic medicine?",
  "id" : 709050461601583104,
  "created_at" : "2016-03-13 16:16:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LucasCioffi",
      "screen_name" : "LucasCioffi",
      "indices" : [ 47, 59 ],
      "id_str" : "9920092",
      "id" : 9920092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/PcIT0SS9ut",
      "expanded_url" : "http:\/\/sunlightfoundation.com\/blog\/2016\/03\/07\/opengov-voices-announcing-transparencycamp-online-march-19\/",
      "display_url" : "sunlightfoundation.com\/blog\/2016\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "707259758915547137",
  "text" : "Transparency Camp Online, independently run by @LucasCioffi, is an all online open space gov't transparency conf. https:\/\/t.co\/PcIT0SS9ut",
  "id" : 707259758915547137,
  "created_at" : "2016-03-08 17:40:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 52, 66 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/706111959876427776\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/q5cNcZTp9n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcydESaXEAAsSFW.jpg",
      "id_str" : "706111938577764352",
      "id" : 706111938577764352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcydESaXEAAsSFW.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/q5cNcZTp9n"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706111959876427776",
  "text" : "Note the yellow van on its side. It may be a while. @arlingtonruby https:\/\/t.co\/q5cNcZTp9n",
  "id" : 706111959876427776,
  "created_at" : "2016-03-05 13:39:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 108, 122 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706111333289357313",
  "text" : "Entrance ramp from toll road to I66 eastbound blocked due to accident. I may be hours late to retrocession. @arlingtonruby",
  "id" : 706111333289357313,
  "created_at" : "2016-03-05 13:37:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]