Grailbird.data.tweets_2013_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Ruby Conf",
      "screen_name" : "BigRubyConf",
      "indices" : [ 0, 12 ],
      "id_str" : "882257671",
      "id" : 882257671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307254764071186434",
  "in_reply_to_user_id" : 882257671,
  "text" : "@BigRubyConf Attendees, f you're looking to hire or just need some temporary help with Ruby related work, feel free to get in touch with me.",
  "id" : 307254764071186434,
  "created_at" : "2013-02-28 22:23:38 +0000",
  "in_reply_to_screen_name" : "BigRubyConf",
  "in_reply_to_user_id_str" : "882257671",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306852966260953088",
  "text" : "Sweet! I have both seats on my side of the aisle of a CRJ100 40 or so seater IAD -&gt; DFW. Pilot warns of turbulence though.",
  "id" : 306852966260953088,
  "created_at" : "2013-02-27 19:47:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306851742509834240",
  "text" : "Security dog at Dulles Airport was very professional. 2 seconds of sniffing per person and she refused to socialize. :-)",
  "id" : 306851742509834240,
  "created_at" : "2013-02-27 19:42:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Ruby Conf",
      "screen_name" : "BigRubyConf",
      "indices" : [ 28, 40 ],
      "id_str" : "882257671",
      "id" : 882257671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/qi1mz9Mcg2",
      "expanded_url" : "https:\/\/github.com\/ricn\/rika",
      "display_url" : "github.com\/ricn\/rika"
    } ]
  },
  "geo" : { },
  "id_str" : "306814626107101184",
  "text" : "Heading to Dallas today for @bigrubyconf. Hope to give a lightning talk on JRuby and Rika (https:\/\/t.co\/qi1mz9Mcg2).",
  "id" : 306814626107101184,
  "created_at" : "2013-02-27 17:14:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Nystr\u00F6m",
      "screen_name" : "richardnystrom",
      "indices" : [ 3, 18 ],
      "id_str" : "8103572",
      "id" : 8103572
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 94, 108 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/zSpQYtmmJs",
      "expanded_url" : "https:\/\/github.com\/ricn\/rika",
      "display_url" : "github.com\/ricn\/rika"
    } ]
  },
  "geo" : { },
  "id_str" : "306569598348713984",
  "text" : "RT @richardnystrom: New version of the Rika gem is out with new convenience methods thanks to @keithrbennett. https:\/\/t.co\/zSpQYtmmJs #jruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 74, 88 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jruby",
        "indices" : [ 114, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/zSpQYtmmJs",
        "expanded_url" : "https:\/\/github.com\/ricn\/rika",
        "display_url" : "github.com\/ricn\/rika"
      } ]
    },
    "geo" : { },
    "id_str" : "306563020035858433",
    "text" : "New version of the Rika gem is out with new convenience methods thanks to @keithrbennett. https:\/\/t.co\/zSpQYtmmJs #jruby",
    "id" : 306563020035858433,
    "created_at" : "2013-02-27 00:34:54 +0000",
    "user" : {
      "name" : "Richard Nystr\u00F6m",
      "screen_name" : "richardnystrom",
      "protected" : false,
      "id_str" : "8103572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554806005\/me_normal.jpg",
      "id" : 8103572,
      "verified" : false
    }
  },
  "id" : 306569598348713984,
  "created_at" : "2013-02-27 01:01:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Nystr\u00F6m",
      "screen_name" : "richardnystrom",
      "indices" : [ 3, 18 ],
      "id_str" : "8103572",
      "id" : 8103572
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 20, 34 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/a4c2jQiFZz",
      "expanded_url" : "http:\/\/gist.github.com",
      "display_url" : "gist.github.com"
    } ]
  },
  "geo" : { },
  "id_str" : "306541807959957505",
  "text" : "RT @richardnystrom: @keithrbennett You can use http:\/\/t.co\/a4c2jQiFZz for that and choose Markdown as the language.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/a4c2jQiFZz",
        "expanded_url" : "http:\/\/gist.github.com",
        "display_url" : "gist.github.com"
      } ]
    },
    "in_reply_to_status_id_str" : "306539317738758147",
    "geo" : { },
    "id_str" : "306540858579230720",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett You can use http:\/\/t.co\/a4c2jQiFZz for that and choose Markdown as the language.",
    "id" : 306540858579230720,
    "in_reply_to_status_id" : 306539317738758147,
    "created_at" : "2013-02-26 23:06:50 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "Richard Nystr\u00F6m",
      "screen_name" : "richardnystrom",
      "protected" : false,
      "id_str" : "8103572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1554806005\/me_normal.jpg",
      "id" : 8103572,
      "verified" : false
    }
  },
  "id" : 306541807959957505,
  "created_at" : "2013-02-26 23:10:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "306539317738758147",
  "text" : "What do people use to see results of changes to Github markdown README.md w\/o committing them to master &amp; pushing to Github?",
  "id" : 306539317738758147,
  "created_at" : "2013-02-26 23:00:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Uapm6EH6aR",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/15\/hello-nailgun-goodbye-jvm-startup-delays\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "306500648797622273",
  "text" : "Wow, my JRuby unit test took 2 seconds using Nailgun, 10 seconds without. See my article at http:\/\/t.co\/Uapm6EH6aR for an easy how-to.",
  "id" : 306500648797622273,
  "created_at" : "2013-02-26 20:27:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Odio",
      "screen_name" : "sodio",
      "indices" : [ 0, 6 ],
      "id_str" : "14205130",
      "id" : 14205130
    }, {
      "name" : "Mandy Moore",
      "screen_name" : "therubyrep",
      "indices" : [ 11, 22 ],
      "id_str" : "28831220",
      "id" : 28831220
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "306160724789563392",
  "geo" : { },
  "id_str" : "306171234784264194",
  "in_reply_to_user_id" : 14205130,
  "text" : "@sodio Try @therubyrep (Mandy Moore) for a virtual assistant.",
  "id" : 306171234784264194,
  "in_reply_to_status_id" : 306160724789563392,
  "created_at" : "2013-02-25 22:38:05 +0000",
  "in_reply_to_screen_name" : "sodio",
  "in_reply_to_user_id_str" : "14205130",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/VY1BIDMNbD",
      "expanded_url" : "http:\/\/Meetup.com",
      "display_url" : "Meetup.com"
    } ]
  },
  "geo" : { },
  "id_str" : "306063084403978240",
  "text" : "http:\/\/t.co\/VY1BIDMNbD should provide an easy way to see organizer fees. Instead they bury that info, making you register group first.",
  "id" : 306063084403978240,
  "created_at" : "2013-02-25 15:28:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JRuby",
      "indices" : [ 8, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/0BaNknWfAy",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/5026518",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "305840472977448960",
  "text" : "Run the #JRuby script at https:\/\/t.co\/0BaNknWfAy to see the locales built into the JVM &amp; their date, number, and currency formats.",
  "id" : 305840472977448960,
  "created_at" : "2013-02-25 00:43:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 0, 6 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/nqliLMGfSL",
      "expanded_url" : "http:\/\/visualvm.java.net\/download.html",
      "display_url" : "visualvm.java.net\/download.html"
    } ]
  },
  "geo" : { },
  "id_str" : "305747029240446977",
  "text" : "#jruby ists on Mac OS, you can download VisualVM, a free and useful tool for peering into running JVM's, at http:\/\/t.co\/nqliLMGfSL.",
  "id" : 305747029240446977,
  "created_at" : "2013-02-24 18:32:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua kemp",
      "screen_name" : "Joshuakemp01",
      "indices" : [ 3, 16 ],
      "id_str" : "402020935",
      "id" : 402020935
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 49, 63 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "Cody Kemp",
      "screen_name" : "codesterkemp",
      "indices" : [ 68, 81 ],
      "id_str" : "942634428",
      "id" : 942634428
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joshuakemp01\/status\/304083401974116353\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/CqY7PKxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BDhSPjUCcAEDKXy.jpg",
      "id_str" : "304083401978310657",
      "id" : 304083401978310657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BDhSPjUCcAEDKXy.jpg",
      "sizes" : [ {
        "h" : 1840,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 577,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CqY7PKxj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "304101669027860480",
  "text" : "RT @Joshuakemp01 Pair programming in Reston with @keithrbennett and @codesterkemp ....coding at its best :-) http:\/\/t.co\/CqY7PKxj",
  "id" : 304101669027860480,
  "created_at" : "2013-02-20 05:34:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303622293916114944",
  "geo" : { },
  "id_str" : "303629673915617280",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight And the community has benefited from your enthusiastic service, especially via #rubydcamp.  Thanks for that. It was a compliment. ;)",
  "id" : 303629673915617280,
  "in_reply_to_status_id" : 303622293916114944,
  "created_at" : "2013-02-18 22:18:50 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303577804744822785",
  "geo" : { },
  "id_str" : "303585273370001409",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Exactly.",
  "id" : 303585273370001409,
  "in_reply_to_status_id" : 303577804744822785,
  "created_at" : "2013-02-18 19:22:24 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "303554492224401408",
  "geo" : { },
  "id_str" : "303574699407974400",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight You would have made a great moonie. ;)",
  "id" : 303574699407974400,
  "in_reply_to_status_id" : 303554492224401408,
  "created_at" : "2013-02-18 18:40:23 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emil Stenstr\u00F6m",
      "screen_name" : "EmilStenstrom",
      "indices" : [ 52, 66 ],
      "id_str" : "16038461",
      "id" : 16038461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/I5pdxZAx",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=yKxnnKLn9Hc&list=UUvGMGQC8gNkd4gwxSbABIlw&index=7",
      "display_url" : "youtube.com\/watch?v=yKxnnK\u2026"
    }, {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/D2DRZGBF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zNbF006Y5x4",
      "display_url" : "youtube.com\/watch?v=zNbF00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303359983112814592",
  "text" : "great science tricks too at http:\/\/t.co\/I5pdxZAx RT @EmilStenstrom 44 seconds on assumptions\u2026: http:\/\/t.co\/D2DRZGBF",
  "id" : 303359983112814592,
  "created_at" : "2013-02-18 04:27:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "303348016264409088",
  "text" : "Had a date with someone I love tonight -- myself! :)  Took myself to dinner and a movie -- Zero Dark Thirty.",
  "id" : 303348016264409088,
  "created_at" : "2013-02-18 03:39:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Hickey",
      "screen_name" : "richhickey",
      "indices" : [ 40, 51 ],
      "id_str" : "46130870",
      "id" : 46130870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/WHYCQdO6",
      "expanded_url" : "http:\/\/www.infoq.com\/articles\/Datomic-Information-Model",
      "display_url" : "infoq.com\/articles\/Datom\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "303347705495834624",
  "text" : "Fascinating and approachable article by @richhickey about the Datomic DB, which adds the time dimension to data, at http:\/\/t.co\/WHYCQdO6.",
  "id" : 303347705495834624,
  "created_at" : "2013-02-18 03:38:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Metosin",
      "screen_name" : "metosin",
      "indices" : [ 3, 11 ],
      "id_str" : "155849408",
      "id" : 155849408
    }, {
      "name" : "Rich Hickey",
      "screen_name" : "richhickey",
      "indices" : [ 99, 110 ],
      "id_str" : "46130870",
      "id" : 46130870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/zf7APNYC",
      "expanded_url" : "http:\/\/bit.ly\/Z2mQW0",
      "display_url" : "bit.ly\/Z2mQW0"
    } ]
  },
  "geo" : { },
  "id_str" : "303342104623591424",
  "text" : "RT @metosin: Clojure in Action 2.ed MEAP. Save -50% with code cloj2rh at http:\/\/t.co\/zf7APNYC (via @richhickey)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich Hickey",
        "screen_name" : "richhickey",
        "indices" : [ 86, 97 ],
        "id_str" : "46130870",
        "id" : 46130870
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/zf7APNYC",
        "expanded_url" : "http:\/\/bit.ly\/Z2mQW0",
        "display_url" : "bit.ly\/Z2mQW0"
      } ]
    },
    "geo" : { },
    "id_str" : "303259672037691392",
    "text" : "Clojure in Action 2.ed MEAP. Save -50% with code cloj2rh at http:\/\/t.co\/zf7APNYC (via @richhickey)",
    "id" : 303259672037691392,
    "created_at" : "2013-02-17 21:48:34 +0000",
    "user" : {
      "name" : "Metosin",
      "screen_name" : "metosin",
      "protected" : false,
      "id_str" : "155849408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529756427598839808\/ZrFGHLoO_normal.png",
      "id" : 155849408,
      "verified" : false
    }
  },
  "id" : 303342104623591424,
  "created_at" : "2013-02-18 03:16:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 82 ],
      "url" : "https:\/\/t.co\/4go27Wx0",
      "expanded_url" : "https:\/\/gist.github.com\/afeld\/4952991",
      "display_url" : "gist.github.com\/afeld\/4952991"
    } ]
  },
  "geo" : { },
  "id_str" : "302081465229930497",
  "text" : "@aidenfeldman Nice list of good api's not requiring auth. at https:\/\/t.co\/4go27Wx0. People, Aiden's inviting suggestions for this list.",
  "id" : 302081465229930497,
  "created_at" : "2013-02-14 15:46:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathenharvey",
      "screen_name" : "nathenharvey",
      "indices" : [ 98, 111 ],
      "id_str" : "15926485",
      "id" : 15926485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301860318345322498",
  "text" : "s\/b \"With Chef, you stop treating your servers like pets, and start treating them like cattle.\" - @nathenharvey",
  "id" : 301860318345322498,
  "created_at" : "2013-02-14 01:08:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathenharvey",
      "screen_name" : "nathenharvey",
      "indices" : [ 92, 105 ],
      "id_str" : "15926485",
      "id" : 15926485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "301858222090899456",
  "text" : "With Chef, you stop treating your servers like pets, and start treating them like cattle. - @nathenharvey",
  "id" : 301858222090899456,
  "created_at" : "2013-02-14 00:59:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    }, {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 29, 34 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301843166703796224",
  "geo" : { },
  "id_str" : "301847283396407296",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick I suggest contacting @baaz, at least for Clojure community in Europe if not for jobs. He just started a Clojure group in Budapest.",
  "id" : 301847283396407296,
  "in_reply_to_status_id" : 301843166703796224,
  "created_at" : "2013-02-14 00:16:15 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301828299380891648",
  "geo" : { },
  "id_str" : "301839133935038464",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Scanning the jruby-user group for pain and confusion points would probably be fruitful.",
  "id" : 301839133935038464,
  "in_reply_to_status_id" : 301828299380891648,
  "created_at" : "2013-02-13 23:43:52 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Johnson",
      "screen_name" : "clickonchris",
      "indices" : [ 0, 13 ],
      "id_str" : "16949048",
      "id" : 16949048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301762179198222336",
  "geo" : { },
  "id_str" : "301837085923483649",
  "in_reply_to_user_id" : 16949048,
  "text" : "@clickonchris I'm interested in the gig. Feel free to DM me.",
  "id" : 301837085923483649,
  "in_reply_to_status_id" : 301762179198222336,
  "created_at" : "2013-02-13 23:35:43 +0000",
  "in_reply_to_screen_name" : "clickonchris",
  "in_reply_to_user_id_str" : "16949048",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301729996987305986",
  "geo" : { },
  "id_str" : "301732790418956288",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Need more info\/context.  Can you post a minimal example illustrating the problem? Should we move this conversation to email?",
  "id" : 301732790418956288,
  "in_reply_to_status_id" : 301729996987305986,
  "created_at" : "2013-02-13 16:41:17 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 42, 55 ],
      "id_str" : "655883",
      "id" : 655883
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 57, 71 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/OFbPcHDY",
      "expanded_url" : "http:\/\/bit.ly\/11GsYIY",
      "display_url" : "bit.ly\/11GsYIY"
    } ]
  },
  "geo" : { },
  "id_str" : "301727871855128576",
  "text" : "You're welcome! (http:\/\/t.co\/OFbPcHDY) RT @kenrickchien: @keithrbennett Thanks for the work on the blog post w\/Oracle, #jruby and rails.",
  "id" : 301727871855128576,
  "created_at" : "2013-02-13 16:21:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301088258719350785",
  "geo" : { },
  "id_str" : "301727487287783424",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien What java_signature problems are you having?",
  "id" : 301727487287783424,
  "in_reply_to_status_id" : 301088258719350785,
  "created_at" : "2013-02-13 16:20:13 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/wjwZDiAL",
      "expanded_url" : "http:\/\/bit.ly\/11GpaY0",
      "display_url" : "bit.ly\/11GpaY0"
    } ]
  },
  "geo" : { },
  "id_str" : "301721193050951680",
  "text" : "I finally understand \"that\" vs. \"which\", thanks to the Chicago Manual of Style web site: http:\/\/t.co\/wjwZDiAL",
  "id" : 301721193050951680,
  "created_at" : "2013-02-13 15:55:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris St. John",
      "screen_name" : "stjohncj",
      "indices" : [ 0, 9 ],
      "id_str" : "60298711",
      "id" : 60298711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "301397181796061184",
  "geo" : { },
  "id_str" : "301435879271067649",
  "in_reply_to_user_id" : 60298711,
  "text" : "@stjohncj Looking forward to seeing you and your presentation at Baltimore on Rails tonight. You're among friends. ;)",
  "id" : 301435879271067649,
  "in_reply_to_status_id" : 301397181796061184,
  "created_at" : "2013-02-12 21:01:28 +0000",
  "in_reply_to_screen_name" : "stjohncj",
  "in_reply_to_user_id_str" : "60298711",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 36, 43 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "erlangdc2013",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "300248735076741123",
  "geo" : { },
  "id_str" : "300253302241759232",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Sitting next to *my* homie, @elight, at #erlangdc2013. Fun stuff.",
  "id" : 300253302241759232,
  "in_reply_to_status_id" : 300248735076741123,
  "created_at" : "2013-02-09 14:42:20 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 0, 9 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "299255893546110976",
  "geo" : { },
  "id_str" : "299617637963554816",
  "in_reply_to_user_id" : 91333167,
  "text" : "@climagic I believe the \"-1\" is not needed. When output is redirected, it will be one per line by default.",
  "id" : 299617637963554816,
  "in_reply_to_status_id" : 299255893546110976,
  "created_at" : "2013-02-07 20:36:26 +0000",
  "in_reply_to_screen_name" : "climagic",
  "in_reply_to_user_id_str" : "91333167",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/nxjo8Ssw",
      "expanded_url" : "http:\/\/gethuman.com",
      "display_url" : "gethuman.com"
    } ]
  },
  "geo" : { },
  "id_str" : "299197561946906625",
  "text" : "Just used http:\/\/t.co\/nxjo8Ssw to effortlessly have United Airlines call *me*!  Awesome service.",
  "id" : 299197561946906625,
  "created_at" : "2013-02-06 16:47:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "298815693959360512",
  "text" : "RT @headius: If JRuby switched from the Common Public License to the Eclipse Public License in 1.7.3, would it affect your project?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "298770365914685441",
    "text" : "If JRuby switched from the Common Public License to the Eclipse Public License in 1.7.3, would it affect your project?",
    "id" : 298770365914685441,
    "created_at" : "2013-02-05 12:29:40 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736361495756480513\/U0H_Wfk4_normal.jpg",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 298815693959360512,
  "created_at" : "2013-02-05 15:29:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297521558929432577",
  "text" : "@objo Congrats, enjoy it.  I've done some good life refactoring and traveling during sabbaticals \/ between work assignments.",
  "id" : 297521558929432577,
  "created_at" : "2013-02-02 01:47:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Harris",
      "screen_name" : "harrisimo",
      "indices" : [ 3, 13 ],
      "id_str" : "16680882",
      "id" : 16680882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297392365696598017",
  "text" : "RT @harrisimo: This is what happens if you give a cake shop a USB stick containing an image you want to appear on a cake: http:\/\/t.co\/dX ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/dXza7jy9",
        "expanded_url" : "http:\/\/i.imgur.com\/xTQEp9Z.jpg",
        "display_url" : "i.imgur.com\/xTQEp9Z.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "297282231611834368",
    "text" : "This is what happens if you give a cake shop a USB stick containing an image you want to appear on a cake: http:\/\/t.co\/dXza7jy9",
    "id" : 297282231611834368,
    "created_at" : "2013-02-01 09:56:21 +0000",
    "user" : {
      "name" : "Brian Harris",
      "screen_name" : "harrisimo",
      "protected" : false,
      "id_str" : "16680882",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/83018922\/moi_normal.JPG",
      "id" : 16680882,
      "verified" : false
    }
  },
  "id" : 297392365696598017,
  "created_at" : "2013-02-01 17:13:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]