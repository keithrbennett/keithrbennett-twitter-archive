Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Kilmer",
      "screen_name" : "rich_kilmer",
      "indices" : [ 0, 12 ],
      "id_str" : "9572502",
      "id" : 9572502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/151734956916359168\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/lUx9F2Xn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AhsSI69CQAEXgJB.jpg",
      "id_str" : "151734956920553473",
      "id" : 151734956920553473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AhsSI69CQAEXgJB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/lUx9F2Xn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "151131213283860483",
  "geo" : { },
  "id_str" : "151734956916359168",
  "in_reply_to_user_id" : 9572502,
  "text" : "@rich_kilmer Check out this house -- just off Reston Pkwy, Fieldview Dr I think, just south of Route 7. http:\/\/t.co\/lUx9F2Xn",
  "id" : 151734956916359168,
  "in_reply_to_status_id" : 151131213283860483,
  "created_at" : "2011-12-27 18:43:28 +0000",
  "in_reply_to_screen_name" : "rich_kilmer",
  "in_reply_to_user_id_str" : "9572502",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JRubyConf",
      "screen_name" : "JRubyConf",
      "indices" : [ 0, 10 ],
      "id_str" : "71363379",
      "id" : 71363379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150661194049527808",
  "in_reply_to_user_id" : 71363379,
  "text" : "@jrubyconf Is the conference all day for each of the 3 days May 21-23?  Need to know to make travel plans.",
  "id" : 150661194049527808,
  "created_at" : "2011-12-24 19:36:42 +0000",
  "in_reply_to_screen_name" : "JRubyConf",
  "in_reply_to_user_id_str" : "71363379",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/DSe7WMMO",
      "expanded_url" : "http:\/\/edition.cnn.com\/2011\/12\/23\/world\/asia\/climate-change-impact-cities\/index.html?hpt=hp_c1",
      "display_url" : "edition.cnn.com\/2011\/12\/23\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150652234072457216",
  "text" : "Climate change's dire effects on the future of the world's cities: http:\/\/t.co\/DSe7WMMO",
  "id" : 150652234072457216,
  "created_at" : "2011-12-24 19:01:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146466180163575808",
  "text" : "Just finished 13 hour Android hackathon with Jason G.  Tired but happy and a little smarter.",
  "id" : 146466180163575808,
  "created_at" : "2011-12-13 05:47:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145996530929778691",
  "text" : "Apple Time Capsule.  2 TB NAS, router w\/private & guest networks, and network print server. Under $300.  5 minutes to set up.  Awesome.",
  "id" : 145996530929778691,
  "created_at" : "2011-12-11 22:41:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Plotkin",
      "screen_name" : "zarfeblong",
      "indices" : [ 3, 14 ],
      "id_str" : "16203848",
      "id" : 16203848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145895139695538176",
  "text" : "RT @zarfeblong: The patent system is based on the premise that ideas are rare and precious, but implementation is easy. No wonder it's f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "145269648500326400",
    "text" : "The patent system is based on the premise that ideas are rare and precious, but implementation is easy. No wonder it's failing for software!",
    "id" : 145269648500326400,
    "created_at" : "2011-12-09 22:32:37 +0000",
    "user" : {
      "name" : "Andrew Plotkin",
      "screen_name" : "zarfeblong",
      "protected" : false,
      "id_str" : "16203848",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3080585710\/1f3e21047d2527ab9472e706acdfb86e_normal.png",
      "id" : 16203848,
      "verified" : false
    }
  },
  "id" : 145895139695538176,
  "created_at" : "2011-12-11 15:58:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145608877826768897",
  "geo" : { },
  "id_str" : "145894750938079232",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick All of them. :-)  How about Strangeloop? Seems like a great fit.",
  "id" : 145894750938079232,
  "in_reply_to_status_id" : 145608877826768897,
  "created_at" : "2011-12-11 15:56:33 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145303090340446208",
  "geo" : { },
  "id_str" : "145537715214098432",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer Maybe the shell just never exits.  Try typing ctrl-D, or adding \"; exit\" to the command you send to it.",
  "id" : 145537715214098432,
  "in_reply_to_status_id" : 145303090340446208,
  "created_at" : "2011-12-10 16:17:49 +0000",
  "in_reply_to_screen_name" : "_zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144859181936148480",
  "text" : "Just found out, Comcast recently imposed a 250 GB monthly limit on home Internet service bandwidth. No problem for me for now though.",
  "id" : 144859181936148480,
  "created_at" : "2011-12-08 19:21:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/Y24XvaWX",
      "expanded_url" : "http:\/\/xfinity.com\/constantguard",
      "display_url" : "xfinity.com\/constantguard"
    } ]
  },
  "geo" : { },
  "id_str" : "144858768537161728",
  "text" : "Comcast customers, for Windows boxes, you can get free Norton Security Suite by installing http:\/\/t.co\/Y24XvaWX.",
  "id" : 144858768537161728,
  "created_at" : "2011-12-08 19:19:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144577421109235712",
  "geo" : { },
  "id_str" : "144580271843454977",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer Zee, but you wouldn't buy a gift card for someone expecting them to resell it, right?  And gift cards can be discounted (Costco).",
  "id" : 144580271843454977,
  "in_reply_to_status_id" : 144577421109235712,
  "created_at" : "2011-12-08 00:53:17 +0000",
  "in_reply_to_screen_name" : "_zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/x3QfRJq6",
      "expanded_url" : "http:\/\/tinyurl.com\/7ttavas",
      "display_url" : "tinyurl.com\/7ttavas"
    } ]
  },
  "in_reply_to_status_id_str" : "144566812569374721",
  "geo" : { },
  "id_str" : "144579557087911936",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi I use Amazon reviews to predict my satisfaction. Here's a highly reviewed UPS: http:\/\/t.co\/x3QfRJq6.",
  "id" : 144579557087911936,
  "in_reply_to_status_id" : 144566812569374721,
  "created_at" : "2011-12-08 00:50:27 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ole Martin Moen",
      "screen_name" : "oleMMoen",
      "indices" : [ 3, 12 ],
      "id_str" : "313242999",
      "id" : 313242999
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/czoibOP7",
      "expanded_url" : "http:\/\/i.imgur.com\/UxYiq.jpg",
      "display_url" : "i.imgur.com\/UxYiq.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "143703679646699520",
  "text" : "RT @oleMMoen: Cool! The Norwegian flag contains the Indonesian, Polish, Dutch, Finnish, French, and Thai flag: http:\/\/t.co\/czoibOP7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/czoibOP7",
        "expanded_url" : "http:\/\/i.imgur.com\/UxYiq.jpg",
        "display_url" : "i.imgur.com\/UxYiq.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "143339573831933953",
    "text" : "Cool! The Norwegian flag contains the Indonesian, Polish, Dutch, Finnish, French, and Thai flag: http:\/\/t.co\/czoibOP7",
    "id" : 143339573831933953,
    "created_at" : "2011-12-04 14:43:12 +0000",
    "user" : {
      "name" : "Ole Martin Moen",
      "screen_name" : "oleMMoen",
      "protected" : false,
      "id_str" : "313242999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777111953592479744\/kacLEcID_normal.jpg",
      "id" : 313242999,
      "verified" : false
    }
  },
  "id" : 143703679646699520,
  "created_at" : "2011-12-05 14:50:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "indices" : [ 3, 6 ],
      "id_str" : "15504330",
      "id" : 15504330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143546183556669440",
  "text" : "RT @wm: \"runners can only run full speed for short distances. we fix that problem by firing the pistol every 100 yards and calling it a  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "143208540734095360",
    "text" : "\"runners can only run full speed for short distances. we fix that problem by firing the pistol every 100 yards and calling it a new sprint.\"",
    "id" : 143208540734095360,
    "created_at" : "2011-12-04 06:02:31 +0000",
    "user" : {
      "name" : "William Morgan",
      "screen_name" : "wm",
      "protected" : false,
      "id_str" : "15504330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571426011502227456\/q0nvUd3i_normal.jpeg",
      "id" : 15504330,
      "verified" : false
    }
  },
  "id" : 143546183556669440,
  "created_at" : "2011-12-05 04:24:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 0, 7 ],
      "id_str" : "17416571",
      "id" : 17416571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "airbnb",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "136540167174504448",
  "geo" : { },
  "id_str" : "143367563789860864",
  "in_reply_to_user_id" : 17416571,
  "text" : "@airbnb First #airbnb experience a resounding success.  Thanks!",
  "id" : 143367563789860864,
  "in_reply_to_status_id" : 136540167174504448,
  "created_at" : "2011-12-04 16:34:25 +0000",
  "in_reply_to_screen_name" : "Airbnb",
  "in_reply_to_user_id_str" : "17416571",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/TPOe9XgZ",
      "expanded_url" : "http:\/\/www.amazon.com\/Schumacher-IP-125-Instant-Starter-Battery\/dp\/B000TD6S9U\/ref=sr_1_1?ie=UTF8&qid=1323015927&sr=8-1",
      "display_url" : "amazon.com\/Schumacher-IP-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "143365958495514624",
  "text" : "I highly recommend getting a quality portable jumpstarter like http:\/\/t.co\/TPOe9XgZ. Earlier version has worked well for me. Good xmas gift?",
  "id" : 143365958495514624,
  "created_at" : "2011-12-04 16:28:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Spalding",
      "screen_name" : "librarythingtim",
      "indices" : [ 3, 19 ],
      "id_str" : "5917472",
      "id" : 5917472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "143359550735663105",
  "text" : "RT @librarythingtim: Saturday, instead of taking your child to a bookstore, show them your Kindle library and say \"When I die, you're no ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "142628597289582593",
    "text" : "Saturday, instead of taking your child to a bookstore, show them your Kindle library and say \"When I die, you're not licensed to use this.\"",
    "id" : 142628597289582593,
    "created_at" : "2011-12-02 15:38:02 +0000",
    "user" : {
      "name" : "Tim Spalding",
      "screen_name" : "librarythingtim",
      "protected" : false,
      "id_str" : "5917472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1401219401\/tim_normal.jpg",
      "id" : 5917472,
      "verified" : false
    }
  },
  "id" : 143359550735663105,
  "created_at" : "2011-12-04 16:02:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]