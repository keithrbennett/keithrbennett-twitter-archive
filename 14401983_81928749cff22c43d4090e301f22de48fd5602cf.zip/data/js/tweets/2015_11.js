Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 1, 8 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "indices" : [ 109, 122 ],
      "id_str" : "18061835",
      "id" : 18061835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668300038007861248",
  "text" : ".@github How can one contact the owner of a Github group ('hackerhours'), or at least find out who it is? cc @aidanfeldman",
  "id" : 668300038007861248,
  "created_at" : "2015-11-22 05:28:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 0, 7 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667511977556578304",
  "geo" : { },
  "id_str" : "667527465976373248",
  "in_reply_to_user_id" : 17055675,
  "text" : "@Adkron Nice to see you too, and thanks again.",
  "id" : 667527465976373248,
  "in_reply_to_status_id" : 667511977556578304,
  "created_at" : "2015-11-20 02:18:44 +0000",
  "in_reply_to_screen_name" : "Adkron",
  "in_reply_to_user_id_str" : "17055675",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amos King",
      "screen_name" : "Adkron",
      "indices" : [ 0, 7 ],
      "id_str" : "17055675",
      "id" : 17055675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "667480286704177152",
  "geo" : { },
  "id_str" : "667484541242732544",
  "in_reply_to_user_id" : 17055675,
  "text" : "@Adkron Yes.  After the initial screwup, everyone did their job right. Both planes vacated and nobody got hurt. Thanks for the kind wishes.",
  "id" : 667484541242732544,
  "in_reply_to_status_id" : 667480286704177152,
  "created_at" : "2015-11-19 23:28:10 +0000",
  "in_reply_to_screen_name" : "Adkron",
  "in_reply_to_user_id_str" : "17055675",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 20, 29 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5TdqINbZ1O",
      "expanded_url" : "https:\/\/goo.gl\/photos\/gHaDkv1tMfMp6t6H6",
      "display_url" : "goo.gl\/photos\/gHaDkv1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "667477828611502081",
  "text" : "My flight home from @rubyconf yesterday featured an aborted takeoff due to a plane intending to land as we took off: https:\/\/t.co\/5TdqINbZ1O",
  "id" : 667477828611502081,
  "created_at" : "2015-11-19 23:01:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 109, 118 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/667076375094820864\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/CloTHRhQk8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHuaF4UcAA7LL3.jpg",
      "id_str" : "667076351849951232",
      "id" : 667076351849951232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHuaF4UcAA7LL3.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CloTHRhQk8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667076375094820864",
  "text" : "Amazing $10 lunch at Koreana Rest. in San Antonio. My first &amp; last SA meals were here. Bye till next yr, @rubyconf! https:\/\/t.co\/CloTHRhQk8",
  "id" : 667076375094820864,
  "created_at" : "2015-11-18 20:26:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/667067972909797377\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/H8YvI2Jjsi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUHmtLrUcAAhno1.jpg",
      "id_str" : "667067883730530304",
      "id" : 667067883730530304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUHmtLrUcAAhno1.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/H8YvI2Jjsi"
    } ],
    "hashtags" : [ {
      "text" : "Alamo",
      "indices" : [ 18, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667067972909797377",
  "text" : "This guide at the #Alamo is amazing. So many fascinating stories &amp; info about native plant life. https:\/\/t.co\/H8YvI2Jjsi",
  "id" : 667067972909797377,
  "created_at" : "2015-11-18 19:52:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Berkopec",
      "screen_name" : "nateberkopec",
      "indices" : [ 0, 13 ],
      "id_str" : "18259813",
      "id" : 18259813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666804953223004160",
  "geo" : { },
  "id_str" : "667029209517326336",
  "in_reply_to_user_id" : 18259813,
  "text" : "@nateberkopec Sorry!  For some reason I did not see your tweet until this morning.",
  "id" : 667029209517326336,
  "in_reply_to_status_id" : 666804953223004160,
  "created_at" : "2015-11-18 17:18:51 +0000",
  "in_reply_to_screen_name" : "nateberkopec",
  "in_reply_to_user_id_str" : "18259813",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna",
      "screen_name" : "flexlingie",
      "indices" : [ 28, 39 ],
      "id_str" : "37953915",
      "id" : 37953915
    }, {
      "name" : "sofia garcia",
      "screen_name" : "sofisagarcia_",
      "indices" : [ 44, 58 ],
      "id_str" : "355040812",
      "id" : 355040812
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 85, 94 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/667023932847853569\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/TosVPFYfMt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUG-upGVAAAp1an.jpg",
      "id_str" : "667023928343199744",
      "id" : 667023928343199744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUG-upGVAAAp1an.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      } ],
      "display_url" : "pic.twitter.com\/TosVPFYfMt"
    } ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667023932847853569",
  "text" : "Another #rubykaraoke photo: @flexlingie and @sofisagarcia_ at the Republic of Texas, @RubyConf 2015. https:\/\/t.co\/TosVPFYfMt",
  "id" : 667023932847853569,
  "created_at" : "2015-11-18 16:57:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernie Miller",
      "screen_name" : "erniemiller",
      "indices" : [ 0, 12 ],
      "id_str" : "16143891",
      "id" : 16143891
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 112, 120 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666790517556932608",
  "geo" : { },
  "id_str" : "667022150625136640",
  "in_reply_to_user_id" : 16143891,
  "text" : "@erniemiller Sorry. The closer place was Hooters-like. Side benefit: I prefer meeting natives to tourists.   cc @headius #rubykaraoke",
  "id" : 667022150625136640,
  "in_reply_to_status_id" : 666790517556932608,
  "created_at" : "2015-11-18 16:50:48 +0000",
  "in_reply_to_screen_name" : "erniemiller",
  "in_reply_to_user_id_str" : "16143891",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anna",
      "screen_name" : "flexlingie",
      "indices" : [ 0, 11 ],
      "id_str" : "37953915",
      "id" : 37953915
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666843789533691904",
  "geo" : { },
  "id_str" : "666846304669052928",
  "in_reply_to_user_id" : 37953915,
  "text" : "@flexlingie excellent! We look forward to your arrival.",
  "id" : 666846304669052928,
  "in_reply_to_status_id" : 666843789533691904,
  "created_at" : "2015-11-18 05:12:03 +0000",
  "in_reply_to_screen_name" : "flexlingie",
  "in_reply_to_user_id_str" : "37953915",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fabian Rodriguez",
      "screen_name" : "fabianrbz",
      "indices" : [ 23, 33 ],
      "id_str" : "345029661",
      "id" : 345029661
    }, {
      "name" : "Sebastian Suttner",
      "screen_name" : "ssuttner",
      "indices" : [ 38, 47 ],
      "id_str" : "341240020",
      "id" : 341240020
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 64, 73 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666834720454414336\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/EZudjG1vq1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CUESoKTUEAEK9D8.jpg",
      "id_str" : "666834700996972545",
      "id" : 666834700996972545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CUESoKTUEAEK9D8.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      } ],
      "display_url" : "pic.twitter.com\/EZudjG1vq1"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 10, 22 ]
    }, {
      "text" : "RubyKaraoke",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666834720454414336",
  "text" : "Uruguayan #rubyfriends @fabianrbz and @ssuttner at #RubyKaraoke @rubyconf https:\/\/t.co\/EZudjG1vq1",
  "id" : 666834720454414336,
  "created_at" : "2015-11-18 04:26:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 94, 103 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666800718175686657",
  "text" : "Leaving the conference hotel lobby at about 8:30 in case anyone wants a ride to #rubykaraoke. @rubyconf",
  "id" : 666800718175686657,
  "created_at" : "2015-11-18 02:10:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sofia garcia",
      "screen_name" : "sofisagarcia_",
      "indices" : [ 0, 14 ],
      "id_str" : "355040812",
      "id" : 355040812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666749172201218049",
  "geo" : { },
  "id_str" : "666782620915625984",
  "in_reply_to_user_id" : 355040812,
  "text" : "@sofisagarcia_ I just emailed you a Dropbox link.  Feel free to share it. It was way too big for email.",
  "id" : 666782620915625984,
  "in_reply_to_status_id" : 666749172201218049,
  "created_at" : "2015-11-18 00:58:59 +0000",
  "in_reply_to_screen_name" : "sofisagarcia_",
  "in_reply_to_user_id_str" : "355040812",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 130, 139 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 35 ],
      "url" : "https:\/\/t.co\/g8ZsjXKgtB",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/koreana-restaurant-san-antonio",
      "display_url" : "yelp.com\/biz\/koreana-re\u2026"
    }, {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/tiw4nxXJT1",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/me-and-c-a-karaoke-bar-san-antonio",
      "display_url" : "yelp.com\/biz\/me-and-c-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666759457599266816",
  "text" : "Leaving for https:\/\/t.co\/g8ZsjXKgtB for Korean dinner at 7:00, then https:\/\/t.co\/tiw4nxXJT1. Anyone want to join me? #rubykaraoke @rubyconf",
  "id" : 666759457599266816,
  "created_at" : "2015-11-17 23:26:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 117, 126 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/WuhAHBxVtv",
      "expanded_url" : "http:\/\/songbookslive.com",
      "display_url" : "songbookslive.com"
    } ]
  },
  "in_reply_to_status_id_str" : "666719117408256001",
  "geo" : { },
  "id_str" : "666722283495555074",
  "in_reply_to_user_id" : 14401983,
  "text" : "Huge song selection. To find them go to https:\/\/t.co\/WuhAHBxVtv  and input \"meandca\" as songbook name.  Spanish too! @rubyconf #rubykaraoke",
  "id" : 666722283495555074,
  "in_reply_to_status_id" : 666719117408256001,
  "created_at" : "2015-11-17 20:59:14 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sofia garcia",
      "screen_name" : "sofisagarcia_",
      "indices" : [ 0, 14 ],
      "id_str" : "355040812",
      "id" : 355040812
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 15, 24 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666675566049804288",
  "geo" : { },
  "id_str" : "666720003555778560",
  "in_reply_to_user_id" : 355040812,
  "text" : "@sofisagarcia_ @rubyconf You're incredible too. I got a video of you singing on Sunday night in case you want it. ;)",
  "id" : 666720003555778560,
  "in_reply_to_status_id" : 666675566049804288,
  "created_at" : "2015-11-17 20:50:10 +0000",
  "in_reply_to_screen_name" : "sofisagarcia_",
  "in_reply_to_user_id_str" : "355040812",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 116, 125 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/tiw4nxG8ur",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/me-and-c-a-karaoke-bar-san-antonio",
      "display_url" : "yelp.com\/biz\/me-and-c-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666719117408256001",
  "text" : "Karaoke 8:30\/9 - 2:00 tonight at https:\/\/t.co\/tiw4nxG8ur. Contact me if need transport @ my twitter handle @ gmail. @rubyconf #rubykaraoke",
  "id" : 666719117408256001,
  "created_at" : "2015-11-17 20:46:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Anna",
      "screen_name" : "flexlingie",
      "indices" : [ 9, 20 ],
      "id_str" : "37953915",
      "id" : 37953915
    }, {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 21, 31 ],
      "id_str" : "14498747",
      "id" : 14498747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666681172743688192",
  "geo" : { },
  "id_str" : "666699344096002048",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @flexlingie @tom_enebo Closer is good but I have a concern that it would be better to discuss face to face. Meet at reg. desk at 2?",
  "id" : 666699344096002048,
  "in_reply_to_status_id" : 666681172743688192,
  "created_at" : "2015-11-17 19:28:04 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Anna",
      "screen_name" : "flexlingie",
      "indices" : [ 9, 20 ],
      "id_str" : "37953915",
      "id" : 37953915
    }, {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 21, 31 ],
      "id_str" : "14498747",
      "id" : 14498747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/tiw4nxXJT1",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/me-and-c-a-karaoke-bar-san-antonio",
      "display_url" : "yelp.com\/biz\/me-and-c-a\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "666607333473153024",
  "geo" : { },
  "id_str" : "666646242496237569",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @flexlingie @tom_enebo I'm in. I suggest https:\/\/t.co\/tiw4nxXJT1. 8:30-10:00 is best time to sing, before the \"competition\".",
  "id" : 666646242496237569,
  "in_reply_to_status_id" : 666607333473153024,
  "created_at" : "2015-11-17 15:57:04 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Faraday",
      "screen_name" : "MarmiteJunction",
      "indices" : [ 3, 19 ],
      "id_str" : "329032057",
      "id" : 329032057
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 38, 47 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarmiteJunction\/status\/666413860451028992\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/7Tv2DHf5WP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT-T3yGUAAE7Koz.jpg",
      "id_str" : "666413856424460289",
      "id" : 666413856424460289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT-T3yGUAAE7Koz.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7Tv2DHf5WP"
    } ],
    "hashtags" : [ {
      "text" : "YouHeardItHereFirst",
      "indices" : [ 49, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666458190511345664",
  "text" : "RT @MarmiteJunction: Ruby in Hindi at @rubyconf\n\n#YouHeardItHereFirst https:\/\/t.co\/7Tv2DHf5WP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rubyconf",
        "screen_name" : "rubyconf",
        "indices" : [ 17, 26 ],
        "id_str" : "16222737",
        "id" : 16222737
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarmiteJunction\/status\/666413860451028992\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/7Tv2DHf5WP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CT-T3yGUAAE7Koz.jpg",
        "id_str" : "666413856424460289",
        "id" : 666413856424460289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT-T3yGUAAE7Koz.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7Tv2DHf5WP"
      } ],
      "hashtags" : [ {
        "text" : "YouHeardItHereFirst",
        "indices" : [ 28, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "666413860451028992",
    "text" : "Ruby in Hindi at @rubyconf\n\n#YouHeardItHereFirst https:\/\/t.co\/7Tv2DHf5WP",
    "id" : 666413860451028992,
    "created_at" : "2015-11-17 00:33:40 +0000",
    "user" : {
      "name" : "Happy Christmas",
      "screen_name" : "MarmiteJunction",
      "protected" : false,
      "id_str" : "329032057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798545542624190464\/A_nnH2NR_normal.jpg",
      "id" : 329032057,
      "verified" : false
    }
  },
  "id" : 666458190511345664,
  "created_at" : "2015-11-17 03:29:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666376038516187138",
  "text" : ".@rubyconf Beer, some hard liquor, and light snacks available. Asiana Karaoke, 4408 Walzem Rd, San Antonio, TX 78218, (210) 501-9448.",
  "id" : 666376038516187138,
  "created_at" : "2015-11-16 22:03:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666375978269192192\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/3109nDMJ4Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT9xa2eUEAEGp9h.jpg",
      "id_str" : "666375975987318785",
      "id" : 666375975987318785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT9xa2eUEAEGp9h.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3109nDMJ4Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666375978269192192",
  "text" : ".@rubyconf It's ~15 min drive, $2\/song, many lang's incl. English, Japanese, Spanish, though not huge selection. https:\/\/t.co\/3109nDMJ4Q",
  "id" : 666375978269192192,
  "created_at" : "2015-11-16 22:03:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666375832743624705\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/7aA8wUBrx1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT9xSVjUYAAP3UA.jpg",
      "id_str" : "666375829710987264",
      "id" : 666375829710987264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT9xSVjUYAAP3UA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7aA8wUBrx1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/ZRmU5Yntuj",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/asiana-big-bang-karaoke-san-antonio",
      "display_url" : "yelp.com\/biz\/asiana-big\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "666375832743624705",
  "text" : ".@rubyconf Anyone interested in (more) karaoke tonight or tomorrow night at https:\/\/t.co\/ZRmU5Yntuj, maybe ~10PM? https:\/\/t.co\/7aA8wUBrx1",
  "id" : 666375832743624705,
  "created_at" : "2015-11-16 22:02:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 1, 9 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 38, 47 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666130856960921600\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/OcMDMyMj2X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT6ScQlVEAAn1fM.jpg",
      "id_str" : "666130809082941440",
      "id" : 666130809082941440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT6ScQlVEAAn1fM.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OcMDMyMj2X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666130856960921600",
  "text" : ".@headius singing \"Hips Don't Lie\" at @rubyconf. https:\/\/t.co\/OcMDMyMj2X",
  "id" : 666130856960921600,
  "created_at" : "2015-11-16 05:49:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "celeeeeeeeeeeeeeeeen",
      "screen_name" : "celeenr",
      "indices" : [ 52, 60 ],
      "id_str" : "17829616",
      "id" : 17829616
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 64, 73 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666130170298765313\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/JyWKtxyu2G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT6Ryz0VAAA2hiu.jpg",
      "id_str" : "666130096986587136",
      "id" : 666130096986587136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT6Ryz0VAAA2hiu.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JyWKtxyu2G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666130170298765313",
  "text" : "Stellar rendition of \"Total Eclipse of My Heart\" by @celeenr at @rubyconf. https:\/\/t.co\/JyWKtxyu2G",
  "id" : 666130170298765313,
  "created_at" : "2015-11-16 05:46:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 44, 53 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666126717002510336\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/NsIlgzYwk2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT6OqzDU8AAYkJA.jpg",
      "id_str" : "666126660807225344",
      "id" : 666126660807225344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT6OqzDU8AAYkJA.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/NsIlgzYwk2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666126717002510336",
  "text" : "Singing \"Livin' la Vida Loca\" in Spanish at @rubyconf. https:\/\/t.co\/NsIlgzYwk2",
  "id" : 666126717002510336,
  "created_at" : "2015-11-16 05:32:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 26, 36 ],
      "id_str" : "14498747",
      "id" : 14498747
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 41, 49 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 70, 79 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666123718301585408\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/A24kF3F6aX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT6L6NaUcAACycG.jpg",
      "id_str" : "666123627046137856",
      "id" : 666123627046137856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT6L6NaUcAACycG.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/A24kF3F6aX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666123718301585408",
  "text" : "Singing \"Lean On Me\" with @tom_enebo and @headius, JRuby creators, at @rubyconf. https:\/\/t.co\/A24kF3F6aX",
  "id" : 666123718301585408,
  "created_at" : "2015-11-16 05:20:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 14, 23 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "666109146035433472",
  "geo" : { },
  "id_str" : "666122492604362753",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 @rubyconf \"I Knew You Were Trouble\" by Taylor Swift.",
  "id" : 666122492604362753,
  "in_reply_to_status_id" : 666109146035433472,
  "created_at" : "2015-11-16 05:15:52 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walter Latimer",
      "screen_name" : "walterlatimer",
      "indices" : [ 1, 15 ],
      "id_str" : "1641668262",
      "id" : 1641668262
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 56, 65 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666120259837947904\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/FFUyIT1m9s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT6I0iqUAAEUJBb.jpg",
      "id_str" : "666120231136264193",
      "id" : 666120231136264193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT6I0iqUAAEUJBb.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FFUyIT1m9s"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666120259837947904",
  "text" : ".@walterlatimer singing karaoke and making a dollar. :) @rubyconf https:\/\/t.co\/FFUyIT1m9s",
  "id" : 666120259837947904,
  "created_at" : "2015-11-16 05:07:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 30, 39 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666108840958492672\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/jc9jN9JKNU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT5-Xq4UYAAmftN.jpg",
      "id_str" : "666108740010008576",
      "id" : 666108740010008576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT5-Xq4UYAAmftN.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jc9jN9JKNU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666108840958492672",
  "text" : "And another karaoke moment at @rubyconf. https:\/\/t.co\/jc9jN9JKNU",
  "id" : 666108840958492672,
  "created_at" : "2015-11-16 04:21:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 5, 14 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666103167159959552\/photo\/1",
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/RrheaXN6Y4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT55GNVUcAAJecO.jpg",
      "id_str" : "666102942462668800",
      "id" : 666102942462668800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT55GNVUcAAJecO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/RrheaXN6Y4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666103167159959552",
  "text" : "More @rubyconf karaoke. https:\/\/t.co\/RrheaXN6Y4",
  "id" : 666103167159959552,
  "created_at" : "2015-11-16 03:59:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 32, 41 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/666100158002655233\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/S9HNJDGdQu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CT52ghmUsAAyZAu.jpg",
      "id_str" : "666100096044412928",
      "id" : 666100096044412928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CT52ghmUsAAyZAu.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/S9HNJDGdQu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "666100158002655233",
  "text" : "Karaoke at Republic of Texas at @rubyconf in San Antonio! https:\/\/t.co\/S9HNJDGdQu",
  "id" : 666100158002655233,
  "created_at" : "2015-11-16 03:47:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 13, 22 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 83, 91 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/Ni9lj7gbqR",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/republic-of-texas-restaurant-san-antonio",
      "display_url" : "yelp.com\/biz\/republic-o\u2026"
    }, {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/5lkxturluc",
      "expanded_url" : "http:\/\/www.mikeperham.com\/events\/",
      "display_url" : "mikeperham.com\/events\/"
    } ]
  },
  "geo" : { },
  "id_str" : "665962448718024704",
  "text" : "#rubykaraoke @rubyconf Karaoke (!!!) from 9PM on at https:\/\/t.co\/Ni9lj7gbqR as per @mperham at https:\/\/t.co\/5lkxturluc.",
  "id" : 665962448718024704,
  "created_at" : "2015-11-15 18:39:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665912590216896512",
  "text" : "RT @climagic: t=$(($(tput cols)\/3));for FR in $(seq $(tput lines));do printf \"\\e[44m%$\u007Bt\u007Ds\\e[47m %$\u007Bt\u007Ds\\e[41m%$\u007Bt\u007Ds\\e[0m\\n\";done # French F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "665880246172930048",
    "text" : "t=$(($(tput cols)\/3));for FR in $(seq $(tput lines));do printf \"\\e[44m%$\u007Bt\u007Ds\\e[47m %$\u007Bt\u007Ds\\e[41m%$\u007Bt\u007Ds\\e[0m\\n\";done # French Flag",
    "id" : 665880246172930048,
    "created_at" : "2015-11-15 13:13:16 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 665912590216896512,
  "created_at" : "2015-11-15 15:21:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helio Cola",
      "screen_name" : "hacrods",
      "indices" : [ 0, 8 ],
      "id_str" : "2901793161",
      "id" : 2901793161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "665712402013515776",
  "geo" : { },
  "id_str" : "665802300066308096",
  "in_reply_to_user_id" : 2901793161,
  "text" : "@hacrods Yes, there were lots of us on that plane!",
  "id" : 665802300066308096,
  "in_reply_to_status_id" : 665712402013515776,
  "created_at" : "2015-11-15 08:03:33 +0000",
  "in_reply_to_screen_name" : "hacrods",
  "in_reply_to_user_id_str" : "2901793161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helio Cola",
      "screen_name" : "hacrods",
      "indices" : [ 0, 8 ],
      "id_str" : "2901793161",
      "id" : 2901793161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/SD2H7TGrS0",
      "expanded_url" : "https:\/\/bugs.ruby-lang.org\/issues\/11665",
      "display_url" : "bugs.ruby-lang.org\/issues\/11665"
    } ]
  },
  "in_reply_to_status_id_str" : "663102460257419265",
  "geo" : { },
  "id_str" : "665705302050762753",
  "in_reply_to_user_id" : 14401983,
  "text" : "@hacrods Thanks for the retweet.  Interesting discussion about it on the Ruby Language issue tracker at https:\/\/t.co\/SD2H7TGrS0.",
  "id" : 665705302050762753,
  "in_reply_to_status_id" : 663102460257419265,
  "created_at" : "2015-11-15 01:38:06 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/wGzoFCz3TY",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2015\/11\/07\/the-case-for-nested-methods-in-ruby\/",
      "display_url" : "bbs-software.com\/blog\/2015\/11\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "663102460257419265",
  "text" : "Posted my first technical blog article in a long time, \"The Case for Nested Methods in Ruby\", at https:\/\/t.co\/wGzoFCz3TY.",
  "id" : 663102460257419265,
  "created_at" : "2015-11-07 21:15:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661686916438491136",
  "text" : "Found a great directory compare tool called 'meld'.  It's Gnome but can be installed on a Mac with: brew install homebrew\/x11\/meld",
  "id" : 661686916438491136,
  "created_at" : "2015-11-03 23:30:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]