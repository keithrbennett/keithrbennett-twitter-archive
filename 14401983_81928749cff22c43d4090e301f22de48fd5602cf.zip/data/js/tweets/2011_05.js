Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "Srihari Srinivasan",
      "screen_name" : "srihari",
      "indices" : [ 29, 37 ],
      "id_str" : "9032522",
      "id" : 9032522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75215277767401474",
  "text" : "RT @nashjain: Interesting RT @srihari: Pixar's hiring criteria - http:\/\/is.gd\/BguHpp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Srihari Srinivasan",
        "screen_name" : "srihari",
        "indices" : [ 15, 23 ],
        "id_str" : "9032522",
        "id" : 9032522
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "74543897426149377",
    "text" : "Interesting RT @srihari: Pixar's hiring criteria - http:\/\/is.gd\/BguHpp",
    "id" : 74543897426149377,
    "created_at" : "2011-05-28 18:33:44 +0000",
    "user" : {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "protected" : false,
      "id_str" : "10411062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775404265976332288\/LOoVpSln_normal.jpg",
      "id" : 10411062,
      "verified" : false
    }
  },
  "id" : 75215277767401474,
  "created_at" : "2011-05-30 15:01:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74661350969839616",
  "text" : "Android GUI's -- The Case Against GUI Builders and Data Driven GUI Configuration http:\/\/wp.me\/pnNgC-72",
  "id" : 74661350969839616,
  "created_at" : "2011-05-29 02:20:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68922147652902912",
  "text" : "Returning tonight from a 4 week working vacation in Southeast Asia networking, learning, researching, coding.  Ar\u2026http:\/\/snipurl.com\/27uge6.",
  "id" : 68922147652902912,
  "created_at" : "2011-05-13 06:14:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68594005306388480",
  "text" : "Singapore and Its Red Dot RubyConf http:\/\/wp.me\/pnNgC-6g",
  "id" : 68594005306388480,
  "created_at" : "2011-05-12 08:30:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Ong",
      "screen_name" : "jasonong",
      "indices" : [ 5, 14 ],
      "id_str" : "6823692",
      "id" : 6823692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65232812000808960",
  "text" : "From @jasonong: Numerous Ruby\/Rails learning links at http:\/\/net.tutsplus.com\/articles\/web-roundups\/essential-ruby-rails-3-reading-3\/.",
  "id" : 65232812000808960,
  "created_at" : "2011-05-03 01:54:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]