Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "luckyday",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297163198543589376",
  "text" : "Sitting at Panera for a late bowl of soup, it's 9:00, closing time and the friendly Panerista handed me a box full of free scones. #luckyday",
  "id" : 297163198543589376,
  "created_at" : "2013-02-01 02:03:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bentoconf",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "297019205490995200",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Is there a #bentoconf today?",
  "id" : 297019205490995200,
  "created_at" : "2013-01-31 16:31:11 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 10, 16 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296852419697078273",
  "geo" : { },
  "id_str" : "296853319815663617",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @peeja Not prerelease. life_game_viewer-0.9.0.gem.  A JRuby Swing app for educational\/illustrative use, no dependencies on it.",
  "id" : 296853319815663617,
  "in_reply_to_status_id" : 296852419697078273,
  "created_at" : "2013-01-31 05:32:01 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate",
      "screen_name" : "fowlduck",
      "indices" : [ 0, 9 ],
      "id_str" : "7284122",
      "id" : 7284122
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 10, 16 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296821768902017024",
  "geo" : { },
  "id_str" : "296851683890319360",
  "in_reply_to_user_id" : 7284122,
  "text" : "@fowlduck @peeja That list includes an old version of my gem that could be deleted and nobody would care, including me. What should I do?",
  "id" : 296851683890319360,
  "in_reply_to_status_id" : 296821768902017024,
  "created_at" : "2013-01-31 05:25:31 +0000",
  "in_reply_to_screen_name" : "fowlduck",
  "in_reply_to_user_id_str" : "7284122",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296757521459343360",
  "geo" : { },
  "id_str" : "296800880165015553",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx Thanks for your hard work. There will always be those who don't understand or appreciate the gift given by people like yourself.",
  "id" : 296800880165015553,
  "in_reply_to_status_id" : 296757521459343360,
  "created_at" : "2013-01-31 02:03:38 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "296451347803406337",
  "geo" : { },
  "id_str" : "296497802371022850",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer '&amp;' is needed so that the proc is seen as the unnamed block param, not a regular param: [1,nil].reject(&amp;Proc.new \u007B |v| v.nil? \u007D)",
  "id" : 296497802371022850,
  "in_reply_to_status_id" : 296451347803406337,
  "created_at" : "2013-01-30 05:59:19 +0000",
  "in_reply_to_screen_name" : "_zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Fraser",
      "screen_name" : "sfraser",
      "indices" : [ 3, 11 ],
      "id_str" : "2583921",
      "id" : 2583921
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/71GeD8li",
      "expanded_url" : "http:\/\/www.smithsonianmag.com\/history-archaeology\/For-40-Years-This-Russian-Family-Was-Cut-Off-From-Human-Contact-Unaware-of-World-War-II-188843001.html",
      "display_url" : "smithsonianmag.com\/history-archae\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "296426623547351041",
  "text" : "RT @sfraser: Russian family cut off from all society for 40 years, spinning wheel FTW: http:\/\/t.co\/71GeD8li",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 94 ],
        "url" : "http:\/\/t.co\/71GeD8li",
        "expanded_url" : "http:\/\/www.smithsonianmag.com\/history-archaeology\/For-40-Years-This-Russian-Family-Was-Cut-Off-From-Human-Contact-Unaware-of-World-War-II-188843001.html",
        "display_url" : "smithsonianmag.com\/history-archae\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "296387231512399872",
    "text" : "Russian family cut off from all society for 40 years, spinning wheel FTW: http:\/\/t.co\/71GeD8li",
    "id" : 296387231512399872,
    "created_at" : "2013-01-29 22:39:57 +0000",
    "user" : {
      "name" : "Scott Fraser",
      "screen_name" : "sfraser",
      "protected" : false,
      "id_str" : "2583921",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573656538\/IMG_1349_normal.JPG",
      "id" : 2583921,
      "verified" : false
    }
  },
  "id" : 296426623547351041,
  "created_at" : "2013-01-30 01:16:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295973879636164608",
  "text" : "RT @elight: Available for Ruby\/Rails remote contracting PT or FT: staff aug, remote mentoring\/pairing, code cleanup\/reviews.  Referrals  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "295927191097724928",
    "text" : "Available for Ruby\/Rails remote contracting PT or FT: staff aug, remote mentoring\/pairing, code cleanup\/reviews.  Referrals welcome. Plz RT.",
    "id" : 295927191097724928,
    "created_at" : "2013-01-28 16:11:55 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 295973879636164608,
  "created_at" : "2013-01-28 19:17:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295323283891576832",
  "geo" : { },
  "id_str" : "295327050103914497",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Just noticed, that very page has a sidebar link to \"Know the Difference Between Lose and Loose\".",
  "id" : 295327050103914497,
  "in_reply_to_status_id" : 295323283891576832,
  "created_at" : "2013-01-27 00:27:10 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "295323283891576832",
  "geo" : { },
  "id_str" : "295324086568116225",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett By the way, I was looking for an explanatory page about \"its\" vs. \"it's\" for my friend, not for me. ;)",
  "id" : 295324086568116225,
  "in_reply_to_status_id" : 295323283891576832,
  "created_at" : "2013-01-27 00:15:23 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "295323708816490496",
  "text" : "Proofreading an English document for a Swedish developer friend.  I'm pretty good at this -- anyone need this kind of service?",
  "id" : 295323708816490496,
  "created_at" : "2013-01-27 00:13:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "it_must_be_true_it_was_on_internet",
      "indices" : [ 105, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/JbrYgNYi",
      "expanded_url" : "http:\/\/www.wikihow.com\/Use-Its-and-It's",
      "display_url" : "wikihow.com\/Use-Its-and-It\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "295323283891576832",
  "text" : "Grammar page at http:\/\/t.co\/JbrYgNYi re: \"its\" vs \"it's\" confuses \"looses\" with \"loses\" (image, Part 1). #it_must_be_true_it_was_on_internet",
  "id" : 295323283891576832,
  "created_at" : "2013-01-27 00:12:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294904174976581633",
  "geo" : { },
  "id_str" : "294958850136739841",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Of course, agreed. IMO many recent &amp; excellent communication media - Github, Twitter, Facebook, Meetup are misused to our detriment.",
  "id" : 294958850136739841,
  "in_reply_to_status_id" : 294904174976581633,
  "created_at" : "2013-01-26 00:04:04 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294884182956572672",
  "geo" : { },
  "id_str" : "294903895279403008",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja +1. Prospective employers, especially. Else it's a disincentive to post. Protip: Bitbucket offers free private repos.",
  "id" : 294903895279403008,
  "in_reply_to_status_id" : 294884182956572672,
  "created_at" : "2013-01-25 20:25:42 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294644030623580161",
  "geo" : { },
  "id_str" : "294840817833615361",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick I'm very happy with my Columbia Interchange winter coat, but don't know if it's warm enough for your area.",
  "id" : 294840817833615361,
  "in_reply_to_status_id" : 294644030623580161,
  "created_at" : "2013-01-25 16:15:03 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294600637843382273",
  "text" : "So often we (of all beliefs\/positions) (even unconsciously) slip into selective sensitivity. To whom am I\/you insensitive? #fb",
  "id" : 294600637843382273,
  "created_at" : "2013-01-25 00:20:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 74 ],
      "url" : "https:\/\/t.co\/Jh5EtuSd",
      "expanded_url" : "https:\/\/github.com\/ricn\/rika\/pull\/3",
      "display_url" : "github.com\/ricn\/rika\/pull\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294585385063948291",
  "text" : "My first open source pull request in quite a while...https:\/\/t.co\/Jh5EtuSd .",
  "id" : 294585385063948291,
  "created_at" : "2013-01-24 23:20:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Nystr\u00F6m",
      "screen_name" : "richardnystrom",
      "indices" : [ 0, 15 ],
      "id_str" : "8103572",
      "id" : 8103572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 129 ],
      "url" : "https:\/\/t.co\/1oC84tlo",
      "expanded_url" : "https:\/\/github.com\/ricn\/rika",
      "display_url" : "github.com\/ricn\/rika"
    } ]
  },
  "geo" : { },
  "id_str" : "294584420759904256",
  "in_reply_to_user_id" : 8103572,
  "text" : "@richardnystrom Thanks for rika, Ruby gem for Apache Tika, providing parsing of a myriad of document types. https:\/\/t.co\/1oC84tlo #jruby",
  "id" : 294584420759904256,
  "created_at" : "2013-01-24 23:16:13 +0000",
  "in_reply_to_screen_name" : "richardnystrom",
  "in_reply_to_user_id_str" : "8103572",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 7, 19 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 20, 31 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bigrubyconf",
      "indices" : [ 45, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/LBtlNW1j",
      "expanded_url" : "http:\/\/bigrubyconf.com",
      "display_url" : "bigrubyconf.com"
    } ]
  },
  "in_reply_to_status_id_str" : "294527384156270592",
  "geo" : { },
  "id_str" : "294550008068468736",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja @angelaharms @ashedryden I'm going to #bigrubyconf (http:\/\/t.co\/LBtlNW1j), but not Ruby Midwest.  Gotta budget my conf. addiction. ;)",
  "id" : 294550008068468736,
  "in_reply_to_status_id" : 294527384156270592,
  "created_at" : "2013-01-24 20:59:29 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 13, 19 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294524658190004224",
  "geo" : { },
  "id_str" : "294525542659653633",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms @peeja Ideally, I guess, since we have a common culture of sorts, and specific activities to practice, but not necessarily.",
  "id" : 294525542659653633,
  "in_reply_to_status_id" : 294524658190004224,
  "created_at" : "2013-01-24 19:22:16 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 7, 19 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294452547740119041",
  "geo" : { },
  "id_str" : "294521947004481536",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja @angelaharms Count me in on that conference.  I'd like to help myself and others be more sensitive and supportive.",
  "id" : 294521947004481536,
  "in_reply_to_status_id" : 294452547740119041,
  "created_at" : "2013-01-24 19:07:58 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294473046205538305",
  "geo" : { },
  "id_str" : "294520538058080256",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja In Ruby 1.9+ it's 2 chars as well (not counting the parentheses):    -&gt;    \u2026and Ruby is not even primarily a functional language.",
  "id" : 294520538058080256,
  "in_reply_to_status_id" : 294473046205538305,
  "created_at" : "2013-01-24 19:02:22 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan McGeary",
      "screen_name" : "rmm5t",
      "indices" : [ 0, 6 ],
      "id_str" : "11645552",
      "id" : 11645552
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "busyconf",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "doingitright",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294484512635760641",
  "in_reply_to_user_id" : 11645552,
  "text" : "@rmm5t I love that #busyconf gives you a single page, clear, printable receipt, great for bookkeeping. #doingitright",
  "id" : 294484512635760641,
  "created_at" : "2013-01-24 16:39:13 +0000",
  "in_reply_to_screen_name" : "rmm5t",
  "in_reply_to_user_id_str" : "11645552",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "indices" : [ 0, 6 ],
      "id_str" : "14375110",
      "id" : 14375110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294181640853389312",
  "geo" : { },
  "id_str" : "294233027888963585",
  "in_reply_to_user_id" : 14375110,
  "text" : "@fogus Are you aware of multi entry clipboards, e.g. Jumpcut for Mac and glipper\/klipper for Linux? Would they work for you?",
  "id" : 294233027888963585,
  "in_reply_to_status_id" : 294181640853389312,
  "created_at" : "2013-01-23 23:59:55 +0000",
  "in_reply_to_screen_name" : "fogus",
  "in_reply_to_user_id_str" : "14375110",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Ruby Conf",
      "screen_name" : "BigRubyConf",
      "indices" : [ 0, 12 ],
      "id_str" : "882257671",
      "id" : 882257671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "294129665256353792",
  "geo" : { },
  "id_str" : "294232299858452480",
  "in_reply_to_user_id" : 882257671,
  "text" : "@BigRubyConf Could you DM me an email address or other means by which I can privately ask you a registration question?",
  "id" : 294232299858452480,
  "in_reply_to_status_id" : 294129665256353792,
  "created_at" : "2013-01-23 23:57:01 +0000",
  "in_reply_to_screen_name" : "BigRubyConf",
  "in_reply_to_user_id_str" : "882257671",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MacKeeper",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 120 ],
      "url" : "https:\/\/t.co\/onoCLjwJ",
      "expanded_url" : "https:\/\/discussions.apple.com\/thread\/4276731?start=0&tstart=0",
      "display_url" : "discussions.apple.com\/thread\/4276731\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "294177649671168000",
  "text" : "Thought maybe I should finally respond to the #MacKeeper ads and download it, but then found this: https:\/\/t.co\/onoCLjwJ. Anyone like it?",
  "id" : 294177649671168000,
  "created_at" : "2013-01-23 20:19:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Clewell",
      "screen_name" : "bobclewell",
      "indices" : [ 3, 14 ],
      "id_str" : "16598490",
      "id" : 16598490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "294136583408467969",
  "text" : "RT @bobclewell: I don't think I ever pasted formatted text and thought, \"Ah yes. Nice. I'm so glad that text maintained its formatting.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "294134018155372544",
    "text" : "I don't think I ever pasted formatted text and thought, \"Ah yes. Nice. I'm so glad that text maintained its formatting.\"",
    "id" : 294134018155372544,
    "created_at" : "2013-01-23 17:26:29 +0000",
    "user" : {
      "name" : "Bob Clewell",
      "screen_name" : "bobclewell",
      "protected" : false,
      "id_str" : "16598490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723488618443096066\/K1jzRYW1_normal.jpg",
      "id" : 16598490,
      "verified" : false
    }
  },
  "id" : 294136583408467969,
  "created_at" : "2013-01-23 17:36:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293814434227449856",
  "text" : "There are a multitude of definitions of \"legacy code\" in use, many of which have nothing to do with the meaning of the word \"legacy\".",
  "id" : 293814434227449856,
  "created_at" : "2013-01-22 20:16:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 10, 17 ],
      "id_str" : "3948061",
      "id" : 3948061
    }, {
      "name" : "ashe dryden",
      "screen_name" : "ashedryden",
      "indices" : [ 18, 29 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293572577589346304",
  "geo" : { },
  "id_str" : "293575827398987776",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @elight @ashedryden Oh, hell even *I* can take stuff apart.  It's putting it back together that's hard. ;)",
  "id" : 293575827398987776,
  "in_reply_to_status_id" : 293572577589346304,
  "created_at" : "2013-01-22 04:28:26 +0000",
  "in_reply_to_screen_name" : "_zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Julian",
      "screen_name" : "jonathanjulian",
      "indices" : [ 3, 18 ],
      "id_str" : "14846101",
      "id" : 14846101
    }, {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 19, 30 ],
      "id_str" : "520859958",
      "id" : 520859958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "293574944787415041",
  "text" : "RT @jonathanjulian @cupakromer You can unpack the k\/v: \u007B a:'a', b:'b' \u007D.inject(\u007B\u007D) \u007B |memo,(k,v)| memo[k] = v.capitalize; memo \u007D",
  "id" : 293574944787415041,
  "created_at" : "2013-01-22 04:24:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/BONMI51l",
      "expanded_url" : "http:\/\/www.cdc.gov\/flu\/about\/qa\/disease.htm",
      "display_url" : "cdc.gov\/flu\/about\/qa\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "293517151078318080",
  "text" : "US Centers for Disease Control Seasonal Influenza Q&amp;A page is at http:\/\/t.co\/BONMI51l. Be careful out there!",
  "id" : 293517151078318080,
  "created_at" : "2013-01-22 00:35:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "293492555394478080",
  "geo" : { },
  "id_str" : "293516595525980160",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler YW. I've given away lots of stuff w\/them. BTW, congrats on the Berlin gig. You're an adventurer and explorer. I admire that.",
  "id" : 293516595525980160,
  "in_reply_to_status_id" : 293492555394478080,
  "created_at" : "2013-01-22 00:33:04 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freecycle",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Zt4ehlrC",
      "expanded_url" : "http:\/\/groups.freecycle.org\/freecycledc",
      "display_url" : "groups.freecycle.org\/freecycledc"
    } ]
  },
  "in_reply_to_status_id_str" : "293402926351802373",
  "geo" : { },
  "id_str" : "293469140335882240",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler It's more work, but you can offer stuff to individuals by posting offer messages. They pick up. http:\/\/t.co\/Zt4ehlrC #freecycle",
  "id" : 293469140335882240,
  "in_reply_to_status_id" : 293402926351802373,
  "created_at" : "2013-01-21 21:24:30 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 105 ],
      "url" : "https:\/\/t.co\/viOt3HJB",
      "expanded_url" : "https:\/\/github.com\/rails\/rails\/blob\/master\/railties\/railties.gemspec",
      "display_url" : "github.com\/rails\/rails\/bl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "292758851344793601",
  "text" : "Why is railties specifying a version 3.4 of RDoc that was superseded in Jan. 2010? (https:\/\/t.co\/viOt3HJB) It's messing w\/my json dep.",
  "id" : 292758851344793601,
  "created_at" : "2013-01-19 22:22:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292734928100147200",
  "text" : "Five Guys in Herndon, VA closed permanently, maybe because they were plagued with a chemical stench from the adjacent nail salon.",
  "id" : 292734928100147200,
  "created_at" : "2013-01-19 20:47:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "staples",
      "indices" : [ 64, 72 ]
    }, {
      "text" : "sheesh",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "292679401836003328",
  "text" : "Why does it take 7-10 days to process an unsubscribe request at #staples &amp; others?  Do they snail mail it for manual data entry? #sheesh",
  "id" : 292679401836003328,
  "created_at" : "2013-01-19 17:06:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neal Ford",
      "screen_name" : "neal4d",
      "indices" : [ 69, 76 ],
      "id_str" : "12733362",
      "id" : 12733362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/6ivmsx0W",
      "expanded_url" : "http:\/\/www.ibm.com\/developerworks\/views\/java\/libraryview.jsp?search_by=functional+thinking",
      "display_url" : "ibm.com\/developerworks\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "291932405009362945",
  "text" : "Wow, *lots* of FP articles by Neal Ford at http:\/\/t.co\/6ivmsx0W:  RT @neal4d published installment 19 of my Functional Thinking series\u2026",
  "id" : 291932405009362945,
  "created_at" : "2013-01-17 15:38:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Ammons",
      "screen_name" : "RyanAmmons",
      "indices" : [ 0, 11 ],
      "id_str" : "378389754",
      "id" : 378389754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291771025685876736",
  "geo" : { },
  "id_str" : "291778339121790976",
  "in_reply_to_user_id" : 378389754,
  "text" : "@RyanAmmons Thanks, and sorry about that.  I'm your follower now. ;)",
  "id" : 291778339121790976,
  "in_reply_to_status_id" : 291771025685876736,
  "created_at" : "2013-01-17 05:25:51 +0000",
  "in_reply_to_screen_name" : "RyanAmmons",
  "in_reply_to_user_id_str" : "378389754",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "psa",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291692209961586689",
  "text" : "#psa: Please be very sparing in cologne use. Many people are hypersensitive and\/or allergic. For more info, google \"perfume allergy\".",
  "id" : 291692209961586689,
  "created_at" : "2013-01-16 23:43:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "applying_the_analytical_mind_to_everyday_life",
      "indices" : [ 71, 117 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291585842735091713",
  "geo" : { },
  "id_str" : "291640370968797186",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler My micro-time-saving life hack is to shave with 2 razors.  #applying_the_analytical_mind_to_everyday_life",
  "id" : 291640370968797186,
  "in_reply_to_status_id" : 291585842735091713,
  "created_at" : "2013-01-16 20:17:37 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291558685237473282",
  "geo" : { },
  "id_str" : "291638266023788544",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Understood. I use Bitbucket for free private repos and Github for free public ones.",
  "id" : 291638266023788544,
  "in_reply_to_status_id" : 291558685237473282,
  "created_at" : "2013-01-16 20:09:15 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Thomas",
      "screen_name" : "pragdave",
      "indices" : [ 86, 95 ],
      "id_str" : "6186692",
      "id" : 6186692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291604423258550272",
  "text" : "Doing loads of LinkedIn endorsements for the first time. Favorite: \"Does Dave Thomas (@pragdave) know about Ruby?\"  Heh\u2026I think so. ;)",
  "id" : 291604423258550272,
  "created_at" : "2013-01-16 17:54:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291323995515650048",
  "geo" : { },
  "id_str" : "291380122165071872",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Would a free private Bitbucket repo work, or do you really want others to see it? (Is it really for you to access from anywhere?)",
  "id" : 291380122165071872,
  "in_reply_to_status_id" : 291323995515650048,
  "created_at" : "2013-01-16 03:03:29 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "291308962450653187",
  "text" : "Do I understand correctly that the serious Java flaws of late refer to Java only in the browser, and not to Java based servers?",
  "id" : 291308962450653187,
  "created_at" : "2013-01-15 22:20:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hilary Mason",
      "screen_name" : "hmason",
      "indices" : [ 0, 7 ],
      "id_str" : "765548",
      "id" : 765548
    }, {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 8, 19 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "291292547337314304",
  "geo" : { },
  "id_str" : "291305316782596096",
  "in_reply_to_user_id" : 765548,
  "text" : "@hmason @chadfowler Funny thing is they can be somewhat related -- e.g. a personal ad mentioning \"self-defecating humor\" - a neg. extreme.",
  "id" : 291305316782596096,
  "in_reply_to_status_id" : 291292547337314304,
  "created_at" : "2013-01-15 22:06:14 +0000",
  "in_reply_to_screen_name" : "hmason",
  "in_reply_to_user_id_str" : "765548",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 49, 63 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "retroruby",
      "indices" : [ 80, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/RpKu8Ib5",
      "expanded_url" : "http:\/\/conf.arlingtonruby.org\/",
      "display_url" : "conf.arlingtonruby.org"
    } ]
  },
  "geo" : { },
  "id_str" : "291304308274782208",
  "text" : "Great open space conference in Arlington, VA. RT @arlingtonruby A month to till #retroruby! http:\/\/t.co\/RpKu8Ib5 ping us if you need a code.",
  "id" : 291304308274782208,
  "created_at" : "2013-01-15 22:02:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290936339434713088",
  "text" : "\u2026and, no, I'm not related to him. ;)",
  "id" : 290936339434713088,
  "created_at" : "2013-01-14 21:40:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290936219175620608",
  "text" : "Enjoying the Tony Bennett \"channel\" on Pandora Radio...",
  "id" : 290936219175620608,
  "created_at" : "2013-01-14 21:39:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 77, 88 ],
      "id_str" : "14284130",
      "id" : 14284130
    }, {
      "name" : "nathenharvey",
      "screen_name" : "nathenharvey",
      "indices" : [ 107, 120 ],
      "id_str" : "15926485",
      "id" : 15926485
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290935869802688512",
  "text" : "Belated congrats to Engine Yard Innovators Awards recipients (and nice guys) @hiro_asari (Open Source) and @nathenharvey (DevOps) &amp; others.",
  "id" : 290935869802688512,
  "created_at" : "2013-01-14 21:38:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 0, 10 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/sbIH8nc8",
      "expanded_url" : "http:\/\/brandonhays.com\/blog\/2012\/08\/20\/depression-digging-out-and-pursuing-happiness\/",
      "display_url" : "brandonhays.com\/blog\/2012\/08\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "290467775292510209",
  "in_reply_to_user_id" : 59341538,
  "text" : "@tehviking's (Brandon Hays') courageous post about depression and what has helped him: http:\/\/t.co\/sbIH8nc8.",
  "id" : 290467775292510209,
  "created_at" : "2013-01-13 14:38:08 +0000",
  "in_reply_to_screen_name" : "tehviking",
  "in_reply_to_user_id_str" : "59341538",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/pYuKdSZh",
      "expanded_url" : "http:\/\/gfx.io\/",
      "display_url" : "gfx.io"
    } ]
  },
  "in_reply_to_status_id_str" : "290280043643535361",
  "geo" : { },
  "id_str" : "290460852686028800",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann If a MacBook Pro, could it be an app is draining battery by forcing use of the discrete video adapter (see http:\/\/t.co\/pYuKdSZh)?",
  "id" : 290460852686028800,
  "in_reply_to_status_id" : 290280043643535361,
  "created_at" : "2013-01-13 14:10:38 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "290219386105643009",
  "text" : "On a late day ride, over the brown wooded trail, racing the sun home.",
  "id" : 290219386105643009,
  "created_at" : "2013-01-12 22:11:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Schofield",
      "screen_name" : "jackschofield",
      "indices" : [ 3, 17 ],
      "id_str" : "18058741",
      "id" : 18058741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/rrDPfrWH",
      "expanded_url" : "http:\/\/bit.ly\/WXwO87",
      "display_url" : "bit.ly\/WXwO87"
    } ]
  },
  "geo" : { },
  "id_str" : "289827020903424000",
  "text" : "RT @jackschofield I want the world to scroll this way, says Richard Wallis at Magic Scroll http:\/\/t.co\/rrDPfrWH - nice web page reading tool",
  "id" : 289827020903424000,
  "created_at" : "2013-01-11 20:12:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Hunt",
      "screen_name" : "PragmaticAndy",
      "indices" : [ 0, 14 ],
      "id_str" : "18194778",
      "id" : 18194778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/9gIM0kzl",
      "expanded_url" : "http:\/\/moneydance.com\/",
      "display_url" : "moneydance.com"
    } ]
  },
  "in_reply_to_status_id_str" : "289765169326878720",
  "geo" : { },
  "id_str" : "289767213089583104",
  "in_reply_to_user_id" : 18194778,
  "text" : "@PragmaticAndy http:\/\/t.co\/9gIM0kzl is simple and runs on Linux, Mac OS, and Windows. Maybe better for smaller orgs though, I don't know.",
  "id" : 289767213089583104,
  "in_reply_to_status_id" : 289765169326878720,
  "created_at" : "2013-01-11 16:14:21 +0000",
  "in_reply_to_screen_name" : "PragmaticAndy",
  "in_reply_to_user_id_str" : "18194778",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/dgOQudVW",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/01\/09\/using-oracle-in-jruby-and-rails\/",
      "display_url" : "bbs-software.com\/blog\/2013\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "289757226661474304",
  "text" : "Posted a blog article, \"Using Oracle in JRuby with Rails and Sequel\",at http:\/\/t.co\/dgOQudVW.  Comments\/corrections\/discussion welcome.",
  "id" : 289757226661474304,
  "created_at" : "2013-01-11 15:34:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 0, 11 ],
      "id_str" : "520859958",
      "id" : 520859958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289751465701040128",
  "in_reply_to_user_id" : 520859958,
  "text" : "@cupakromer To me, the biggest issue is why is it forbidden to use \"self.\" to call a private method.  Sounds like a language bug\/oversight.",
  "id" : 289751465701040128,
  "created_at" : "2013-01-11 15:11:47 +0000",
  "in_reply_to_screen_name" : "cupakromer",
  "in_reply_to_user_id_str" : "520859958",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fluepidemic",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289741666867376128",
  "text" : "People, if you're coughing or sneezing, please do everyone else a favor and stay home. Flu can be serious.  #fluepidemic",
  "id" : 289741666867376128,
  "created_at" : "2013-01-11 14:32:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289084926459015168",
  "text" : "My female former coworker, a wonderful 48 year old marathon running constant purveyor of cheer, died of flu last week. Get your flu shots!",
  "id" : 289084926459015168,
  "created_at" : "2013-01-09 19:03:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davidlohr Bueso",
      "screen_name" : "davidlohr",
      "indices" : [ 3, 13 ],
      "id_str" : "255559775",
      "id" : 255559775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "289046520878202880",
  "text" : "RT @davidlohr: A programmer had a problem. He thought to himself, \"I know, I'll solve it with threads!\". has Now problems. two he",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "288786300067270656",
    "text" : "A programmer had a problem. He thought to himself, \"I know, I'll solve it with threads!\". has Now problems. two he",
    "id" : 288786300067270656,
    "created_at" : "2013-01-08 23:16:33 +0000",
    "user" : {
      "name" : "Davidlohr Bueso",
      "screen_name" : "davidlohr",
      "protected" : false,
      "id_str" : "255559775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666496898228862980\/gECwKRfo_normal.jpg",
      "id" : 255559775,
      "verified" : false
    }
  },
  "id" : 289046520878202880,
  "created_at" : "2013-01-09 16:30:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "287450544472211456",
  "geo" : { },
  "id_str" : "287450894474285056",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Booted from Linux CD, followed the instructions to install the tool (effectively, in memory), and ran it.  Almost effortless.",
  "id" : 287450894474285056,
  "in_reply_to_status_id" : 287450544472211456,
  "created_at" : "2013-01-05 06:50:08 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/ZBXAPynZ",
      "expanded_url" : "https:\/\/help.ubuntu.com\/community\/Boot-Repair#A2nd_option_:_install_Boot-Repair_in_Ubuntu",
      "display_url" : "help.ubuntu.com\/community\/Boot\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "287450544472211456",
  "text" : "Amazing\u2026simple repair of Win 8 install overwriting grub so that Ubuntu-based Linux (Mint) partition was unbootable -- https:\/\/t.co\/ZBXAPynZ",
  "id" : 287450544472211456,
  "created_at" : "2013-01-05 06:48:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/KsFFFIYx",
      "expanded_url" : "http:\/\/www.eendusa.com\/ewaste.php",
      "display_url" : "eendusa.com\/ewaste.php"
    } ]
  },
  "geo" : { },
  "id_str" : "287260945984659456",
  "text" : "Interesting explanations of toxic materials in computer equipment -- best to recycle: http:\/\/t.co\/KsFFFIYx",
  "id" : 287260945984659456,
  "created_at" : "2013-01-04 18:15:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jared Richardson",
      "screen_name" : "jaredrichardson",
      "indices" : [ 3, 19 ],
      "id_str" : "10790362",
      "id" : 10790362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/6uE6pOl2",
      "expanded_url" : "http:\/\/www.regexper.com\/",
      "display_url" : "regexper.com"
    } ]
  },
  "geo" : { },
  "id_str" : "286886402208174081",
  "text" : "RT @jaredrichardson A visual reg ex tool. Sweet. http:\/\/t.co\/6uE6pOl2  Try w\/email regex: \\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]\u007B2,4\u007D\\b",
  "id" : 286886402208174081,
  "created_at" : "2013-01-03 17:27:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "286639832581672960",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien I now have a Rails app running on JRuby and talking to an Oracle DB (on Amazon RDS). Might post a blog article about it.",
  "id" : 286639832581672960,
  "created_at" : "2013-01-03 01:07:16 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "286507060760289280",
  "geo" : { },
  "id_str" : "286547058075238400",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Do you mean, why wasn't String::scan implemented as an iterator for lazy loading, for dealing with very large strings?",
  "id" : 286547058075238400,
  "in_reply_to_status_id" : 286507060760289280,
  "created_at" : "2013-01-02 18:58:37 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/E3Jvoulu",
      "expanded_url" : "http:\/\/www.mcsweeneys.net\/articles\/in-which-i-fix-my-girlfriends-grandparents-wifi-and-am-hailed-as-a-conquering-hero",
      "display_url" : "mcsweeneys.net\/articles\/in-wh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "286159374697779200",
  "text" : "\"In Which I Fix My Girlfriend\u2019s Grandparents\u2019 WiFi and Am Hailed as a Conquering Hero.\" by By Mike Lacher - http:\/\/t.co\/E3Jvoulu",
  "id" : 286159374697779200,
  "created_at" : "2013-01-01 17:18:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]