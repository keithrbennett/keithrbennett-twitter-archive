Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "340243588615135232",
  "text" : "Anyone looking for an outstanding home cleaning team in Northern Virginia, feel free to contact me.  They've done great work for me.",
  "id" : 340243588615135232,
  "created_at" : "2013-05-30 23:09:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "self2013",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339969584490749952",
  "text" : "Looking for someone to share driving from Reston,VA to Charlotte,NC &amp; back next week for #self2013, an excellent and free Linux conference.",
  "id" : 339969584490749952,
  "created_at" : "2013-05-30 05:00:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 0, 10 ],
      "id_str" : "15067554",
      "id" : 15067554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337676134974115840",
  "in_reply_to_user_id" : 15067554,
  "text" : "@sandimetz I'd like to ask you about volume discount on POODR for a large org.  How can I contact you (twitter too limited)?",
  "id" : 337676134974115840,
  "created_at" : "2013-05-23 21:07:18 +0000",
  "in_reply_to_screen_name" : "sandimetz",
  "in_reply_to_user_id_str" : "15067554",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 3, 10 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335535437953245184",
  "text" : "RT @elight: I\u2019m still looking for Ruby\/Rails freelance work starting 5\/21: rescue, green field, remote pairing\/mentoring. Ping me.\nPlease R\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "335443425224687616",
    "text" : "I\u2019m still looking for Ruby\/Rails freelance work starting 5\/21: rescue, green field, remote pairing\/mentoring. Ping me.\nPlease RT.",
    "id" : 335443425224687616,
    "created_at" : "2013-05-17 17:15:19 +0000",
    "user" : {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "protected" : false,
      "id_str" : "3948061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796362488195465216\/6TqhdY9L_normal.jpg",
      "id" : 3948061,
      "verified" : false
    }
  },
  "id" : 335535437953245184,
  "created_at" : "2013-05-17 23:20:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/uFrjqGEXDJ",
      "expanded_url" : "http:\/\/new.livestream.com\/internetsociety\/reinventing-the-internet",
      "display_url" : "new.livestream.com\/internetsociet\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "334461015364358145",
  "text" : "Attended a great talk by Vint Cerf last night\u2026it's online at http:\/\/t.co\/uFrjqGEXDJ.",
  "id" : 334461015364358145,
  "created_at" : "2013-05-15 00:11:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/sgiLMDyk3S",
      "expanded_url" : "http:\/\/blog.boastr.net\/?page_id=79",
      "display_url" : "blog.boastr.net\/?page_id=79"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/eRWyg3OoO2",
      "expanded_url" : "http:\/\/lifehacker.com\/5489410\/secondbar-puts-a-menu-bar-on-all-your-macs-monitors",
      "display_url" : "lifehacker.com\/5489410\/second\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "329662045089824768",
  "text" : "SecondBar puts the Mac system menu on all connected displays. Woohoo!!! Check out http:\/\/t.co\/sgiLMDyk3S and http:\/\/t.co\/eRWyg3OoO2",
  "id" : 329662045089824768,
  "created_at" : "2013-05-01 18:22:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]