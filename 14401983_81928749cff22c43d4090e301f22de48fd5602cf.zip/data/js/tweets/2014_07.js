Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/493924593552199680\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Re4zk4Tuik",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtrFzBaCQAA5iX8.jpg",
      "id_str" : "493924589492125696",
      "id" : 493924589492125696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtrFzBaCQAA5iX8.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/Re4zk4Tuik"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "493924593552199680",
  "text" : "Reston Metro Station UI fail. Which way is the Kiss &amp; Ride? Another sign pointed in 2 wrong directions. http:\/\/t.co\/Re4zk4Tuik",
  "id" : 493924593552199680,
  "created_at" : "2014-07-29 01:02:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 73, 80 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AP5gZWEi7a",
      "expanded_url" : "http:\/\/functionalconf.com\/",
      "display_url" : "functionalconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "493041256675561473",
  "text" : "Delighted to be presenting \"Functional Programming in Ruby\" at the 3-day @fuconf in Bangalore this October. http:\/\/t.co\/AP5gZWEi7a",
  "id" : 493041256675561473,
  "created_at" : "2014-07-26 14:32:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492826712636665856",
  "geo" : { },
  "id_str" : "492830408216559616",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann I don't understand, are you saying that inject is better in this case? (If so, why?) Or that inject\/reduce are often used for this?",
  "id" : 492830408216559616,
  "in_reply_to_status_id" : 492826712636665856,
  "created_at" : "2014-07-26 00:35:00 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492731219428532226",
  "geo" : { },
  "id_str" : "492826044861136900",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann Also, in these situations, I prefer each_with_object to inject.  No need to explicitly return the hash.",
  "id" : 492826044861136900,
  "in_reply_to_status_id" : 492731219428532226,
  "created_at" : "2014-07-26 00:17:40 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Lesches",
      "screen_name" : "davidlesches",
      "indices" : [ 3, 16 ],
      "id_str" : "854309916",
      "id" : 854309916
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/davidlesches\/status\/492810986437345281\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/n60Egg01bG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtbQ-s-CIAAmx1k.jpg",
      "id_str" : "492810984885460992",
      "id" : 492810984885460992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtbQ-s-CIAAmx1k.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/n60Egg01bG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "492825222157189120",
  "text" : "RT @davidlesches: OK this is the greatest photo I have ever seen in my life, bar none. http:\/\/t.co\/n60Egg01bG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/davidlesches\/status\/492810986437345281\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/n60Egg01bG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtbQ-s-CIAAmx1k.jpg",
        "id_str" : "492810984885460992",
        "id" : 492810984885460992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtbQ-s-CIAAmx1k.jpg",
        "sizes" : [ {
          "h" : 486,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/n60Egg01bG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "492810986437345281",
    "text" : "OK this is the greatest photo I have ever seen in my life, bar none. http:\/\/t.co\/n60Egg01bG",
    "id" : 492810986437345281,
    "created_at" : "2014-07-25 23:17:49 +0000",
    "user" : {
      "name" : "David Lesches",
      "screen_name" : "davidlesches",
      "protected" : false,
      "id_str" : "854309916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671906178926907392\/5s3sorMo_normal.jpg",
      "id" : 854309916,
      "verified" : false
    }
  },
  "id" : 492825222157189120,
  "created_at" : "2014-07-26 00:14:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492731219428532226",
  "geo" : { },
  "id_str" : "492770786550513664",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann That's nice for just that computation, but I want add'l features accessible via methods, e.g. total count, % totals, to_s w\/name.",
  "id" : 492770786550513664,
  "in_reply_to_status_id" : 492731219428532226,
  "created_at" : "2014-07-25 20:38:05 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "492731219428532226",
  "geo" : { },
  "id_str" : "492768565036998656",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann data.inject(\u007B\u007D) \u007B |h, e| h[e] = (h[e] ? h[e] + 1 : 1); h; \u007D  # even shorter ;)",
  "id" : 492768565036998656,
  "in_reply_to_status_id" : 492731219428532226,
  "created_at" : "2014-07-25 20:29:15 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/aQYvhcEXdT",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/numeric\/multi_counter.rb",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "492724099870126080",
  "text" : "Need frequency counts or %'s of total for an enumerable of values? Check out MultiCounter in the trick_bag gem: https:\/\/t.co\/aQYvhcEXdT",
  "id" : 492724099870126080,
  "created_at" : "2014-07-25 17:32:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte Ashlock",
      "screen_name" : "CrazyIdealist",
      "indices" : [ 3, 17 ],
      "id_str" : "151996874",
      "id" : 151996874
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CrazyIdealist\/status\/491679983195000832\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/bAnZv9Uo4Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLMVtECUAAszBj.png",
      "id_str" : "491679982582648832",
      "id" : 491679982582648832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLMVtECUAAszBj.png",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 774
      } ],
      "display_url" : "pic.twitter.com\/bAnZv9Uo4Q"
    } ],
    "hashtags" : [ {
      "text" : "BKAuthorDay",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491701581641809921",
  "text" : "RT @CrazyIdealist: What if all Earth was your home? What if we treated all humanity like neighbors? #BKAuthorDay http:\/\/t.co\/bAnZv9Uo4Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CrazyIdealist\/status\/491679983195000832\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/bAnZv9Uo4Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtLMVtECUAAszBj.png",
        "id_str" : "491679982582648832",
        "id" : 491679982582648832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtLMVtECUAAszBj.png",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 774
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 774
        } ],
        "display_url" : "pic.twitter.com\/bAnZv9Uo4Q"
      } ],
      "hashtags" : [ {
        "text" : "BKAuthorDay",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "491679983195000832",
    "text" : "What if all Earth was your home? What if we treated all humanity like neighbors? #BKAuthorDay http:\/\/t.co\/bAnZv9Uo4Q",
    "id" : 491679983195000832,
    "created_at" : "2014-07-22 20:23:37 +0000",
    "user" : {
      "name" : "Charlotte Ashlock",
      "screen_name" : "CrazyIdealist",
      "protected" : false,
      "id_str" : "151996874",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713475068727144448\/E95cUW7A_normal.jpg",
      "id" : 151996874,
      "verified" : false
    }
  },
  "id" : 491701581641809921,
  "created_at" : "2014-07-22 21:49:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "becamp_info",
      "screen_name" : "becamp_info",
      "indices" : [ 93, 105 ],
      "id_str" : "2168804167",
      "id" : 2168804167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491213573129912320",
  "text" : "Just signed up for this year's Becamp, Charlottesville's fun &amp; informative unconference. @becamp_info",
  "id" : 491213573129912320,
  "created_at" : "2014-07-21 13:30:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 3, 8 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 10, 24 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490876889968304131",
  "text" : "RT @_ZPH: @keithrbennett and you can do \"open -a Safari sample.html\" also. Works for most apps.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "490562645301665792",
    "geo" : { },
    "id_str" : "490581439163805696",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett and you can do \"open -a Safari sample.html\" also. Works for most apps.",
    "id" : 490581439163805696,
    "in_reply_to_status_id" : 490562645301665792,
    "created_at" : "2014-07-19 19:38:24 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "protected" : true,
      "id_str" : "737649619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684598254613364738\/foWoE2fB_normal.jpg",
      "id" : 737649619,
      "verified" : false
    }
  },
  "id" : 490876889968304131,
  "created_at" : "2014-07-20 15:12:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490562645301665792",
  "text" : "On the Mac, sometimes it's easier to start an app on the command line with 'open -a', e.g. 'open -a Keynote'.",
  "id" : 490562645301665792,
  "created_at" : "2014-07-19 18:23:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete Carapetyan",
      "screen_name" : "appwritercom",
      "indices" : [ 3, 16 ],
      "id_str" : "177138943",
      "id" : 177138943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nfjs",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "490537515678306304",
  "text" : "RT @appwritercom: Any time a human does a simple repetive task for a computer, all the computers get together late at night and laugh #nfjs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neal Ford",
        "screen_name" : "neal4d",
        "indices" : [ 122, 129 ],
        "id_str" : "12733362",
        "id" : 12733362
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nfjs",
        "indices" : [ 116, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "490256341206716416",
    "text" : "Any time a human does a simple repetive task for a computer, all the computers get together late at night and laugh #nfjs @neal4d Neal Ford",
    "id" : 490256341206716416,
    "created_at" : "2014-07-18 22:06:34 +0000",
    "user" : {
      "name" : "Pete Carapetyan",
      "screen_name" : "appwritercom",
      "protected" : false,
      "id_str" : "177138943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751056300469989378\/toWFwvpT_normal.jpg",
      "id" : 177138943,
      "verified" : false
    }
  },
  "id" : 490537515678306304,
  "created_at" : "2014-07-19 16:43:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jason \u03BBewis",
      "screen_name" : "canweriotnow",
      "indices" : [ 3, 16 ],
      "id_str" : "158606135",
      "id" : 158606135
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "489168726017597441",
  "text" : "RT @canweriotnow: A Lisp koan:\n\n(",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 39.3273946, -76.6006189 ]
    },
    "id_str" : "489142255312457728",
    "text" : "A Lisp koan:\n\n(",
    "id" : 489142255312457728,
    "created_at" : "2014-07-15 20:19:36 +0000",
    "user" : {
      "name" : "jason \u03BBewis",
      "screen_name" : "canweriotnow",
      "protected" : false,
      "id_str" : "158606135",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664700435446525952\/wB7Ku3qB_normal.png",
      "id" : 158606135,
      "verified" : false
    }
  },
  "id" : 489168726017597441,
  "created_at" : "2014-07-15 22:04:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby for Good",
      "screen_name" : "RubyforGood",
      "indices" : [ 30, 42 ],
      "id_str" : "2474347308",
      "id" : 2474347308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488762570443350016",
  "text" : "Super excited about attending @rubyforgood, an informal, collaborative Ruby hackathon.  There's still room to attend and to sponsor.",
  "id" : 488762570443350016,
  "created_at" : "2014-07-14 19:10:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488513530061393920",
  "text" : "Who knew? To format selected text in Keynote as super\/subscripts, use Ctrl-Command + or -, respectively.",
  "id" : 488513530061393920,
  "created_at" : "2014-07-14 02:41:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488093354773999617",
  "text" : "...and why does Twitter think I'm in San Bernardino, CA?  The Amtrak train I'm on isn't *that* fast.",
  "id" : 488093354773999617,
  "created_at" : "2014-07-12 22:51:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian Bitbucket",
      "screen_name" : "Bitbucket",
      "indices" : [ 1, 11 ],
      "id_str" : "174379786",
      "id" : 174379786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "488093040213368832",
  "text" : ".@bitbucket, Why is the lambda keyword in Ruby colored in gray, the same color as comments?",
  "id" : 488093040213368832,
  "created_at" : "2014-07-12 22:50:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "indices" : [ 0, 9 ],
      "id_str" : "20173708",
      "id" : 20173708
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "radicalhelpfulness",
      "indices" : [ 47, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1MU742rP68",
      "expanded_url" : "http:\/\/www.techhumans.com\/2014\/06\/26\/kaizen-and-radical-helpfulness\/",
      "display_url" : "techhumans.com\/2014\/06\/26\/kai\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "487406073452560385",
  "geo" : { },
  "id_str" : "487595331446505473",
  "in_reply_to_user_id" : 20173708,
  "text" : "@adomokos Very cool. You are a practitioner of #radicalhelpfulness. I blogged about this at http:\/\/t.co\/1MU742rP68.",
  "id" : 487595331446505473,
  "in_reply_to_status_id" : 487406073452560385,
  "created_at" : "2014-07-11 13:52:40 +0000",
  "in_reply_to_screen_name" : "adomokos",
  "in_reply_to_user_id_str" : "20173708",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 0, 8 ],
      "id_str" : "38699900",
      "id" : 38699900
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 9, 18 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487457670064922626",
  "geo" : { },
  "id_str" : "487461529768308736",
  "in_reply_to_user_id" : 38699900,
  "text" : "@geeksam @sarahmei I'd like to discuss this further, but Twitter is a lousy medium for nontrivial technical conversations. Thanks though.",
  "id" : 487461529768308736,
  "in_reply_to_status_id" : 487457670064922626,
  "created_at" : "2014-07-11 05:00:59 +0000",
  "in_reply_to_screen_name" : "geeksam",
  "in_reply_to_user_id_str" : "38699900",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 0, 8 ],
      "id_str" : "38699900",
      "id" : 38699900
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 97, 106 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487294944109813760",
  "geo" : { },
  "id_str" : "487451292931870720",
  "in_reply_to_user_id" : 38699900,
  "text" : "@geeksam extend self has the same effect as module_function but does not duplicate the methods?  @sarahmei",
  "id" : 487451292931870720,
  "in_reply_to_status_id" : 487294944109813760,
  "created_at" : "2014-07-11 04:20:19 +0000",
  "in_reply_to_screen_name" : "geeksam",
  "in_reply_to_user_id_str" : "38699900",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 0, 8 ],
      "id_str" : "38699900",
      "id" : 38699900
    }, {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 9, 18 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "487084124771856386",
  "geo" : { },
  "id_str" : "487251535194107904",
  "in_reply_to_user_id" : 38699900,
  "text" : "@geeksam @sarahmei In general when defining a module I use module_function and almost always refer to its methods with the module name.",
  "id" : 487251535194107904,
  "in_reply_to_status_id" : 487084124771856386,
  "created_at" : "2014-07-10 15:06:33 +0000",
  "in_reply_to_screen_name" : "geeksam",
  "in_reply_to_user_id_str" : "38699900",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 0, 9 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483089356941320192",
  "geo" : { },
  "id_str" : "486949453606031360",
  "in_reply_to_user_id" : 10411062,
  "text" : "@nashjain I use Thunderbird as a mail client for the Mac.  Also frustrating in some ways.  Every year or two I switch back and forth. ;)",
  "id" : 486949453606031360,
  "in_reply_to_status_id" : 483089356941320192,
  "created_at" : "2014-07-09 19:06:11 +0000",
  "in_reply_to_screen_name" : "nashjain",
  "in_reply_to_user_id_str" : "10411062",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry D'Antonio",
      "screen_name" : "jerrydantonio",
      "indices" : [ 0, 14 ],
      "id_str" : "14144174",
      "id" : 14144174
    }, {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 15, 20 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "486853742919421952",
  "geo" : { },
  "id_str" : "486876666934095872",
  "in_reply_to_user_id" : 14144174,
  "text" : "@jerrydantonio @_ZPH Matz has said that Ruby has and will rely on OS processes for its concurrency. No plan to remove GIL.",
  "id" : 486876666934095872,
  "in_reply_to_status_id" : 486853742919421952,
  "created_at" : "2014-07-09 14:16:57 +0000",
  "in_reply_to_screen_name" : "jerrydantonio",
  "in_reply_to_user_id_str" : "14144174",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ezpassva",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486873956704452608",
  "text" : "#ezpassva Your anti-phishing email gave bad info -- phishing emails *usually* have legitimate addresses in headers, but have bad links.",
  "id" : 486873956704452608,
  "created_at" : "2014-07-09 14:06:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MetLife",
      "screen_name" : "MetLife",
      "indices" : [ 28, 36 ],
      "id_str" : "78661839",
      "id" : 78661839
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486556279792754688",
  "text" : "Was there a good reason for @metlife to require a number in a *user id!*, or was it just to ensure that I forget it?",
  "id" : 486556279792754688,
  "created_at" : "2014-07-08 17:03:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/qZw9NAIt75",
      "expanded_url" : "http:\/\/drexel.edu\/dontwashyourchicken\/",
      "display_url" : "drexel.edu\/dontwashyourch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "486508261441429505",
  "text" : "Wow, this surprised me. Don't wash your chicken before cooking it: http:\/\/t.co\/qZw9NAIt75",
  "id" : 486508261441429505,
  "created_at" : "2014-07-08 13:53:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 6, 17 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CT9fAnkLou",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/coffeesmith-chantilly-2",
      "display_url" : "yelp.com\/biz\/coffeesmit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "486135482645241856",
  "geo" : { },
  "id_str" : "486158757190053888",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH @seanmarcia If you can go further west to Chantilly, I recommend Coffeesmith (http:\/\/t.co\/CT9fAnkLou). Across from Lotte Plaza.",
  "id" : 486158757190053888,
  "in_reply_to_status_id" : 486135482645241856,
  "created_at" : "2014-07-07 14:44:14 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/485901838152368128\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qJxniWqiG9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Br5FI0kCAAA4dZd.jpg",
      "id_str" : "485901827653632000",
      "id" : 485901827653632000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Br5FI0kCAAA4dZd.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qJxniWqiG9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "485901838152368128",
  "text" : "Fireworks yesterday (yes, July 5th) courtesy of Manor Country Club (I'm guessing), Silver Spring, Maryland, USA. http:\/\/t.co\/qJxniWqiG9",
  "id" : 485901838152368128,
  "created_at" : "2014-07-06 21:43:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danny Yee",
      "screen_name" : "DannyYee",
      "indices" : [ 3, 12 ],
      "id_str" : "38058775",
      "id" : 38058775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/N91WMPdxMR",
      "expanded_url" : "http:\/\/tinyurl.com\/lhscfba",
      "display_url" : "tinyurl.com\/lhscfba"
    } ]
  },
  "geo" : { },
  "id_str" : "484700611276177408",
  "text" : "RT @DannyYee: JCPenney allowed to sacrifice employees to Cthulhu  http:\/\/t.co\/N91WMPdxMR (MoonmontChronicle)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/danny.oz.au\/blog\/\" rel=\"nofollow\"\u003EDanny Yee\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/N91WMPdxMR",
        "expanded_url" : "http:\/\/tinyurl.com\/lhscfba",
        "display_url" : "tinyurl.com\/lhscfba"
      } ]
    },
    "geo" : { },
    "id_str" : "484596321912123392",
    "text" : "JCPenney allowed to sacrifice employees to Cthulhu  http:\/\/t.co\/N91WMPdxMR (MoonmontChronicle)",
    "id" : 484596321912123392,
    "created_at" : "2014-07-03 07:15:41 +0000",
    "user" : {
      "name" : "Danny Yee",
      "screen_name" : "DannyYee",
      "protected" : false,
      "id_str" : "38058775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/402689494\/favicon_normal.png",
      "id" : 38058775,
      "verified" : false
    }
  },
  "id" : 484700611276177408,
  "created_at" : "2014-07-03 14:10:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/484679993847717888\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/PRVx02ulqX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Brnt4udIcAEFc8X.png",
      "id_str" : "484679993717714945",
      "id" : 484679993717714945,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brnt4udIcAEFc8X.png",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 688
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 688
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PRVx02ulqX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484699689871097856",
  "text" : "RT @SciencePorn: http:\/\/t.co\/PRVx02ulqX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/484679993847717888\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/PRVx02ulqX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Brnt4udIcAEFc8X.png",
        "id_str" : "484679993717714945",
        "id" : 484679993717714945,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Brnt4udIcAEFc8X.png",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 688
        }, {
          "h" : 316,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 688
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/PRVx02ulqX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "484679993847717888",
    "text" : "http:\/\/t.co\/PRVx02ulqX",
    "id" : 484679993847717888,
    "created_at" : "2014-07-03 12:48:10 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 484699689871097856,
  "created_at" : "2014-07-03 14:06:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linuxjournal",
      "screen_name" : "linuxjournal",
      "indices" : [ 0, 13 ],
      "id_str" : "9799222",
      "id" : 9799222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "484335770871013376",
  "in_reply_to_user_id" : 9799222,
  "text" : "@linuxjournal Naming is important. How about sortable issue filenames with dates, e.g. \"linux-journal-2014-07.pdf\" instead of \"dlj243.pdf\"?",
  "id" : 484335770871013376,
  "created_at" : "2014-07-02 14:00:20 +0000",
  "in_reply_to_screen_name" : "linuxjournal",
  "in_reply_to_user_id_str" : "9799222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]