Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528377163113062401",
  "geo" : { },
  "id_str" : "528382878560698368",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH Thanks, that worked! Reason for + rather than * was so only files needing change would be written. Not huge deal but nice-to-have.",
  "id" : 528382878560698368,
  "in_reply_to_status_id" : 528377163113062401,
  "created_at" : "2014-11-01 03:07:49 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/XGOEj20Fkl",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/e064341c9cdd5b4cf3dc",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "528372155923595265",
  "geo" : { },
  "id_str" : "528373611476680704",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH I appreciate it. I wanted to use OSX but used Linux when it didn't work. Could you check this out?: https:\/\/t.co\/XGOEj20Fkl",
  "id" : 528373611476680704,
  "in_reply_to_status_id" : 528372155923595265,
  "created_at" : "2014-11-01 02:31:00 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528360760997871616",
  "geo" : { },
  "id_str" : "528371208362807296",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH Good point.  I had to run my command on a Linux host. I don't understand the empty quotes though; in addition to the original command?",
  "id" : 528371208362807296,
  "in_reply_to_status_id" : 528360760997871616,
  "created_at" : "2014-11-01 02:21:27 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HrbbTk6aTh",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/10711051\/trailing-whitespace-elimination-script-for-multiple-files",
      "display_url" : "stackoverflow.com\/questions\/1071\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528356643592216577",
  "text" : "Remove Ruby code trailing whitespace: find . -type f -name '*.rb' -exec sed --in-place 's\/[[:space:]]\\+$\/\/' \u007B\u007D \\+ # http:\/\/t.co\/HrbbTk6aTh",
  "id" : 528356643592216577,
  "created_at" : "2014-11-01 01:23:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "indices" : [ 3, 13 ],
      "id_str" : "15243796",
      "id" : 15243796
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528215251444322306",
  "text" : "RT @ngauthier: Why do engineers confuse Halloween and Christmas? Because Oct 31 = Dec 25.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "528181590321823745",
    "text" : "Why do engineers confuse Halloween and Christmas? Because Oct 31 = Dec 25.",
    "id" : 528181590321823745,
    "created_at" : "2014-10-31 13:47:58 +0000",
    "user" : {
      "name" : "Nick Gauthier",
      "screen_name" : "ngauthier",
      "protected" : false,
      "id_str" : "15243796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725487771603759105\/ywrvw_pl_normal.jpg",
      "id" : 15243796,
      "verified" : false
    }
  },
  "id" : 528215251444322306,
  "created_at" : "2014-10-31 16:01:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mushtaq Ahmed \u0646",
      "screen_name" : "mushtaqA",
      "indices" : [ 0, 9 ],
      "id_str" : "15560520",
      "id" : 15560520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "528032904022990848",
  "geo" : { },
  "id_str" : "528110621573664768",
  "in_reply_to_user_id" : 15560520,
  "text" : "@mushtaqA Ok, thanks.",
  "id" : 528110621573664768,
  "in_reply_to_status_id" : 528032904022990848,
  "created_at" : "2014-10-31 09:05:58 +0000",
  "in_reply_to_screen_name" : "mushtaqA",
  "in_reply_to_user_id_str" : "15560520",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Charbon",
      "screen_name" : "JulienCharbon",
      "indices" : [ 98, 112 ],
      "id_str" : "1391742494",
      "id" : 1391742494
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/KPRZ1eAfvU",
      "expanded_url" : "http:\/\/git-scm.com\/book\/en\/v2",
      "display_url" : "git-scm.com\/book\/en\/v2"
    } ]
  },
  "geo" : { },
  "id_str" : "527818623784861696",
  "text" : "Scott Chacon's free Pro Git book version 2 is out!  http:\/\/t.co\/KPRZ1eAfvU Thanks for telling me, @JulienCharbon.",
  "id" : 527818623784861696,
  "created_at" : "2014-10-30 13:45:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mushtaq Ahmed \u0646",
      "screen_name" : "mushtaqA",
      "indices" : [ 0, 9 ],
      "id_str" : "15560520",
      "id" : 15560520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/14xsSuye7m",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!topic\/fnprog\/WwoXZpXApyA",
      "display_url" : "groups.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527808397899747328",
  "in_reply_to_user_id" : 15560520,
  "text" : "@mushtaqA Any chance you could take a look at a Scala issue of my coworker?  (I attended FunctionalConf.) It's at https:\/\/t.co\/14xsSuye7m.",
  "id" : 527808397899747328,
  "created_at" : "2014-10-30 13:05:02 +0000",
  "in_reply_to_screen_name" : "mushtaqA",
  "in_reply_to_user_id_str" : "15560520",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527556409618362370",
  "text" : "If you're in a plane and someone's coughing a lot, *demand* that the flight attendants put a mask on them. I should have.",
  "id" : 527556409618362370,
  "created_at" : "2014-10-29 20:23:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527556226037854208",
  "text" : "Got the flu, probably from the guy coughing in my 14 hour ride (12 hr flight + 2 hrs on the ground for mechanical difficulties Tokyo -&gt; DC.",
  "id" : 527556226037854208,
  "created_at" : "2014-10-29 20:23:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/LbMdU5lfi2",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/whitespace-test-1\/compare\/whitespace-and-text-change?diff=unified&expand=1&w=1",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "527106949968846848",
  "text" : "To see Github comparision that ignores whitespace, add param \"w=1\" to URL (\"?w=1\" or \"&amp;w=1\" dep. on position) , e.g. https:\/\/t.co\/LbMdU5lfi2",
  "id" : 527106949968846848,
  "created_at" : "2014-10-28 14:37:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jukka Zitting",
      "screen_name" : "jukkaz",
      "indices" : [ 0, 7 ],
      "id_str" : "10183542",
      "id" : 10183542
    }, {
      "name" : "Google",
      "screen_name" : "Google",
      "indices" : [ 8, 15 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526796916139761665",
  "geo" : { },
  "id_str" : "526853134292111361",
  "in_reply_to_user_id" : 10183542,
  "text" : "@jukkaz @google Congrats, Jukka. They're lucky to have you.",
  "id" : 526853134292111361,
  "in_reply_to_status_id" : 526796916139761665,
  "created_at" : "2014-10-27 21:49:10 +0000",
  "in_reply_to_screen_name" : "jukkaz",
  "in_reply_to_user_id_str" : "10183542",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Magicalmaths.org",
      "screen_name" : "magicalmaths",
      "indices" : [ 3, 16 ],
      "id_str" : "150588511",
      "id" : 150588511
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/magicalmaths\/status\/526093493178220544\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7ubrbSirJ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B00PPRNIcAApTzn.jpg",
      "id_str" : "526093486463152128",
      "id" : 526093486463152128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B00PPRNIcAApTzn.jpg",
      "sizes" : [ {
        "h" : 591,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 591,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/7ubrbSirJ2"
    } ],
    "hashtags" : [ {
      "text" : "funnymathjokes",
      "indices" : [ 68, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/6yzS3fgDjL",
      "expanded_url" : "http:\/\/www.magicalmaths.org",
      "display_url" : "magicalmaths.org"
    } ]
  },
  "geo" : { },
  "id_str" : "526795980562530305",
  "text" : "RT @magicalmaths: Now this is definitely one for the mathematicians #funnymathjokes\n\nhttp:\/\/t.co\/6yzS3fgDjL http:\/\/t.co\/7ubrbSirJ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/magicalmaths\/status\/526093493178220544\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/7ubrbSirJ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B00PPRNIcAApTzn.jpg",
        "id_str" : "526093486463152128",
        "id" : 526093486463152128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B00PPRNIcAApTzn.jpg",
        "sizes" : [ {
          "h" : 591,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 591,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/7ubrbSirJ2"
      } ],
      "hashtags" : [ {
        "text" : "funnymathjokes",
        "indices" : [ 50, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/6yzS3fgDjL",
        "expanded_url" : "http:\/\/www.magicalmaths.org",
        "display_url" : "magicalmaths.org"
      } ]
    },
    "geo" : { },
    "id_str" : "526093493178220544",
    "text" : "Now this is definitely one for the mathematicians #funnymathjokes\n\nhttp:\/\/t.co\/6yzS3fgDjL http:\/\/t.co\/7ubrbSirJ2",
    "id" : 526093493178220544,
    "created_at" : "2014-10-25 19:30:37 +0000",
    "user" : {
      "name" : "Magicalmaths.org",
      "screen_name" : "magicalmaths",
      "protected" : false,
      "id_str" : "150588511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442256838352859136\/SNv3b0Tl_normal.png",
      "id" : 150588511,
      "verified" : false
    }
  },
  "id" : 526795980562530305,
  "created_at" : "2014-10-27 18:02:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Miller",
      "screen_name" : "heathercmiller",
      "indices" : [ 3, 18 ],
      "id_str" : "22874473",
      "id" : 22874473
    }, {
      "name" : "Prisoner 849",
      "screen_name" : "jamesiry",
      "indices" : [ 60, 69 ],
      "id_str" : "19044984",
      "id" : 19044984
    }, {
      "name" : "Databricks",
      "screen_name" : "databricks",
      "indices" : [ 70, 81 ],
      "id_str" : "1562518867",
      "id" : 1562518867
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/heathercmiller\/status\/526770571728531456\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/sqiNaYGDQy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B093CwRCQAEwnD4.jpg",
      "id_str" : "526770570625433601",
      "id" : 526770570625433601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B093CwRCQAEwnD4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sqiNaYGDQy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526794333841027074",
  "text" : "RT @heathercmiller: Carved something scary into pumpkin cc\/ @jamesiry @databricks (office jackolantern) http:\/\/t.co\/sqiNaYGDQy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Prisoner 849",
        "screen_name" : "jamesiry",
        "indices" : [ 40, 49 ],
        "id_str" : "19044984",
        "id" : 19044984
      }, {
        "name" : "Databricks",
        "screen_name" : "databricks",
        "indices" : [ 50, 61 ],
        "id_str" : "1562518867",
        "id" : 1562518867
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/heathercmiller\/status\/526770571728531456\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/sqiNaYGDQy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B093CwRCQAEwnD4.jpg",
        "id_str" : "526770570625433601",
        "id" : 526770570625433601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B093CwRCQAEwnD4.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/sqiNaYGDQy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "526770571728531456",
    "text" : "Carved something scary into pumpkin cc\/ @jamesiry @databricks (office jackolantern) http:\/\/t.co\/sqiNaYGDQy",
    "id" : 526770571728531456,
    "created_at" : "2014-10-27 16:21:05 +0000",
    "user" : {
      "name" : "Heather Miller",
      "screen_name" : "heathercmiller",
      "protected" : false,
      "id_str" : "22874473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1452273043\/profilepic_normal.jpg",
      "id" : 22874473,
      "verified" : false
    }
  },
  "id" : 526794333841027074,
  "created_at" : "2014-10-27 17:55:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 1, 15 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526539838317940736",
  "text" : ".@yukihiro_matz I am at Narita Airport in Japan, birthplace of my favorite language, Ruby, coding in it.  Thank you, Matz.",
  "id" : 526539838317940736,
  "created_at" : "2014-10-27 01:04:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reza Primardiansyah",
      "screen_name" : "rprimar",
      "indices" : [ 0, 8 ],
      "id_str" : "136221945",
      "id" : 136221945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526466683783766017",
  "geo" : { },
  "id_str" : "526528643086811136",
  "in_reply_to_user_id" : 136221945,
  "text" : "@rprimar Thank you, Reza.",
  "id" : 526528643086811136,
  "in_reply_to_status_id" : 526466683783766017,
  "created_at" : "2014-10-27 00:19:45 +0000",
  "in_reply_to_screen_name" : "rprimar",
  "in_reply_to_user_id_str" : "136221945",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/526524416121790464\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/9HXFgiDBqp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B06XKM7CcAA4oPv.jpg",
      "id_str" : "526524407972261888",
      "id" : 526524407972261888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B06XKM7CcAA4oPv.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/9HXFgiDBqp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526524416121790464",
  "text" : "Ramen for breakfast at Tokyo's Narita Airport. http:\/\/t.co\/9HXFgiDBqp",
  "id" : 526524416121790464,
  "created_at" : "2014-10-27 00:02:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "justin",
      "screen_name" : "justinxreese",
      "indices" : [ 0, 13 ],
      "id_str" : "14255877",
      "id" : 14255877
    }, {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 37, 41 ],
      "id_str" : "8076192",
      "id" : 8076192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "526393000835162112",
  "geo" : { },
  "id_str" : "526409733284958208",
  "in_reply_to_user_id" : 14255877,
  "text" : "@justinxreese I did not notice that! @shr why no 3's in floor numbers?",
  "id" : 526409733284958208,
  "in_reply_to_status_id" : 526393000835162112,
  "created_at" : "2014-10-26 16:27:15 +0000",
  "in_reply_to_screen_name" : "justinxreese",
  "in_reply_to_user_id_str" : "14255877",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/526388643036803075\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JRTaThqmeO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B04bpy2CUAAATBa.jpg",
      "id_str" : "526388611285929984",
      "id" : 526388611285929984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B04bpy2CUAAATBa.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JRTaThqmeO"
    } ],
    "hashtags" : [ {
      "text" : "uifail",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526388643036803075",
  "text" : "#uifail in Bangkok elevator. Why does floor #22 appear to be under the basement? http:\/\/t.co\/JRTaThqmeO",
  "id" : 526388643036803075,
  "created_at" : "2014-10-26 15:03:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/526388051556040704\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/NtGHxmB2TD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B04bHnNCMAEmvPn.jpg",
      "id_str" : "526388024045613057",
      "id" : 526388024045613057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B04bHnNCMAEmvPn.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/NtGHxmB2TD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526388051556040704",
  "text" : "In Bangkok airport. Will fly about 5.5 hours to Tokyo then about 12 hours to Washington. http:\/\/t.co\/NtGHxmB2TD",
  "id" : 526388051556040704,
  "created_at" : "2014-10-26 15:01:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/526387637880242176\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7sLH3k1U7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B04aufQCAAA6Weq.jpg",
      "id_str" : "526387592413970432",
      "id" : 526387592413970432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B04aufQCAAA6Weq.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/7sLH3k1U7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "526387637880242176",
  "text" : "Had my suitcase wrapped for the 1st time cuz the latch was bent and the bag was opened a crack. Hope it's recyclable. http:\/\/t.co\/7sLH3k1U7k",
  "id" : 526387637880242176,
  "created_at" : "2014-10-26 14:59:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vladimir Rybas",
      "screen_name" : "vrybas",
      "indices" : [ 1, 8 ],
      "id_str" : "62731307",
      "id" : 62731307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bangkokrb",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/I0HH8Fjzof",
      "expanded_url" : "https:\/\/gist.github.com\/vrybas\/207f75f806e0c82708ec",
      "display_url" : "gist.github.com\/vrybas\/207f75f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "526339172915630080",
  "text" : ".@vrybas (from #bangkokrb) would like some feedback re: functional vs. OO approaches in his JavaScript code at https:\/\/t.co\/I0HH8Fjzof.",
  "id" : 526339172915630080,
  "created_at" : "2014-10-26 11:46:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b_architect",
      "screen_name" : "b_architect",
      "indices" : [ 0, 12 ],
      "id_str" : "22439512",
      "id" : 22439512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bangkokrb",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525935691813765121",
  "geo" : { },
  "id_str" : "526020237104533504",
  "in_reply_to_user_id" : 22439512,
  "text" : "@b_architect Great to meet you too at #bangkokrb.  Even though the presentations were in Thai I greatly enjoyed the \"hallway track\".",
  "id" : 526020237104533504,
  "in_reply_to_status_id" : 525935691813765121,
  "created_at" : "2014-10-25 14:39:32 +0000",
  "in_reply_to_screen_name" : "b_architect",
  "in_reply_to_user_id_str" : "22439512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "b_architect",
      "screen_name" : "b_architect",
      "indices" : [ 1, 13 ],
      "id_str" : "22439512",
      "id" : 22439512
    }, {
      "name" : "Nutty",
      "screen_name" : "GREANUT",
      "indices" : [ 14, 22 ],
      "id_str" : "93163245",
      "id" : 93163245
    }, {
      "name" : "\u0E1B\u0E34\u0E15\u0E34 \u0E21\u0E32\u0E19\u0E35 \u0E44\u0E21\u0E48\u0E21\u0E32\u0E19\u0E30",
      "screen_name" : "NocommenZ",
      "indices" : [ 23, 33 ],
      "id_str" : "16009123",
      "id" : 16009123
    }, {
      "name" : "\u0E17\u0E35\u0E48\u0E27\u0E48\u0E32\u0E01\u0E32\u0E23\u0E14\u0E19\u0E15\u0E23\u0E35",
      "screen_name" : "zeedmember",
      "indices" : [ 34, 45 ],
      "id_str" : "103810641",
      "id" : 103810641
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525930807580307456\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Lx6mwm3zaa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0x7RMjCIAAzF6H.jpg",
      "id_str" : "525930791851663360",
      "id" : 525930791851663360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0x7RMjCIAAzF6H.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Lx6mwm3zaa"
    } ],
    "hashtags" : [ {
      "text" : "bangkokrb",
      "indices" : [ 56, 66 ]
    }, {
      "text" : "rubyfriends",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525930807580307456",
  "text" : ".@b_architect @GREANUT @nocommenz @zeedmember and me at #bangkokrb #rubyfriends. http:\/\/t.co\/Lx6mwm3zaa",
  "id" : 525930807580307456,
  "created_at" : "2014-10-25 08:44:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bangkok.rb",
      "screen_name" : "bangkokrb",
      "indices" : [ 39, 49 ],
      "id_str" : "2855348406",
      "id" : 2855348406
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525899217366036480\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/Qvo5iw4g9l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0xeie_CIAE-OP0.jpg",
      "id_str" : "525899203021512705",
      "id" : 525899203021512705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0xeie_CIAE-OP0.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/Qvo5iw4g9l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525899217366036480",
  "text" : "At the Bangkok Ruby user group meetup. @bangkokrb http:\/\/t.co\/Qvo5iw4g9l",
  "id" : 525899217366036480,
  "created_at" : "2014-10-25 06:38:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525887646703165441\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Mbc24S7Z3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0xUAe3CAAEs-QD.jpg",
      "id_str" : "525887623756120065",
      "id" : 525887623756120065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0xUAe3CAAEs-QD.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Mbc24S7Z3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525887646703165441",
  "text" : "Pomegranate juice vendor on a Bangkok boulevard. http:\/\/t.co\/Mbc24S7Z3J",
  "id" : 525887646703165441,
  "created_at" : "2014-10-25 05:52:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "indices" : [ 1, 14 ],
      "id_str" : "18061835",
      "id" : 18061835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/9gk2WD64TH",
      "expanded_url" : "http:\/\/www.thinkful.com\/learn\/ruby-on-rails-tutorial",
      "display_url" : "thinkful.com\/learn\/ruby-on-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "525860486244360192",
  "text" : ".@aidanfeldman's mini-guide to Ruby on Rails was just published at http:\/\/t.co\/9gk2WD64TH.",
  "id" : 525860486244360192,
  "created_at" : "2014-10-25 04:04:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Tannenbaum \u30C4",
      "screen_name" : "TheRoyalTbomb",
      "indices" : [ 0, 14 ],
      "id_str" : "281405328",
      "id" : 281405328
    }, {
      "name" : "Audrey Troutt",
      "screen_name" : "auditty",
      "indices" : [ 15, 23 ],
      "id_str" : "17523680",
      "id" : 17523680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "525640030405275648",
  "geo" : { },
  "id_str" : "525690141830959104",
  "in_reply_to_user_id" : 281405328,
  "text" : "@TheRoyalTbomb @auditty you were just retweeted by one. ;)",
  "id" : 525690141830959104,
  "in_reply_to_status_id" : 525640030405275648,
  "created_at" : "2014-10-24 16:47:51 +0000",
  "in_reply_to_screen_name" : "TheRoyalTbomb",
  "in_reply_to_user_id_str" : "281405328",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 1, 11 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525611645780127744",
  "text" : ".@starbucks Found out after buying capuccino that you are the only coffee shop I've encountered in Thailand that charges for wifi. Annoyed.",
  "id" : 525611645780127744,
  "created_at" : "2014-10-24 11:35:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525239307586387970\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/gsLB2FvOzh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0oGV6FCEAAi_tT.jpg",
      "id_str" : "525239279979466752",
      "id" : 525239279979466752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0oGV6FCEAAi_tT.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/gsLB2FvOzh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525239307586387970",
  "text" : "Played ball with this boy for a few minutes (with his Mom's permission!) in Chiang Mai city park. http:\/\/t.co\/gsLB2FvOzh",
  "id" : 525239307586387970,
  "created_at" : "2014-10-23 10:56:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525238946909798400\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/3vy58lVliR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0oGAOfCIAEyma1.jpg",
      "id_str" : "525238907500109825",
      "id" : 525238907500109825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0oGAOfCIAEyma1.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/3vy58lVliR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525238946909798400",
  "text" : "Sleeping cat hogs the bench in Chiang Mai's city park. http:\/\/t.co\/3vy58lVliR",
  "id" : 525238946909798400,
  "created_at" : "2014-10-23 10:54:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/525238762192642048\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/12hRgdR8aY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0oF1tHCUAAvxEj.jpg",
      "id_str" : "525238726742396928",
      "id" : 525238726742396928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0oF1tHCUAAvxEj.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/12hRgdR8aY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "525238762192642048",
  "text" : "Chang Mai's stunning city park, made beautiful by skillful design blend of nature and local architecture. http:\/\/t.co\/12hRgdR8aY",
  "id" : 525238762192642048,
  "created_at" : "2014-10-23 10:54:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524995749419819008\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/2huzePQJmp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0koy1oCUAA48fN.jpg",
      "id_str" : "524995685418946560",
      "id" : 524995685418946560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0koy1oCUAA48fN.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2huzePQJmp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524995749419819008",
  "text" : "Great Chiang Mai Beercamp meeting tonight. In this photo: Andy, Aimmee, Alvin, Rob, Scott, Ken, and myself. http:\/\/t.co\/2huzePQJmp",
  "id" : 524995749419819008,
  "created_at" : "2014-10-22 18:48:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524994063137636352\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/7hcl3AkAez",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0knSlaCEAERk-d.jpg",
      "id_str" : "524994031797800961",
      "id" : 524994031797800961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0knSlaCEAERk-d.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/7hcl3AkAez"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524994063137636352",
  "text" : "Sababa comes through again with another great meal. Ezra, the owner, dances outside to have fun &amp; attract customers. http:\/\/t.co\/7hcl3AkAez",
  "id" : 524994063137636352,
  "created_at" : "2014-10-22 18:41:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524993156916314112\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/VT23m3fRBy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0kmeOGCEAAGOnA.jpg",
      "id_str" : "524993132186701824",
      "id" : 524993132186701824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0kmeOGCEAAGOnA.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/VT23m3fRBy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524993156916314112",
  "text" : "Don't let Su's diminutive size fool you. She's strong and skillful and has been helping me. 2 hr massage: $14 http:\/\/t.co\/VT23m3fRBy",
  "id" : 524993156916314112,
  "created_at" : "2014-10-22 18:38:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524865191582789633\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/F5t0Qxq1oU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0iyFlPCMAABhBM.jpg",
      "id_str" : "524865165552922624",
      "id" : 524865165552922624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0iyFlPCMAABhBM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/F5t0Qxq1oU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524865191582789633",
  "text" : "Sticky rice desserts. http:\/\/t.co\/F5t0Qxq1oU",
  "id" : 524865191582789633,
  "created_at" : "2014-10-22 10:09:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524864939211509761\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/dCfwnIMgc9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ix3SFCIAAlbYF.jpg",
      "id_str" : "524864919892533248",
      "id" : 524864919892533248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ix3SFCIAAlbYF.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/dCfwnIMgc9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524864939211509761",
  "text" : "Making fresh sugar cane juice.  Unlike sugar crystals, the juice has flavor. http:\/\/t.co\/dCfwnIMgc9",
  "id" : 524864939211509761,
  "created_at" : "2014-10-22 10:08:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524820287963938816\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/fBetmWe197",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0iJROHCEAI12qJ.jpg",
      "id_str" : "524820285527035906",
      "id" : 524820285527035906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0iJROHCEAI12qJ.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/fBetmWe197"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524820287963938816",
  "text" : "Prayer room in Chiang Mai airport mall. Nice gesture acknowledging this country's Muslims. http:\/\/t.co\/fBetmWe197",
  "id" : 524820287963938816,
  "created_at" : "2014-10-22 07:11:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/mIHq8SpGvs",
      "expanded_url" : "http:\/\/www.boundingoveroursteps.com\/shirts-of-red-and-yellow-political-situation-thailand\/",
      "display_url" : "boundingoveroursteps.com\/shirts-of-red-\u2026"
    }, {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/MKGhxr1Yhe",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/2013%E2%80%9314_Thai_political_crisis",
      "display_url" : "en.wikipedia.org\/wiki\/2013%E2%8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "524587699181998080",
  "geo" : { },
  "id_str" : "524596279477678081",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Simple version: http:\/\/t.co\/mIHq8SpGvs. Detailed version: http:\/\/t.co\/MKGhxr1Yhe. Yellow: pro-establishment, Red: pro-Thaksin.",
  "id" : 524596279477678081,
  "in_reply_to_status_id" : 524587699181998080,
  "created_at" : "2014-10-21 16:21:14 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524593838518595584\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qXKdq8qGq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0e7S0TCYAAwp1W.jpg",
      "id_str" : "524593813562482688",
      "id" : 524593813562482688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0e7S0TCYAAwp1W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qXKdq8qGq6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524593838518595584",
  "text" : "Here is the other side of coworking Camp in Chiang Mai. It's getting late and the crowd has thinned. http:\/\/t.co\/qXKdq8qGq6",
  "id" : 524593838518595584,
  "created_at" : "2014-10-21 16:11:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Buckbee",
      "screen_name" : "mbuckbee",
      "indices" : [ 0, 9 ],
      "id_str" : "5972282",
      "id" : 5972282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "524569340063277056",
  "geo" : { },
  "id_str" : "524578453362724865",
  "in_reply_to_user_id" : 5972282,
  "text" : "@mbuckbee Yeah, I know. The tree house is prime territory.  The students got there before me. :)",
  "id" : 524578453362724865,
  "in_reply_to_status_id" : 524569340063277056,
  "created_at" : "2014-10-21 15:10:24 +0000",
  "in_reply_to_screen_name" : "mbuckbee",
  "in_reply_to_user_id_str" : "5972282",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524569145858199552\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UhSSJPcQov",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0ek1iACQAAVCnM.jpg",
      "id_str" : "524569121178927104",
      "id" : 524569121178927104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0ek1iACQAAVCnM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/UhSSJPcQov"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524569145858199552",
  "text" : "Coworking at Chiang Mai's Camp.  Open 24 hours. That's a \"tree house\" on the right. Theres much more space not shown. http:\/\/t.co\/UhSSJPcQov",
  "id" : 524569145858199552,
  "created_at" : "2014-10-21 14:33:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524481815197655040",
  "text" : "Went all over town today in my bright yellow shirt. I forgot that that's a political statement in Thailand. Went home and changed my shirt.",
  "id" : 524481815197655040,
  "created_at" : "2014-10-21 08:46:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524481229844791297\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dRsFmRinie",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0dU4mlCUAAB_pL.jpg",
      "id_str" : "524481213017247744",
      "id" : 524481213017247744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0dU4mlCUAAB_pL.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/dRsFmRinie"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524481229844791297",
  "text" : "I love the supermarket food courts and counters in Thailand. Food is fresh, clean, fast, and cheap. Pad Thai: $1.25. http:\/\/t.co\/dRsFmRinie",
  "id" : 524481229844791297,
  "created_at" : "2014-10-21 08:44:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    }, {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 9, 20 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523921153027768320",
  "geo" : { },
  "id_str" : "524139182835261440",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl @seanmarcia If you've never been here before, I'd (obviously) recommend it.  I'd be happy to be of assistance.",
  "id" : 524139182835261440,
  "in_reply_to_status_id" : 523921153027768320,
  "created_at" : "2014-10-20 10:04:53 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524117910906617856\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/511Wsk4zuT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0YKdWhCcAAN3tE.jpg",
      "id_str" : "524117906011877376",
      "id" : 524117906011877376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0YKdWhCcAAN3tE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/511Wsk4zuT"
    } ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524117910906617856",
  "text" : "#barcampcm7 before-party on Fri.  Chiang Mai has many in &amp; outdoor coffee\/beer\/food places, great for get togethers. http:\/\/t.co\/511Wsk4zuT",
  "id" : 524117910906617856,
  "created_at" : "2014-10-20 08:40:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524077140950540288\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/HegGoleeul",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0XlXI6CYAA8dTF.jpg",
      "id_str" : "524077117349191680",
      "id" : 524077117349191680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0XlXI6CYAA8dTF.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/HegGoleeul"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524077140950540288",
  "text" : "This is getting to be a daily habit and I'm loving it. Mango and mango with sticky rice. http:\/\/t.co\/HegGoleeul",
  "id" : 524077140950540288,
  "created_at" : "2014-10-20 05:58:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524030740518825985\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/mvVuL1KjyF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0W7Kk6CEAEIlc9.jpg",
      "id_str" : "524030722038697985",
      "id" : 524030722038697985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0W7Kk6CEAEIlc9.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mvVuL1KjyF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524030740518825985",
  "text" : "\"Egg MookMiffin\" at the Butter is Better Diner and Bakery. They bake the muffins and make their own yogurt\/kefir. http:\/\/t.co\/mvVuL1KjyF",
  "id" : 524030740518825985,
  "created_at" : "2014-10-20 02:53:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/524014757045481472\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/h2mHO2bbMJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Wsn1NCcAEfbIj.jpg",
      "id_str" : "524014731955171329",
      "id" : 524014731955171329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Wsn1NCcAEfbIj.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/h2mHO2bbMJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "524014757045481472",
  "text" : "My search for the elusive indigenous Southeast Asian stinky fruit durian ends at...Swensen's! http:\/\/t.co\/h2mHO2bbMJ",
  "id" : 524014757045481472,
  "created_at" : "2014-10-20 01:50:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523867863304511490\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JHQA7s7LYE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Um_fFCEAAvSA4.jpg",
      "id_str" : "523867803774750720",
      "id" : 523867803774750720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Um_fFCEAAvSA4.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/JHQA7s7LYE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523867863304511490",
  "text" : "Generous portion of delicious schnitzel, hummous, and salad at Sababa Israeli restaurant in Chiang Mai. http:\/\/t.co\/JHQA7s7LYE",
  "id" : 523867863304511490,
  "created_at" : "2014-10-19 16:06:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 0, 4 ],
      "id_str" : "8076192",
      "id" : 8076192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "523725025971408896",
  "geo" : { },
  "id_str" : "523763663606276098",
  "in_reply_to_user_id" : 8076192,
  "text" : "@shr Thanks, Simon.  I just registered.",
  "id" : 523763663606276098,
  "in_reply_to_status_id" : 523725025971408896,
  "created_at" : "2014-10-19 09:12:43 +0000",
  "in_reply_to_screen_name" : "shr",
  "in_reply_to_user_id_str" : "8076192",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523686467252387842",
  "text" : "Conf's should follow #barcampcm7's lead re: after parties.  Food and drink too, but in a quiet environment conducive to hrs of conversation.",
  "id" : 523686467252387842,
  "created_at" : "2014-10-19 04:05:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel: Raw Safari",
      "screen_name" : "raw_safari",
      "indices" : [ 55, 66 ],
      "id_str" : "165335630",
      "id" : 165335630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523672993923215360\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/teKG1qtdlK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0R1zqGCQAAmB0B.jpg",
      "id_str" : "523672987015200768",
      "id" : 523672987015200768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0R1zqGCQAAmB0B.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/teKG1qtdlK"
    } ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523672993923215360",
  "text" : "Enjoyed learning about world nomadic travel from Manny @raw_safari at #barcampcm7. http:\/\/t.co\/teKG1qtdlK",
  "id" : 523672993923215360,
  "created_at" : "2014-10-19 03:12:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523672238248042496",
  "text" : "The Clojure expression I mentioned at #barcampcm7: 1st 10 Fibonacci numbers: (take 10 (map first (iterate (fn [[a b]] [b (+ a b)]) [0 1])))",
  "id" : 523672238248042496,
  "created_at" : "2014-10-19 03:09:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 50, 54 ],
      "id_str" : "8076192",
      "id" : 8076192
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523403181909229568\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/cVdzGp9wB1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0OAazzCEAEOhn3.jpg",
      "id_str" : "523403179774316545",
      "id" : 523403179774316545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0OAazzCEAEOhn3.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/cVdzGp9wB1"
    } ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 58, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523403181909229568",
  "text" : "Learning about geek bread making in Thailand from @shr at #barcampcm7. http:\/\/t.co\/cVdzGp9wB1",
  "id" : 523403181909229568,
  "created_at" : "2014-10-18 09:20:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523310541121400832\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/OPAtrE6F65",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0MsJNFCQAA4QeG.jpg",
      "id_str" : "523310518346334208",
      "id" : 523310518346334208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0MsJNFCQAA4QeG.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OPAtrE6F65"
    } ],
    "hashtags" : [ {
      "text" : "barcampchiangmai",
      "indices" : [ 18, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523310541121400832",
  "text" : "Making friends at #barcampchiangmai. http:\/\/t.co\/OPAtrE6F65",
  "id" : 523310541121400832,
  "created_at" : "2014-10-18 03:12:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barcamp Chiang Mai",
      "screen_name" : "barcampcm",
      "indices" : [ 39, 49 ],
      "id_str" : "54895666",
      "id" : 54895666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523303362255548416\/photo\/1",
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/L6C4suglcr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0MloQoCcAACdZq.jpg",
      "id_str" : "523303355293003776",
      "id" : 523303355293003776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0MloQoCcAACdZq.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L6C4suglcr"
    } ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523303362255548416",
  "text" : "BarCamp Chiang Mai begins! #barcampcm7 @barcampcm http:\/\/t.co\/L6C4suglcr",
  "id" : 523303362255548416,
  "created_at" : "2014-10-18 02:43:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523168525305667584\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/sL0SnA8Zxz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0Kq7X_CMAAdOP1.jpg",
      "id_str" : "523168443755802624",
      "id" : 523168443755802624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0Kq7X_CMAAdOP1.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/sL0SnA8Zxz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523168525305667584",
  "text" : "My rented wheels here in Chiang Mai. Must be mindful. Tonight a stray dog walked into my path. http:\/\/t.co\/sL0SnA8Zxz",
  "id" : 523168525305667584,
  "created_at" : "2014-10-17 17:47:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDFC4levels @ \uD83C\uDDEE\uD83C\uDDE9",
      "screen_name" : "levelsio",
      "indices" : [ 3, 12 ],
      "id_str" : "1577241403",
      "id" : 1577241403
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/levelsio\/status\/493671469721739265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/LK0Wm0Yt5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtnflL6CYAA8trD.png",
      "id_str" : "493671464118149120",
      "id" : 493671464118149120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtnflL6CYAA8trD.png",
      "sizes" : [ {
        "h" : 931,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1176,
        "resize" : "fit",
        "w" : 1294
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LK0Wm0Yt5v"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/levelsio\/status\/493671469721739265\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/LK0Wm0Yt5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BtnflL6CcAALF55.png",
      "id_str" : "493671464118153216",
      "id" : 493671464118153216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtnflL6CcAALF55.png",
      "sizes" : [ {
        "h" : 1182,
        "resize" : "fit",
        "w" : 1298
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 932,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LK0Wm0Yt5v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/X9EjpSkZNu",
      "expanded_url" : "http:\/\/NomadList.io",
      "display_url" : "NomadList.io"
    } ]
  },
  "geo" : { },
  "id_str" : "523066829645049856",
  "text" : "RT @levelsio: 10 most expensive and affordable cities to live for remote workers (via http:\/\/t.co\/X9EjpSkZNu) http:\/\/t.co\/LK0Wm0Yt5v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/levelsio\/status\/493671469721739265\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/LK0Wm0Yt5v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtnflL6CYAA8trD.png",
        "id_str" : "493671464118149120",
        "id" : 493671464118149120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtnflL6CYAA8trD.png",
        "sizes" : [ {
          "h" : 931,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 545,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1176,
          "resize" : "fit",
          "w" : 1294
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LK0Wm0Yt5v"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/levelsio\/status\/493671469721739265\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/LK0Wm0Yt5v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BtnflL6CcAALF55.png",
        "id_str" : "493671464118153216",
        "id" : 493671464118153216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BtnflL6CcAALF55.png",
        "sizes" : [ {
          "h" : 1182,
          "resize" : "fit",
          "w" : 1298
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 932,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LK0Wm0Yt5v"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/X9EjpSkZNu",
        "expanded_url" : "http:\/\/NomadList.io",
        "display_url" : "NomadList.io"
      } ]
    },
    "geo" : { },
    "id_str" : "493671469721739265",
    "text" : "10 most expensive and affordable cities to live for remote workers (via http:\/\/t.co\/X9EjpSkZNu) http:\/\/t.co\/LK0Wm0Yt5v",
    "id" : 493671469721739265,
    "created_at" : "2014-07-28 08:17:05 +0000",
    "user" : {
      "name" : "\uD83C\uDFC4levels @ \uD83C\uDDEE\uD83C\uDDE9",
      "screen_name" : "levelsio",
      "protected" : false,
      "id_str" : "1577241403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812059272250953728\/ySIHJUp-_normal.jpg",
      "id" : 1577241403,
      "verified" : true
    }
  },
  "id" : 523066829645049856,
  "created_at" : "2014-10-17 11:03:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barcamp Chiang Mai",
      "screen_name" : "barcampcm",
      "indices" : [ 1, 11 ],
      "id_str" : "54895666",
      "id" : 54895666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampcm7",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/x9RPtUWe1O",
      "expanded_url" : "http:\/\/confengine.com\/functional-conf-2014\/proposal\/388\/functional-programming-in-ruby",
      "display_url" : "confengine.com\/functional-con\u2026"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/MCOjmqnyvX",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas-functional-conf-bangalore-oct-2014",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "523057309358891008",
  "text" : ".@barcampcm Anyone interested in Functional Programming (Lite) in Ruby tomorrow? http:\/\/t.co\/x9RPtUWe1O, https:\/\/t.co\/MCOjmqnyvX #barcampcm7",
  "id" : 523057309358891008,
  "created_at" : "2014-10-17 10:25:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/523056370610753537\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Yu0TXDiagT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0JE-yFCEAASUxO.jpg",
      "id_str" : "523056352113856512",
      "id" : 523056352113856512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0JE-yFCEAASUxO.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/Yu0TXDiagT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523056370610753537",
  "text" : "This green curry chicken burger and I have something in common. We both look better in person than in photos. ;) http:\/\/t.co\/Yu0TXDiagT",
  "id" : 523056370610753537,
  "created_at" : "2014-10-17 10:22:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barcamp Chiang Mai",
      "screen_name" : "barcampcm",
      "indices" : [ 0, 10 ],
      "id_str" : "54895666",
      "id" : 54895666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523027461161103360",
  "in_reply_to_user_id" : 54895666,
  "text" : "@barcampcm I'd like to present Functional Programming in Ruby if there is interest.  Is there anything I need to do before tomorrow?",
  "id" : 523027461161103360,
  "created_at" : "2014-10-17 08:27:18 +0000",
  "in_reply_to_screen_name" : "barcampcm",
  "in_reply_to_user_id_str" : "54895666",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/522998412401078272\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/xa6kVQzJRh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0IQRXFCYAEHDhm.jpg",
      "id_str" : "522998397167362049",
      "id" : 522998397167362049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0IQRXFCYAEHDhm.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/xa6kVQzJRh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522998412401078272",
  "text" : "Brunch in a Chiang Mai food court. Saba fish, rice, and cut ripe mango. http:\/\/t.co\/xa6kVQzJRh",
  "id" : 522998412401078272,
  "created_at" : "2014-10-17 06:31:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/522998187888369664\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/aDJvdR1BEY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0IQEErCAAEoqAP.jpg",
      "id_str" : "522998168888147969",
      "id" : 522998168888147969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0IQEErCAAEoqAP.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/aDJvdR1BEY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522998187888369664",
  "text" : "Arrived in Chiang Mai last night. Interesting gourd for sale near the night market. http:\/\/t.co\/aDJvdR1BEY",
  "id" : 522998187888369664,
  "created_at" : "2014-10-17 06:30:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barcamp Chiang Mai",
      "screen_name" : "barcampcm",
      "indices" : [ 92, 102 ],
      "id_str" : "54895666",
      "id" : 54895666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/522691189703585792\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/kvHf66An76",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B0D4zXmCcAABfSO.jpg",
      "id_str" : "522691118165553152",
      "id" : 522691118165553152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B0D4zXmCcAABfSO.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/kvHf66An76"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522691189703585792",
  "text" : "Pretty garden outside Bangkok airport's food court. Waiting for my flight to Chiang Mai for @barcampcm. http:\/\/t.co\/kvHf66An76",
  "id" : 522691189703585792,
  "created_at" : "2014-10-16 10:11:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/522269760776830976\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/gcplFXvOG9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bz95k9RCIAA--p4.jpg",
      "id_str" : "522269757626523648",
      "id" : 522269757626523648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bz95k9RCIAA--p4.jpg",
      "sizes" : [ {
        "h" : 1151,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gcplFXvOG9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "522269760776830976",
  "text" : "After my massage, I worked on several therapists. They get tight from their work and need it. (I studied massage.) http:\/\/t.co\/gcplFXvOG9",
  "id" : 522269760776830976,
  "created_at" : "2014-10-15 06:16:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 1, 10 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/NHm5V5Cjy2",
      "expanded_url" : "http:\/\/blogs.agilefaqs.com\/2014\/10\/12\/program-committees-expectation-from-a-talk-proposal-when-selecting-it\/",
      "display_url" : "blogs.agilefaqs.com\/2014\/10\/12\/pro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521586371249446914",
  "text" : ".@nashjain's advice to speakers for their proposals based on his experience organizing many conf's over the years: http:\/\/t.co\/NHm5V5Cjy2",
  "id" : 521586371249446914,
  "created_at" : "2014-10-13 09:00:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 1, 10 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 12, 19 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/34dULE2voL",
      "expanded_url" : "https:\/\/groups.google.com\/forum\/#!forum\/fnprog",
      "display_url" : "groups.google.com\/forum\/#!forum\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "521563708137287680",
  "text" : ".@nashjain (@fuconf organizer) has started a Google group for functional programming, open to the public: https:\/\/t.co\/34dULE2voL",
  "id" : 521563708137287680,
  "created_at" : "2014-10-13 07:30:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/521562590376259584\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/gkSe1EZxgm",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bzz2aHSCIAAKl2P.png",
      "id_str" : "521562585359851520",
      "id" : 521562585359851520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bzz2aHSCIAAKl2P.png",
      "sizes" : [ {
        "h" : 414,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/gkSe1EZxgm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "521562590376259584",
  "text" : "My Thailand vacation is off to a great start. http:\/\/t.co\/gkSe1EZxgm",
  "id" : 521562590376259584,
  "created_at" : "2014-10-13 07:26:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Baishampayan Ghose",
      "screen_name" : "ghoseb",
      "indices" : [ 25, 32 ],
      "id_str" : "2098451",
      "id" : 2098451
    }, {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 36, 43 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520842444892409860",
  "text" : "At Clojure workshop with @ghoseb at @fuconf; 1st 10 Fibonacci numbers: (take 10 (map first (iterate (fn [[a b]] [b (+ a b)]) [0 1])))",
  "id" : 520842444892409860,
  "created_at" : "2014-10-11 07:44:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/520725258630733824\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/ekvcyTmEoh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzn82cECUAA_IHd.jpg",
      "id_str" : "520725244114259968",
      "id" : 520725244114259968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzn82cECUAA_IHd.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/ekvcyTmEoh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520725258630733824",
  "text" : "This stuff is amazing. If India exported this to the USA I'd be a loyal customer. http:\/\/t.co\/ekvcyTmEoh",
  "id" : 520725258630733824,
  "created_at" : "2014-10-10 23:59:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "ThoughtWorks",
      "screen_name" : "thoughtworks",
      "indices" : [ 24, 37 ],
      "id_str" : "23009949",
      "id" : 23009949
    }, {
      "name" : "Helpshift",
      "screen_name" : "helpshift",
      "indices" : [ 38, 48 ],
      "id_str" : "425774771",
      "id" : 425774771
    }, {
      "name" : "nilenso",
      "screen_name" : "nilenso",
      "indices" : [ 49, 57 ],
      "id_str" : "1417080733",
      "id" : 1417080733
    }, {
      "name" : "Dyalog",
      "screen_name" : "dyalogapl",
      "indices" : [ 58, 68 ],
      "id_str" : "36050079",
      "id" : 36050079
    }, {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 121, 128 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520636236566786048",
  "text" : "RT @nashjain: Thank you @thoughtworks @helpshift @nilenso @dyalogapl program committee &amp; all the volunteers who made @FuConf a wonderful ex\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThoughtWorks",
        "screen_name" : "thoughtworks",
        "indices" : [ 10, 23 ],
        "id_str" : "23009949",
        "id" : 23009949
      }, {
        "name" : "Helpshift",
        "screen_name" : "helpshift",
        "indices" : [ 24, 34 ],
        "id_str" : "425774771",
        "id" : 425774771
      }, {
        "name" : "nilenso",
        "screen_name" : "nilenso",
        "indices" : [ 35, 43 ],
        "id_str" : "1417080733",
        "id" : 1417080733
      }, {
        "name" : "Dyalog",
        "screen_name" : "dyalogapl",
        "indices" : [ 44, 54 ],
        "id_str" : "36050079",
        "id" : 36050079
      }, {
        "name" : "Functional Conf",
        "screen_name" : "FuConf",
        "indices" : [ 107, 114 ],
        "id_str" : "2347359145",
        "id" : 2347359145
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 139, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520634523915001856",
    "text" : "Thank you @thoughtworks @helpshift @nilenso @dyalogapl program committee &amp; all the volunteers who made @FuConf a wonderful experience. #win",
    "id" : 520634523915001856,
    "created_at" : "2014-10-10 17:58:38 +0000",
    "user" : {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "protected" : false,
      "id_str" : "10411062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775404265976332288\/LOoVpSln_normal.jpg",
      "id" : 10411062,
      "verified" : false
    }
  },
  "id" : 520636236566786048,
  "created_at" : "2014-10-10 18:05:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Estrada",
      "screen_name" : "hugoestr",
      "indices" : [ 0, 9 ],
      "id_str" : "33578369",
      "id" : 33578369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/N35t8b8s5q",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett",
      "display_url" : "speakerdeck.com\/keithrbennett"
    } ]
  },
  "in_reply_to_status_id_str" : "520593052680077312",
  "geo" : { },
  "id_str" : "520596511281786881",
  "in_reply_to_user_id" : 33578369,
  "text" : "@hugoestr Sure.  They're at https:\/\/t.co\/N35t8b8s5q.",
  "id" : 520596511281786881,
  "in_reply_to_status_id" : 520593052680077312,
  "created_at" : "2014-10-10 15:27:35 +0000",
  "in_reply_to_screen_name" : "hugoestr",
  "in_reply_to_user_id_str" : "33578369",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 24, 33 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 100, 107 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "functionalconf",
      "indices" : [ 108, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520557194882719745",
  "text" : "Thank you so very much, @nashjain and friends, for your hard work building such a great conference. @fuconf #functionalconf",
  "id" : 520557194882719745,
  "created_at" : "2014-10-10 12:51:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "functtionalconf",
      "indices" : [ 10, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520555061575831552",
  "text" : "Anyone at #functtionalconf want to get dinner together or do something tonight?",
  "id" : 520555061575831552,
  "created_at" : "2014-10-10 12:42:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Tate",
      "screen_name" : "redrapids",
      "indices" : [ 21, 31 ],
      "id_str" : "61650296",
      "id" : 61650296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "functionalconf",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520455797566738432",
  "text" : "Excellent keynote by @redrapids at #functionalconf about the rise of FP and motivations for, and obstacles to, &amp; history of, s\/w adoption.",
  "id" : 520455797566738432,
  "created_at" : "2014-10-10 06:08:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "indices" : [ 3, 14 ],
      "id_str" : "259725229",
      "id" : 259725229
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ValaAfshar\/status\/506412668040011776\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/u5rcDsKyW7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwcjowPIcAAchuJ.jpg",
      "id_str" : "506412666152579072",
      "id" : 506412666152579072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwcjowPIcAAchuJ.jpg",
      "sizes" : [ {
        "h" : 575,
        "resize" : "fit",
        "w" : 569
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 569
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 569
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u5rcDsKyW7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520454396962803712",
  "text" : "RT @ValaAfshar: Updated Maslow's hierarchy of needs http:\/\/t.co\/u5rcDsKyW7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ValaAfshar\/status\/506412668040011776\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/u5rcDsKyW7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwcjowPIcAAchuJ.jpg",
        "id_str" : "506412666152579072",
        "id" : 506412666152579072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwcjowPIcAAchuJ.jpg",
        "sizes" : [ {
          "h" : 575,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 569
        }, {
          "h" : 344,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/u5rcDsKyW7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519845353743740928",
    "text" : "Updated Maslow's hierarchy of needs http:\/\/t.co\/u5rcDsKyW7",
    "id" : 519845353743740928,
    "created_at" : "2014-10-08 13:42:45 +0000",
    "user" : {
      "name" : "Vala Afshar",
      "screen_name" : "ValaAfshar",
      "protected" : false,
      "id_str" : "259725229",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1259558245\/vala_300dpi_normal.jpg",
      "id" : 259725229,
      "verified" : true
    }
  },
  "id" : 520454396962803712,
  "created_at" : "2014-10-10 06:02:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruce Tate",
      "screen_name" : "redrapids",
      "indices" : [ 42, 52 ],
      "id_str" : "61650296",
      "id" : 61650296
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "functionalconf",
      "indices" : [ 73, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520417393365889025",
  "text" : "\"You have to overcome fear to discover\" - @redrapids (Bruce Tate) at his #functionalconf keynote.",
  "id" : 520417393365889025,
  "created_at" : "2014-10-10 03:35:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sumit Asok",
      "screen_name" : "sumitasok",
      "indices" : [ 0, 10 ],
      "id_str" : "61692275",
      "id" : 61692275
    }, {
      "name" : "\u30A2\u30CB\u30EB (Anil) \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB",
      "screen_name" : "anildigital",
      "indices" : [ 11, 23 ],
      "id_str" : "63603",
      "id" : 63603
    }, {
      "name" : "Prathamesh Sonpatki",
      "screen_name" : "_cha1tanya",
      "indices" : [ 24, 35 ],
      "id_str" : "633603670",
      "id" : 633603670
    }, {
      "name" : "Nithin Bekal",
      "screen_name" : "nithinbekal",
      "indices" : [ 36, 48 ],
      "id_str" : "9380342",
      "id" : 9380342
    }, {
      "name" : "Santosh Wadghule",
      "screen_name" : "mechanicles",
      "indices" : [ 49, 61 ],
      "id_str" : "10389852",
      "id" : 10389852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520264049213190145",
  "geo" : { },
  "id_str" : "520320093473890304",
  "in_reply_to_user_id" : 61692275,
  "text" : "@sumitasok @anildigital @_cha1tanya @nithinbekal @mechanicles You're very welcome!  I'm glad to be here and meet you all too.",
  "id" : 520320093473890304,
  "in_reply_to_status_id" : 520264049213190145,
  "created_at" : "2014-10-09 21:09:12 +0000",
  "in_reply_to_screen_name" : "sumitasok",
  "in_reply_to_user_id_str" : "61692275",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prathamesh Sonpatki",
      "screen_name" : "_cha1tanya",
      "indices" : [ 0, 11 ],
      "id_str" : "633603670",
      "id" : 633603670
    }, {
      "name" : "\u30A2\u30CB\u30EB (Anil) \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB",
      "screen_name" : "anildigital",
      "indices" : [ 12, 24 ],
      "id_str" : "63603",
      "id" : 63603
    }, {
      "name" : "Sumit Asok",
      "screen_name" : "sumitasok",
      "indices" : [ 25, 35 ],
      "id_str" : "61692275",
      "id" : 61692275
    }, {
      "name" : "Nithin Bekal",
      "screen_name" : "nithinbekal",
      "indices" : [ 36, 48 ],
      "id_str" : "9380342",
      "id" : 9380342
    }, {
      "name" : "Santosh Wadghule",
      "screen_name" : "mechanicles",
      "indices" : [ 49, 61 ],
      "id_str" : "10389852",
      "id" : 10389852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520253833054654464",
  "geo" : { },
  "id_str" : "520318823233097729",
  "in_reply_to_user_id" : 633603670,
  "text" : "@_cha1tanya @anildigital @sumitasok @nithinbekal @mechanicles You're welcome. Nice to meet you all too.  Everyone has been super friendly.",
  "id" : 520318823233097729,
  "in_reply_to_status_id" : 520253833054654464,
  "created_at" : "2014-10-09 21:04:09 +0000",
  "in_reply_to_screen_name" : "_cha1tanya",
  "in_reply_to_user_id_str" : "633603670",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugo Estrada",
      "screen_name" : "hugoestr",
      "indices" : [ 0, 9 ],
      "id_str" : "33578369",
      "id" : 33578369
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "520229455877640192",
  "geo" : { },
  "id_str" : "520317591055650817",
  "in_reply_to_user_id" : 33578369,
  "text" : "@hugoestr Yes, in Bangalore, India for Functional Conf.  I gave a talk on Functional Programming in Ruby.  Enjoying it; everyone super mice.",
  "id" : 520317591055650817,
  "in_reply_to_status_id" : 520229455877640192,
  "created_at" : "2014-10-09 20:59:15 +0000",
  "in_reply_to_screen_name" : "hugoestr",
  "in_reply_to_user_id_str" : "33578369",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30CB\u30EB (Anil) \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB",
      "screen_name" : "anildigital",
      "indices" : [ 13, 25 ],
      "id_str" : "63603",
      "id" : 63603
    }, {
      "name" : "Prathamesh Sonpatki",
      "screen_name" : "_cha1tanya",
      "indices" : [ 26, 37 ],
      "id_str" : "633603670",
      "id" : 633603670
    }, {
      "name" : "Sumit Asok",
      "screen_name" : "sumitasok",
      "indices" : [ 38, 48 ],
      "id_str" : "61692275",
      "id" : 61692275
    }, {
      "name" : "Nithin Bekal",
      "screen_name" : "nithinbekal",
      "indices" : [ 49, 61 ],
      "id_str" : "9380342",
      "id" : 9380342
    }, {
      "name" : "Santosh Wadghule",
      "screen_name" : "mechanicles",
      "indices" : [ 62, 74 ],
      "id_str" : "10389852",
      "id" : 10389852
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 75, 89 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/520224353640669184\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/yDRuIvJbcK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzg1RhvCAAARyaf.jpg",
      "id_str" : "520224332190973952",
      "id" : 520224332190973952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzg1RhvCAAARyaf.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yDRuIvJbcK"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "functionalconf",
      "indices" : [ 93, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520224353640669184",
  "text" : "#rubyfriends @anildigital @_cha1tanya @sumitasok @nithinbekal @mechanicles @keithrbennett at #functionalconf http:\/\/t.co\/yDRuIvJbcK",
  "id" : 520224353640669184,
  "created_at" : "2014-10-09 14:48:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    }, {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 37, 44 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nashjain\/status\/520203865329631233\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/H45xvNhwBM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzgio1rCUAAbHSz.jpg",
      "id_str" : "520203841958989824",
      "id" : 520203841958989824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzgio1rCUAAbHSz.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/H45xvNhwBM"
    } ],
    "hashtags" : [ {
      "text" : "FishBowl",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "FunctionalConf",
      "indices" : [ 45, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520223238211657728",
  "text" : "RT @nashjain: #FishBowl in action at @FuConf #FunctionalConf http:\/\/t.co\/H45xvNhwBM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Functional Conf",
        "screen_name" : "FuConf",
        "indices" : [ 23, 30 ],
        "id_str" : "2347359145",
        "id" : 2347359145
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nashjain\/status\/520203865329631233\/photo\/1",
        "indices" : [ 47, 69 ],
        "url" : "http:\/\/t.co\/H45xvNhwBM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bzgio1rCUAAbHSz.jpg",
        "id_str" : "520203841958989824",
        "id" : 520203841958989824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bzgio1rCUAAbHSz.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/H45xvNhwBM"
      } ],
      "hashtags" : [ {
        "text" : "FishBowl",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "FunctionalConf",
        "indices" : [ 31, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "520203865329631233",
    "text" : "#FishBowl in action at @FuConf #FunctionalConf http:\/\/t.co\/H45xvNhwBM",
    "id" : 520203865329631233,
    "created_at" : "2014-10-09 13:27:21 +0000",
    "user" : {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "protected" : false,
      "id_str" : "10411062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775404265976332288\/LOoVpSln_normal.jpg",
      "id" : 10411062,
      "verified" : false
    }
  },
  "id" : 520223238211657728,
  "created_at" : "2014-10-09 14:44:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 113, 122 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuconf",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520069721861804032",
  "text" : "\"While you were fixing bugs [in a bad code base] you were looking for another job. That's called concurrency.\" - @venkat_s #fuconf",
  "id" : 520069721861804032,
  "created_at" : "2014-10-09 04:34:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 58, 67 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520067157690839040",
  "text" : "Good code should read like a story, not like a puzzle.  - @venkat_s",
  "id" : 520067157690839040,
  "created_at" : "2014-10-09 04:24:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Venkat Subramaniam",
      "screen_name" : "venkat_s",
      "indices" : [ 42, 51 ],
      "id_str" : "14429713",
      "id" : 14429713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/520054874503786497\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/RxM5G9MDrc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BzebJr8CIAAmaV5.jpg",
      "id_str" : "520054872700231680",
      "id" : 520054872700231680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BzebJr8CIAAmaV5.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RxM5G9MDrc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "520054874503786497",
  "text" : ".@functionalconf in Bangalore begins with @venkat_s keynote. http:\/\/t.co\/RxM5G9MDrc",
  "id" : 520054874503786497,
  "created_at" : "2014-10-09 03:35:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Semaphore",
      "screen_name" : "semaphoreapp",
      "indices" : [ 3, 16 ],
      "id_str" : "2778662982",
      "id" : 2778662982
    }, {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 18, 29 ],
      "id_str" : "520859958",
      "id" : 520859958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RSpec",
      "indices" : [ 44, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/bvqW7KFunt",
      "expanded_url" : "http:\/\/bit.ly\/1EjYCwg",
      "display_url" : "bit.ly\/1EjYCwg"
    } ]
  },
  "geo" : { },
  "id_str" : "519402390970064896",
  "text" : "RT @semaphoreapp: @cupakromer shows how new #RSpec makes testing APIs easier: http:\/\/t.co\/bvqW7KFunt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Where's the blue?",
        "screen_name" : "cupakromer",
        "indices" : [ 0, 11 ],
        "id_str" : "520859958",
        "id" : 520859958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RSpec",
        "indices" : [ 26, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/bvqW7KFunt",
        "expanded_url" : "http:\/\/bit.ly\/1EjYCwg",
        "display_url" : "bit.ly\/1EjYCwg"
      } ]
    },
    "geo" : { },
    "id_str" : "519283012295331840",
    "in_reply_to_user_id" : 520859958,
    "text" : "@cupakromer shows how new #RSpec makes testing APIs easier: http:\/\/t.co\/bvqW7KFunt",
    "id" : 519283012295331840,
    "created_at" : "2014-10-07 00:28:12 +0000",
    "in_reply_to_screen_name" : "cupakromer",
    "in_reply_to_user_id_str" : "520859958",
    "user" : {
      "name" : "Semaphore",
      "screen_name" : "semaphoreci",
      "protected" : false,
      "id_str" : "424993983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813789068551196677\/3P8trZO3_normal.jpg",
      "id" : 424993983,
      "verified" : false
    }
  },
  "id" : 519402390970064896,
  "created_at" : "2014-10-07 08:22:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 0, 10 ],
      "id_str" : "14253068",
      "id" : 14253068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "519322713203040259",
  "geo" : { },
  "id_str" : "519398612711653376",
  "in_reply_to_user_id" : 14253068,
  "text" : "@mfeathers Do tell. That could be mega-useful.",
  "id" : 519398612711653376,
  "in_reply_to_status_id" : 519322713203040259,
  "created_at" : "2014-10-07 08:07:33 +0000",
  "in_reply_to_screen_name" : "mfeathers",
  "in_reply_to_user_id_str" : "14253068",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Computer Science",
      "screen_name" : "CompSciFact",
      "indices" : [ 3, 15 ],
      "id_str" : "220145170",
      "id" : 220145170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "519169694214156288",
  "text" : "RT @CompSciFact: A bag of coat hangers is a better metaphor than a bowl of spaghetti for tangled code. It's easier to pull out one noodle t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "519158140844408832",
    "text" : "A bag of coat hangers is a better metaphor than a bowl of spaghetti for tangled code. It's easier to pull out one noodle than one hanger.",
    "id" : 519158140844408832,
    "created_at" : "2014-10-06 16:12:00 +0000",
    "user" : {
      "name" : "Computer Science",
      "screen_name" : "CompSciFact",
      "protected" : false,
      "id_str" : "220145170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712385253206167552\/p2hBQiWf_normal.jpg",
      "id" : 220145170,
      "verified" : false
    }
  },
  "id" : 519169694214156288,
  "created_at" : "2014-10-06 16:57:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Functional Conf",
      "screen_name" : "FuConf",
      "indices" : [ 46, 53 ],
      "id_str" : "2347359145",
      "id" : 2347359145
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CtQ4EX3pln",
      "expanded_url" : "http:\/\/www.functionalconf.com\/",
      "display_url" : "functionalconf.com"
    } ]
  },
  "geo" : { },
  "id_str" : "519151230384627712",
  "text" : "Flying over Iran now, headed to Bangalore for @FuConf Thursday to Saturday.  There's still time to register!: http:\/\/t.co\/CtQ4EX3pln",
  "id" : 519151230384627712,
  "created_at" : "2014-10-06 15:44:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/eQpqELreL9",
      "expanded_url" : "http:\/\/www.bbc.com\/news\/magazine-29476893",
      "display_url" : "bbc.com\/news\/magazine-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518429039212912640",
  "text" : "Caesium: A brief history of timekeeping including why GMT (UTC) came to be the standard: http:\/\/t.co\/eQpqELreL9",
  "id" : 518429039212912640,
  "created_at" : "2014-10-04 15:54:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]