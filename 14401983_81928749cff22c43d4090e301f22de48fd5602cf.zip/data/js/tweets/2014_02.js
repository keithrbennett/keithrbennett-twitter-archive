Grailbird.data.tweets_2014_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/3ti3FtjCLI",
      "expanded_url" : "http:\/\/newhazletttheater.org\/about-us\/history\/",
      "display_url" : "newhazletttheater.org\/about-us\/histo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439053264248897536",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby has a new venue this year -- New Hazlett Theater, the 1st Carnegie Hall, in Pittsburgh (http:\/\/t.co\/3ti3FtjCLI).",
  "id" : 439053264248897536,
  "created_at" : "2014-02-27 15:03:50 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439052658100699136",
  "text" : "RT @JimGaffigan: Those people not on social media look so silly making no effort to gain the approval of strangers over the Internet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439044241625714688",
    "text" : "Those people not on social media look so silly making no effort to gain the approval of strangers over the Internet.",
    "id" : 439044241625714688,
    "created_at" : "2014-02-27 14:27:58 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 439052658100699136,
  "created_at" : "2014-02-27 15:01:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 20, 31 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/tAVfjDpl0I",
      "expanded_url" : "http:\/\/pragprog.com\/screencasts\/v-jwsceasy\/source-control-made-easy",
      "display_url" : "pragprog.com\/screencasts\/v-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "439041434880983040",
  "text" : "Just donated $10 to @jimweirich's family by buying his screencast at (http:\/\/t.co\/tAVfjDpl0I). Whole $10 goes to Jim's family.",
  "id" : 439041434880983040,
  "created_at" : "2014-02-27 14:16:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3c1nRTmKik",
      "expanded_url" : "http:\/\/www.meetup.com\/novarug\/events\/164491782\/",
      "display_url" : "meetup.com\/novarug\/events\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "438379092497678337",
  "text" : "Doing my \"Ruby Lambdas\" presentation at the Reston Ruby meetup tomorrow (see http:\/\/t.co\/3c1nRTmKik).",
  "id" : 438379092497678337,
  "created_at" : "2014-02-25 18:24:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "sdtconf",
      "indices" : [ 0, 8 ],
      "id_str" : "149476614",
      "id" : 149476614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "438348080610824192",
  "in_reply_to_user_id" : 149476614,
  "text" : "@sdtconf Is there an sdtconf this year (I hope)?  When, where?",
  "id" : 438348080610824192,
  "created_at" : "2014-02-25 16:21:41 +0000",
  "in_reply_to_screen_name" : "sdtconf",
  "in_reply_to_user_id_str" : "149476614",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mu-Fan Teng",
      "screen_name" : "ryudoawaru",
      "indices" : [ 0, 11 ],
      "id_str" : "17306085",
      "id" : 17306085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "437759027334770688",
  "geo" : { },
  "id_str" : "437829304131403776",
  "in_reply_to_user_id" : 17306085,
  "text" : "@ryudoawaru Yes, I did.  I just responded via email.  Sorry for the delay.",
  "id" : 437829304131403776,
  "in_reply_to_status_id" : 437759027334770688,
  "created_at" : "2014-02-24 06:00:15 +0000",
  "in_reply_to_screen_name" : "ryudoawaru",
  "in_reply_to_user_id_str" : "17306085",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "436939335926308864",
  "text" : "Jira users, if you insert a (small!) amount of code or terminal output in text, wrap it in \u007Bcode\u007D delimiters for color coded monospace text.",
  "id" : 436939335926308864,
  "created_at" : "2014-02-21 19:03:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436408348968120320",
  "geo" : { },
  "id_str" : "436516057184890880",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx So sad.  Jim was brilliant and friendly, bringing positive energy wherever he went. He will be missed.",
  "id" : 436516057184890880,
  "in_reply_to_status_id" : 436408348968120320,
  "created_at" : "2014-02-20 15:01:52 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael DeHaan",
      "screen_name" : "laserllama",
      "indices" : [ 0, 11 ],
      "id_str" : "52725117",
      "id" : 52725117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436494406263529472",
  "geo" : { },
  "id_str" : "436495967890571265",
  "in_reply_to_user_id" : 52725117,
  "text" : "@laserllama  Thanks.  I was really complaining about Apple, to allow this legal thing to fail a build. gcc on Linux has no such problem.",
  "id" : 436495967890571265,
  "in_reply_to_status_id" : 436494406263529472,
  "created_at" : "2014-02-20 13:42:03 +0000",
  "in_reply_to_screen_name" : "laserllama",
  "in_reply_to_user_id_str" : "52725117",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 0, 9 ],
      "id_str" : "91333167",
      "id" : 91333167
    }, {
      "name" : "Martyn Ranyard",
      "screen_name" : "iMartyn",
      "indices" : [ 10, 18 ],
      "id_str" : "77973285",
      "id" : 77973285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "436156774639341568",
  "geo" : { },
  "id_str" : "436494692021071872",
  "in_reply_to_user_id" : 91333167,
  "text" : "@climagic @iMartyn For the mac, this seems to work: alias clc=\"fc -l -n -1 -1 | sed  's\/^\\s+\/\/' | pbcopy\"",
  "id" : 436494692021071872,
  "in_reply_to_status_id" : 436156774639341568,
  "created_at" : "2014-02-20 13:36:58 +0000",
  "in_reply_to_screen_name" : "climagic",
  "in_reply_to_user_id_str" : "91333167",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ansible",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/8iQzZjuKM3",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/9106009",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "436328170137333762",
  "text" : "Mac OS pip install #ansible was failing because gcc refused to work until run w\/sudo to accept the license (see https:\/\/t.co\/8iQzZjuKM3).",
  "id" : 436328170137333762,
  "created_at" : "2014-02-20 02:35:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sbDFNlNNb8",
      "expanded_url" : "http:\/\/pocket.co\/sbju6",
      "display_url" : "pocket.co\/sbju6"
    } ]
  },
  "geo" : { },
  "id_str" : "436225777135546368",
  "text" : "RT @avdi: Pretty fun read: \"16 People On Things They Couldn\u2019t Believe About America Until They Moved Here\" http:\/\/t.co\/sbDFNlNNb8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/sbDFNlNNb8",
        "expanded_url" : "http:\/\/pocket.co\/sbju6",
        "display_url" : "pocket.co\/sbju6"
      } ]
    },
    "geo" : { },
    "id_str" : "436147655442706432",
    "text" : "Pretty fun read: \"16 People On Things They Couldn\u2019t Believe About America Until They Moved Here\" http:\/\/t.co\/sbDFNlNNb8",
    "id" : 436147655442706432,
    "created_at" : "2014-02-19 14:37:58 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 436225777135546368,
  "created_at" : "2014-02-19 19:48:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "435559838592942081",
  "text" : "TIL to configure per-project Git user info, use PROJECT_DIR\/.git\/config [user] section. Good when you have work and non-work Git userid's.",
  "id" : 435559838592942081,
  "created_at" : "2014-02-17 23:42:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 3, 15 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xBCxzO5Jk6",
      "expanded_url" : "http:\/\/thequickword.wordpress.com\/2014\/02\/16\/james-irys-history-of-programming-languages-illustrated-with-pictures-and-large-fonts\/",
      "display_url" : "thequickword.wordpress.com\/2014\/02\/16\/jam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435453785952247808",
  "text" : "RT @coreyhaines: History of programming languages. Funny, because it is true http:\/\/t.co\/xBCxzO5Jk6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/xBCxzO5Jk6",
        "expanded_url" : "http:\/\/thequickword.wordpress.com\/2014\/02\/16\/james-irys-history-of-programming-languages-illustrated-with-pictures-and-large-fonts\/",
        "display_url" : "thequickword.wordpress.com\/2014\/02\/16\/jam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "435443498142035968",
    "text" : "History of programming languages. Funny, because it is true http:\/\/t.co\/xBCxzO5Jk6",
    "id" : 435443498142035968,
    "created_at" : "2014-02-17 15:59:54 +0000",
    "user" : {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "protected" : false,
      "id_str" : "11458102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629858692012191745\/L8jx6eD3_normal.jpg",
      "id" : 11458102,
      "verified" : true
    }
  },
  "id" : 435453785952247808,
  "created_at" : "2014-02-17 16:40:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/54NEZKnFOg",
      "expanded_url" : "http:\/\/www.checkbook.org\/",
      "display_url" : "checkbook.org"
    } ]
  },
  "geo" : { },
  "id_str" : "435441217766060032",
  "text" : "DC area people, http:\/\/t.co\/54NEZKnFOg has consumer reviews\/advice about businesses, doctors, hospitals, etc. $34\/2 years. No ad revenue.",
  "id" : 435441217766060032,
  "created_at" : "2014-02-17 15:50:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 147 ],
      "url" : "http:\/\/t.co\/QOevFRvSuG",
      "expanded_url" : "http:\/\/www.youtube.com\/playlist?list=PLeqyI2I9O0nvtGsNFnPSZmylVWKLZBNO7",
      "display_url" : "youtube.com\/playlist?list=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "435205430638157825",
  "text" : "Lots of fun at Korean &amp; English karaoke last night. I sing Under the Boardwalk &amp; Korean songs on Youtube playlist at http:\/\/t.co\/QOevFRvSuG",
  "id" : 435205430638157825,
  "created_at" : "2014-02-17 00:13:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/e3rTvOg9DU",
      "expanded_url" : "http:\/\/twitpic.com\/dvjtf9",
      "display_url" : "twitpic.com\/dvjtf9"
    } ]
  },
  "geo" : { },
  "id_str" : "434719050829422592",
  "text" : "RT @climagic: Cool, my Unicode keyboard was delivered. http:\/\/t.co\/e3rTvOg9DU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/e3rTvOg9DU",
        "expanded_url" : "http:\/\/twitpic.com\/dvjtf9",
        "display_url" : "twitpic.com\/dvjtf9"
      } ]
    },
    "geo" : { },
    "id_str" : "434423843432591360",
    "text" : "Cool, my Unicode keyboard was delivered. http:\/\/t.co\/e3rTvOg9DU",
    "id" : 434423843432591360,
    "created_at" : "2014-02-14 20:28:10 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 434719050829422592,
  "created_at" : "2014-02-15 16:01:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 3, 12 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434475441186177024",
  "text" : "RT @zspencer: There once was a greeting card holiday\nThat aggravated social anxietay\ncuz single or not\nThe pressure was hot\nTo have a happy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "434442534727606272",
    "text" : "There once was a greeting card holiday\nThat aggravated social anxietay\ncuz single or not\nThe pressure was hot\nTo have a happy valentines day",
    "id" : 434442534727606272,
    "created_at" : "2014-02-14 21:42:26 +0000",
    "user" : {
      "name" : "Zee",
      "screen_name" : "_zspencer",
      "protected" : true,
      "id_str" : "756161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540237689392361472\/f96ILqGI_normal.jpeg",
      "id" : 756161,
      "verified" : false
    }
  },
  "id" : 434475441186177024,
  "created_at" : "2014-02-14 23:53:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al 'boris' PJ",
      "screen_name" : "businessBoris",
      "indices" : [ 0, 14 ],
      "id_str" : "280445060",
      "id" : 280445060
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "422441157453307904",
  "geo" : { },
  "id_str" : "434421807999774720",
  "in_reply_to_user_id" : 14401983,
  "text" : "@businessboris To answer your question, no, I am still unable to build gollum.  Using Confluence for now &amp; putting xml export in git.",
  "id" : 434421807999774720,
  "in_reply_to_status_id" : 422441157453307904,
  "created_at" : "2014-02-14 20:20:04 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Formerly Shay Pierce",
      "screen_name" : "IQpierce",
      "indices" : [ 3, 12 ],
      "id_str" : "2600856380",
      "id" : 2600856380
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "434337652427726848",
  "text" : "RT @IQpierce: I never felt privileged; I worked hard for each reward I got. But I see now: being in a position to work hard &amp; get rewards I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429255280841728000",
    "text" : "I never felt privileged; I worked hard for each reward I got. But I see now: being in a position to work hard &amp; get rewards IS a privilege.",
    "id" : 429255280841728000,
    "created_at" : "2014-01-31 14:10:08 +0000",
    "user" : {
      "name" : "Shay Pierce",
      "screen_name" : "ShayMakesGames",
      "protected" : false,
      "id_str" : "4052871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769532314124558336\/i0eEP_t-_normal.jpg",
      "id" : 4052871,
      "verified" : false
    }
  },
  "id" : 434337652427726848,
  "created_at" : "2014-02-14 14:45:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nic Schlueter",
      "screen_name" : "schlu",
      "indices" : [ 3, 9 ],
      "id_str" : "14716455",
      "id" : 14716455
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433953779676110849",
  "text" : "RT @schlu: Comcast\/Time Warner - because you already had no choice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433821367637516289",
    "text" : "Comcast\/Time Warner - because you already had no choice",
    "id" : 433821367637516289,
    "created_at" : "2014-02-13 04:34:08 +0000",
    "user" : {
      "name" : "Nic Schlueter",
      "screen_name" : "schlu",
      "protected" : false,
      "id_str" : "14716455",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546089681184493568\/0HbYIDmB_normal.jpeg",
      "id" : 14716455,
      "verified" : false
    }
  },
  "id" : 433953779676110849,
  "created_at" : "2014-02-13 13:20:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hacker News Onion",
      "screen_name" : "HackerNewsOnion",
      "indices" : [ 3, 19 ],
      "id_str" : "1263967268",
      "id" : 1263967268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "433779814122917888",
  "text" : "RT @HackerNewsOnion: Predictive analytics startup uses own software to predict lack of adoption",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "433699098495946752",
    "text" : "Predictive analytics startup uses own software to predict lack of adoption",
    "id" : 433699098495946752,
    "created_at" : "2014-02-12 20:28:17 +0000",
    "user" : {
      "name" : "Hacker News Onion",
      "screen_name" : "HackerNewsOnion",
      "protected" : false,
      "id_str" : "1263967268",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3374120487\/e4f509a5ea232cd5b80f9cbac23d9432_normal.jpeg",
      "id" : 1263967268,
      "verified" : false
    }
  },
  "id" : 433779814122917888,
  "created_at" : "2014-02-13 01:49:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allie_p",
      "screen_name" : "allie_p",
      "indices" : [ 0, 8 ],
      "id_str" : "15954702",
      "id" : 15954702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "433774970809118721",
  "geo" : { },
  "id_str" : "433778675512016897",
  "in_reply_to_user_id" : 15954702,
  "text" : "@allie_p which station? New York is my hometown and I'm curious.",
  "id" : 433778675512016897,
  "in_reply_to_status_id" : 433774970809118721,
  "created_at" : "2014-02-13 01:44:30 +0000",
  "in_reply_to_screen_name" : "allie_p",
  "in_reply_to_user_id_str" : "15954702",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 0, 8 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432927736969965568",
  "geo" : { },
  "id_str" : "432944320321040384",
  "in_reply_to_user_id" : 121639673,
  "text" : "@snuggsi I have no ideological agenda, just want to make sure we're portraying the data accurately. Maybe Forbes had another source?",
  "id" : 432944320321040384,
  "in_reply_to_status_id" : 432927736969965568,
  "created_at" : "2014-02-10 18:29:04 +0000",
  "in_reply_to_screen_name" : "snuggsi",
  "in_reply_to_user_id_str" : "121639673",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 0, 8 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/3MIZUs4HNo",
      "expanded_url" : "http:\/\/www.who.int\/mediacentre\/factsheets\/fs311\/en\/",
      "display_url" : "who.int\/mediacentre\/fa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "432927736969965568",
  "geo" : { },
  "id_str" : "432943824554311680",
  "in_reply_to_user_id" : 121639673,
  "text" : "@snuggsi It's a 2011 article, maybe based on WHO's study (http:\/\/t.co\/3MIZUs4HNo)? WHO says &gt;1.4B *overweight*, 500M obese. Bad journalism?",
  "id" : 432943824554311680,
  "in_reply_to_status_id" : 432927736969965568,
  "created_at" : "2014-02-10 18:27:06 +0000",
  "in_reply_to_screen_name" : "snuggsi",
  "in_reply_to_user_id_str" : "121639673",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 0, 8 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432891355333816324",
  "geo" : { },
  "id_str" : "432892428106727425",
  "in_reply_to_user_id" : 121639673,
  "text" : "@snuggsi That statistic doesn't sound right.  Where did you find it?",
  "id" : 432892428106727425,
  "in_reply_to_status_id" : 432891355333816324,
  "created_at" : "2014-02-10 15:02:52 +0000",
  "in_reply_to_screen_name" : "snuggsi",
  "in_reply_to_user_id_str" : "121639673",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "432667667376254976",
  "geo" : { },
  "id_str" : "432675341589417984",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett To eliminate the terminating newline, use tr -d: git remote -v | head -1 | awk '\u007B print $2 \u007D' | tr -d '\\n' | pbcopy",
  "id" : 432675341589417984,
  "in_reply_to_status_id" : 432667667376254976,
  "created_at" : "2014-02-10 00:40:14 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432667667376254976",
  "text" : "On a Mac, get the remote git spec into your clipboard for cloning to different dir: git remote -v | head -1 | awk '\u007B print $2 \u007D' | pbcopy",
  "id" : 432667667376254976,
  "created_at" : "2014-02-10 00:09:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Pl4Pj7Q46t",
      "expanded_url" : "http:\/\/silverlinemetro.com\/",
      "display_url" : "silverlinemetro.com"
    } ]
  },
  "geo" : { },
  "id_str" : "432642340985917440",
  "text" : "DC area tweeps: get all kinds of info about the new Silver Line metro at http:\/\/t.co\/Pl4Pj7Q46t... except when it will open. :(",
  "id" : 432642340985917440,
  "created_at" : "2014-02-09 22:29:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "eddie castle",
      "screen_name" : "holypurgatory",
      "indices" : [ 3, 17 ],
      "id_str" : "102454285",
      "id" : 102454285
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "432638625483083776",
  "text" : "RT @holypurgatory: Step 1: Buy a 3D printer.\n\nStep 2: Print a 3D printer.\n\nStep 3: Return the 3D printer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427456887282352129",
    "text" : "Step 1: Buy a 3D printer.\n\nStep 2: Print a 3D printer.\n\nStep 3: Return the 3D printer.",
    "id" : 427456887282352129,
    "created_at" : "2014-01-26 15:03:58 +0000",
    "user" : {
      "name" : "eddie castle",
      "screen_name" : "holypurgatory",
      "protected" : false,
      "id_str" : "102454285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726831925831176194\/eXJjE6dV_normal.jpg",
      "id" : 102454285,
      "verified" : false
    }
  },
  "id" : 432638625483083776,
  "created_at" : "2014-02-09 22:14:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "431868466086170624",
  "text" : "A colleague has recommended Landmark Forum training for &gt; success &amp; happiness in work and personal life. Anyone have any opinions about it?",
  "id" : 431868466086170624,
  "created_at" : "2014-02-07 19:14:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430821577769234433",
  "geo" : { },
  "id_str" : "430822279283367938",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl a.b.c is controlled by the public gem author. I need separate spec. 1.2.3.p1 seems to work so far.",
  "id" : 430822279283367938,
  "in_reply_to_status_id" : 430821577769234433,
  "created_at" : "2014-02-04 21:56:50 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430800706077880320",
  "text" : "(I want to retain the public gem's version, and add to it. e.g. public version is '1.2.3' &amp; I want something like '1.2.3_p1' or '1.2.3.p1'.)",
  "id" : 430800706077880320,
  "created_at" : "2014-02-04 20:31:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430800387365289984",
  "text" : "I need to create a custom (fixed) version of a public gem. How can I signify the patch  in its version &amp; have it still be a legal version?",
  "id" : 430800387365289984,
  "created_at" : "2014-02-04 20:29:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 3, 14 ],
      "id_str" : "520859958",
      "id" : 520859958
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 17, 31 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "430710643696496643",
  "text" : "RT @cupakromer: .@keithrbennett check for private methods:\nClass.private_instance_methods.include? :method\nobj.private_methods.include? :me\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 1, 15 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RetroRuby",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429631938358702080",
    "text" : ".@keithrbennett check for private methods:\nClass.private_instance_methods.include? :method\nobj.private_methods.include? :method\n#RetroRuby",
    "id" : 429631938358702080,
    "created_at" : "2014-02-01 15:06:50 +0000",
    "user" : {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "protected" : false,
      "id_str" : "520859958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472046879354523648\/C5kiaPER_normal.png",
      "id" : 520859958,
      "verified" : false
    }
  },
  "id" : 430710643696496643,
  "created_at" : "2014-02-04 14:33:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allie_p",
      "screen_name" : "allie_p",
      "indices" : [ 0, 8 ],
      "id_str" : "15954702",
      "id" : 15954702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430096779976384513",
  "geo" : { },
  "id_str" : "430363191764209664",
  "in_reply_to_user_id" : 15954702,
  "text" : "@allie_p Thanks much for doing this. Where can I send corrections\/clarifications (would take several tweets, so I'd prefer another medium)?",
  "id" : 430363191764209664,
  "in_reply_to_status_id" : 430096779976384513,
  "created_at" : "2014-02-03 15:32:35 +0000",
  "in_reply_to_screen_name" : "allie_p",
  "in_reply_to_user_id_str" : "15954702",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "Calle Erlandsson",
      "screen_name" : "calleerlandsson",
      "indices" : [ 6, 22 ],
      "id_str" : "18140513",
      "id" : 18140513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "430021420635394048",
  "geo" : { },
  "id_str" : "430046099965874176",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @calleerlandsson Don't need the splat ('*') there.  Also, alternate approach using array slicing: a = [0,1,2]; x, y = a[1..2].",
  "id" : 430046099965874176,
  "in_reply_to_status_id" : 430021420635394048,
  "created_at" : "2014-02-02 18:32:34 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Isa Goksu",
      "screen_name" : "IsaGoksu",
      "indices" : [ 3, 12 ],
      "id_str" : "15960539",
      "id" : 15960539
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/LTtWn6hG6B",
      "expanded_url" : "http:\/\/i.imgur.com\/eqznolU.jpg",
      "display_url" : "i.imgur.com\/eqznolU.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "430043282023141376",
  "text" : "RT @IsaGoksu: Selfie level 11 achieved;)  http:\/\/t.co\/LTtWn6hG6B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 50 ],
        "url" : "http:\/\/t.co\/LTtWn6hG6B",
        "expanded_url" : "http:\/\/i.imgur.com\/eqznolU.jpg",
        "display_url" : "i.imgur.com\/eqznolU.jpg"
      } ]
    },
    "geo" : { },
    "id_str" : "430010322678980608",
    "text" : "Selfie level 11 achieved;)  http:\/\/t.co\/LTtWn6hG6B",
    "id" : 430010322678980608,
    "created_at" : "2014-02-02 16:10:24 +0000",
    "user" : {
      "name" : "Isa Goksu",
      "screen_name" : "IsaGoksu",
      "protected" : false,
      "id_str" : "15960539",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2668644405\/ccf08b0b99b9a6614f318767522e98c7_normal.png",
      "id" : 15960539,
      "verified" : false
    }
  },
  "id" : 430043282023141376,
  "created_at" : "2014-02-02 18:21:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "indices" : [ 31, 37 ],
      "id_str" : "14375110",
      "id" : 14375110
    }, {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 107, 122 ],
      "id_str" : "9505092",
      "id" : 9505092
    }, {
      "name" : "Craig Andera",
      "screen_name" : "craigandera",
      "indices" : [ 127, 139 ],
      "id_str" : "16510346",
      "id" : 16510346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/hd4lpGBkuN",
      "expanded_url" : "http:\/\/www.functionalgeekery.com\/",
      "display_url" : "functionalgeekery.com"
    } ]
  },
  "geo" : { },
  "id_str" : "430034291024621568",
  "text" : "Just listened to the excellent @fogus interview at http:\/\/t.co\/hd4lpGBkuN.  They also have interviews with @unclebobmartin and @craigandera.",
  "id" : 430034291024621568,
  "created_at" : "2014-02-02 17:45:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]