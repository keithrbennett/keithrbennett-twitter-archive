Grailbird.data.tweets_2016_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "781118936603586560",
  "geo" : { },
  "id_str" : "781399865695744001",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton Thank you!",
  "id" : 781399865695744001,
  "in_reply_to_status_id" : 781118936603586560,
  "created_at" : "2016-09-29 07:47:00 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/781351030017536000\/photo\/1",
      "indices" : [ 122, 145 ],
      "url" : "https:\/\/t.co\/zuDfwVvYAS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ctfqmd_UkAE6-MH.jpg",
      "id_str" : "781351006978215937",
      "id" : 781351006978215937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ctfqmd_UkAE6-MH.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zuDfwVvYAS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781351030017536000",
  "text" : "Just rented my motorbike. Waiting in a coffee shop for the rain and thunder to subside before the first ride around town. https:\/\/t.co\/zuDfwVvYAS",
  "id" : 781351030017536000,
  "created_at" : "2016-09-29 04:32:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/781334374021144576\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/ik6pdqtOoW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtfbdICUIAAep6W.jpg",
      "id_str" : "781334353791950848",
      "id" : 781334353791950848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtfbdICUIAAep6W.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/ik6pdqtOoW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781334374021144576",
  "text" : "Arriving at my Chiang Mai hotel, my phone chirped at the wifi reconnection &amp; I exclaimed to the staff \"I'm hoooome.\" Coconut shake! https:\/\/t.co\/ik6pdqtOoW",
  "id" : 781334374021144576,
  "created_at" : "2016-09-29 03:26:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "781049199907508224",
  "text" : "I'm at Incheon airport in Seoul. Great KAL flight; comfortable, aisle seat w\/empty seat next to me. Saw great movie: \"Remember\".",
  "id" : 781049199907508224,
  "created_at" : "2016-09-28 08:33:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779773015223599104",
  "text" : "Leaving again for Asia on Tuesday. 1st stop: Chiang Mai, Thailand for tai chi training (and lots of excellent Thai massage of course!).",
  "id" : 779773015223599104,
  "created_at" : "2016-09-24 20:02:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fairfax County",
      "screen_name" : "fairfaxcounty",
      "indices" : [ 97, 111 ],
      "id_str" : "16016705",
      "id" : 16016705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/779413210059378688\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/JfDUmMjMe4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CtEIIotUIAAD1Rt.jpg",
      "id_str" : "779413154971262976",
      "id" : 779413154971262976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CtEIIotUIAAD1Rt.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/JfDUmMjMe4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779413210059378688",
  "text" : "I may be out of the country on Election Day, so I voted today. Efficient and friendly service at @fairfaxcounty ofc. https:\/\/t.co\/JfDUmMjMe4",
  "id" : 779413210059378688,
  "created_at" : "2016-09-23 20:12:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costco",
      "screen_name" : "Costco",
      "indices" : [ 0, 7 ],
      "id_str" : "1056152593",
      "id" : 1056152593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "779112853697691648",
  "in_reply_to_user_id" : 1056152593,
  "text" : "@costco Astonished that your credit cards carry a 3% foreign currency conversion fee. So many cards are 0%. Why not yours?",
  "id" : 779112853697691648,
  "created_at" : "2016-09-23 00:19:14 +0000",
  "in_reply_to_screen_name" : "Costco",
  "in_reply_to_user_id_str" : "1056152593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erik Hatcher",
      "screen_name" : "ErikHatcher",
      "indices" : [ 3, 15 ],
      "id_str" : "1138371924",
      "id" : 1138371924
    }, {
      "name" : "OpenSrc Connections",
      "screen_name" : "o19s",
      "indices" : [ 24, 29 ],
      "id_str" : "42432542",
      "id" : 42432542
    }, {
      "name" : "Eric Pugh",
      "screen_name" : "dep4b",
      "indices" : [ 32, 38 ],
      "id_str" : "22809596",
      "id" : 22809596
    }, {
      "name" : "Search'n General",
      "screen_name" : "softwaredoug",
      "indices" : [ 40, 53 ],
      "id_str" : "24618459",
      "id" : 24618459
    }, {
      "name" : "Scott Stults",
      "screen_name" : "scottstults",
      "indices" : [ 55, 67 ],
      "id_str" : "355421898",
      "id" : 355421898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "becamp",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "778742125756162048",
  "text" : "RT @ErikHatcher: Thanks @o19s - @dep4b, @softwaredoug, @scottstults et al - for hosting this years #becamp; great space, great community!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OpenSrc Connections",
        "screen_name" : "o19s",
        "indices" : [ 7, 12 ],
        "id_str" : "42432542",
        "id" : 42432542
      }, {
        "name" : "Eric Pugh",
        "screen_name" : "dep4b",
        "indices" : [ 15, 21 ],
        "id_str" : "22809596",
        "id" : 22809596
      }, {
        "name" : "Search'n General",
        "screen_name" : "softwaredoug",
        "indices" : [ 23, 36 ],
        "id_str" : "24618459",
        "id" : 24618459
      }, {
        "name" : "Scott Stults",
        "screen_name" : "scottstults",
        "indices" : [ 38, 50 ],
        "id_str" : "355421898",
        "id" : 355421898
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "becamp",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "charlottesville",
        "indices" : [ 122, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "778005514638790656",
    "text" : "Thanks @o19s - @dep4b, @softwaredoug, @scottstults et al - for hosting this years #becamp; great space, great community!  #charlottesville",
    "id" : 778005514638790656,
    "created_at" : "2016-09-19 22:59:03 +0000",
    "user" : {
      "name" : "Erik Hatcher",
      "screen_name" : "ErikHatcher",
      "protected" : false,
      "id_str" : "1138371924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685473446172712961\/uv8uhzzD_normal.jpg",
      "id" : 1138371924,
      "verified" : false
    }
  },
  "id" : 778742125756162048,
  "created_at" : "2016-09-21 23:46:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Pugh",
      "screen_name" : "dep4b",
      "indices" : [ 0, 6 ],
      "id_str" : "22809596",
      "id" : 22809596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "760138362921492481",
  "geo" : { },
  "id_str" : "777529257639772160",
  "in_reply_to_user_id" : 22809596,
  "text" : "@dep4b Prob. not worth the trip by itself, but he could speak at NovaJUG (Java in Reston); maybe we could arrange a combined meetup.",
  "id" : 777529257639772160,
  "in_reply_to_status_id" : 760138362921492481,
  "created_at" : "2016-09-18 15:26:35 +0000",
  "in_reply_to_screen_name" : "dep4b",
  "in_reply_to_user_id_str" : "22809596",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Preetam",
      "screen_name" : "PreetamJinka",
      "indices" : [ 0, 13 ],
      "id_str" : "302840829",
      "id" : 302840829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777508102447005696",
  "geo" : { },
  "id_str" : "777525260740653056",
  "in_reply_to_user_id" : 302840829,
  "text" : "@PreetamJinka Thanks for that resource.",
  "id" : 777525260740653056,
  "in_reply_to_status_id" : 777508102447005696,
  "created_at" : "2016-09-18 15:10:42 +0000",
  "in_reply_to_screen_name" : "PreetamJinka",
  "in_reply_to_user_id_str" : "302840829",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Preetam",
      "screen_name" : "PreetamJinka",
      "indices" : [ 0, 13 ],
      "id_str" : "302840829",
      "id" : 302840829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "777509570872827904",
  "geo" : { },
  "id_str" : "777524931450040320",
  "in_reply_to_user_id" : 302840829,
  "text" : "@PreetamJinka Your choice, but I think you still get order(s) of magnitude less that way, unless you don't travel. BTW, 6%? That's amazing.",
  "id" : 777524931450040320,
  "in_reply_to_status_id" : 777509570872827904,
  "created_at" : "2016-09-18 15:09:24 +0000",
  "in_reply_to_screen_name" : "PreetamJinka",
  "in_reply_to_user_id_str" : "302840829",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "776569661198655488",
  "geo" : { },
  "id_str" : "776577001796866049",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight I'll be right over!  Kidding. I called &amp; they do it every Thursday. Only until 10. :(  Let me know, maybe we could meet there.",
  "id" : 776577001796866049,
  "in_reply_to_status_id" : 776569661198655488,
  "created_at" : "2016-09-16 00:22:39 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773946823102922756",
  "geo" : { },
  "id_str" : "775934578414411776",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Already been embarrassed on phone calls when this sounded. Now changed to Swedish: \"say -v nora St\u00E5 upp f\u00F6r b\u00E4ttre h\u00E4lsa\"",
  "id" : 775934578414411776,
  "in_reply_to_status_id" : 773946823102922756,
  "created_at" : "2016-09-14 05:49:54 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "waze",
      "screen_name" : "waze",
      "indices" : [ 1, 6 ],
      "id_str" : "31171669",
      "id" : 31171669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/b4so6htZvI",
      "expanded_url" : "https:\/\/inbox-static.waze.com\/driverindex.pdf",
      "display_url" : "inbox-static.waze.com\/driverindex.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "775932781301903361",
  "text" : ".@waze How did you calc. your stats for https:\/\/t.co\/b4so6htZvI? There is no way that Cebu's traffic is worse than that of Manila &amp; others.",
  "id" : 775932781301903361,
  "created_at" : "2016-09-14 05:42:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/775704994339258368\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/xE3zV1gwlM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CsPbibIWIAA6wG4.jpg",
      "id_str" : "775704945282654208",
      "id" : 775704945282654208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CsPbibIWIAA6wG4.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/xE3zV1gwlM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775704994339258368",
  "text" : "This is what I get for connecting to a restaurant network without connecting to a VPN. It disabled the Quit action. https:\/\/t.co\/xE3zV1gwlM",
  "id" : 775704994339258368,
  "created_at" : "2016-09-13 14:37:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "775704225640804356",
  "text" : "If your life were *not* on autopilot, what would you be doing differently? ...I have been asking myself.",
  "id" : 775704225640804356,
  "created_at" : "2016-09-13 14:34:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "indices" : [ 3, 11 ],
      "id_str" : "1235521",
      "id" : 1235521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/7Xxcq9Knd4",
      "expanded_url" : "http:\/\/applehelpwriter.com\/2016\/07\/28\/revealing-dropboxs-dirty-little-security-hack\/",
      "display_url" : "applehelpwriter.com\/2016\/07\/28\/rev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "775088589398913024",
  "text" : "RT @timbray: A report of shockingly bad behavior from DropBox. If true, must stop.\nhttps:\/\/t.co\/7Xxcq9Knd4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mvilla.it\/fenix\" rel=\"nofollow\"\u003EFenix for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/7Xxcq9Knd4",
        "expanded_url" : "http:\/\/applehelpwriter.com\/2016\/07\/28\/revealing-dropboxs-dirty-little-security-hack\/",
        "display_url" : "applehelpwriter.com\/2016\/07\/28\/rev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "774621515857874949",
    "text" : "A report of shockingly bad behavior from DropBox. If true, must stop.\nhttps:\/\/t.co\/7Xxcq9Knd4",
    "id" : 774621515857874949,
    "created_at" : "2016-09-10 14:52:15 +0000",
    "user" : {
      "name" : "Tim Bray",
      "screen_name" : "timbray",
      "protected" : false,
      "id_str" : "1235521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421637246\/Tim_normal.jpg",
      "id" : 1235521,
      "verified" : true
    }
  },
  "id" : 775088589398913024,
  "created_at" : "2016-09-11 21:48:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "774350094464417793",
  "text" : "Today at Starbucks I cheerfully allowed a woman in distress to use the rest room before me. She insisted on buying me my capuccino.",
  "id" : 774350094464417793,
  "created_at" : "2016-09-09 20:53:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "773946823102922756",
  "text" : "My reminder Mac shell command for standing up every 15 mins: until false; do; say time to stand up you lazy bum; sleep 900; done",
  "id" : 773946823102922756,
  "created_at" : "2016-09-08 18:11:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ruby",
      "indices" : [ 0, 5 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/g9UwyDF6Bb",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/enumerables\/filtered_enumerable.rb",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "773672542007459840",
  "text" : "#Ruby 's select returns an array. Does Ruby not have any built-in method that does lazy filtering? A solution: https:\/\/t.co\/g9UwyDF6Bb \u2026?",
  "id" : 773672542007459840,
  "created_at" : "2016-09-08 00:01:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "773227872316194816",
  "geo" : { },
  "id_str" : "773551654792732672",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Use it at home as your desktop. \u263A",
  "id" : 773551654792732672,
  "in_reply_to_status_id" : 773227872316194816,
  "created_at" : "2016-09-07 16:01:01 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt McCullar",
      "screen_name" : "TalesofMatteh",
      "indices" : [ 0, 14 ],
      "id_str" : "30960808",
      "id" : 30960808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772643362352553984",
  "geo" : { },
  "id_str" : "772661439496593408",
  "in_reply_to_user_id" : 30960808,
  "text" : "@TalesofMatteh Yes, I'm solo, and in fact am on sabbatical now, avail. for only part time work. As for persuading, maybe start small.",
  "id" : 772661439496593408,
  "in_reply_to_status_id" : 772643362352553984,
  "created_at" : "2016-09-05 05:03:37 +0000",
  "in_reply_to_screen_name" : "TalesofMatteh",
  "in_reply_to_user_id_str" : "30960808",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 0, 13 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "772604892292624384",
  "geo" : { },
  "id_str" : "772610766734319616",
  "in_reply_to_user_id" : 479019528,
  "text" : "@JuanitoFatas I know it's probably hard for you to believe now, but you may be grateful for those youthful looks someday. ;)",
  "id" : 772610766734319616,
  "in_reply_to_status_id" : 772604892292624384,
  "created_at" : "2016-09-05 01:42:15 +0000",
  "in_reply_to_screen_name" : "JuanitoFatas",
  "in_reply_to_user_id_str" : "479019528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ElixirConf",
      "screen_name" : "ElixirConf",
      "indices" : [ 15, 26 ],
      "id_str" : "2432835325",
      "id" : 2432835325
    }, {
      "name" : "Dr. Freeze",
      "screen_name" : "jimfreeze",
      "indices" : [ 33, 43 ],
      "id_str" : "14221645",
      "id" : 14221645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772573212026732546",
  "text" : "Many thanks to @elixirconf &amp; @jimfreeze for my 1st Elixir Conference. Pretty likely I will be changing my focus from Ruby to Elixir soon.",
  "id" : 772573212026732546,
  "created_at" : "2016-09-04 23:13:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/772569871183912962\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/1f63llEo0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cri4MjWXgAEBXsK.jpg",
      "id_str" : "772569861881036801",
      "id" : 772569861881036801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cri4MjWXgAEBXsK.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/1f63llEo0F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "772569871183912962",
  "text" : "My low carb dinner: fresh tofu, ground beef, brussel sprouts in yellow curry sauce; all from Trader Joe's. https:\/\/t.co\/1f63llEo0F",
  "id" : 772569871183912962,
  "created_at" : "2016-09-04 22:59:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]