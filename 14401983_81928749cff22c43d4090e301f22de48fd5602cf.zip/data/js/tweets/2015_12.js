Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis CI",
      "screen_name" : "travisci",
      "indices" : [ 0, 9 ],
      "id_str" : "252481460",
      "id" : 252481460
    }, {
      "name" : "\u3042\u3055\u308A",
      "screen_name" : "hiro_asari",
      "indices" : [ 121, 132 ],
      "id_str" : "14284130",
      "id" : 14284130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/ymrGYQjZCZ",
      "expanded_url" : "https:\/\/github.com\/rubygems\/rubygems\/issues\/1419",
      "display_url" : "github.com\/rubygems\/rubyg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681912035634851840",
  "in_reply_to_user_id" : 252481460,
  "text" : "@travisci If the solution at https:\/\/t.co\/ymrGYQjZCZ is correct, could you fix Travis to use a more current bundler?  cc @hiro_asari",
  "id" : 681912035634851840,
  "created_at" : "2015-12-29 18:57:53 +0000",
  "in_reply_to_screen_name" : "travisci",
  "in_reply_to_user_id_str" : "252481460",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/Ohega9RiFg",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/formatters\/binary_to_hex_and_ascii.rb",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681558145810968576",
  "text" : "Output binary data neatly as hex values and text in #ruby using https:\/\/t.co\/Ohega9RiFg from the trick_bag gem.",
  "id" : 681558145810968576,
  "created_at" : "2015-12-28 19:31:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/o5Hq3BN61o",
      "expanded_url" : "https:\/\/www.compassionandchoices.org",
      "display_url" : "compassionandchoices.org"
    } ]
  },
  "in_reply_to_status_id_str" : "681232439801413632",
  "geo" : { },
  "id_str" : "681541234041700352",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett https:\/\/t.co\/o5Hq3BN61o has informed me that gifts are now doubled, not tripled, but tripling will be Dec. 30-31.",
  "id" : 681541234041700352,
  "in_reply_to_status_id" : 681232439801413632,
  "created_at" : "2015-12-28 18:24:27 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CompassionAndChoices",
      "indices" : [ 50, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/vPW7SBBqom",
      "expanded_url" : "https:\/\/www.compassionandchoices.org\/what-you-can-do\/donate\/make-a-year-end-gift-and-see-it-triple\/",
      "display_url" : "compassionandchoices.org\/what-you-can-d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681232439801413632",
  "text" : "Please consider making a tax ded. contribution to #CompassionAndChoices (in dying) at https:\/\/t.co\/vPW7SBBqom. Gifts tripled till 12\/31.",
  "id" : 681232439801413632,
  "created_at" : "2015-12-27 21:57:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamis Buck",
      "screen_name" : "jamis",
      "indices" : [ 131, 137 ],
      "id_str" : "5877822",
      "id" : 5877822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/lWoVa35NQq",
      "expanded_url" : "http:\/\/weblog.jamisbuck.org\/2015\/12\/12\/little-things-proc-parameters.html?utm_source=rubyweekly&utm_medium=email",
      "display_url" : "weblog.jamisbuck.org\/2015\/12\/12\/lit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "679819971850072064",
  "text" : "Cool #ruby feature: a method\/proc\/lambda can access its parameter metadata w\/ Proc#parameters: https:\/\/t.co\/lWoVa35NQq (article by @jamis).",
  "id" : 679819971850072064,
  "created_at" : "2015-12-24 00:24:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Together",
      "screen_name" : "rubytogether",
      "indices" : [ 75, 88 ],
      "id_str" : "3008787803",
      "id" : 3008787803
    }, {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 124, 138 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/l5B4UHNX0a",
      "expanded_url" : "https:\/\/rubytogether.org\/developers",
      "display_url" : "rubytogether.org\/developers"
    } ]
  },
  "geo" : { },
  "id_str" : "678309822740176896",
  "text" : "Grateful for years of happy &amp; productive #ruby work, I just donated to @RubyTogether at https:\/\/t.co\/l5B4UHNX0a. Thanks @yukihiro_matz!",
  "id" : 678309822740176896,
  "created_at" : "2015-12-19 20:23:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Hubbard",
      "screen_name" : "LukeInTH",
      "indices" : [ 0, 9 ],
      "id_str" : "11998042",
      "id" : 11998042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "674365906135310336",
  "geo" : { },
  "id_str" : "674369065453002752",
  "in_reply_to_user_id" : 11998042,
  "text" : "@LukeInTH Sorry to hear it. This year my daughter got married and I lost both my parents. Yes, life...",
  "id" : 674369065453002752,
  "in_reply_to_status_id" : 674365906135310336,
  "created_at" : "2015-12-08 23:24:49 +0000",
  "in_reply_to_screen_name" : "LukeInTH",
  "in_reply_to_user_id_str" : "11998042",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pimsleur",
      "screen_name" : "Pimsleur",
      "indices" : [ 0, 9 ],
      "id_str" : "14325165",
      "id" : 14325165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673167964515016708",
  "in_reply_to_user_id" : 14325165,
  "text" : "@pimsleur Your teaching materials are great, but continually mispronouncing the name of the language itself is not helpful (Tagalog).",
  "id" : 673167964515016708,
  "created_at" : "2015-12-05 15:52:04 +0000",
  "in_reply_to_screen_name" : "Pimsleur",
  "in_reply_to_user_id_str" : "14325165",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 3, 14 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 29, 43 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671913154608300033",
  "text" : "RT @seanmarcia: On March 5th @arlingtonruby will be holding its next Retrocession!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Ruby",
        "screen_name" : "arlingtonruby",
        "indices" : [ 13, 27 ],
        "id_str" : "284339167",
        "id" : 284339167
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "671811156034650112",
    "text" : "On March 5th @arlingtonruby will be holding its next Retrocession!",
    "id" : 671811156034650112,
    "created_at" : "2015-12-01 22:00:35 +0000",
    "user" : {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "protected" : false,
      "id_str" : "257046682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783412299272814592\/M9kAiG92_normal.jpg",
      "id" : 257046682,
      "verified" : false
    }
  },
  "id" : 671913154608300033,
  "created_at" : "2015-12-02 04:45:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]