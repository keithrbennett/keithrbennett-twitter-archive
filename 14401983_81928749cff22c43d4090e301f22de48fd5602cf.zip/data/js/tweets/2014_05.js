Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 3, 17 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 56, 70 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472522589563133952",
  "text" : "RT @SteelCityRuby: Time to announce some more speakers! @keithrbennett will present \u201CBetter Coding with Ruby Lambdas\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 37, 51 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "472445533085499392",
    "text" : "Time to announce some more speakers! @keithrbennett will present \u201CBetter Coding with Ruby Lambdas\u201D",
    "id" : 472445533085499392,
    "created_at" : "2014-05-30 18:32:47 +0000",
    "user" : {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "protected" : false,
      "id_str" : "404851600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551460511951228928\/ExkXJuce_normal.png",
      "id" : 404851600,
      "verified" : false
    }
  },
  "id" : 472522589563133952,
  "created_at" : "2014-05-30 23:38:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 66, 77 ],
      "id_str" : "9887102",
      "id" : 9887102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/yfGcJ3E9yn",
      "expanded_url" : "http:\/\/metaskills.net\/2010\/07\/30\/the-rvm-ruby-api\/",
      "display_url" : "metaskills.net\/2010\/07\/30\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "472459269934444544",
  "text" : "Who knew, RVM has a Ruby API...this could be very handy.  Thanks, @metaskills for your 2010 article at http:\/\/t.co\/yfGcJ3E9yn.",
  "id" : 472459269934444544,
  "created_at" : "2014-05-30 19:27:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TransparencyCamp",
      "screen_name" : "TCampDC",
      "indices" : [ 0, 8 ],
      "id_str" : "21128021",
      "id" : 21128021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "472095757546569728",
  "in_reply_to_user_id" : 21128021,
  "text" : "@TCampDC I can't make it to camp due to a family situation, may I transfer my registration to a friend? I follow you, feel free to DM me.",
  "id" : 472095757546569728,
  "created_at" : "2014-05-29 19:22:54 +0000",
  "in_reply_to_screen_name" : "TCampDC",
  "in_reply_to_user_id_str" : "21128021",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McDonald's",
      "screen_name" : "McDonalds",
      "indices" : [ 57, 67 ],
      "id_str" : "71026122",
      "id" : 71026122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471773743707336704",
  "text" : "And the winner of today's best remote working venue is...@McDonalds, for a clean, comfortable space w\/wifi, power, and good cheap latte.",
  "id" : 471773743707336704,
  "created_at" : "2014-05-28 22:03:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Julian",
      "screen_name" : "jonathanjulian",
      "indices" : [ 0, 15 ],
      "id_str" : "14846101",
      "id" : 14846101
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 16, 23 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "471714579958202368",
  "geo" : { },
  "id_str" : "471723028707946496",
  "in_reply_to_user_id" : 14846101,
  "text" : "@jonathanjulian @github That helps, but dates as default would be nice, maybe as a config option, to avoid ambiguity if page saved\/printed.",
  "id" : 471723028707946496,
  "in_reply_to_status_id" : 471714579958202368,
  "created_at" : "2014-05-28 18:41:48 +0000",
  "in_reply_to_screen_name" : "jonathanjulian",
  "in_reply_to_user_id_str" : "14846101",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 0, 7 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471701921934606336",
  "in_reply_to_user_id" : 13334762,
  "text" : "@github I was looking at a Github Enterprise site. Still, an option for date\/time display for all date\/times (even recent) would be nice.",
  "id" : 471701921934606336,
  "created_at" : "2014-05-28 17:17:56 +0000",
  "in_reply_to_screen_name" : "github",
  "in_reply_to_user_id_str" : "13334762",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 0, 7 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471699694587236352",
  "in_reply_to_user_id" : 13334762,
  "text" : "@github You are awesome, but is there a way to show dates instead of \"...ago\" on a Releases\/Tags page?",
  "id" : 471699694587236352,
  "created_at" : "2014-05-28 17:09:05 +0000",
  "in_reply_to_screen_name" : "github",
  "in_reply_to_user_id_str" : "13334762",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "471042150994436096",
  "text" : "\u007Brvm gemset empty default global \"\"\u007D removes all my gems so I can test that I've told bundler about all needed gems. Reliable gem cmd equiv?",
  "id" : 471042150994436096,
  "created_at" : "2014-05-26 21:36:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kenenitz",
      "screen_name" : "aceofbassgreg",
      "indices" : [ 0, 14 ],
      "id_str" : "715064136",
      "id" : 715064136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "470926093357035520",
  "geo" : { },
  "id_str" : "470930786166648833",
  "in_reply_to_user_id" : 715064136,
  "text" : "@aceofbassgreg Excellent! I'll look for you too. Probably won't be there next week though.",
  "id" : 470930786166648833,
  "in_reply_to_status_id" : 470926093357035520,
  "created_at" : "2014-05-26 14:13:43 +0000",
  "in_reply_to_screen_name" : "aceofbassgreg",
  "in_reply_to_user_id_str" : "715064136",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/470753669626216448\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/jeGHtQhPci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bohz8meCYAAGPmX.jpg",
      "id_str" : "470753646016094208",
      "id" : 470753646016094208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bohz8meCYAAGPmX.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jeGHtQhPci"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470753669626216448",
  "text" : "Super drumming party and celebration of the human spirit at Meridian Hill Park in Washington, DC. Every Sunday! http:\/\/t.co\/jeGHtQhPci",
  "id" : 470753669626216448,
  "created_at" : "2014-05-26 02:29:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehdi Khalili",
      "screen_name" : "MehdiKhalili",
      "indices" : [ 82, 95 ],
      "id_str" : "281270972",
      "id" : 281270972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/KVJhepgjlH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=XvhAsJPXj1M",
      "display_url" : "youtube.com\/watch?v=XvhAsJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "470243584789458944",
  "text" : "Beautiful &amp; poignant commentary: w\/our \"connected\" life, life passes us by RT @MehdiKhalili Look up from your phone:https:\/\/t.co\/KVJhepgjlH",
  "id" : 470243584789458944,
  "created_at" : "2014-05-24 16:43:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "468942621172576256",
  "geo" : { },
  "id_str" : "469150031727964161",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton Thanks.  I got it to work with \"echo Y | ...\" but the command line option is a better way.  Just changed it.",
  "id" : 469150031727964161,
  "in_reply_to_status_id" : 468942621172576256,
  "created_at" : "2014-05-21 16:17:38 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 0, 6 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "466405398078312449",
  "in_reply_to_user_id" : 18001417,
  "text" : "@hertz finally responded to me after 18 days. About stranding me without a car, they say get over it, it happens. For this we pay extra?",
  "id" : 466405398078312449,
  "created_at" : "2014-05-14 02:31:26 +0000",
  "in_reply_to_screen_name" : "Hertz",
  "in_reply_to_user_id_str" : "18001417",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6MLPHMEHla",
      "expanded_url" : "http:\/\/ow.ly\/wvA5j",
      "display_url" : "ow.ly\/wvA5j"
    } ]
  },
  "geo" : { },
  "id_str" : "463445275156041728",
  "text" : "RT @avdi: To think, Imposter Syndrome nearly robbed me of a valuable ally. Glad it didn't win! http:\/\/t.co\/6MLPHMEHla",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/6MLPHMEHla",
        "expanded_url" : "http:\/\/ow.ly\/wvA5j",
        "display_url" : "ow.ly\/wvA5j"
      } ]
    },
    "geo" : { },
    "id_str" : "463422490795339776",
    "text" : "To think, Imposter Syndrome nearly robbed me of a valuable ally. Glad it didn't win! http:\/\/t.co\/6MLPHMEHla",
    "id" : 463422490795339776,
    "created_at" : "2014-05-05 20:58:26 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 463445275156041728,
  "created_at" : "2014-05-05 22:28:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]