Grailbird.data.tweets_2015_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Bruno Miranda",
      "screen_name" : "brupm",
      "indices" : [ 10, 16 ],
      "id_str" : "4513751",
      "id" : 4513751
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 17, 25 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647098084871180288",
  "geo" : { },
  "id_str" : "647098612762087424",
  "in_reply_to_user_id" : 14401983,
  "text" : "@rubyconf @brupm @geeksam Speaking of productive feedback, I recommend at any conf having badges with the name on both sides.",
  "id" : 647098612762087424,
  "in_reply_to_status_id" : 647098084871180288,
  "created_at" : "2015-09-24 17:21:46 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Bruno Miranda",
      "screen_name" : "brupm",
      "indices" : [ 10, 16 ],
      "id_str" : "4513751",
      "id" : 4513751
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 17, 25 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647091658987712512",
  "geo" : { },
  "id_str" : "647098084871180288",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf @brupm @geeksam Sam, many more thanks to you and the others who are organizing RubyConf.  I know it's a huge amount of work.",
  "id" : 647098084871180288,
  "in_reply_to_status_id" : 647091658987712512,
  "created_at" : "2015-09-24 17:19:40 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Miranda",
      "screen_name" : "brupm",
      "indices" : [ 0, 6 ],
      "id_str" : "4513751",
      "id" : 4513751
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 7, 16 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 17, 25 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647086746585460736",
  "geo" : { },
  "id_str" : "647090765303181312",
  "in_reply_to_user_id" : 14401983,
  "text" : "@brupm @rubyconf @geeksam Bruno, I agree that having times posted would be helpful. Sam, amazingly we have nonstop flights IAD &lt;--&gt; SAT.",
  "id" : 647090765303181312,
  "in_reply_to_status_id" : 647086746585460736,
  "created_at" : "2015-09-24 16:50:35 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bruno Miranda",
      "screen_name" : "brupm",
      "indices" : [ 0, 6 ],
      "id_str" : "4513751",
      "id" : 4513751
    }, {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 7, 16 ],
      "id_str" : "16222737",
      "id" : 16222737
    }, {
      "name" : "Sam Livingston-Gray",
      "screen_name" : "geeksam",
      "indices" : [ 17, 25 ],
      "id_str" : "38699900",
      "id" : 38699900
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "647078541406834688",
  "geo" : { },
  "id_str" : "647086746585460736",
  "in_reply_to_user_id" : 4513751,
  "text" : "@brupm @rubyconf @geeksam I have enough info now to know that I'll want to arrive any time the day before and leave any time the day after.",
  "id" : 647086746585460736,
  "in_reply_to_status_id" : 647078541406834688,
  "created_at" : "2015-09-24 16:34:37 +0000",
  "in_reply_to_screen_name" : "brupm",
  "in_reply_to_user_id_str" : "4513751",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 0, 9 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "646857911717654528",
  "in_reply_to_user_id" : 16222737,
  "text" : "@rubyconf Could you clarify the schedule?  Is it all day Sun\/Mon\/Tues, or is Sun a partial day? Need to plan arrival &amp; departure.",
  "id" : 646857911717654528,
  "created_at" : "2015-09-24 01:25:18 +0000",
  "in_reply_to_screen_name" : "rubyconf",
  "in_reply_to_user_id_str" : "16222737",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fairfax County",
      "screen_name" : "fairfaxcounty",
      "indices" : [ 5, 19 ],
      "id_str" : "16016705",
      "id" : 16016705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/645008849385168896\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/YFHxCDf8VH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CPOIE-bWcAASkh7.jpg",
      "id_str" : "645008790702682112",
      "id" : 645008790702682112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CPOIE-bWcAASkh7.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YFHxCDf8VH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "645008849385168896",
  "text" : "Hey, @fairfaxcounty, could we clean up our bus emissions? http:\/\/t.co\/YFHxCDf8VH",
  "id" : 645008849385168896,
  "created_at" : "2015-09-18 22:57:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/643113591806275584\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0YWScBc4tO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/COzMZy6UYAA_clv.png",
      "id_str" : "643113590342311936",
      "id" : 643113590342311936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/COzMZy6UYAA_clv.png",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 504,
        "resize" : "fit",
        "w" : 1122
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0YWScBc4tO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "643113591806275584",
  "text" : "Wow, I almost fell for a bogus Adobe Flash Player upgrade notice, and this was on Mac OS, not Windows. http:\/\/t.co\/0YWScBc4tO",
  "id" : 643113591806275584,
  "created_at" : "2015-09-13 17:26:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Hessler",
      "screen_name" : "spune",
      "indices" : [ 1, 7 ],
      "id_str" : "14197941",
      "id" : 14197941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/a2jdQaVKue",
      "expanded_url" : "https:\/\/stedolan.github.io\/jq\/",
      "display_url" : "stedolan.github.io\/jq\/"
    } ]
  },
  "in_reply_to_status_id_str" : "641644382815453185",
  "geo" : { },
  "id_str" : "641653208625115137",
  "in_reply_to_user_id" : 14197941,
  "text" : ".@spune 'Thanks! ' * 1_000_000!  jq looks pretty amazing for JSON data manipulation. https:\/\/t.co\/a2jdQaVKue",
  "id" : 641653208625115137,
  "in_reply_to_status_id" : 641644382815453185,
  "created_at" : "2015-09-09 16:43:40 +0000",
  "in_reply_to_screen_name" : "spune",
  "in_reply_to_user_id_str" : "14197941",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/KWnNVvArvs",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/3d4642196fdb8c4a8aa8",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "641643409246146561",
  "text" : "Tiny Ruby script to convert JSON to pretty JSON as a Unix filter command: https:\/\/t.co\/KWnNVvArvs",
  "id" : 641643409246146561,
  "created_at" : "2015-09-09 16:04:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/638828760368705536\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/aYJPbZ7WDG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CN2TXzkUkAQQpo9.png",
      "id_str" : "638828759345303556",
      "id" : 638828759345303556,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CN2TXzkUkAQQpo9.png",
      "sizes" : [ {
        "h" : 102,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 102,
        "resize" : "fit",
        "w" : 297
      }, {
        "h" : 102,
        "resize" : "crop",
        "w" : 102
      } ],
      "display_url" : "pic.twitter.com\/aYJPbZ7WDG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638828760368705536",
  "text" : "I'm sure it's an excellent meetup, but I couldn't help laughing at the \"1 going\". http:\/\/t.co\/aYJPbZ7WDG",
  "id" : 638828760368705536,
  "created_at" : "2015-09-01 21:40:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]