Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/726459032983113728\/photo\/1",
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/s3PzVdxQJa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChTmo4BUkAAhXSK.jpg",
      "id_str" : "726459029820575744",
      "id" : 726459029820575744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChTmo4BUkAAhXSK.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 4128,
        "resize" : "fit",
        "w" : 2322
      } ],
      "display_url" : "pic.twitter.com\/s3PzVdxQJa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726459032983113728",
  "text" : "It's not the heat that makes walking hard, it's sharing narrow sidewalks w\/poles &amp; trees w\/motorcycles zipping by. https:\/\/t.co\/s3PzVdxQJa",
  "id" : 726459032983113728,
  "created_at" : "2016-04-30 17:11:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/726455215755399168\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/VsGhcdTy6t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChTjKraUUAEk9RZ.jpg",
      "id_str" : "726455212504797185",
      "id" : 726455212504797185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChTjKraUUAEk9RZ.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 4128,
        "resize" : "fit",
        "w" : 2322
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VsGhcdTy6t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "726455215755399168",
  "text" : "Got pampered in Cebu at the \"Pink Strawberry\" salon with a manicure &amp; pedicure.  Total cost: under $4.00, plus tip. https:\/\/t.co\/VsGhcdTy6t",
  "id" : 726455215755399168,
  "created_at" : "2016-04-30 16:56:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/726059057967185921\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/4Riw7KLE5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChN63RUWMAAK4uU.jpg",
      "id_str" : "726059054896918528",
      "id" : 726059054896918528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChN63RUWMAAK4uU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      } ],
      "display_url" : "pic.twitter.com\/4Riw7KLE5Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724485168853983232",
  "geo" : { },
  "id_str" : "726059057967185921",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg OTOH, many, like the one in my room, have these ingenious water spritzers; no need for paper, &amp; cleaner! https:\/\/t.co\/4Riw7KLE5Y",
  "id" : 726059057967185921,
  "in_reply_to_status_id" : 724485168853983232,
  "created_at" : "2016-04-29 14:42:23 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/726058659424428032\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/mGq5gcfuTB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChN6gFnWgAAXK0n.jpg",
      "id_str" : "726058656618414080",
      "id" : 726058656618414080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChN6gFnWgAAXK0n.jpg",
      "sizes" : [ {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 4128,
        "resize" : "fit",
        "w" : 2322
      } ],
      "display_url" : "pic.twitter.com\/mGq5gcfuTB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724485168853983232",
  "geo" : { },
  "id_str" : "726058659424428032",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Here in the Philippines many toilets are without seats at all!  This is the public rest room in my hotel. https:\/\/t.co\/mGq5gcfuTB",
  "id" : 726058659424428032,
  "in_reply_to_status_id" : 724485168853983232,
  "created_at" : "2016-04-29 14:40:48 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/sDik89bOIu",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=dYpwzUrF80M",
      "display_url" : "youtube.com\/watch?v=dYpwzU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "726057415477710848",
  "text" : "A Jew and an Arab walk down the street in my home town, New York City, and...that's it. Tears in my eyes.  https:\/\/t.co\/sDik89bOIu",
  "id" : 726057415477710848,
  "created_at" : "2016-04-29 14:35:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 28, 33 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725243834762809345",
  "text" : "Re: Ruby protected methods, @avdi, you once asked for a use case. How about an == method that compares nonpublic data &amp; needs other.attr?",
  "id" : 725243834762809345,
  "created_at" : "2016-04-27 08:42:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/725187447970107392\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/TVcwCifcx8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ChBg0bYUUAAwKgG.jpg",
      "id_str" : "725185993825865728",
      "id" : 725185993825865728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ChBg0bYUUAAwKgG.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TVcwCifcx8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725187447970107392",
  "text" : "Humongous 'guitar\" in the new Robinson's Galleria Mall in Cebu. https:\/\/t.co\/TVcwCifcx8",
  "id" : 725187447970107392,
  "created_at" : "2016-04-27 04:58:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724423033583230976",
  "geo" : { },
  "id_str" : "724501494523817984",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Hey, if it was hard to write, it should be hard to read. \u263A (not)",
  "id" : 724501494523817984,
  "in_reply_to_status_id" : 724423033583230976,
  "created_at" : "2016-04-25 07:33:11 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724337296003182593",
  "geo" : { },
  "id_str" : "724455875402821633",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Yeah, that pisses me off to no end! ;)  A good argument for leaving the toilet seat up in public places.",
  "id" : 724455875402821633,
  "in_reply_to_status_id" : 724337296003182593,
  "created_at" : "2016-04-25 04:31:55 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Montalenti",
      "screen_name" : "amontalenti",
      "indices" : [ 0, 12 ],
      "id_str" : "34270918",
      "id" : 34270918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724452599508819968",
  "geo" : { },
  "id_str" : "724454320226230272",
  "in_reply_to_user_id" : 14401983,
  "text" : "@amontalenti But hotels are expensive or bad. AirBNB? Also, Bayside is very nice but w\/LIRR, no subway. Astoria is nice too, closer to city.",
  "id" : 724454320226230272,
  "in_reply_to_status_id" : 724452599508819968,
  "created_at" : "2016-04-25 04:25:44 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Montalenti",
      "screen_name" : "amontalenti",
      "indices" : [ 0, 12 ],
      "id_str" : "34270918",
      "id" : 34270918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724452599508819968",
  "geo" : { },
  "id_str" : "724453278776356864",
  "in_reply_to_user_id" : 14401983,
  "text" : "@amontalenti Where will you be spending time? I'm assuming Manhattan too expensive. Great ethnic rest's in those parts of Queens.",
  "id" : 724453278776356864,
  "in_reply_to_status_id" : 724452599508819968,
  "created_at" : "2016-04-25 04:21:36 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Montalenti",
      "screen_name" : "amontalenti",
      "indices" : [ 0, 12 ],
      "id_str" : "34270918",
      "id" : 34270918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "724226153112846338",
  "geo" : { },
  "id_str" : "724452599508819968",
  "in_reply_to_user_id" : 34270918,
  "text" : "@amontalenti I grew up in Queens.  I'd recommend somewhere near the Jackson Heights subway station (E\/F\/7+), or Woodside (7+LIRR).",
  "id" : 724452599508819968,
  "in_reply_to_status_id" : 724226153112846338,
  "created_at" : "2016-04-25 04:18:54 +0000",
  "in_reply_to_screen_name" : "amontalenti",
  "in_reply_to_user_id_str" : "34270918",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/722293001070903297\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/a2c2XKn2z8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgYZnOLUsAIPIa9.jpg",
      "id_str" : "722292951850725378",
      "id" : 722292951850725378,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgYZnOLUsAIPIa9.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/a2c2XKn2z8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "722293001070903297",
  "text" : "I love this place. Met these folks at the pool last night and then we went to karaoke. Great \"Endless Love\" duet! https:\/\/t.co\/a2c2XKn2z8",
  "id" : 722293001070903297,
  "created_at" : "2016-04-19 05:17:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "MEET THE JACKFRUIT\u2122",
      "screen_name" : "MTJCOM",
      "indices" : [ 63, 70 ],
      "id_str" : "707649352966217728",
      "id" : 707649352966217728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whaddyaknow",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720560482067750915",
  "geo" : { },
  "id_str" : "720967382672416768",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett There's a \"Meet the Jackfruit\" Twitter account (@MTJCOM) and they retweeted my jackfruit tweet!  #whaddyaknow",
  "id" : 720967382672416768,
  "in_reply_to_status_id" : 720560482067750915,
  "created_at" : "2016-04-15 13:29:53 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720786887879688192\/photo\/1",
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/u35sgy9gbF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgC_z1NUIAE2VA9.jpg",
      "id_str" : "720786837556436993",
      "id" : 720786837556436993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgC_z1NUIAE2VA9.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/u35sgy9gbF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720786887879688192",
  "text" : "Courageous construction workers in Cebu. (Note the guy in the center of the photo.) https:\/\/t.co\/u35sgy9gbF",
  "id" : 720786887879688192,
  "created_at" : "2016-04-15 01:32:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720786586774835200\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/JEFz66BXUN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CgC_gZRVIAAxAAJ.jpg",
      "id_str" : "720786503639572480",
      "id" : 720786503639572480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CgC_gZRVIAAxAAJ.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1820,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JEFz66BXUN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720786586774835200",
  "text" : "Some pretty good looking roosters in an alley in Cebu. https:\/\/t.co\/JEFz66BXUN",
  "id" : 720786586774835200,
  "created_at" : "2016-04-15 01:31:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lailson Bandeira",
      "screen_name" : "lailsonbm",
      "indices" : [ 1, 11 ],
      "id_str" : "10492892",
      "id" : 10492892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720560854916313089",
  "geo" : { },
  "id_str" : "720562076226183168",
  "in_reply_to_user_id" : 10492892,
  "text" : ".@lailsonbm Yes, but not this time.  To me it's very candy-like &amp; tastes to me like Juicy Fruit gum. Does it grow in Brazil?",
  "id" : 720562076226183168,
  "in_reply_to_status_id" : 720560854916313089,
  "created_at" : "2016-04-14 10:39:21 +0000",
  "in_reply_to_screen_name" : "lailsonbm",
  "in_reply_to_user_id_str" : "10492892",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720560482067750915\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/sTnbay8VaZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf_x8E4UYAA2hO9.jpg",
      "id_str" : "720560479806971904",
      "id" : 720560479806971904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf_x8E4UYAA2hO9.jpg",
      "sizes" : [ {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sTnbay8VaZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720560482067750915",
  "text" : "Jackfruit vendors near Osme\u00F1a Circle in Cebu, Philippines. https:\/\/t.co\/sTnbay8VaZ",
  "id" : 720560482067750915,
  "created_at" : "2016-04-14 10:33:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720440887935782912\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ey5UgbAlhW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf-FKx0UIAAW7oI.jpg",
      "id_str" : "720440885620514816",
      "id" : 720440885620514816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf-FKx0UIAAW7oI.jpg",
      "sizes" : [ {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ey5UgbAlhW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720440887935782912",
  "text" : "This all male comedy team in Cebu brought the house down, made me want to learn Tagalog so I could understand them. https:\/\/t.co\/ey5UgbAlhW",
  "id" : 720440887935782912,
  "created_at" : "2016-04-14 02:37:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gregory Kenenitz",
      "screen_name" : "aceofbassgreg",
      "indices" : [ 0, 14 ],
      "id_str" : "715064136",
      "id" : 715064136
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720439482609053697\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/CYHeTgh3vD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf-D4-oUsAAy459.jpg",
      "id_str" : "720439480310607872",
      "id" : 720439480310607872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf-D4-oUsAAy459.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CYHeTgh3vD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "720272906618413057",
  "geo" : { },
  "id_str" : "720439482609053697",
  "in_reply_to_user_id" : 715064136,
  "text" : "@aceofbassgreg Yes, we went to the tarsier sanctuary, but they're nocturnal so they weren't very engaging. https:\/\/t.co\/CYHeTgh3vD",
  "id" : 720439482609053697,
  "in_reply_to_status_id" : 720272906618413057,
  "created_at" : "2016-04-14 02:32:12 +0000",
  "in_reply_to_screen_name" : "aceofbassgreg",
  "in_reply_to_user_id_str" : "715064136",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/720157342814187520\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/dMliALcEst",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf6DOyPUIAAOJQC.jpg",
      "id_str" : "720157280453271552",
      "id" : 720157280453271552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf6DOyPUIAAOJQC.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dMliALcEst"
    } ],
    "hashtags" : [ {
      "text" : "durian",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "720157342814187520",
  "text" : "Finally found #durian in the Philippines! In Robinson's Mall Food Court,  Osme\u00F1a Circle, Cebu. https:\/\/t.co\/dMliALcEst",
  "id" : 720157342814187520,
  "created_at" : "2016-04-13 07:51:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 34, 48 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/headius\/status\/719855425743560704\/photo\/1",
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/vEzNQENEYl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1we7PUYAAwv59.jpg",
      "id_str" : "719855192049475584",
      "id" : 719855192049475584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1we7PUYAAwv59.jpg",
      "sizes" : [ {
        "h" : 1088,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 193,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vEzNQENEYl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719856673737670656",
  "text" : "RT @headius: Farewell to my buddy @keithrbennett and my new friends in Cebu! https:\/\/t.co\/vEzNQENEYl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 21, 35 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/headius\/status\/719855425743560704\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/vEzNQENEYl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1we7PUYAAwv59.jpg",
        "id_str" : "719855192049475584",
        "id" : 719855192049475584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1we7PUYAAwv59.jpg",
        "sizes" : [ {
          "h" : 1088,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 580,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 193,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vEzNQENEYl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "719855425743560704",
    "text" : "Farewell to my buddy @keithrbennett and my new friends in Cebu! https:\/\/t.co\/vEzNQENEYl",
    "id" : 719855425743560704,
    "created_at" : "2016-04-12 11:51:22 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736361495756480513\/U0H_Wfk4_normal.jpg",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 719856673737670656,
  "created_at" : "2016-04-12 11:56:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/719831358026047489\/photo\/1",
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/ZjHLh4V2Fg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1atejUEAAz8KR.jpg",
      "id_str" : "719831252790939648",
      "id" : 719831252790939648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1atejUEAAz8KR.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/ZjHLh4V2Fg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719831358026047489",
  "text" : "Sunset over the island of Cebu, seen from the ferry from Tagbilaran, Bohol, to Cebu City, Cebu, Philippines. https:\/\/t.co\/ZjHLh4V2Fg",
  "id" : 719831358026047489,
  "created_at" : "2016-04-12 10:15:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/719830143997386752\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/Vz9mgf7SzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1ZnKIUYAAhq1X.jpg",
      "id_str" : "719830044718161920",
      "id" : 719830044718161920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1ZnKIUYAAhq1X.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Vz9mgf7SzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719830143997386752",
  "text" : "Saw the \"Chocolate Hills\" of Bohol (Philippines) today. They are mostly limestone. https:\/\/t.co\/Vz9mgf7SzR",
  "id" : 719830143997386752,
  "created_at" : "2016-04-12 10:10:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 1, 9 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/719828862243221504\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mfNAFWrXlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cf1YbcWUAAAGdbI.jpg",
      "id_str" : "719828743938637824",
      "id" : 719828743938637824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cf1YbcWUAAAGdbI.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mfNAFWrXlG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "719828862243221504",
  "text" : ".@headius and me in Tagbilaran, Bohol, Philippines. He starts for home tonight, I stay in Cebu for a week or 3. https:\/\/t.co\/mfNAFWrXlG",
  "id" : 719828862243221504,
  "created_at" : "2016-04-12 10:05:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Bibat",
      "screen_name" : "bry_bibat",
      "indices" : [ 3, 13 ],
      "id_str" : "36372383",
      "id" : 36372383
    }, {
      "name" : "Akira Matsuda",
      "screen_name" : "a_matsuda",
      "indices" : [ 37, 47 ],
      "id_str" : "7220202",
      "id" : 7220202
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 75, 89 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyConfPH",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718476651810545665",
  "text" : "RT @bry_bibat: #RubyConfPH karaoke:\n\n@a_matsuda sang Welcome to the Jungle\n@keithrbennett sang Bakit Ngayon Ka Lang?\nI sang \u7D05\n\nThe circle i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Akira Matsuda",
        "screen_name" : "a_matsuda",
        "indices" : [ 22, 32 ],
        "id_str" : "7220202",
        "id" : 7220202
      }, {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 60, 74 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RubyConfPH",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "718475325240266752",
    "text" : "#RubyConfPH karaoke:\n\n@a_matsuda sang Welcome to the Jungle\n@keithrbennett sang Bakit Ngayon Ka Lang?\nI sang \u7D05\n\nThe circle is complete \uD83D\uDE02",
    "id" : 718475325240266752,
    "created_at" : "2016-04-08 16:27:20 +0000",
    "user" : {
      "name" : "Bryan Bibat",
      "screen_name" : "bry_bibat",
      "protected" : false,
      "id_str" : "36372383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809060907825307648\/M8ENM8u3_normal.jpg",
      "id" : 36372383,
      "verified" : false
    }
  },
  "id" : 718476651810545665,
  "created_at" : "2016-04-08 16:32:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 90, 101 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconfph",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/XN8776PESe",
      "expanded_url" : "http:\/\/www.techhumans.com\/2016\/03\/19\/we-humans\/",
      "display_url" : "techhumans.com\/2016\/03\/19\/we-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "718468470799609857",
  "text" : "My lightning talk from today is posted on my TechHumans blog, at https:\/\/t.co\/XN8776PESe. @rubyconfph #rubyconfph",
  "id" : 718468470799609857,
  "created_at" : "2016-04-08 16:00:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 1, 9 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "718349038115033088",
  "geo" : { },
  "id_str" : "718467610916958208",
  "in_reply_to_user_id" : 9989362,
  "text" : ".@headius Happy to show you around Cebu, one of my homes away from home.  Thanks for joining me.",
  "id" : 718467610916958208,
  "in_reply_to_status_id" : 718349038115033088,
  "created_at" : "2016-04-08 15:56:41 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/718019639519752192\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/PbgiCAcFsi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cfbq_D7VIAAsfyf.jpg",
      "id_str" : "718019559718985728",
      "id" : 718019559718985728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cfbq_D7VIAAsfyf.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PbgiCAcFsi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "718019639519752192",
  "text" : "Sunset over Manila harbor as seen from the Mall of Asia. https:\/\/t.co\/PbgiCAcFsi",
  "id" : 718019639519752192,
  "created_at" : "2016-04-07 10:16:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 1, 12 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717669643805020160",
  "text" : ".@rubyconfph Will the lightning talk presenters have any Internet access?",
  "id" : 717669643805020160,
  "created_at" : "2016-04-06 11:05:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura Eck",
      "screen_name" : "laura_nobilis",
      "indices" : [ 3, 17 ],
      "id_str" : "1493664176",
      "id" : 1493664176
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/laura_nobilis\/status\/717637282816131072\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/KAzF36f7A3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfWPTjtUAAAoPoi.jpg",
      "id_str" : "717637281801043968",
      "id" : 717637281801043968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfWPTjtUAAAoPoi.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KAzF36f7A3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717657641162420225",
  "text" : "RT @laura_nobilis: Finally someone with a reasonable outlook on things. https:\/\/t.co\/KAzF36f7A3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/laura_nobilis\/status\/717637282816131072\/photo\/1",
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/KAzF36f7A3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CfWPTjtUAAAoPoi.jpg",
        "id_str" : "717637281801043968",
        "id" : 717637281801043968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfWPTjtUAAAoPoi.jpg",
        "sizes" : [ {
          "h" : 445,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 445,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KAzF36f7A3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "717637282816131072",
    "text" : "Finally someone with a reasonable outlook on things. https:\/\/t.co\/KAzF36f7A3",
    "id" : 717637282816131072,
    "created_at" : "2016-04-06 08:57:15 +0000",
    "user" : {
      "name" : "Laura Eck",
      "screen_name" : "laura_nobilis",
      "protected" : false,
      "id_str" : "1493664176",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638923398148591616\/bhyjjJJ-_normal.jpg",
      "id" : 1493664176,
      "verified" : false
    }
  },
  "id" : 717657641162420225,
  "created_at" : "2016-04-06 10:18:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 0, 11 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    }, {
      "name" : "Nico Hagenburger",
      "screen_name" : "Hagenburger",
      "indices" : [ 12, 24 ],
      "id_str" : "14147875",
      "id" : 14147875
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 25, 33 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Christopher Rigor",
      "screen_name" : "crigor",
      "indices" : [ 34, 41 ],
      "id_str" : "111347742",
      "id" : 111347742
    }, {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 42, 55 ],
      "id_str" : "479019528",
      "id" : 479019528
    }, {
      "name" : "Assaf Gelber",
      "screen_name" : "assafgelber",
      "indices" : [ 56, 68 ],
      "id_str" : "1197150764",
      "id" : 1197150764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717636308491837440",
  "geo" : { },
  "id_str" : "717655600302133248",
  "in_reply_to_user_id" : 1920753961,
  "text" : "@RubyConfPH @Hagenburger @headius @crigor @JuanitoFatas @assafgelber I'd like to join. I'll be coming from Makati.  when\/where?",
  "id" : 717655600302133248,
  "in_reply_to_status_id" : 717636308491837440,
  "created_at" : "2016-04-06 10:10:03 +0000",
  "in_reply_to_screen_name" : "RubyConfPH",
  "in_reply_to_user_id_str" : "1920753961",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 1, 12 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    }, {
      "name" : "Nico Hagenburger",
      "screen_name" : "Hagenburger",
      "indices" : [ 13, 25 ],
      "id_str" : "14147875",
      "id" : 14147875
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 26, 34 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Christopher Rigor",
      "screen_name" : "crigor",
      "indices" : [ 35, 42 ],
      "id_str" : "111347742",
      "id" : 111347742
    }, {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 43, 56 ],
      "id_str" : "479019528",
      "id" : 479019528
    }, {
      "name" : "Assaf Gelber",
      "screen_name" : "assafgelber",
      "indices" : [ 57, 69 ],
      "id_str" : "1197150764",
      "id" : 1197150764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/z7KqHLvzSB",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/centerstage-family-ktv-and-resto-bar-makati",
      "display_url" : "yelp.com\/biz\/centerstag\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "717636308491837440",
  "geo" : { },
  "id_str" : "717648092921618433",
  "in_reply_to_user_id" : 1920753961,
  "text" : ".@RubyConfPH @Hagenburger @headius @crigor @JuanitoFatas @assafgelber How about karaoke at https:\/\/t.co\/z7KqHLvzSB? I'll pay the room fee.",
  "id" : 717648092921618433,
  "in_reply_to_status_id" : 717636308491837440,
  "created_at" : "2016-04-06 09:40:13 +0000",
  "in_reply_to_screen_name" : "RubyConfPH",
  "in_reply_to_user_id_str" : "1920753961",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charo Nuguid",
      "screen_name" : "rcdiugun",
      "indices" : [ 0, 9 ],
      "id_str" : "2951901",
      "id" : 2951901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "717274518310400000",
  "geo" : { },
  "id_str" : "717647375796285440",
  "in_reply_to_user_id" : 2951901,
  "text" : "@rcdiugun Thank you!  Let me know if you'd like to have coffee and catch me up with what you've been doing for the last 5 years. ;)",
  "id" : 717647375796285440,
  "in_reply_to_status_id" : 717274518310400000,
  "created_at" : "2016-04-06 09:37:22 +0000",
  "in_reply_to_screen_name" : "rcdiugun",
  "in_reply_to_user_id_str" : "2951901",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Miller",
      "screen_name" : "ASmallFiction",
      "indices" : [ 3, 17 ],
      "id_str" : "46769303",
      "id" : 46769303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717277414678667265",
  "text" : "RT @ASmallFiction: We scattered our signals across the cosmos, searching for life.\n\nWhen the reply came from the stars, it decoded to one w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "703436059233783808",
    "text" : "We scattered our signals across the cosmos, searching for life.\n\nWhen the reply came from the stars, it decoded to one word:\n\n\"Unsubscribe.\"",
    "id" : 703436059233783808,
    "created_at" : "2016-02-27 04:26:40 +0000",
    "user" : {
      "name" : "A Small Fiction",
      "screen_name" : "ASmallFiction",
      "protected" : false,
      "id_str" : "46769303",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606295929222619136\/oP5wM9aF_normal.jpg",
      "id" : 46769303,
      "verified" : false
    }
  },
  "id" : 717277414678667265,
  "created_at" : "2016-04-05 09:07:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/717267940958056448\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/2doyhMfwGO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CfQ_WlXVAAA6gv7.jpg",
      "id_str" : "717267897878380544",
      "id" : 717267897878380544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CfQ_WlXVAAA6gv7.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2doyhMfwGO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717267940958056448",
  "text" : "So glad to be \"home\" in Manila. With Peter from Switzerland, and Marrien and Patricia. Manicure &amp; pedicure: $11. https:\/\/t.co\/2doyhMfwGO",
  "id" : 717267940958056448,
  "created_at" : "2016-04-05 08:29:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]