Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/Zr2PDfphOg",
      "expanded_url" : "http:\/\/GoToMeeting.com",
      "display_url" : "GoToMeeting.com"
    }, {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/GS6sXQ3C5G",
      "expanded_url" : "http:\/\/community.gotomeeting.com\/gotomeeting\/topics\/use_gotomeeting_online_on_linux",
      "display_url" : "community.gotomeeting.com\/gotomeeting\/to\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "318423710245736448",
  "text" : "Want http:\/\/t.co\/Zr2PDfphOg to support Linux? Add your comment to http:\/\/t.co\/GS6sXQ3C5G. Please publicize\/retweet.",
  "id" : 318423710245736448,
  "created_at" : "2013-03-31 18:05:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/kZnguIB4dB",
      "expanded_url" : "http:\/\/www.acm.uiuc.edu\/errors\/404.html",
      "display_url" : "acm.uiuc.edu\/errors\/404.html"
    } ]
  },
  "geo" : { },
  "id_str" : "317705117472264192",
  "text" : "A depressed web server bares its soul on 404 error\u2026 http:\/\/t.co\/kZnguIB4dB",
  "id" : 317705117472264192,
  "created_at" : "2013-03-29 18:29:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/e3LpIegjgS",
      "expanded_url" : "http:\/\/dc.startupweekend.org\/events\/startup-weekend-dc-spring-2013\/#.UVSfnoL641d",
      "display_url" : "dc.startupweekend.org\/events\/startup\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317364512669982721",
  "text" : "Just signed up for Startup Weekend DC (http:\/\/t.co\/e3LpIegjgS)!  My first startup weekend, it should be a really interesting experience.",
  "id" : 317364512669982721,
  "created_at" : "2013-03-28 19:56:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "316647601221033985",
  "text" : "Surprised when other devs I met wanted to indicate state change in a web app solely by color. I would have added icon, text, and\/or texture.",
  "id" : 316647601221033985,
  "created_at" : "2013-03-26 20:27:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "316004239753228289",
  "geo" : { },
  "id_str" : "316607530237325312",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja You could use JRuby in a ScriptingContainer in your Clojure app and work with prawn that way.",
  "id" : 316607530237325312,
  "in_reply_to_status_id" : 316004239753228289,
  "created_at" : "2013-03-26 17:48:12 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315955760418942976",
  "geo" : { },
  "id_str" : "316001475807547392",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja If you need open source, I'm pretty sure it would be a Java library such as PDFBox or iText. Else, maybe a cmd line i'face to Adobe?",
  "id" : 316001475807547392,
  "in_reply_to_status_id" : 315955760418942976,
  "created_at" : "2013-03-25 01:39:57 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315209997975973888",
  "geo" : { },
  "id_str" : "315217553477734400",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick Would a Java interface with only 1 method work for you?: java.lang.Runnable .",
  "id" : 315217553477734400,
  "in_reply_to_status_id" : 315209997975973888,
  "created_at" : "2013-03-22 21:44:55 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Fowler",
      "screen_name" : "martinfowler",
      "indices" : [ 0, 13 ],
      "id_str" : "16665197",
      "id" : 16665197
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315203564135915521",
  "in_reply_to_user_id" : 16665197,
  "text" : "@martinfowler Thanks for the recommendation to look at SourceTree.  Looks nice!  Also, learned that you're a fan of Ruby.  Cool!",
  "id" : 315203564135915521,
  "created_at" : "2013-03-22 20:49:20 +0000",
  "in_reply_to_screen_name" : "martinfowler",
  "in_reply_to_user_id_str" : "16665197",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Rogues",
      "screen_name" : "rubyrogues",
      "indices" : [ 19, 30 ],
      "id_str" : "284225770",
      "id" : 284225770
    }, {
      "name" : "Martin Fowler",
      "screen_name" : "martinfowler",
      "indices" : [ 32, 45 ],
      "id_str" : "16665197",
      "id" : 16665197
    }, {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 50, 60 ],
      "id_str" : "15067554",
      "id" : 15067554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315203191694303232",
  "text" : "Accompanied by the @rubyrogues' @martinfowler and @sandimetz episodes on my 4+ hour drive to New York City last night.  Great stuff!",
  "id" : 315203191694303232,
  "created_at" : "2013-03-22 20:47:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 0, 9 ],
      "id_str" : "14164724",
      "id" : 14164724
    }, {
      "name" : "JRubyConf",
      "screen_name" : "JRubyConf",
      "indices" : [ 10, 20 ],
      "id_str" : "71363379",
      "id" : 71363379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/g1TJnrC8Qr",
      "expanded_url" : "http:\/\/markmail.org\/search\/?q=jrubyconf%20list%3Aorg.codehaus.jruby.user#query:jrubyconf%20list%3Aorg.codehaus.jruby.user%20order%3Adate-backward+page:1+mid:mtjzdgpobptvr5om+state:results",
      "display_url" : "markmail.org\/search\/?q=jrub\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "314087213698805761",
  "geo" : { },
  "id_str" : "314098287592472576",
  "in_reply_to_user_id" : 14164724,
  "text" : "@sarahmei @JRubyConf There's talk about Raleigh (http:\/\/t.co\/g1TJnrC8Qr), but it's just speculation. I'd be interested in knowing too.",
  "id" : 314098287592472576,
  "in_reply_to_status_id" : 314087213698805761,
  "created_at" : "2013-03-19 19:37:22 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 3, 8 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314096655664304128",
  "text" : "RT @avdi: I said a habitually derogatory thing yesterday. Teenage daughter called me on it. So proud.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "314070907977084930",
    "text" : "I said a habitually derogatory thing yesterday. Teenage daughter called me on it. So proud.",
    "id" : 314070907977084930,
    "created_at" : "2013-03-19 17:48:34 +0000",
    "user" : {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "protected" : false,
      "id_str" : "52593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436586539229777920\/4NQoTOEN_normal.png",
      "id" : 52593,
      "verified" : false
    }
  },
  "id" : 314096655664304128,
  "created_at" : "2013-03-19 19:30:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    }, {
      "name" : "Mike Subelsky",
      "screen_name" : "subelsky",
      "indices" : [ 14, 23 ],
      "id_str" : "14498193",
      "id" : 14498193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "314045881605300224",
  "geo" : { },
  "id_str" : "314095170289283072",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 @subelsky Yikes! How about some intermediate variables for readability?",
  "id" : 314095170289283072,
  "in_reply_to_status_id" : 314045881605300224,
  "created_at" : "2013-03-19 19:24:58 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Morris",
      "screen_name" : "bengm",
      "indices" : [ 0, 6 ],
      "id_str" : "17659039",
      "id" : 17659039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "313082891284410368",
  "geo" : { },
  "id_str" : "313083913402716160",
  "in_reply_to_user_id" : 17659039,
  "text" : "@bengm Yes, I love durian.  I've spent lots of time in Thailand &amp; other parts of SE Asia.  Have you tried durian?  Do you like it?",
  "id" : 313083913402716160,
  "in_reply_to_status_id" : 313082891284410368,
  "created_at" : "2013-03-17 00:26:36 +0000",
  "in_reply_to_screen_name" : "bengm",
  "in_reply_to_user_id_str" : "17659039",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uE031GoldenRonin\uE031",
      "screen_name" : "RoninWolf02",
      "indices" : [ 0, 12 ],
      "id_str" : "193484559",
      "id" : 193484559
    }, {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 13, 25 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/iSgBFLGKWs",
      "expanded_url" : "http:\/\/www.snopes.com\/politics\/military\/breakfast.asp",
      "display_url" : "snopes.com\/politics\/milit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "312985227452633088",
  "geo" : { },
  "id_str" : "313049342745387008",
  "in_reply_to_user_id" : 193484559,
  "text" : "@RoninWolf02 @JimGaffigan Partly, but not completely true, according to Snopes: http:\/\/t.co\/iSgBFLGKWs - still, inexcusable IMO",
  "id" : 313049342745387008,
  "in_reply_to_status_id" : 312985227452633088,
  "created_at" : "2013-03-16 22:09:14 +0000",
  "in_reply_to_screen_name" : "RoninWolf02",
  "in_reply_to_user_id_str" : "193484559",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 141, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313045535101685761",
  "text" : "At Hai Duong in Eden Center, Falls Church, VA, eating pho w\/fresh tofu, broccoli, mushrooms &amp; onions instead of meat. Yum! Next: durian! #fb",
  "id" : 313045535101685761,
  "created_at" : "2013-03-16 21:54:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313044118538444800",
  "text" : "NY Times Android app consumed half of all my Verizon Wireless data usage: &gt; 200 MB in a week.  Disabling updates...",
  "id" : 313044118538444800,
  "created_at" : "2013-03-16 21:48:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/RMxqR4W60J",
      "expanded_url" : "http:\/\/overapi.com\/",
      "display_url" : "overapi.com"
    } ]
  },
  "geo" : { },
  "id_str" : "312051077614817280",
  "text" : "Lots of API cheat sheets in one place: http:\/\/t.co\/RMxqR4W60J",
  "id" : 312051077614817280,
  "created_at" : "2013-03-14 04:02:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311952791369306112",
  "text" : "Prerelease of the Joy of Clojure, Second Edition (for 1.5) is on sale (half price) for a week from Manning. Discount code is joc2elaunch50.",
  "id" : 311952791369306112,
  "created_at" : "2013-03-13 21:31:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart Sierra",
      "screen_name" : "stuartsierra",
      "indices" : [ 36, 49 ],
      "id_str" : "22637653",
      "id" : 22637653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/LgLCmVcAVV",
      "expanded_url" : "http:\/\/wit.io\/posts\/clojure-all-grown-up",
      "display_url" : "wit.io\/posts\/clojure-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "311645535020933121",
  "text" : "Why Clojure is such a good idea; RT @stuartsierra Clojure grown up http:\/\/t.co\/LgLCmVcAVV",
  "id" : 311645535020933121,
  "created_at" : "2013-03-13 01:11:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311625698622185472",
  "text" : "JSClass looks really cool.  Anyone have any feedback about it?  Do people load it onto the client side into a browser, or is it too big?",
  "id" : 311625698622185472,
  "created_at" : "2013-03-12 23:52:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luigi Ray-Monta\u00F1ez",
      "screen_name" : "1uigi",
      "indices" : [ 3, 9 ],
      "id_str" : "1261161",
      "id" : 1261161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309017958632550400",
  "text" : "RT @1uigi: A software engineer walks into a bar: \"I'll have 1.0E20 root beers.\" Bartender: \"That's a root beer float.\" Engineer: \"Make i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "308997138090692608",
    "text" : "A software engineer walks into a bar: \"I'll have 1.0E20 root beers.\" Bartender: \"That's a root beer float.\" Engineer: \"Make it a double.\"",
    "id" : 308997138090692608,
    "created_at" : "2013-03-05 17:47:13 +0000",
    "user" : {
      "name" : "Luigi Ray-Monta\u00F1ez",
      "screen_name" : "1uigi",
      "protected" : false,
      "id_str" : "1261161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/757997246340300801\/_zbsLiz9_normal.jpg",
      "id" : 1261161,
      "verified" : false
    }
  },
  "id" : 309017958632550400,
  "created_at" : "2013-03-05 19:09:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308280138821410816",
  "text" : "Leaving Dallas today. Great day yesterday: caught up w\/an old friend here, nice downtown walk, Kennedy museum, &amp; Ft Worth rodeo! #fb",
  "id" : 308280138821410816,
  "created_at" : "2013-03-03 18:18:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 135, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308279396832276481",
  "text" : "What's the best photo sharing site for: no need for others to log in or have account, access to full size photos, and nice slideshow?  #fb",
  "id" : 308279396832276481,
  "created_at" : "2013-03-03 18:15:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/308023168512163842\/photo\/1",
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/epuY5uqF41",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEZRcJZCAAAdDYE.jpg",
      "id_str" : "308023168520552448",
      "id" : 308023168520552448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEZRcJZCAAAdDYE.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/epuY5uqF41"
    } ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 62, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308023168512163842",
  "text" : "Bar stool sighted at the Longhorn Saloon, Fort Worth, Texas.  #fb http:\/\/t.co\/epuY5uqF41",
  "id" : 308023168512163842,
  "created_at" : "2013-03-03 01:17:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Ruby Conf",
      "screen_name" : "BigRubyConf",
      "indices" : [ 22, 34 ],
      "id_str" : "882257671",
      "id" : 882257671
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/307669270731575297\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/mH7gSyoceW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BEUPklbCUAA6dNy.jpg",
      "id_str" : "307669270739963904",
      "id" : 307669270739963904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BEUPklbCUAA6dNy.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mH7gSyoceW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307669270731575297",
  "text" : "Re: a lunch conv'n at @bigrubyconf, I found durians at Carrolton Plaza Spmkt &amp; smoothees at Bon Mua Rest. Enjoy! :-) http:\/\/t.co\/mH7gSyoceW",
  "id" : 307669270731575297,
  "created_at" : "2013-03-02 01:50:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Ruby Conf",
      "screen_name" : "BigRubyConf",
      "indices" : [ 0, 12 ],
      "id_str" : "882257671",
      "id" : 882257671
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/Lc37u0y0KT",
      "expanded_url" : "http:\/\/tika.apache.org\/1.3\/formats.html",
      "display_url" : "tika.apache.org\/1.3\/formats.ht\u2026"
    }, {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/qi1mz9Mcg2",
      "expanded_url" : "https:\/\/github.com\/ricn\/rika",
      "display_url" : "github.com\/ricn\/rika"
    }, {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/w8ed7K5QS4",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/5026007",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/RnlHDVgL2Y",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/05\/conways-game-of-life-viewer\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307604805143130112",
  "in_reply_to_user_id" : 882257671,
  "text" : "@bigrubyconf Links for my lightning talk: http:\/\/t.co\/Lc37u0y0KT, https:\/\/t.co\/qi1mz9Mcg2, https:\/\/t.co\/w8ed7K5QS4, http:\/\/t.co\/RnlHDVgL2Y.",
  "id" : 307604805143130112,
  "created_at" : "2013-03-01 21:34:35 +0000",
  "in_reply_to_screen_name" : "BigRubyConf",
  "in_reply_to_user_id_str" : "882257671",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nycresistor",
      "screen_name" : "nycresistor",
      "indices" : [ 33, 45 ],
      "id_str" : "13557862",
      "id" : 13557862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/9y8r18aRuN",
      "expanded_url" : "http:\/\/www.nycresistor.com\/2013\/02\/23\/raspberry-pis-vending\/",
      "display_url" : "nycresistor.com\/2013\/02\/23\/ras\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "307510191019143169",
  "text" : "This week's geekly prize goes to @nycresistor for having Raspberry Pi's in their vending machine! http:\/\/t.co\/9y8r18aRuN",
  "id" : 307510191019143169,
  "created_at" : "2013-03-01 15:18:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]