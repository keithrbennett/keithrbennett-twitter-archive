Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Peeters",
      "screen_name" : "peeterskris",
      "indices" : [ 117, 129 ],
      "id_str" : "115080251",
      "id" : 115080251
    }, {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "indices" : [ 130, 139 ],
      "id_str" : "16176754",
      "id" : 16176754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/iVJTXhyFVu",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Anscombe%27s_quartet",
      "display_url" : "en.wikipedia.org\/wiki\/Anscombe%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "539058567199092736",
  "geo" : { },
  "id_str" : "539275882993836032",
  "in_reply_to_user_id" : 115080251,
  "text" : "This Wikipedia link looks authoritative and goes into much more detail, incl. source data: http:\/\/t.co\/iVJTXhyFVu cc @peeterskris @pickover",
  "id" : 539275882993836032,
  "in_reply_to_status_id" : 539058567199092736,
  "created_at" : "2014-12-01 04:32:44 +0000",
  "in_reply_to_screen_name" : "peeterskris",
  "in_reply_to_user_id_str" : "115080251",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Peeters",
      "screen_name" : "peeterskris",
      "indices" : [ 3, 15 ],
      "id_str" : "115080251",
      "id" : 115080251
    }, {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "indices" : [ 17, 26 ],
      "id_str" : "16176754",
      "id" : 16176754
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539274932996571136",
  "text" : "RT @peeterskris: @pickover not the same median. My mistake. Google Anscombe's Quartet for details.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cliff Pickover",
        "screen_name" : "pickover",
        "indices" : [ 0, 9 ],
        "id_str" : "16176754",
        "id" : 16176754
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "539057688215580672",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 51.1691728, 5.2715932 ]
    },
    "id_str" : "539058567199092736",
    "in_reply_to_user_id" : 16176754,
    "text" : "@pickover not the same median. My mistake. Google Anscombe's Quartet for details.",
    "id" : 539058567199092736,
    "in_reply_to_status_id" : 539057688215580672,
    "created_at" : "2014-11-30 14:09:12 +0000",
    "in_reply_to_screen_name" : "pickover",
    "in_reply_to_user_id_str" : "16176754",
    "user" : {
      "name" : "Kris Peeters",
      "screen_name" : "peeterskris",
      "protected" : false,
      "id_str" : "115080251",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000230711902\/a3810b0b271e4c177fb04fb651908ee0_normal.jpeg",
      "id" : 115080251,
      "verified" : false
    }
  },
  "id" : 539274932996571136,
  "created_at" : "2014-12-01 04:28:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "indices" : [ 3, 18 ],
      "id_str" : "19768990",
      "id" : 19768990
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Mr_Mike_Clarke\/status\/539157397743628288\/photo\/1",
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/lH4T7Ixz8R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3t4yxRIIAA1tHk.jpg",
      "id_str" : "539157394014871552",
      "id" : 539157394014871552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3t4yxRIIAA1tHk.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 1162
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lH4T7Ixz8R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539261025615609856",
  "text" : "RT @Mr_Mike_Clarke: Nailed it! http:\/\/t.co\/lH4T7Ixz8R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Mr_Mike_Clarke\/status\/539157397743628288\/photo\/1",
        "indices" : [ 11, 33 ],
        "url" : "http:\/\/t.co\/lH4T7Ixz8R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3t4yxRIIAA1tHk.jpg",
        "id_str" : "539157394014871552",
        "id" : 539157394014871552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3t4yxRIIAA1tHk.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 728,
          "resize" : "fit",
          "w" : 1162
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/lH4T7Ixz8R"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539157397743628288",
    "text" : "Nailed it! http:\/\/t.co\/lH4T7Ixz8R",
    "id" : 539157397743628288,
    "created_at" : "2014-11-30 20:41:55 +0000",
    "user" : {
      "name" : "Michael Clarke",
      "screen_name" : "Mr_Mike_Clarke",
      "protected" : false,
      "id_str" : "19768990",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755456702552674305\/Pc7ciPL3_normal.jpg",
      "id" : 19768990,
      "verified" : false
    }
  },
  "id" : 539261025615609856,
  "created_at" : "2014-12-01 03:33:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "indices" : [ 3, 12 ],
      "id_str" : "16176754",
      "id" : 16176754
    }, {
      "name" : "Kris Peeters",
      "screen_name" : "peeterskris",
      "indices" : [ 111, 123 ],
      "id_str" : "115080251",
      "id" : 115080251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539258406218264576",
  "text" : "RT @pickover: These sets all have the same mean, median, and variance. Lesson: Always Visualize the Data. (thx @peeterskris) http:\/\/t.co\/Rm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kris Peeters",
        "screen_name" : "peeterskris",
        "indices" : [ 97, 109 ],
        "id_str" : "115080251",
        "id" : 115080251
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pickover\/status\/539057688215580672\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/RmAqsunh9z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3seHFQCYAAAdLN.jpg",
        "id_str" : "539057687418265600",
        "id" : 539057687418265600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3seHFQCYAAAdLN.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RmAqsunh9z"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539057688215580672",
    "text" : "These sets all have the same mean, median, and variance. Lesson: Always Visualize the Data. (thx @peeterskris) http:\/\/t.co\/RmAqsunh9z",
    "id" : 539057688215580672,
    "created_at" : "2014-11-30 14:05:42 +0000",
    "user" : {
      "name" : "Cliff Pickover",
      "screen_name" : "pickover",
      "protected" : false,
      "id_str" : "16176754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69072946\/twitter3_normal.jpg",
      "id" : 16176754,
      "verified" : false
    }
  },
  "id" : 539258406218264576,
  "created_at" : "2014-12-01 03:23:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "indices" : [ 50, 57 ],
      "id_str" : "119166791",
      "id" : 119166791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538870458570260483",
  "text" : "Disappointed at my 1st Acela experience in years, @amtrak. Super bright fluorescent lights in all cars but quiet car...now quiet car too.",
  "id" : 538870458570260483,
  "created_at" : "2014-11-30 01:41:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/538844200885047296\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/tlSmGGNq60",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3pb8OJCMAALhuh.jpg",
      "id_str" : "538844195570462720",
      "id" : 538844195570462720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3pb8OJCMAALhuh.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tlSmGGNq60"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538844200885047296",
  "text" : "Dinner at the most interesting Broadway in New York City, the one in Elmhurst and Jackson Heights, Queens. http:\/\/t.co\/tlSmGGNq60",
  "id" : 538844200885047296,
  "created_at" : "2014-11-29 23:57:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538737888603947008",
  "text" : "RT @JimGaffigan: My Kids: Can we come back to Disney?\nMe: Sure with your new dad.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538728789598277632",
    "text" : "My Kids: Can we come back to Disney?\nMe: Sure with your new dad.",
    "id" : 538728789598277632,
    "created_at" : "2014-11-29 16:18:47 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 538737888603947008,
  "created_at" : "2014-11-29 16:54:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brilliant Ads",
      "screen_name" : "Brilliant_Ads",
      "indices" : [ 3, 17 ],
      "id_str" : "564686965",
      "id" : 564686965
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Brilliant_Ads\/status\/538463628085964800\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/ao68C1HDiV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B3kB0RlIcAEVp7o.jpg",
      "id_str" : "538463628031455233",
      "id" : 538463628031455233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3kB0RlIcAEVp7o.jpg",
      "sizes" : [ {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 424,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/ao68C1HDiV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538514056295251968",
  "text" : "RT @Brilliant_Ads: Rowenta 2100 Watt Vacuum Cleaner http:\/\/t.co\/ao68C1HDiV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Brilliant_Ads\/status\/538463628085964800\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/ao68C1HDiV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B3kB0RlIcAEVp7o.jpg",
        "id_str" : "538463628031455233",
        "id" : 538463628031455233,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B3kB0RlIcAEVp7o.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 424,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/ao68C1HDiV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "538463628085964800",
    "text" : "Rowenta 2100 Watt Vacuum Cleaner http:\/\/t.co\/ao68C1HDiV",
    "id" : 538463628085964800,
    "created_at" : "2014-11-28 22:45:07 +0000",
    "user" : {
      "name" : "Brilliant Ads",
      "screen_name" : "Brilliant_Ads",
      "protected" : false,
      "id_str" : "564686965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/568757608471736320\/HVxk-qDA_normal.jpeg",
      "id" : 564686965,
      "verified" : false
    }
  },
  "id" : 538514056295251968,
  "created_at" : "2014-11-29 02:05:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radamanthus Batnag",
      "screen_name" : "radamanthus",
      "indices" : [ 0, 12 ],
      "id_str" : "6012542",
      "id" : 6012542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "534622543177457664",
  "geo" : { },
  "id_str" : "538457384419885059",
  "in_reply_to_user_id" : 6012542,
  "text" : "@radamanthus Sorry I wasn't able to. Going to RubyConf Philippines? We'll have karaoke there? I want to sing Bakit Ngayon Ka Lang. ;)",
  "id" : 538457384419885059,
  "in_reply_to_status_id" : 534622543177457664,
  "created_at" : "2014-11-28 22:20:19 +0000",
  "in_reply_to_screen_name" : "radamanthus",
  "in_reply_to_user_id_str" : "6012542",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 3, 12 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    }, {
      "name" : "Skud",
      "screen_name" : "Skud",
      "indices" : [ 32, 37 ],
      "id_str" : "823980",
      "id" : 823980
    }, {
      "name" : "Trans*H4CK",
      "screen_name" : "TransH4CK",
      "indices" : [ 122, 132 ],
      "id_str" : "1373127894",
      "id" : 1373127894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jsWBnCwlIM",
      "expanded_url" : "http:\/\/infotrope.net\/2014\/11\/28\/why-i-dont-like-hackathons-by-alex-bayley-aged-39-12\/",
      "display_url" : "infotrope.net\/2014\/11\/28\/why\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "538445399988903936",
  "text" : "RT @zspencer: This blog post by @Skud is exactly what\u2019s wrong with hackathon culture: http:\/\/t.co\/jsWBnCwlIM\n\nGroups like @TransH4CK buck t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Skud",
        "screen_name" : "Skud",
        "indices" : [ 18, 23 ],
        "id_str" : "823980",
        "id" : 823980
      }, {
        "name" : "Trans*H4CK",
        "screen_name" : "TransH4CK",
        "indices" : [ 108, 118 ],
        "id_str" : "1373127894",
        "id" : 1373127894
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/jsWBnCwlIM",
        "expanded_url" : "http:\/\/infotrope.net\/2014\/11\/28\/why-i-dont-like-hackathons-by-alex-bayley-aged-39-12\/",
        "display_url" : "infotrope.net\/2014\/11\/28\/why\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "538430352398639104",
    "text" : "This blog post by @Skud is exactly what\u2019s wrong with hackathon culture: http:\/\/t.co\/jsWBnCwlIM\n\nGroups like @TransH4CK buck the trend.",
    "id" : 538430352398639104,
    "created_at" : "2014-11-28 20:32:54 +0000",
    "user" : {
      "name" : "Zee",
      "screen_name" : "_zspencer",
      "protected" : true,
      "id_str" : "756161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540237689392361472\/f96ILqGI_normal.jpeg",
      "id" : 756161,
      "verified" : false
    }
  },
  "id" : 538445399988903936,
  "created_at" : "2014-11-28 21:32:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537828959866458113",
  "geo" : { },
  "id_str" : "537839163207593984",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia 10 times cooler then. ;)",
  "id" : 537839163207593984,
  "in_reply_to_status_id" : 537828959866458113,
  "created_at" : "2014-11-27 05:23:43 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marius Lucian Pop",
      "screen_name" : "mlpinit",
      "indices" : [ 0, 8 ],
      "id_str" : "125417337",
      "id" : 125417337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537703822127546368",
  "geo" : { },
  "id_str" : "537828792950358016",
  "in_reply_to_user_id" : 125417337,
  "text" : "@mlpinit Bon voyage, my friend.",
  "id" : 537828792950358016,
  "in_reply_to_status_id" : 537703822127546368,
  "created_at" : "2014-11-27 04:42:31 +0000",
  "in_reply_to_screen_name" : "mlpinit",
  "in_reply_to_user_id_str" : "125417337",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537789287228403712",
  "geo" : { },
  "id_str" : "537828471498899456",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Sean, you speak Spanish? That's mucho cool. ;)",
  "id" : 537828471498899456,
  "in_reply_to_status_id" : 537789287228403712,
  "created_at" : "2014-11-27 04:41:14 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Benjamin Tan Wei Hao",
      "screen_name" : "bentanweihao",
      "indices" : [ 0, 13 ],
      "id_str" : "54950832",
      "id" : 54950832
    }, {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 14, 25 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537768055527317504",
  "geo" : { },
  "id_str" : "537770120069001216",
  "in_reply_to_user_id" : 54950832,
  "text" : "@bentanweihao @RubyConfPH You should totally give an Elixir talk.  Elixir is Ruby-ish.  In any case it would be great to see you there.",
  "id" : 537770120069001216,
  "in_reply_to_status_id" : 537768055527317504,
  "created_at" : "2014-11-27 00:49:22 +0000",
  "in_reply_to_screen_name" : "bentanweihao",
  "in_reply_to_user_id_str" : "54950832",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 127, 138 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537765259046825986",
  "text" : "Just submitted my talk proposal for RubyConf Philippines.  CFP closes Dec. 4.  It's at Boracay, a beautiful beach resort area. @RubyConfPH",
  "id" : 537765259046825986,
  "created_at" : "2014-11-27 00:30:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "537000524361760768",
  "geo" : { },
  "id_str" : "537003769436057601",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett BTW, I meant a person or company, not a software package.",
  "id" : 537003769436057601,
  "in_reply_to_status_id" : 537000524361760768,
  "created_at" : "2014-11-24 22:04:10 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/01zB4Z6a0X",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=nGEy-vFJCSE",
      "display_url" : "youtube.com\/watch?v=nGEy-v\u2026"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/5w4WaJZqm7",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas-functional-conf-bangalore-oct-2014",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "537000524361760768",
  "text" : "Know a quality, reasonably priced video editor to mix a PDF into a video of me presenting? https:\/\/t.co\/01zB4Z6a0X https:\/\/t.co\/5w4WaJZqm7",
  "id" : 537000524361760768,
  "created_at" : "2014-11-24 21:51:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5439\u304D\u66FF\u3048",
      "screen_name" : "e_dub_kendo",
      "indices" : [ 0, 12 ],
      "id_str" : "126215206",
      "id" : 126215206
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 13, 20 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536650950770180096",
  "geo" : { },
  "id_str" : "536746633661546496",
  "in_reply_to_user_id" : 126215206,
  "text" : "@e_dub_kendo @elight I agree that it is noble to respond to anger with understanding, as long as we don't tolerate\/enable bad behavior.",
  "id" : 536746633661546496,
  "in_reply_to_status_id" : 536650950770180096,
  "created_at" : "2014-11-24 05:02:24 +0000",
  "in_reply_to_screen_name" : "e_dub_kendo",
  "in_reply_to_user_id_str" : "126215206",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5439\u304D\u66FF\u3048",
      "screen_name" : "e_dub_kendo",
      "indices" : [ 0, 12 ],
      "id_str" : "126215206",
      "id" : 126215206
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 13, 20 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "536647282561925120",
  "geo" : { },
  "id_str" : "536650431045578753",
  "in_reply_to_user_id" : 126215206,
  "text" : "@e_dub_kendo @elight Yes, but expressing anger is also a choice, and is sometimes born of a failure to empathize.",
  "id" : 536650431045578753,
  "in_reply_to_status_id" : 536647282561925120,
  "created_at" : "2014-11-23 22:40:07 +0000",
  "in_reply_to_screen_name" : "e_dub_kendo",
  "in_reply_to_user_id_str" : "126215206",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/535524895539470336\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/UXYrXFrVwK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B26RDXSCEAITtC-.jpg",
      "id_str" : "535524892678950914",
      "id" : 535524892678950914,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B26RDXSCEAITtC-.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/UXYrXFrVwK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535524895539470336",
  "text" : "Kudos to the San Diego airport. AC and USB power in the airport lounge. Free wifi too. http:\/\/t.co\/UXYrXFrVwK",
  "id" : 535524895539470336,
  "created_at" : "2014-11-20 20:07:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "tom_enebo",
      "screen_name" : "tom_enebo",
      "indices" : [ 9, 19 ],
      "id_str" : "14498747",
      "id" : 14498747
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535477693613998080",
  "geo" : { },
  "id_str" : "535480284523667456",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @tom_enebo I can be in the Omni lobby in 5-10 mins. If not there, where to meet you? Want to go to Little Italy? I can drive.",
  "id" : 535480284523667456,
  "in_reply_to_status_id" : 535477693613998080,
  "created_at" : "2014-11-20 17:10:23 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535465312615800833",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Sorry I missed you last night. Interested in a quick breakfast?  Also, I drive to the airport at 10:30, need a ride?",
  "id" : 535465312615800833,
  "created_at" : "2014-11-20 16:10:53 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 1, 15 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535212581972365312",
  "text" : ".@yukihiro_matz at #rubyconf: \"So many people complain about the GIL (global interpreter lock), but it's there to protect you.\"",
  "id" : 535212581972365312,
  "created_at" : "2014-11-19 23:26:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/zfBNdrsXnY",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/11\/22\/rubys-injectreduce-and-each_with_object\/",
      "display_url" : "bbs-software.com\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535190140424290304",
  "text" : "To clarify what I was trying to say about each_with_object vs. inject, see my blog article: http:\/\/t.co\/zfBNdrsXnY #rubyconf",
  "id" : 535190140424290304,
  "created_at" : "2014-11-19 21:57:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WePay",
      "screen_name" : "WePay",
      "indices" : [ 92, 98 ],
      "id_str" : "16582289",
      "id" : 16582289
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/535187873818226689\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7stdwnl9sN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B21ehxrIQAEZWAD.jpg",
      "id_str" : "535187865089884161",
      "id" : 535187865089884161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B21ehxrIQAEZWAD.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7stdwnl9sN"
    } ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/dbt3x6MzV8",
      "expanded_url" : "http:\/\/www.eurobarespresso.com\/espressocoffeehotchocolate",
      "display_url" : "eurobarespresso.com\/espressocoffee\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "535187873818226689",
  "text" : "1 of #rubyconf's greatest hits, outstanding coffee drinks by http:\/\/t.co\/dbt3x6MzV8. Thanks @WePay for sponsoring it! http:\/\/t.co\/7stdwnl9sN",
  "id" : 535187873818226689,
  "created_at" : "2014-11-19 21:48:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 0, 9 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    }, {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 10, 22 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "535121209394884608",
  "geo" : { },
  "id_str" : "535123687960498177",
  "in_reply_to_user_id" : 756161,
  "text" : "@zspencer @RonJeffries What Z said. There's no automatic notification.  Unlike svn, git doesn't talk to the remote\/server unless told to.",
  "id" : 535123687960498177,
  "in_reply_to_status_id" : 535121209394884608,
  "created_at" : "2014-11-19 17:33:23 +0000",
  "in_reply_to_screen_name" : "_zspencer",
  "in_reply_to_user_id_str" : "756161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 11, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534783705827393538",
  "text" : ".@rubyconf #rubyconf If you use Ruby to do DNS, I'd love to talk to you. I'm helping renovate &amp; enhance the dnsruby gem &amp; would like input.",
  "id" : 534783705827393538,
  "created_at" : "2014-11-18 19:02:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 1, 11 ],
      "id_str" : "15067554",
      "id" : 15067554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534770694639198208",
  "text" : ".@sandimetz at #rubyconf: work on the app that is your life: health, happiness, and the world we leave to our children.\"",
  "id" : 534770694639198208,
  "created_at" : "2014-11-18 18:10:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sandi Metz",
      "screen_name" : "sandimetz",
      "indices" : [ 13, 23 ],
      "id_str" : "15067554",
      "id" : 15067554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 3, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534768754324811777",
  "text" : "At #rubyconf @sandimetz keynote, Sandi shows the ways printing was done before computers and says: \"You can never complain about CSS again.\"",
  "id" : 534768754324811777,
  "created_at" : "2014-11-18 18:03:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/534617453234384897\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/YoiS3KfHrv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2tXvO2CMAEkMp8.jpg",
      "id_str" : "534617449723736065",
      "id" : 534617449723736065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2tXvO2CMAEkMp8.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YoiS3KfHrv"
    } ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 13, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534617453234384897",
  "text" : "\"Unofficial\" #rubyconf karaoke party.  Party on! http:\/\/t.co\/YoiS3KfHrv",
  "id" : 534617453234384897,
  "created_at" : "2014-11-18 08:01:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 62, 71 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/534550969820790784\/photo\/1",
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/6U3mgC7Z3H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2sbRYACMAIQX8O.jpg",
      "id_str" : "534550966087856130",
      "id" : 534550966087856130,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2sbRYACMAIQX8O.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6U3mgC7Z3H"
    } ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534550969820790784",
  "text" : "At the feet of the Ruby masters at the Nobu BOF at #rubyconf. @rubyconf http:\/\/t.co\/6U3mgC7Z3H",
  "id" : 534550969820790784,
  "created_at" : "2014-11-18 03:37:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534547951180578817",
  "text" : ".@rubyconf Organizers, will we be able to use the projector for our BOF in Room 23 at 8:00?  If so, how?",
  "id" : 534547951180578817,
  "created_at" : "2014-11-18 03:25:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 1, 10 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/5w4WaJZqm7",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas-functional-conf-bangalore-oct-2014",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534480019729678338",
  "text" : ".@rubyconf Func. Prog. in Ruby BOF at 8 tonight, rm 23. I can show some of my pres (https:\/\/t.co\/5w4WaJZqm7) if there's interest. #rubyconf",
  "id" : 534480019729678338,
  "created_at" : "2014-11-17 22:55:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Youssef Chaker",
      "screen_name" : "ychaker",
      "indices" : [ 32, 40 ],
      "id_str" : "16708075",
      "id" : 16708075
    }, {
      "name" : "Benjamin Tan Wei Hao",
      "screen_name" : "bentanweihao",
      "indices" : [ 41, 54 ],
      "id_str" : "54950832",
      "id" : 54950832
    }, {
      "name" : "Ishaan Singal",
      "screen_name" : "IshaanSingal",
      "indices" : [ 55, 68 ],
      "id_str" : "335467448",
      "id" : 335467448
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/534446493034242048\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/w8njMLtiAY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q8QD_CEAAOC63.jpg",
      "id_str" : "534446489930436608",
      "id" : 534446489930436608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q8QD_CEAAOC63.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/w8njMLtiAY"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 5, 17 ]
    }, {
      "text" : "rubyconf",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534446493034242048",
  "text" : "More #rubyfriends at #rubyconf: @ychaker @bentanweihao @IshaanSingal and me. http:\/\/t.co\/w8njMLtiAY",
  "id" : 534446493034242048,
  "created_at" : "2014-11-17 20:42:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guilherme Carvalho",
      "screen_name" : "guieevc",
      "indices" : [ 27, 35 ],
      "id_str" : "65629258",
      "id" : 65629258
    }, {
      "name" : "Lailson Bandeira",
      "screen_name" : "lailsonbm",
      "indices" : [ 36, 46 ],
      "id_str" : "10492892",
      "id" : 10492892
    }, {
      "name" : "Lucas Marinho",
      "screen_name" : "lmarinho",
      "indices" : [ 47, 56 ],
      "id_str" : "21595670",
      "id" : 21595670
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/534445821823942656\/photo\/1",
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/fwSAGVboiB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2q7o-CCUAADqup.jpg",
      "id_str" : "534445818317524992",
      "id" : 534445818317524992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2q7o-CCUAADqup.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/fwSAGVboiB"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "rubyconf",
      "indices" : [ 16, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534445821823942656",
  "text" : "#rubyfriends at #rubyconf: @guieevc @lailsonbm @lmarinho and me. http:\/\/t.co\/fwSAGVboiB",
  "id" : 534445821823942656,
  "created_at" : "2014-11-17 20:39:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 116, 125 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534372183422685185",
  "text" : "Also, if you're at #rubyconf &amp; staying at the Omni, they will provide a refrigerator in your room at no charge. @rubyconf",
  "id" : 534372183422685185,
  "created_at" : "2014-11-17 15:47:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 133, 142 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534371865012088832",
  "text" : "If you're staying at Omni &amp; booked #rubyconf group rate, hotel staff told me we will not be charged $9.99\/day for the 3 MB plan. @rubyconf",
  "id" : 534371865012088832,
  "created_at" : "2014-11-17 15:45:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/534234068112519168\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/enyVazzTyU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2n7DRdCQAAe5Nw.jpg",
      "id_str" : "534234064463478784",
      "id" : 534234064463478784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2n7DRdCQAAe5Nw.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/enyVazzTyU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "534234068112519168",
  "text" : "Enjoying San Diego's Asian area at Convoy St. Had a great bowl of ramen here. http:\/\/t.co\/enyVazzTyU",
  "id" : 534234068112519168,
  "created_at" : "2014-11-17 06:38:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyconf",
      "indices" : [ 10, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/jWauLFyMuc",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/titas-ii-restaurant-national-city",
      "display_url" : "yelp.com\/biz\/titas-ii-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534135038624149505",
  "text" : "Anyone at #rubyconf interested in karaoke (English&amp;Filipino) tonight?  I'm thinking of going to Tita\u2019s II Restaurant: http:\/\/t.co\/jWauLFyMuc",
  "id" : 534135038624149505,
  "created_at" : "2014-11-17 00:04:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Roland Bouman",
      "screen_name" : "rolandbouman",
      "indices" : [ 25, 38 ],
      "id_str" : "51754021",
      "id" : 51754021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532710284230918144",
  "text" : "RT @headius: Inspired by @rolandbouman and Monty Python, I've decided to set up an argument booth at RubyConf. Stop by and I'll tell you yo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Roland Bouman",
        "screen_name" : "rolandbouman",
        "indices" : [ 12, 25 ],
        "id_str" : "51754021",
        "id" : 51754021
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "532696540713086980",
    "text" : "Inspired by @rolandbouman and Monty Python, I've decided to set up an argument booth at RubyConf. Stop by and I'll tell you you're wrong.",
    "id" : 532696540713086980,
    "created_at" : "2014-11-13 00:48:46 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736361495756480513\/U0H_Wfk4_normal.jpg",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 532710284230918144,
  "created_at" : "2014-11-13 01:43:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "532212335734423552",
  "text" : "PSA: When adding a complex regular expression to your code, explain what it's doing, ideally by giving it a descriptive (long ok) name.",
  "id" : 532212335734423552,
  "created_at" : "2014-11-11 16:44:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/mdPRS8ZW7h",
      "expanded_url" : "http:\/\/4thmouse.com\/index.php\/2011\/03\/20\/why-class-variables-in-ruby-are-a-bad-idea\/",
      "display_url" : "4thmouse.com\/index.php\/2011\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "531960337541922817",
  "text" : "Excellent and concise explanation of (bad) class variables and (not as bad) class instance variables in Ruby: http:\/\/t.co\/mdPRS8ZW7h",
  "id" : 531960337541922817,
  "created_at" : "2014-11-11 00:03:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 1, 7 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531596652013158401",
  "text" : ".@hertz It's been a year now since the Miami fiasco. Will we never get this resolved? Pls dont say contact cust svc; you contact me.",
  "id" : 531596652013158401,
  "created_at" : "2014-11-09 23:58:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 0, 6 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531596525315842048",
  "in_reply_to_user_id" : 18001417,
  "text" : "@hertz It's been a year now since the Miami fiasco.  Will we never get this resolved? Pls dont say contact cust svc; you contact me.",
  "id" : 531596525315842048,
  "created_at" : "2014-11-09 23:57:42 +0000",
  "in_reply_to_screen_name" : "Hertz",
  "in_reply_to_user_id_str" : "18001417",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Saif Hakim",
      "screen_name" : "saifelse",
      "indices" : [ 0, 9 ],
      "id_str" : "323005289",
      "id" : 323005289
    }, {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 10, 16 ],
      "id_str" : "18001417",
      "id" : 18001417
    }, {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 89, 95 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "531162116854923264",
  "geo" : { },
  "id_str" : "531595836829224961",
  "in_reply_to_user_id" : 323005289,
  "text" : "@saifelse @Hertz Congrats for the special treatment, but what awful service for the 14.  @hertz, very surprised you would retweet this.",
  "id" : 531595836829224961,
  "in_reply_to_status_id" : 531162116854923264,
  "created_at" : "2014-11-09 23:54:58 +0000",
  "in_reply_to_screen_name" : "saifelse",
  "in_reply_to_user_id_str" : "323005289",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/GvwfiBfcpG",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/6a0c4a713fc13fe6bbce",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "529676427772583936",
  "text" : "Rubyists, for string concatenation, prefer &lt;&lt; to +=, to avoid creation of an unnecessary object. https:\/\/t.co\/GvwfiBfcpG",
  "id" : 529676427772583936,
  "created_at" : "2014-11-04 16:47:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linuxjournal",
      "screen_name" : "linuxjournal",
      "indices" : [ 1, 14 ],
      "id_str" : "9799222",
      "id" : 9799222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "484362813788663808",
  "geo" : { },
  "id_str" : "529418316087971840",
  "in_reply_to_user_id" : 9799222,
  "text" : ".@linuxjournal Just downloaded this month's issue.  File name: Linux-Journal-2014-11.pdf.  Well done, thank you!",
  "id" : 529418316087971840,
  "in_reply_to_status_id" : 484362813788663808,
  "created_at" : "2014-11-03 23:42:17 +0000",
  "in_reply_to_screen_name" : "linuxjournal",
  "in_reply_to_user_id_str" : "9799222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nogooddeedgoesunpunished",
      "indices" : [ 88, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "529392190326190080",
  "text" : "Ah, statistics.  Trimmed down some well tested code, and my test coverage % decreased.  #nogooddeedgoesunpunished",
  "id" : 529392190326190080,
  "created_at" : "2014-11-03 21:58:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kurt Seifried",
      "screen_name" : "kurtseifried",
      "indices" : [ 3, 16 ],
      "id_str" : "28968343",
      "id" : 28968343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ZsYgEZdcCb",
      "expanded_url" : "http:\/\/www.brennancenter.org\/analysis\/im-terrified-my-new-tv-why-im-scared-turn-thing",
      "display_url" : "brennancenter.org\/analysis\/im-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "528547902927667200",
  "text" : "RT @kurtseifried: This is why you stick a firewall in between all your appliances and the Internet http:\/\/t.co\/ZsYgEZdcCb and block everyth\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/ZsYgEZdcCb",
        "expanded_url" : "http:\/\/www.brennancenter.org\/analysis\/im-terrified-my-new-tv-why-im-scared-turn-thing",
        "display_url" : "brennancenter.org\/analysis\/im-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "528388348922966016",
    "text" : "This is why you stick a firewall in between all your appliances and the Internet http:\/\/t.co\/ZsYgEZdcCb and block everything by default",
    "id" : 528388348922966016,
    "created_at" : "2014-11-01 03:29:34 +0000",
    "user" : {
      "name" : "Kurt Seifried",
      "screen_name" : "kurtseifried",
      "protected" : false,
      "id_str" : "28968343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1524599683\/buddha-cat2_normal.jpg",
      "id" : 28968343,
      "verified" : false
    }
  },
  "id" : 528547902927667200,
  "created_at" : "2014-11-01 14:03:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]