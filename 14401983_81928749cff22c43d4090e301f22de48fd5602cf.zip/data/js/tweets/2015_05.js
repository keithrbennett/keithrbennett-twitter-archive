Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604812928529874944",
  "text" : "@radiomorillo We're going to karaoke tonight at Harry's Detroit.  Want to join us?",
  "id" : 604812928529874944,
  "created_at" : "2015-05-31 00:53:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aisha Blake",
      "screen_name" : "AishaBlake",
      "indices" : [ 0, 11 ],
      "id_str" : "372978756",
      "id" : 372978756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "604772913179426818",
  "geo" : { },
  "id_str" : "604786845516464128",
  "in_reply_to_user_id" : 372978756,
  "text" : "@AishaBlake I'll be there (Harry's Detroit, 2482 Clifford Street), and may also be able to help drive if anyone needs it.  #selfconf",
  "id" : 604786845516464128,
  "in_reply_to_status_id" : 604772913179426818,
  "created_at" : "2015-05-30 23:09:55 +0000",
  "in_reply_to_screen_name" : "AishaBlake",
  "in_reply_to_user_id_str" : "372978756",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/r4Y73gxpwN",
      "expanded_url" : "http:\/\/www.yelp.com\/map\/punch-bowl-social-detroit-3",
      "display_url" : "yelp.com\/map\/punch-bowl\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "604749056888451073",
  "geo" : { },
  "id_str" : "604750617739968514",
  "in_reply_to_user_id" : 14401983,
  "text" : "#selfconf Just found Punch Bowl (http:\/\/t.co\/r4Y73gxpwN) for karaoke &amp; verified by phone.  Rooms are first come, first served though, no res",
  "id" : 604750617739968514,
  "in_reply_to_status_id" : 604749056888451073,
  "created_at" : "2015-05-30 20:45:57 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/3b4xSWnO3B",
      "expanded_url" : "http:\/\/www.yelp.com\/biz\/blue-karaoke-ann-arbor",
      "display_url" : "yelp.com\/biz\/blue-karao\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "604749056888451073",
  "text" : "#selfconf Looks like the only karaoke we can find for tonight is in Ann Arbor, probably http:\/\/t.co\/3b4xSWnO3B .  Anyone interested?",
  "id" : 604749056888451073,
  "created_at" : "2015-05-30 20:39:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny Bloomer",
      "screen_name" : "jennybloomer",
      "indices" : [ 9, 22 ],
      "id_str" : "32915532",
      "id" : 32915532
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/604711352603525121\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/CYFf222j3v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGRdw_qUgAASEIK.jpg",
      "id_str" : "604711346278531072",
      "id" : 604711346278531072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGRdw_qUgAASEIK.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CYFf222j3v"
    } ],
    "hashtags" : [ {
      "text" : "impostersyndrome",
      "indices" : [ 37, 54 ]
    }, {
      "text" : "selfconf",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604711352603525121",
  "text" : "Enjoying @jennybloomer talk about at #impostersyndrome at #selfconf. http:\/\/t.co\/CYFf222j3v",
  "id" : 604711352603525121,
  "created_at" : "2015-05-30 18:09:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/604506796657680384\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/EzRyqA3b00",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGOjuc1UAAEZBnP.jpg",
      "id_str" : "604506793406889985",
      "id" : 604506793406889985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGOjuc1UAAEZBnP.jpg",
      "sizes" : [ {
        "h" : 134,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 76,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 229,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EzRyqA3b00"
    } ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604506796657680384",
  "text" : "Great view of Detroit and Windsor (Canada) from the #selfconf after party venue. http:\/\/t.co\/EzRyqA3b00",
  "id" : 604506796657680384,
  "created_at" : "2015-05-30 04:37:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aisha Blake",
      "screen_name" : "AishaBlake",
      "indices" : [ 16, 27 ],
      "id_str" : "372978756",
      "id" : 372978756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604383244667199489",
  "text" : "Hey, #selfconf, @AishaBlake and I are looking to do karaoke tomorrow night.  Interested?  Know a place?",
  "id" : 604383244667199489,
  "created_at" : "2015-05-29 20:26:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "indices" : [ 3, 6 ],
      "id_str" : "1133971",
      "id" : 1133971
    }, {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 25, 38 ],
      "id_str" : "15349954",
      "id" : 15349954
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604382413897252864",
  "text" : "RT @j3: Great session by @onealexharms facilitating conversation about difficult topics of gender and sexuality at #selfconf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Harms",
        "screen_name" : "onealexharms",
        "indices" : [ 17, 30 ],
        "id_str" : "15349954",
        "id" : 15349954
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "selfconf",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "604374694033248257",
    "text" : "Great session by @onealexharms facilitating conversation about difficult topics of gender and sexuality at #selfconf",
    "id" : 604374694033248257,
    "created_at" : "2015-05-29 19:52:10 +0000",
    "user" : {
      "name" : "Jeff Casimir",
      "screen_name" : "j3",
      "protected" : false,
      "id_str" : "1133971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667052575775043584\/GAMQ5_2P_normal.jpg",
      "id" : 1133971,
      "verified" : false
    }
  },
  "id" : 604382413897252864,
  "created_at" : "2015-05-29 20:22:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detroit Labs",
      "screen_name" : "DetroitLabs",
      "indices" : [ 13, 25 ],
      "id_str" : "260369442",
      "id" : 260369442
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/604308274788237312\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/wAOVUXggJI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGLvK_3UgAAGT5g.jpg",
      "id_str" : "604308272242262016",
      "id" : 604308272242262016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGLvK_3UgAAGT5g.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/wAOVUXggJI"
    } ],
    "hashtags" : [ {
      "text" : "selfconf",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604308274788237312",
  "text" : "Enjoying the @detroitlabs session on large teams at #selfconf. Check out the funny slide. http:\/\/t.co\/wAOVUXggJI",
  "id" : 604308274788237312,
  "created_at" : "2015-05-29 15:28:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attila Domokos",
      "screen_name" : "adomokos",
      "indices" : [ 0, 9 ],
      "id_str" : "20173708",
      "id" : 20173708
    }, {
      "name" : "Naresh Jain",
      "screen_name" : "sdtconf",
      "indices" : [ 100, 108 ],
      "id_str" : "149476614",
      "id" : 149476614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "603043266666303489",
  "geo" : { },
  "id_str" : "603196020080713728",
  "in_reply_to_user_id" : 20173708,
  "text" : "@adomokos I hope you'll be returning to Minneapolis for the Simple Design &amp; Testing Conference? @sdtconf",
  "id" : 603196020080713728,
  "in_reply_to_status_id" : 603043266666303489,
  "created_at" : "2015-05-26 13:48:32 +0000",
  "in_reply_to_screen_name" : "adomokos",
  "in_reply_to_user_id_str" : "20173708",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 3, 16 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Tracy Harms",
      "screen_name" : "kaleidic",
      "indices" : [ 73, 82 ],
      "id_str" : "16911769",
      "id" : 16911769
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603036116309176320",
  "text" : "RT @onealexharms: I'm gonna be in Detroit next weekend for SelfConf with @kaleidic. You coming? Here's a discount: self-conf-friends http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tracy Harms",
        "screen_name" : "kaleidic",
        "indices" : [ 55, 64 ],
        "id_str" : "16911769",
        "id" : 16911769
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/N4T85C0TTQ",
        "expanded_url" : "http:\/\/selfconference.org",
        "display_url" : "selfconference.org"
      } ]
    },
    "geo" : { },
    "id_str" : "603021365533347840",
    "text" : "I'm gonna be in Detroit next weekend for SelfConf with @kaleidic. You coming? Here's a discount: self-conf-friends http:\/\/t.co\/N4T85C0TTQ",
    "id" : 603021365533347840,
    "created_at" : "2015-05-26 02:14:31 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 603036116309176320,
  "created_at" : "2015-05-26 03:13:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "100% GOATS",
      "screen_name" : "EverythingGoats",
      "indices" : [ 3, 19 ],
      "id_str" : "2973453269",
      "id" : 2973453269
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EverythingGoats\/status\/603006384536428544\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/7MvXlw7BID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF5PFLiW0AAmWmI.jpg",
      "id_str" : "603006350529056768",
      "id" : 603006350529056768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF5PFLiW0AAmWmI.jpg",
      "sizes" : [ {
        "h" : 938,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 938,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 550,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7MvXlw7BID"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603035680172814336",
  "text" : "RT @EverythingGoats: whatever floats your goat http:\/\/t.co\/7MvXlw7BID",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EverythingGoats\/status\/603006384536428544\/photo\/1",
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/7MvXlw7BID",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF5PFLiW0AAmWmI.jpg",
        "id_str" : "603006350529056768",
        "id" : 603006350529056768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF5PFLiW0AAmWmI.jpg",
        "sizes" : [ {
          "h" : 938,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 938,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 550,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7MvXlw7BID"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603006384536428544",
    "text" : "whatever floats your goat http:\/\/t.co\/7MvXlw7BID",
    "id" : 603006384536428544,
    "created_at" : "2015-05-26 01:15:00 +0000",
    "user" : {
      "name" : "100% GOATS",
      "screen_name" : "EverythingGoats",
      "protected" : false,
      "id_str" : "2973453269",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/807458505347268608\/Z25Tt04m_normal.jpg",
      "id" : 2973453269,
      "verified" : false
    }
  },
  "id" : 603035680172814336,
  "created_at" : "2015-05-26 03:11:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBrains",
      "screen_name" : "jetbrains",
      "indices" : [ 127, 137 ],
      "id_str" : "14146389",
      "id" : 14146389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/8DC6UteHpE",
      "expanded_url" : "http:\/\/www.jetbrains.com\/idea\/buy\/#personal",
      "display_url" : "jetbrains.com\/idea\/buy\/#pers\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "602880549297004544",
  "text" : "Intellij Idea pers. license 20% off until May 31st (see http:\/\/t.co\/8DC6UteHpE).  Great product to develop in Java &amp; more. @jetbrains",
  "id" : 602880549297004544,
  "created_at" : "2015-05-25 16:54:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Naresh Jain",
      "screen_name" : "sdtconf",
      "indices" : [ 62, 70 ],
      "id_str" : "149476614",
      "id" : 149476614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "602873479743066113",
  "geo" : { },
  "id_str" : "602878488794759171",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms Yes, much looking forward to it.  Also going to @sdtconf.  It would be great to see you there too...?",
  "id" : 602878488794759171,
  "in_reply_to_status_id" : 602873479743066113,
  "created_at" : "2015-05-25 16:46:47 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "self.conference",
      "screen_name" : "selfconference",
      "indices" : [ 0, 15 ],
      "id_str" : "152773995",
      "id" : 152773995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fyi",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602872809908379648",
  "in_reply_to_user_id" : 152773995,
  "text" : "@selfconference Motor City Casino Hotel parking is free (self or valet). Also, cheaper lodging at La Quinta near DTW but 15 min drive #fyi",
  "id" : 602872809908379648,
  "created_at" : "2015-05-25 16:24:13 +0000",
  "in_reply_to_screen_name" : "selfconference",
  "in_reply_to_user_id_str" : "152773995",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "indices" : [ 3, 16 ],
      "id_str" : "6742522",
      "id" : 6742522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602603186722078721",
  "text" : "RT @hypatiadotca: Please, my friends, wear your seatbelts - even in taxis \/ lyfts \/ ubers etc. &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602577233413218304",
    "text" : "Please, my friends, wear your seatbelts - even in taxis \/ lyfts \/ ubers etc. &lt;3",
    "id" : 602577233413218304,
    "created_at" : "2015-05-24 20:49:42 +0000",
    "user" : {
      "name" : "Leigh Honeywell",
      "screen_name" : "hypatiadotca",
      "protected" : false,
      "id_str" : "6742522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777680485501722624\/ZOiZulxt_normal.jpg",
      "id" : 6742522,
      "verified" : true
    }
  },
  "id" : 602603186722078721,
  "created_at" : "2015-05-24 22:32:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egor Homakov",
      "screen_name" : "homakov",
      "indices" : [ 0, 8 ],
      "id_str" : "86890115",
      "id" : 86890115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "601810920319426560",
  "geo" : { },
  "id_str" : "601818915052855296",
  "in_reply_to_user_id" : 86890115,
  "text" : "@homakov Wow. They should have thanked you with a $1000 gift card. Ingrates.",
  "id" : 601818915052855296,
  "in_reply_to_status_id" : 601810920319426560,
  "created_at" : "2015-05-22 18:36:25 +0000",
  "in_reply_to_screen_name" : "homakov",
  "in_reply_to_user_id_str" : "86890115",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "indices" : [ 126, 132 ],
      "id_str" : "14375110",
      "id" : 14375110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SRcMpARtE2",
      "expanded_url" : "http:\/\/www.meetup.com\/koreans\/events\/222552883\/",
      "display_url" : "meetup.com\/koreans\/events\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "599321864343842817",
  "text" : "I'm hosting a Korean-style karaoke meetup tonight in Centreville, VA.  Anyone interested?  Details at http:\/\/t.co\/SRcMpARtE2. @fogus ?",
  "id" : 599321864343842817,
  "created_at" : "2015-05-15 21:14:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McDonald's",
      "screen_name" : "McDonalds",
      "indices" : [ 18, 28 ],
      "id_str" : "71026122",
      "id" : 71026122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598274648187404288",
  "text" : "I like to work at @mcdonalds sometimes.  Good latte &amp; wifi, BUT they should really do something about that incessant &amp; piercing beeping.",
  "id" : 598274648187404288,
  "created_at" : "2015-05-12 23:52:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "priceless",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597772365376856064",
  "text" : "That moment when you go to the rest room for the 1st time in your workday &amp; realize that your fly has been open the whole time.  #priceless",
  "id" : 597772365376856064,
  "created_at" : "2015-05-11 14:36:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evernote",
      "screen_name" : "evernote",
      "indices" : [ 16, 25 ],
      "id_str" : "13837292",
      "id" : 13837292
    }, {
      "name" : "Wunderlist",
      "screen_name" : "Wunderlist",
      "indices" : [ 70, 81 ],
      "id_str" : "211089576",
      "id" : 211089576
    }, {
      "name" : "Scrumwise",
      "screen_name" : "scrumwise",
      "indices" : [ 94, 104 ],
      "id_str" : "230688512",
      "id" : 230688512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597516619271770112",
  "text" : "Disillusioned w\/@evernote losing notes and not syncing.  Anyone tried @wunderlist?  Feedback? @scrumwise looks interesting too, but not free",
  "id" : 597516619271770112,
  "created_at" : "2015-05-10 21:40:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597269914097942528",
  "text" : "No, Apple Mail spell checker, I really *did* mean the Greek island of \"Ios\", not the Apple operating system \"iOS\".",
  "id" : 597269914097942528,
  "created_at" : "2015-05-10 05:20:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amazon",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/jfjey9fNqB",
      "expanded_url" : "http:\/\/smile.amazon.com",
      "display_url" : "smile.amazon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "597069147705475072",
  "text" : "Amazon customers, pls consider using http:\/\/t.co\/jfjey9fNqB to have #amazon donate part of your purchase price to the charity of your choice",
  "id" : 597069147705475072,
  "created_at" : "2015-05-09 16:02:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "brweber2",
      "screen_name" : "brweber2",
      "indices" : [ 37, 46 ],
      "id_str" : "9899312",
      "id" : 9899312
    }, {
      "name" : "Adam Guyot",
      "screen_name" : "MonkeyIsNull",
      "indices" : [ 53, 66 ],
      "id_str" : "250635492",
      "id" : 250635492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "elixir",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/3p4Ah3nQJq",
      "expanded_url" : "http:\/\/www.elixirmastery.com\/",
      "display_url" : "elixirmastery.com"
    } ]
  },
  "geo" : { },
  "id_str" : "596688314574319619",
  "text" : "#elixir training in Washington DC by @brweber2 &amp; @MonkeyIsNull. These guys know what they're talking about.  Info at http:\/\/t.co\/3p4Ah3nQJq.",
  "id" : 596688314574319619,
  "created_at" : "2015-05-08 14:49:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/bdez6iBiRu",
      "expanded_url" : "https:\/\/www.theexplorercard.com",
      "display_url" : "theexplorercard.com"
    } ]
  },
  "geo" : { },
  "id_str" : "596115815545458688",
  "text" : "People, I know a bit about credit card offers &amp; this is a great time to get a United credit card.  50K mile bonus!  https:\/\/t.co\/bdez6iBiRu",
  "id" : 596115815545458688,
  "created_at" : "2015-05-07 00:54:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Idiosyncratic Ruby",
      "screen_name" : "idiosyncraticrb",
      "indices" : [ 3, 19 ],
      "id_str" : "3226052345",
      "id" : 3226052345
    }, {
      "name" : "Ruby String Magic",
      "screen_name" : "RubyStrings",
      "indices" : [ 68, 80 ],
      "id_str" : "2794069742",
      "id" : 2794069742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/JKHfSPsUD3",
      "expanded_url" : "http:\/\/idiosyncratic-ruby.com\/2-ruby-string-magic.html",
      "display_url" : "idiosyncratic-ruby.com\/2-ruby-string-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595035252516618240",
  "text" : "RT @idiosyncraticrb: Episode 2 is out: 10 Lesser Known Things about @RubyStrings http:\/\/t.co\/JKHfSPsUD3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ruby String Magic",
        "screen_name" : "RubyStrings",
        "indices" : [ 47, 59 ],
        "id_str" : "2794069742",
        "id" : 2794069742
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/JKHfSPsUD3",
        "expanded_url" : "http:\/\/idiosyncratic-ruby.com\/2-ruby-string-magic.html",
        "display_url" : "idiosyncratic-ruby.com\/2-ruby-string-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594561392746856449",
    "text" : "Episode 2 is out: 10 Lesser Known Things about @RubyStrings http:\/\/t.co\/JKHfSPsUD3",
    "id" : 594561392746856449,
    "created_at" : "2015-05-02 17:57:37 +0000",
    "user" : {
      "name" : "Idiosyncratic Ruby",
      "screen_name" : "idiosyncraticrb",
      "protected" : false,
      "id_str" : "3226052345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595270644876587008\/dL-bmb2z_normal.png",
      "id" : 3226052345,
      "verified" : false
    }
  },
  "id" : 595035252516618240,
  "created_at" : "2015-05-04 01:20:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/594884090517553152\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/XyaUUaj64M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEFz65VVEAAtWwM.jpg",
      "id_str" : "594884081449504768",
      "id" : 594884081449504768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEFz65VVEAAtWwM.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XyaUUaj64M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594884090517553152",
  "text" : "Roller skate rickshaw on U Street in Washington, DC yesterday! http:\/\/t.co\/XyaUUaj64M",
  "id" : 594884090517553152,
  "created_at" : "2015-05-03 15:19:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DC Metro Connection",
      "screen_name" : "DCMConnection",
      "indices" : [ 3, 17 ],
      "id_str" : "355636038",
      "id" : 355636038
    }, {
      "name" : "Kevin Eike",
      "screen_name" : "kevin_eike",
      "indices" : [ 22, 33 ],
      "id_str" : "123735167",
      "id" : 123735167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594692081475518464",
  "text" : "RT @DCMConnection: RT @kevin_eike: There\u2019s a guy dressed as a Union soldier on the Red Line. He\u2019s like 150 years late, probably because he \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Eike",
        "screen_name" : "kevin_eike",
        "indices" : [ 3, 14 ],
        "id_str" : "123735167",
        "id" : 123735167
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594646225149886464",
    "text" : "RT @kevin_eike: There\u2019s a guy dressed as a Union soldier on the Red Line. He\u2019s like 150 years late, probably because he took metro&lt; lol",
    "id" : 594646225149886464,
    "created_at" : "2015-05-02 23:34:42 +0000",
    "user" : {
      "name" : "DC Metro Connection",
      "screen_name" : "DCMConnection",
      "protected" : false,
      "id_str" : "355636038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3306360471\/340ad5dbd04daaaa8b3c52d8bfc7833c_normal.jpeg",
      "id" : 355636038,
      "verified" : false
    }
  },
  "id" : 594692081475518464,
  "created_at" : "2015-05-03 02:36:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594685867333185537",
  "geo" : { },
  "id_str" : "594690381599645696",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 Because of Angular, Rails, both, something else?",
  "id" : 594690381599645696,
  "in_reply_to_status_id" : 594685867333185537,
  "created_at" : "2015-05-03 02:30:10 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Jamieson Becker",
      "screen_name" : "JamiesonBecker",
      "indices" : [ 6, 21 ],
      "id_str" : "795723250420563968",
      "id" : 795723250420563968
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 22, 29 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "594527115996958720",
  "geo" : { },
  "id_str" : "594609654585495553",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH @JamiesonBecker @united United not all bad. 24 hour refund policy &amp; intl miles redemption are nice. Flew from US - Asia RT for 75K.",
  "id" : 594609654585495553,
  "in_reply_to_status_id" : 594527115996958720,
  "created_at" : "2015-05-02 21:09:23 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 3, 13 ],
      "id_str" : "25103",
      "id" : 25103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/pSJGQw5dee",
      "expanded_url" : "http:\/\/blog.jessitron.com\/2015\/05\/fitting-in-v-belonging.html",
      "display_url" : "blog.jessitron.com\/2015\/05\/fittin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "594595630061846529",
  "text" : "RT @jessitron: How \"fitting in\" is the enemy of belonging, and therefore of great teams:\nhttp:\/\/t.co\/pSJGQw5dee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/pSJGQw5dee",
        "expanded_url" : "http:\/\/blog.jessitron.com\/2015\/05\/fitting-in-v-belonging.html",
        "display_url" : "blog.jessitron.com\/2015\/05\/fittin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "594525011584552960",
    "text" : "How \"fitting in\" is the enemy of belonging, and therefore of great teams:\nhttp:\/\/t.co\/pSJGQw5dee",
    "id" : 594525011584552960,
    "created_at" : "2015-05-02 15:33:03 +0000",
    "user" : {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "protected" : false,
      "id_str" : "25103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728251919467057152\/Z2uk49Ww_normal.jpg",
      "id" : 25103,
      "verified" : false
    }
  },
  "id" : 594595630061846529,
  "created_at" : "2015-05-02 20:13:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]