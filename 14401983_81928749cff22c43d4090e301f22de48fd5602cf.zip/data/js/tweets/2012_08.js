Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rubyconf",
      "screen_name" : "rubyconf",
      "indices" : [ 17, 26 ],
      "id_str" : "16222737",
      "id" : 16222737
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241154133661470720",
  "text" : "Got my ticket to @rubyconf.  Anyone know if it's all day, all 3 days?",
  "id" : 241154133661470720,
  "created_at" : "2012-08-30 12:43:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    }, {
      "name" : "spine.",
      "screen_name" : "spine",
      "indices" : [ 11, 17 ],
      "id_str" : "16273582",
      "id" : 16273582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240827451176009728",
  "geo" : { },
  "id_str" : "240842677279674370",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg @spine I do a toasted whole wheat sandwich w\/eggs fried in sesame oil, topped w rosemary, anise, shredded cheese, and pesto sauce",
  "id" : 240842677279674370,
  "in_reply_to_status_id" : 240827451176009728,
  "created_at" : "2012-08-29 16:05:43 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Calvert",
      "screen_name" : "charlesbcalvert",
      "indices" : [ 3, 19 ],
      "id_str" : "276173574",
      "id" : 276173574
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 21, 35 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "NoVaRUG",
      "screen_name" : "novarug",
      "indices" : [ 67, 75 ],
      "id_str" : "8937552",
      "id" : 8937552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/dUp6OWft",
      "expanded_url" : "http:\/\/bit.ly\/PpWQhR",
      "display_url" : "bit.ly\/PpWQhR"
    } ]
  },
  "geo" : { },
  "id_str" : "240798004737622018",
  "text" : "RT @charlesbcalvert: @keithrbennett gave a good over view of JRuby @novarug tonight: http:\/\/t.co\/dUp6OWft",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 0, 14 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "NoVaRUG",
        "screen_name" : "novarug",
        "indices" : [ 46, 54 ],
        "id_str" : "8937552",
        "id" : 8937552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/dUp6OWft",
        "expanded_url" : "http:\/\/bit.ly\/PpWQhR",
        "display_url" : "bit.ly\/PpWQhR"
      } ]
    },
    "geo" : { },
    "id_str" : "240599489642131456",
    "in_reply_to_user_id" : 14401983,
    "text" : "@keithrbennett gave a good over view of JRuby @novarug tonight: http:\/\/t.co\/dUp6OWft",
    "id" : 240599489642131456,
    "created_at" : "2012-08-28 23:59:23 +0000",
    "in_reply_to_screen_name" : "keithrbennett",
    "in_reply_to_user_id_str" : "14401983",
    "user" : {
      "name" : "Charles Calvert",
      "screen_name" : "charlesbcalvert",
      "protected" : false,
      "id_str" : "276173574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1305034877\/Charles_head_shot_square_normal.png",
      "id" : 276173574,
      "verified" : false
    }
  },
  "id" : 240798004737622018,
  "created_at" : "2012-08-29 13:08:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/7XsK24Qh",
      "expanded_url" : "http:\/\/www.mwaa.com\/5112.htm",
      "display_url" : "mwaa.com\/5112.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "239367486569578496",
  "text" : "MWAA proposes Dulles toll road increase from $2.25 to $4.50. Feedback submit button yields error. Protest in person! http:\/\/t.co\/7XsK24Qh",
  "id" : 239367486569578496,
  "created_at" : "2012-08-25 14:23:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "konsole",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239104963110899712",
  "text" : "To run rvm in term. emulators, you may need to tell them to start shell in login mode (\"zsh -l\", \"bash -l\"). Thanks, #konsole handbook.",
  "id" : 239104963110899712,
  "created_at" : "2012-08-24 21:00:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/1M3mG7Qj",
      "expanded_url" : "http:\/\/www.meetup.com\/novarug\/events\/79011252\/",
      "display_url" : "meetup.com\/novarug\/events\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238705828515938306",
  "text" : "I'll be speaking and facilitating a discussion of JRuby at the No. Virginia Ruby Meetup on Tues. 8\/28, in Reston, VA (http:\/\/t.co\/1M3mG7Qj).",
  "id" : 238705828515938306,
  "created_at" : "2012-08-23 18:34:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236469606280228864",
  "text" : "I have a free 3 month trial to Dropbox 100 (100 GB) to give away.  Anyone want it?",
  "id" : 236469606280228864,
  "created_at" : "2012-08-17 14:28:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "indices" : [ 0, 13 ],
      "id_str" : "19768213",
      "id" : 19768213
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235523312594350080",
  "geo" : { },
  "id_str" : "235577482500259840",
  "in_reply_to_user_id" : 19768213,
  "text" : "@bmoreonrails Thanks for having me.  I always enjoy visiting you guys.",
  "id" : 235577482500259840,
  "in_reply_to_status_id" : 235523312594350080,
  "created_at" : "2012-08-15 03:23:43 +0000",
  "in_reply_to_screen_name" : "bmoreonrails",
  "in_reply_to_user_id_str" : "19768213",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "indices" : [ 3, 16 ],
      "id_str" : "19768213",
      "id" : 19768213
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 51, 65 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/bmoreonrails\/status\/235523312594350080\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/RCXroFbc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A0S_NHfCcAAI7Kb.jpg",
      "id_str" : "235523312598544384",
      "id" : 235523312598544384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0S_NHfCcAAI7Kb.jpg",
      "sizes" : [ {
        "h" : 1944,
        "resize" : "fit",
        "w" : 2592
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/RCXroFbc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235577201855172608",
  "text" : "RT @bmoreonrails: Getting some jruby goodness from @keithrbennett http:\/\/t.co\/RCXroFbc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 33, 47 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/bmoreonrails\/status\/235523312594350080\/photo\/1",
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/RCXroFbc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A0S_NHfCcAAI7Kb.jpg",
        "id_str" : "235523312598544384",
        "id" : 235523312598544384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A0S_NHfCcAAI7Kb.jpg",
        "sizes" : [ {
          "h" : 1944,
          "resize" : "fit",
          "w" : 2592
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RCXroFbc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "235523312594350080",
    "text" : "Getting some jruby goodness from @keithrbennett http:\/\/t.co\/RCXroFbc",
    "id" : 235523312594350080,
    "created_at" : "2012-08-14 23:48:29 +0000",
    "user" : {
      "name" : "B'more on Rails",
      "screen_name" : "bmoreonrails",
      "protected" : false,
      "id_str" : "19768213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843097247\/logo64square_normal.png",
      "id" : 19768213,
      "verified" : false
    }
  },
  "id" : 235577201855172608,
  "created_at" : "2012-08-15 03:22:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/qg5ax6Qg",
      "expanded_url" : "http:\/\/www.meetup.com\/bmore-on-rails\/events\/67001182\/",
      "display_url" : "meetup.com\/bmore-on-rails\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235014371254878208",
  "text" : "I'm speaking on JRuby tomorrow at Baltimore on Rails (http:\/\/t.co\/qg5ax6Qg). Let me know if you have any JRuby questions, maybe I can help.",
  "id" : 235014371254878208,
  "created_at" : "2012-08-13 14:06:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233281845578563584",
  "text" : "Fed up w\/VZW. Thinking of switching to AT&amp;T. Also, I want a phone I can use outside the US (VZW uses CDMA, not GSM).  Thoughts on AT&amp;T?",
  "id" : 233281845578563584,
  "created_at" : "2012-08-08 19:21:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233281377645260801",
  "text" : "Verizon Wireless sends me a warranty replacement lemon yet again. They swear they test them. The tests are apparently not very thorough.",
  "id" : 233281377645260801,
  "created_at" : "2012-08-08 19:19:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232570934664499200",
  "text" : "Note to self: Don't procrastinate cleaning when tree sap gets on my car.  $60 later it looks 80% better but there's still paint damage.",
  "id" : 232570934664499200,
  "created_at" : "2012-08-06 20:16:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232192050194415616",
  "text" : "@objo How can we sign up to be notified about your PeopleConf\/TechConf in October?",
  "id" : 232192050194415616,
  "created_at" : "2012-08-05 19:11:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "indices" : [ 3, 14 ],
      "id_str" : "14693115",
      "id" : 14693115
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 52, 66 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc12",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231959070167416833",
  "text" : "RT @rayonrails: Holy smokin aces great job everyone @SteelCityRuby. Please..please do it again. #scrc12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steel City Ruby Conf",
        "screen_name" : "SteelCityRuby",
        "indices" : [ 36, 50 ],
        "id_str" : "404851600",
        "id" : 404851600
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc12",
        "indices" : [ 80, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231879412491104259",
    "text" : "Holy smokin aces great job everyone @SteelCityRuby. Please..please do it again. #scrc12",
    "id" : 231879412491104259,
    "created_at" : "2012-08-04 22:28:54 +0000",
    "user" : {
      "name" : "Ray Rogers \uF8FF",
      "screen_name" : "rayonrails",
      "protected" : false,
      "id_str" : "14693115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755854437952921600\/M5gRCHEj_normal.jpg",
      "id" : 14693115,
      "verified" : false
    }
  },
  "id" : 231959070167416833,
  "created_at" : "2012-08-05 03:45:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mandy Moore",
      "screen_name" : "therubyrep",
      "indices" : [ 3, 14 ],
      "id_str" : "28831220",
      "id" : 28831220
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "devs",
      "indices" : [ 22, 27 ]
    }, {
      "text" : "tech",
      "indices" : [ 28, 33 ]
    }, {
      "text" : "ruby",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231130422187261952",
  "text" : "RT @therubyrep: Attn: #devs #tech #ruby: Are you wasting time on the administrative aspect of work? I'm the Ruby Rep &amp; we should tal ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "devs",
        "indices" : [ 6, 11 ]
      }, {
        "text" : "tech",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "ruby",
        "indices" : [ 18, 23 ]
      } ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/Vzmjwiid",
        "expanded_url" : "http:\/\/ow.ly\/cH7Dl",
        "display_url" : "ow.ly\/cH7Dl"
      } ]
    },
    "geo" : { },
    "id_str" : "231084460970475520",
    "text" : "Attn: #devs #tech #ruby: Are you wasting time on the administrative aspect of work? I'm the Ruby Rep &amp; we should talk! http:\/\/t.co\/Vzmjwiid",
    "id" : 231084460970475520,
    "created_at" : "2012-08-02 17:50:03 +0000",
    "user" : {
      "name" : "Mandy Moore",
      "screen_name" : "therubyrep",
      "protected" : false,
      "id_str" : "28831220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/692360967582142464\/R20_gohe_normal.jpg",
      "id" : 28831220,
      "verified" : false
    }
  },
  "id" : 231130422187261952,
  "created_at" : "2012-08-02 20:52:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]