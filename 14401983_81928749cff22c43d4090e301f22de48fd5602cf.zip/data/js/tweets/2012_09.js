Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 119, 126 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252546843404279808",
  "text" : "Grateful to have spent the last three days with the smart and friendly people of #rubydcamp. Thanks to all, especially @elight.",
  "id" : 252546843404279808,
  "created_at" : "2012-09-30 23:13:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252400726096109569",
  "text" : "Is there anyone at #rubydcamp who could help me with some Postgres installation problems?",
  "id" : 252400726096109569,
  "created_at" : "2012-09-30 13:33:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/gpIG1M2q",
      "expanded_url" : "http:\/\/img.ly\/nSZz",
      "display_url" : "img.ly\/nSZz"
    } ]
  },
  "geo" : { },
  "id_str" : "251893637196173312",
  "text" : "Geeking out at #rubydcamp. http:\/\/t.co\/gpIG1M2q",
  "id" : 251893637196173312,
  "created_at" : "2012-09-29 03:58:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ruby_dcamp",
      "screen_name" : "ruby_dcamp",
      "indices" : [ 0, 11 ],
      "id_str" : "15386856",
      "id" : 15386856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "251359100271738882",
  "geo" : { },
  "id_str" : "251361006536773632",
  "in_reply_to_user_id" : 15386856,
  "text" : "@ruby_dcamp #rubydcamp Evan, I can pick up supplies.  What do you need?",
  "id" : 251361006536773632,
  "in_reply_to_status_id" : 251359100271738882,
  "created_at" : "2012-09-27 16:41:48 +0000",
  "in_reply_to_screen_name" : "ruby_dcamp",
  "in_reply_to_user_id_str" : "15386856",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Kalin",
      "screen_name" : "martinisoft",
      "indices" : [ 3, 15 ],
      "id_str" : "771669",
      "id" : 771669
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251323859909890048",
  "text" : "RT @martinisoft: Gave a high five to the TSA agent for the excellent massage. Awkward stares from everyone else. :o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "251298126651080704",
    "text" : "Gave a high five to the TSA agent for the excellent massage. Awkward stares from everyone else. :o",
    "id" : 251298126651080704,
    "created_at" : "2012-09-27 12:31:56 +0000",
    "user" : {
      "name" : "Aaron Kalin",
      "screen_name" : "martinisoft",
      "protected" : false,
      "id_str" : "771669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732264980179869697\/lxx2rG1T_normal.jpg",
      "id" : 771669,
      "verified" : false
    }
  },
  "id" : 251323859909890048,
  "created_at" : "2012-09-27 14:14:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251145781980049408",
  "text" : "#rubydcamp Planning to bring my 28\" and 22\" monitors, but we could probably use more\/bigger ones.  Also, don't forget cell phone chargers!",
  "id" : 251145781980049408,
  "created_at" : "2012-09-27 02:26:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250436774550175744",
  "text" : "#rubydcamp folks, I may be able to offer transport IAD \/ No. Virginia &lt;--&gt; DCamp on Thursday and Sunday.  Contact me if interested.",
  "id" : 250436774550175744,
  "created_at" : "2012-09-25 03:29:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/B78nT6hv",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/23\/wordpress-administration-with-ruby\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/2\u2026"
    }, {
      "indices" : [ 105, 126 ],
      "url" : "https:\/\/t.co\/9qlMZHI3",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/wordpress_config_parser",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "250336819735040000",
  "text" : "Published gem and blog article for basic but useful WordPress admin in Ruby, at http:\/\/t.co\/B78nT6hv and https:\/\/t.co\/9qlMZHI3.",
  "id" : 250336819735040000,
  "created_at" : "2012-09-24 20:52:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubydcamp",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249893317062569985",
  "text" : "For anyone who would like to explore JRuby at #rubydcamp, I recommend installing it before arriving (preferably w\/rvm: 'rvm install jruby').",
  "id" : 249893317062569985,
  "created_at" : "2012-09-23 15:29:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Logan",
      "screen_name" : "jlloganiii",
      "indices" : [ 24, 35 ],
      "id_str" : "97340565",
      "id" : 97340565
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "edencenter",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "durian",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249680430075346946",
  "text" : "Cycled 30 miles RT with @jlloganiii to #edencenter (DC area's Vietnamtown) for a #durian smoothie. Challenging laziness has been rewarding.",
  "id" : 249680430075346946,
  "created_at" : "2012-09-23 01:23:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sciencefriday",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249215386103451649",
  "text" : "#sciencefriday Obscure but sobering water use fact: Throwing away half a hamburger wastes as much water as a one hour shower.",
  "id" : 249215386103451649,
  "created_at" : "2012-09-21 18:35:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 35, 40 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/wYxI4XdX",
      "expanded_url" : "http:\/\/bit.ly\/SFj5R4",
      "display_url" : "bit.ly\/SFj5R4"
    } ]
  },
  "geo" : { },
  "id_str" : "248857027546337281",
  "text" : "Great client relations article: RT @avdi Devblog: Client Dating Tips http:\/\/t.co\/wYxI4XdX",
  "id" : 248857027546337281,
  "created_at" : "2012-09-20 18:51:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248215570808459264",
  "text" : "I've used Array.first and last in Ruby, but didn't know you could pass an arg: [1,2,3,4,5].first(2) -&gt; [1,2]. Nice!",
  "id" : 248215570808459264,
  "created_at" : "2012-09-19 00:22:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/sfhsjuQC",
      "expanded_url" : "http:\/\/www.bbs-software.com\/",
      "display_url" : "bbs-software.com"
    } ]
  },
  "geo" : { },
  "id_str" : "247748109671727104",
  "text" : "Published \"Hello, Nailgun; Goodbye, JVM Startup Delays\" and \"Stealth Conditionals in Ruby\" on my blog at http:\/\/t.co\/sfhsjuQC.",
  "id" : 247748109671727104,
  "created_at" : "2012-09-17 17:25:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 3, 16 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247183350480138241",
  "text" : "RT @kenrickchien: Even though the deadline is near, we stayed calm and wrote clean code, allowing us to finish much sooner than if we to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "247116703505465344",
    "text" : "Even though the deadline is near, we stayed calm and wrote clean code, allowing us to finish much sooner than if we took shortcuts.",
    "id" : 247116703505465344,
    "created_at" : "2012-09-15 23:36:27 +0000",
    "user" : {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "protected" : false,
      "id_str" : "655883",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2958271027\/ef2793e336487f30b0ac45c756e013f1_normal.jpeg",
      "id" : 655883,
      "verified" : false
    }
  },
  "id" : 247183350480138241,
  "created_at" : "2012-09-16 04:01:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247111614485114881",
  "text" : "Reviving my interest in bicycling. Rode from Reston to G'town. Lucky for me Reston is 400' above sea level. :-)  Taking bus home.",
  "id" : 247111614485114881,
  "created_at" : "2012-09-15 23:16:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/hI1oml2y",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/13\/rubys-forwardable\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246209343329017856",
  "text" : "Published a blog article about Ruby delegation at http:\/\/t.co\/hI1oml2y.",
  "id" : 246209343329017856,
  "created_at" : "2012-09-13 11:30:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 133 ],
      "url" : "https:\/\/t.co\/lkJgOeyI",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/life_game_viewer",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245934218226577408",
  "text" : "Published my first Ruby gem, life_game_viewer, a JRuby\/Swing app to aid Game of Life exercise.  Project page at https:\/\/t.co\/lkJgOeyI.",
  "id" : 245934218226577408,
  "created_at" : "2012-09-12 17:17:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 99 ],
      "url" : "https:\/\/t.co\/j6gtiD9P",
      "expanded_url" : "https:\/\/code.google.com\/p\/guava-libraries\/wiki\/GuavaExplained",
      "display_url" : "code.google.com\/p\/guava-librar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245214059857846274",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines For sanity with Java, I'd also look into Google's Guava library (https:\/\/t.co\/j6gtiD9P). I used Google Collections predecessor.",
  "id" : 245214059857846274,
  "created_at" : "2012-09-10 17:36:02 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 0, 12 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/DSaG1qHY",
      "expanded_url" : "http:\/\/commons.apache.org\/lang\/api-2.5\/org\/apache\/commons\/lang\/StringUtils.html",
      "display_url" : "commons.apache.org\/lang\/api-2.5\/o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245212715017195520",
  "in_reply_to_user_id" : 11458102,
  "text" : "@coreyhaines For Java, to preserve sanity, use Apache Commons Lang, especially its StringUtils class (http:\/\/t.co\/DSaG1qHY).",
  "id" : 245212715017195520,
  "created_at" : "2012-09-10 17:30:41 +0000",
  "in_reply_to_screen_name" : "coreyhaines",
  "in_reply_to_user_id_str" : "11458102",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 0, 9 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244568679688327168",
  "in_reply_to_user_id" : 14881835,
  "text" : "@rubygems pw reset message was in spam folder; analysis message said \"Bayes spam probability is 99 to 100%\"; Anything I can do to help?",
  "id" : 244568679688327168,
  "created_at" : "2012-09-08 22:51:31 +0000",
  "in_reply_to_screen_name" : "rubygems",
  "in_reply_to_user_id_str" : "14881835",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nailgun",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "jruby",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244175035454083072",
  "text" : "#nailgun makes running rspec tests in #jruby so much faster. No JVM startup time.  Easy to use too.",
  "id" : 244175035454083072,
  "created_at" : "2012-09-07 20:47:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyGems",
      "screen_name" : "rubygems",
      "indices" : [ 0, 9 ],
      "id_str" : "14881835",
      "id" : 14881835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244115750929973248",
  "in_reply_to_user_id" : 14881835,
  "text" : "@rubygems Help!  Password reset not working!?",
  "id" : 244115750929973248,
  "created_at" : "2012-09-07 16:51:45 +0000",
  "in_reply_to_screen_name" : "rubygems",
  "in_reply_to_user_id_str" : "14881835",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia Motors America",
      "screen_name" : "Kia",
      "indices" : [ 0, 4 ],
      "id_str" : "23689478",
      "id" : 23689478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243804099466887168",
  "geo" : { },
  "id_str" : "243818252986359810",
  "in_reply_to_user_id" : 23689478,
  "text" : "@Kia Just called your cust. svc. A waste of time.  Kia's goal looks like it's evading responsibility for the braking issue. Another Toyota?",
  "id" : 243818252986359810,
  "in_reply_to_status_id" : 243804099466887168,
  "created_at" : "2012-09-06 21:09:36 +0000",
  "in_reply_to_screen_name" : "Kia",
  "in_reply_to_user_id_str" : "23689478",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kia Motors America",
      "screen_name" : "Kia",
      "indices" : [ 19, 23 ],
      "id_str" : "23689478",
      "id" : 23689478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243790234280673281",
  "text" : "VERY disappointed, @Kia cust svc. You say all Optimas have this brake issue (low assist on rebrake after brake release) so it's \"normal\".",
  "id" : 243790234280673281,
  "created_at" : "2012-09-06 19:18:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bluehost",
      "screen_name" : "bluehost",
      "indices" : [ 16, 25 ],
      "id_str" : "551208828",
      "id" : 551208828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243368216649420800",
  "text" : "Glad I moved to @bluehost. Great phone support, informative articles and screencasts. Reps were patient and taught me a lot. Great price too",
  "id" : 243368216649420800,
  "created_at" : "2012-09-05 15:21:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243367135185883136",
  "text" : "...and less control of my data. No export to .sql, only xml; no DB or shell access.",
  "id" : 243367135185883136,
  "created_at" : "2012-09-05 15:17:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/oYf1JXfG",
      "expanded_url" : "http:\/\/wordpress.com",
      "display_url" : "wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "243366373395427328",
  "text" : "Hosting a blog on http:\/\/t.co\/oYf1JXfG is a false economy.  Paid upgrades for features as fundamental as storage of media files.",
  "id" : 243366373395427328,
  "created_at" : "2012-09-05 15:13:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243366056868081664",
  "text" : "Labor Day Weekend was indeed a weekend of labor.  Consolidated WP blogs, web sites, domain registrations, email accounts to 1 hosting co.",
  "id" : 243366056868081664,
  "created_at" : "2012-09-05 15:12:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 49, 61 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/deD2onGC",
      "expanded_url" : "http:\/\/codingintheclink7.eventbrite.com",
      "display_url" : "codingintheclink7.eventbrite.com"
    } ]
  },
  "geo" : { },
  "id_str" : "243226661812858880",
  "text" : "Angela &amp; Co., you have guts and goodness: RT @angelaharms I'm in! \/\/ Coding in the Clink VII! http:\/\/t.co\/deD2onGC",
  "id" : 243226661812858880,
  "created_at" : "2012-09-05 05:58:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Grove",
      "screen_name" : "yaypie",
      "indices" : [ 108, 115 ],
      "id_str" : "11639232",
      "id" : 11639232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 33 ],
      "url" : "https:\/\/t.co\/2iBbpAqe",
      "expanded_url" : "https:\/\/github.com\/rgrove\/larch",
      "display_url" : "github.com\/rgrove\/larch"
    } ]
  },
  "geo" : { },
  "id_str" : "243204544392200192",
  "text" : "Used Larch (https:\/\/t.co\/2iBbpAqe), a great Ruby gem, to move email messages to a new IMAP server.  Thanks, @yaypie!",
  "id" : 243204544392200192,
  "created_at" : "2012-09-05 04:30:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 24, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/FBkbxc8m",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/04\/jruby-presentation-northern-virginia-ruby-user-group\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "243010522528755713",
  "text" : "Slides and audio for my #jruby presentation at  last week's Novarug meeting are now up on my blog at http:\/\/t.co\/FBkbxc8m",
  "id" : 243010522528755713,
  "created_at" : "2012-09-04 15:39:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 3, 12 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Kl5dyW0F",
      "expanded_url" : "http:\/\/xkcd.com\/844\/",
      "display_url" : "xkcd.com\/844\/"
    } ]
  },
  "geo" : { },
  "id_str" : "242818465457664000",
  "text" : "RT @nashjain: LOL: How to write good code: http:\/\/t.co\/Kl5dyW0F via @internetzJedi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/Kl5dyW0F",
        "expanded_url" : "http:\/\/xkcd.com\/844\/",
        "display_url" : "xkcd.com\/844\/"
      } ]
    },
    "geo" : { },
    "id_str" : "242343198347915264",
    "text" : "LOL: How to write good code: http:\/\/t.co\/Kl5dyW0F via @internetzJedi",
    "id" : 242343198347915264,
    "created_at" : "2012-09-02 19:28:15 +0000",
    "user" : {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "protected" : false,
      "id_str" : "10411062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775404265976332288\/LOoVpSln_normal.jpg",
      "id" : 10411062,
      "verified" : false
    }
  },
  "id" : 242818465457664000,
  "created_at" : "2012-09-04 02:56:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "microsoft",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241996494415212545",
  "text" : "Impressed with the hardware in the #microsoft store...it's no longer a race to the bottom. If only Windows had a native Unix command line.",
  "id" : 241996494415212545,
  "created_at" : "2012-09-01 20:30:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "microsoft",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241982785374535681",
  "text" : "Just walked into an Apple store...oh, wait, it's a #microsoft store that looks\/feels exactly like an Apple store -- layout, wood floor &amp; all",
  "id" : 241982785374535681,
  "created_at" : "2012-09-01 19:36:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]