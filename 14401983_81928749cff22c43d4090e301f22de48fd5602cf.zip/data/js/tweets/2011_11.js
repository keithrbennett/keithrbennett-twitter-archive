Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/WQXw2Q6D",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2061663\/Frozen-Planet-Climate-change-episode-wont-shown-US.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "139846374463254528",
  "text" : "Not one of America's noble moments -- network assists those who wish to keep their heads in the sand: http:\/\/t.co\/WQXw2Q6D",
  "id" : 139846374463254528,
  "created_at" : "2011-11-24 23:22:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139101676551421952",
  "text" : "At Beehive Baltimore for the Ruby hackfest tonight.  Awesome place! Incubator with creatively designed workspaces plus large coworking room.",
  "id" : 139101676551421952,
  "created_at" : "2011-11-22 22:03:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Uncle Bob Martin",
      "screen_name" : "unclebobmartin",
      "indices" : [ 10, 25 ],
      "id_str" : "9505092",
      "id" : 9505092
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scna",
      "indices" : [ 3, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139100269861543936",
  "text" : "At #scna, @unclebobmartin: Rails s\/be for delivery of the app data; back end s\/not be Rails. &gt; testing, scripting, packaging, &lt; coupling.",
  "id" : 139100269861543936,
  "created_at" : "2011-11-22 21:57:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bedra",
      "screen_name" : "abedra",
      "indices" : [ 40, 47 ],
      "id_str" : "8839052",
      "id" : 8839052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scna",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139098774260822016",
  "text" : "Enjoyed #scna in Chicago last weekend.  @abedra said \"less coffee, more naps\".  I agree.  Coffee masks fatigue; naps resolve it.",
  "id" : 139098774260822016,
  "created_at" : "2011-11-22 21:51:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/37Z96HPp",
      "expanded_url" : "https:\/\/github.com\/ruboto\/ruboto-irb\/commits\/master\/README.markdown",
      "display_url" : "github.com\/ruboto\/ruboto-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138803255416324096",
  "text" : "Woohoo! My first Ruboto commit (http:\/\/t.co\/37Z96HPp). So what if it was the README? :)",
  "id" : 138803255416324096,
  "created_at" : "2011-11-22 02:17:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/dleliCPR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch_popup?v=Cj6ho1-G6tw&vq=medium",
      "display_url" : "youtube.com\/watch_popup?v=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "136547792381415424",
  "text" : "Breathtaking bike-fu, on http:\/\/t.co\/dleliCPR.",
  "id" : 136547792381415424,
  "created_at" : "2011-11-15 20:55:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 7, 14 ],
      "id_str" : "17416571",
      "id" : 17416571
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scna2011",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136538961018494977",
  "text" : "Trying @airbnb for the first time this week, in Chicago, for #scna2011.  Wish me luck!",
  "id" : 136538961018494977,
  "created_at" : "2011-11-15 20:19:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135491994293256192",
  "text" : "Time to clean my laptop.  Little girl at pizza place whispers to her Dad, \"that man's computer is dirty\".",
  "id" : 135491994293256192,
  "created_at" : "2011-11-12 22:59:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pamela Slim",
      "screen_name" : "pamslim",
      "indices" : [ 3, 11 ],
      "id_str" : "14172588",
      "id" : 14172588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/iFAgS7DW",
      "expanded_url" : "http:\/\/twitpic.com\/7cr3t5",
      "display_url" : "twitpic.com\/7cr3t5"
    } ]
  },
  "geo" : { },
  "id_str" : "134733465286488064",
  "text" : "RT @pamslim: Yoda's pie chart. Does it get any better? http:\/\/t.co\/iFAgS7DW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/iFAgS7DW",
        "expanded_url" : "http:\/\/twitpic.com\/7cr3t5",
        "display_url" : "twitpic.com\/7cr3t5"
      } ]
    },
    "geo" : { },
    "id_str" : "134651245465051136",
    "text" : "Yoda's pie chart. Does it get any better? http:\/\/t.co\/iFAgS7DW",
    "id" : 134651245465051136,
    "created_at" : "2011-11-10 15:18:53 +0000",
    "user" : {
      "name" : "Pamela Slim",
      "screen_name" : "pamslim",
      "protected" : false,
      "id_str" : "14172588",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742540487093932032\/8wY0N7R-_normal.jpg",
      "id" : 14172588,
      "verified" : false
    }
  },
  "id" : 134733465286488064,
  "created_at" : "2011-11-10 20:45:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J'aime Ohm",
      "screen_name" : "jaimeohm",
      "indices" : [ 3, 12 ],
      "id_str" : "43301668",
      "id" : 43301668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133220825779290112",
  "text" : "RT @jaimeohm: Coders are special. \"We are expected to know how to do things we've never done before and estimate how long they will take ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sarah Allen",
        "screen_name" : "ultrasaurus",
        "indices" : [ 125, 137 ],
        "id_str" : "13368452",
        "id" : 13368452
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129284508087357440",
    "text" : "Coders are special. \"We are expected to know how to do things we've never done before and estimate how long they will take.\" @ultrasaurus",
    "id" : 129284508087357440,
    "created_at" : "2011-10-26 19:53:23 +0000",
    "user" : {
      "name" : "J'aime Ohm",
      "screen_name" : "jaimeohm",
      "protected" : false,
      "id_str" : "43301668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1368689709\/pii2011_avatar_normal.jpg",
      "id" : 43301668,
      "verified" : false
    }
  },
  "id" : 133220825779290112,
  "created_at" : "2011-11-06 16:34:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "133187927550345216",
  "geo" : { },
  "id_str" : "133193566498455552",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms I'm going to the airport in a while.  If they give it to me, I could overnight it to you tomorrow, and you'd get it Tuesday.",
  "id" : 133193566498455552,
  "in_reply_to_status_id" : 133187927550345216,
  "created_at" : "2011-11-06 14:46:35 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 10, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132968079272574976",
  "text" : "Anyone at #rubymidwest need a ride to the airport at 10:15 tomorrow morning?",
  "id" : 132968079272574976,
  "created_at" : "2011-11-05 23:50:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 9, 14 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 37, 50 ],
      "id_str" : "5660222",
      "id" : 5660222
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 83, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132862202649640962",
  "text" : "Talks by @avdi on Confident Code and @davetron5000 on Command Line Apps in Ruby at #rubymidwest will help me write better code.  Thanks!",
  "id" : 132862202649640962,
  "created_at" : "2011-11-05 16:49:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby Midwest",
      "screen_name" : "RubyMidwest",
      "indices" : [ 0, 12 ],
      "id_str" : "97356520",
      "id" : 97356520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyMidwest",
      "indices" : [ 56, 68 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132534289085628416",
  "geo" : { },
  "id_str" : "132625469257420800",
  "in_reply_to_user_id" : 97356520,
  "text" : "@RubyMidwest Huge thanks to the *organizers* for making #RubyMidwest awesome!",
  "id" : 132625469257420800,
  "in_reply_to_status_id" : 132534289085628416,
  "created_at" : "2011-11-05 01:09:10 +0000",
  "in_reply_to_screen_name" : "RubyMidwest",
  "in_reply_to_user_id_str" : "97356520",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Boyd",
      "screen_name" : "rboyd",
      "indices" : [ 0, 6 ],
      "id_str" : "3949351",
      "id" : 3949351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "132256115441418240",
  "geo" : { },
  "id_str" : "132446956478930945",
  "in_reply_to_user_id" : 3949351,
  "text" : "@rboyd Found karaoke tonight (Fri) closer: Westport Flea Market. So, #rubymidwest, who's up for it?  Starts at 9 I think. (pkng at Hol. Inn)",
  "id" : 132446956478930945,
  "in_reply_to_status_id" : 132256115441418240,
  "created_at" : "2011-11-04 13:19:49 +0000",
  "in_reply_to_screen_name" : "rboyd",
  "in_reply_to_user_id_str" : "3949351",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132243224877215744",
  "text" : "KCI (Kansas City airport): mere steps from gate to baggage claim, then mere steps to the door.  Very nice.",
  "id" : 132243224877215744,
  "created_at" : "2011-11-03 23:50:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132242885738369024",
  "text" : "Idyllic flight watching the lush cloud carpet across the majestic skies of the eastern half of the US (DC to Kansas City, MO).",
  "id" : 132242885738369024,
  "created_at" : "2011-11-03 23:48:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/VArbvK9O",
      "expanded_url" : "http:\/\/launch.groups.yahoo.com\/group\/KansasCityKaraoke\/message\/35267",
      "display_url" : "launch.groups.yahoo.com\/group\/KansasCi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132242586600611840",
  "text" : "#rubymidwest Anyone interested in karaoke tonight, 9:00+ to midnight? I found this: http:\/\/t.co\/VArbvK9O.",
  "id" : 132242586600611840,
  "created_at" : "2011-11-03 23:47:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u007B:ok, :dave\u007D",
      "screen_name" : "DaveShah",
      "indices" : [ 3, 12 ],
      "id_str" : "191802939",
      "id" : 191802939
    }, {
      "name" : "Jason Felice",
      "screen_name" : "eraserhd",
      "indices" : [ 75, 84 ],
      "id_str" : "43691392",
      "id" : 43691392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132238522684944385",
  "text" : "RT @daveshah: Just googled \"do a barrel roll\" \u2026 that made my day :) Thanks @eraserhd !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Felice",
        "screen_name" : "eraserhd",
        "indices" : [ 61, 70 ],
        "id_str" : "43691392",
        "id" : 43691392
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132196590994722816",
    "text" : "Just googled \"do a barrel roll\" \u2026 that made my day :) Thanks @eraserhd !",
    "id" : 132196590994722816,
    "created_at" : "2011-11-03 20:44:58 +0000",
    "user" : {
      "name" : "\u007B:ok, :dave\u007D",
      "screen_name" : "DaveShah",
      "protected" : false,
      "id_str" : "191802939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730757641425719296\/fVlVnlyL_normal.jpg",
      "id" : 191802939,
      "verified" : false
    }
  },
  "id" : 132238522684944385,
  "created_at" : "2011-11-03 23:31:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/VArbvK9O",
      "expanded_url" : "http:\/\/launch.groups.yahoo.com\/group\/KansasCityKaraoke\/message\/35267",
      "display_url" : "launch.groups.yahoo.com\/group\/KansasCi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "132166568531595264",
  "geo" : { },
  "id_str" : "132168564386971650",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms Absolutely!  Are you and\/or anyone else interested in karaoke tonight, 9 to midnight?  I found this: http:\/\/t.co\/VArbvK9O.",
  "id" : 132168564386971650,
  "in_reply_to_status_id" : 132166568531595264,
  "created_at" : "2011-11-03 18:53:35 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymidwest",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132166225257172992",
  "text" : "Will be arriving KCI for #rubymidwest 6:40 PM.  Renting car. Anyone want a ride and want to join me for famous KC Gates BBQ ribs on the way?",
  "id" : 132166225257172992,
  "created_at" : "2011-11-03 18:44:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/aGYshKP8",
      "expanded_url" : "http:\/\/www.nytimes.com\/2011\/10\/30\/opinion\/mona-simpsons-eulogy-for-steve-jobs.html?_r=1&pagewanted=all",
      "display_url" : "nytimes.com\/2011\/10\/30\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "131360544404930560",
  "text" : "Steve Jobs, an inspiration yet again, through his sister:  http:\/\/t.co\/aGYshKP8",
  "id" : 131360544404930560,
  "created_at" : "2011-11-01 13:22:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]