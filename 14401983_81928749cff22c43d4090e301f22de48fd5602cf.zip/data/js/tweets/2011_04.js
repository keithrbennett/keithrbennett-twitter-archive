Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "63061839818391553",
  "text" : "In the Philippines studying Android technology and meeting the active Ruby and Android dev communities here.",
  "id" : 63061839818391553,
  "created_at" : "2011-04-27 02:08:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61993038855151617",
  "text" : "Lots of fun, learning, and networking at Red Dot RubyConf in Singapore.  Soon, on to Manila and Cebu for more of the same.",
  "id" : 61993038855151617,
  "created_at" : "2011-04-24 03:21:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61992606632132609",
  "text" : "#reddot Thank you, Red Dot RubyConf in Singapore for a great conference and great times.  Red Dot and Singapore rock!",
  "id" : 61992606632132609,
  "created_at" : "2011-04-24 03:19:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 3, 12 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "61478597017346048",
  "text" : "RT @sarahmei: I like that #reddot ruby conf has longer talks in the morning, shorter talks in the afternoon. Goes well with my relative  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/joindiaspora.com\" rel=\"nofollow\"\u003EDiaspora\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "reddot",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "61326036872335360",
    "text" : "I like that #reddot ruby conf has longer talks in the morning, shorter talks in the afternoon. Goes well with my relative attention span.",
    "id" : 61326036872335360,
    "created_at" : "2011-04-22 07:10:41 +0000",
    "user" : {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "protected" : false,
      "id_str" : "14164724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731640298820894720\/SD43wVMV_normal.jpg",
      "id" : 14164724,
      "verified" : false
    }
  },
  "id" : 61478597017346048,
  "created_at" : "2011-04-22 17:16:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddot",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60909767417270272",
  "text" : "#reddot Any beginning Rubyists interested in a presentation of http:\/\/www.slideshare.net\/keithrbennett\/what-i-love-about-ruby?",
  "id" : 60909767417270272,
  "created_at" : "2011-04-21 03:36:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Dudney",
      "screen_name" : "bdudney",
      "indices" : [ 3, 11 ],
      "id_str" : "15178823",
      "id" : 15178823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "58584975196422144",
  "text" : "RT @bdudney: Funniest thing I've heard RE: C++ - When the only hammer you have is C++ every problem looks like your thumb.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "57913892071944192",
    "text" : "Funniest thing I've heard RE: C++ - When the only hammer you have is C++ every problem looks like your thumb.",
    "id" : 57913892071944192,
    "created_at" : "2011-04-12 21:12:02 +0000",
    "user" : {
      "name" : "Bill Dudney",
      "screen_name" : "bdudney",
      "protected" : false,
      "id_str" : "15178823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797920829099147264\/OLKYrhB__normal.jpg",
      "id" : 15178823,
      "verified" : false
    }
  },
  "id" : 58584975196422144,
  "created_at" : "2011-04-14 17:38:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Nathan Hessler",
      "screen_name" : "spune",
      "indices" : [ 19, 25 ],
      "id_str" : "14197941",
      "id" : 14197941
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 46, 51 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55962236073672704",
  "geo" : { },
  "id_str" : "55985384915599360",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler +1 for @spune's recommendation of @avdi's http:\/\/wideteams.com.",
  "id" : 55985384915599360,
  "in_reply_to_status_id" : 55962236073672704,
  "created_at" : "2011-04-07 13:28:50 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wouter dewanckel",
      "screen_name" : "wouterdewanckel",
      "indices" : [ 3, 19 ],
      "id_str" : "224201699",
      "id" : 224201699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55982996775387137",
  "text" : "RT @wouterdewanckel: CFO asks CEO \"What happens if we invest in developing our people & then they leave us?\" CEO:  'What happens if we d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "55563903240900608",
    "text" : "CFO asks CEO \"What happens if we invest in developing our people & then they leave us?\" CEO:  'What happens if we don't, and they stay?\"",
    "id" : 55563903240900608,
    "created_at" : "2011-04-06 09:34:01 +0000",
    "user" : {
      "name" : "wouter dewanckel",
      "screen_name" : "wouterdewanckel",
      "protected" : false,
      "id_str" : "224201699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1185502559\/wdw_normal.jpg",
      "id" : 224201699,
      "verified" : false
    }
  },
  "id" : 55982996775387137,
  "created_at" : "2011-04-07 13:19:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]