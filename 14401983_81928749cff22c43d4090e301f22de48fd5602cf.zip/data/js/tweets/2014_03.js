Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Rigor",
      "screen_name" : "crigor",
      "indices" : [ 0, 7 ],
      "id_str" : "111347742",
      "id" : 111347742
    }, {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 81, 92 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450340786517729280",
  "in_reply_to_user_id" : 111347742,
  "text" : "@crigor Congrats for organizing the first national ruby conf in the Philippines, @RubyConfPH.  Wish I could have been there. Next year!",
  "id" : 450340786517729280,
  "created_at" : "2014-03-30 18:36:25 +0000",
  "in_reply_to_screen_name" : "crigor",
  "in_reply_to_user_id_str" : "111347742",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 3, 14 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    }, {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 65, 76 ],
      "id_str" : "14761655",
      "id" : 14761655
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RubyConfPH\/status\/449490362105462784\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3ase5wLjd0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjzpGkXCUAIm7kL.jpg",
      "id_str" : "449490361878990850",
      "id" : 449490361878990850,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjzpGkXCUAIm7kL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 979,
        "resize" : "fit",
        "w" : 1469
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3ase5wLjd0"
    } ],
    "hashtags" : [ {
      "text" : "RubyConfPH",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449987295413018624",
  "text" : "RT @RubyConfPH: Friday hug from the Philippines! #RubyConfPH \/cc @tenderlove http:\/\/t.co\/3ase5wLjd0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Patterson",
        "screen_name" : "tenderlove",
        "indices" : [ 49, 60 ],
        "id_str" : "14761655",
        "id" : 14761655
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RubyConfPH\/status\/449490362105462784\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/3ase5wLjd0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjzpGkXCUAIm7kL.jpg",
        "id_str" : "449490361878990850",
        "id" : 449490361878990850,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjzpGkXCUAIm7kL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 979,
          "resize" : "fit",
          "w" : 1469
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3ase5wLjd0"
      } ],
      "hashtags" : [ {
        "text" : "RubyConfPH",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449490362105462784",
    "text" : "Friday hug from the Philippines! #RubyConfPH \/cc @tenderlove http:\/\/t.co\/3ase5wLjd0",
    "id" : 449490362105462784,
    "created_at" : "2014-03-28 10:17:08 +0000",
    "user" : {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "protected" : false,
      "id_str" : "1920753961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776092333389385728\/tZpJR9bc_normal.jpg",
      "id" : 1920753961,
      "verified" : false
    }
  },
  "id" : 449987295413018624,
  "created_at" : "2014-03-29 19:11:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 3, 7 ],
      "id_str" : "8076192",
      "id" : 8076192
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ucl",
      "indices" : [ 114, 118 ]
    }, {
      "text" : "rip",
      "indices" : [ 119, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449541779189035008",
  "text" : "RT @shr: Tribute to Jerry Roberts MBE, a key codebreaker at Bletchley Park - includes link to recent talk he gave #ucl #rip http:\/\/t.co\/lxg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ucl",
        "indices" : [ 105, 109 ]
      }, {
        "text" : "rip",
        "indices" : [ 110, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/lxgVSWrYca",
        "expanded_url" : "http:\/\/www.ucl.ac.uk\/news\/news-articles\/0314\/270314-tribute-to-captain-jerry-roberts-mbe\/",
        "display_url" : "ucl.ac.uk\/news\/news-arti\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "449527526415532032",
    "text" : "Tribute to Jerry Roberts MBE, a key codebreaker at Bletchley Park - includes link to recent talk he gave #ucl #rip http:\/\/t.co\/lxgVSWrYca",
    "id" : 449527526415532032,
    "created_at" : "2014-03-28 12:44:48 +0000",
    "user" : {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "protected" : false,
      "id_str" : "8076192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1317218980\/bc_1_normal.jpg",
      "id" : 8076192,
      "verified" : false
    }
  },
  "id" : 449541779189035008,
  "created_at" : "2014-03-28 13:41:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcamp",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/lwQRAVS69d",
      "expanded_url" : "http:\/\/barcamp.org\/w\/page\/402984\/FrontPage",
      "display_url" : "barcamp.org\/w\/page\/402984\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448932926840119297",
  "text" : "Bar Camp organizers, please keep the international schedule at http:\/\/t.co\/lwQRAVS69d updated!  #barcamp",
  "id" : 448932926840119297,
  "created_at" : "2014-03-26 21:22:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/pkX3pIiTj1",
      "expanded_url" : "http:\/\/www.eventbrite.com\/e\/barcamp-harrisburg-6-tickets-10590684021",
      "display_url" : "eventbrite.com\/e\/barcamp-harr\u2026"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/lwQRAVS69d",
      "expanded_url" : "http:\/\/barcamp.org\/w\/page\/402984\/FrontPage",
      "display_url" : "barcamp.org\/w\/page\/402984\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448932707381567488",
  "text" : "Barcamp Harrisburg, Saturday, May 3, 2014!  See http:\/\/t.co\/pkX3pIiTj1.  Organizers, could you update http:\/\/t.co\/lwQRAVS69d?",
  "id" : 448932707381567488,
  "created_at" : "2014-03-26 21:21:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448191670052737024",
  "text" : "TIL in Ruby if I want symbols' colons to be printed, I can use :my_symbol.inspect instead of :my_symbol.to_s.",
  "id" : 448191670052737024,
  "created_at" : "2014-03-24 20:16:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    }, {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 14, 19 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/zMbLIp7NDV",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2013\/11\/22\/rubys-injectreduce-and-each_with_object\/",
      "display_url" : "bbs-software.com\/blog\/2013\/11\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "447561223312519168",
  "geo" : { },
  "id_str" : "447607272789639168",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien @_ZPH Sometimes each_with_object is better. I blogged about it at http:\/\/t.co\/zMbLIp7NDV.",
  "id" : 447607272789639168,
  "in_reply_to_status_id" : 447561223312519168,
  "created_at" : "2014-03-23 05:34:24 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yardoc",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/QNAnrQUNu0",
      "expanded_url" : "http:\/\/rubydoc.info\/gems\/yard\/file\/docs\/Tags.md",
      "display_url" : "rubydoc.info\/gems\/yard\/file\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447092134450307072",
  "text" : "Some lesser known but useful #yardoc tags\/directives (see http:\/\/t.co\/QNAnrQUNu0): note example deprecated option raise yield* !macro",
  "id" : 447092134450307072,
  "created_at" : "2014-03-21 19:27:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atlassian",
      "screen_name" : "Atlassian",
      "indices" : [ 0, 10 ],
      "id_str" : "18060279",
      "id" : 18060279
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/oz6ARKKrSB",
      "expanded_url" : "http:\/\/www.augnova.com\/clearvision-git-best-practices\/#.UyxtkV7D7XQ",
      "display_url" : "augnova.com\/clearvision-gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "447055418985283584",
  "in_reply_to_user_id" : 18060279,
  "text" : "@atlassian (Jira\/Confluence\/...) Northern Virginina user group inaugural meeting re: git best practices April 1st: http:\/\/t.co\/oz6ARKKrSB",
  "id" : 447055418985283584,
  "created_at" : "2014-03-21 17:01:32 +0000",
  "in_reply_to_screen_name" : "Atlassian",
  "in_reply_to_user_id_str" : "18060279",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Johnson",
      "screen_name" : "mellowcoder",
      "indices" : [ 0, 12 ],
      "id_str" : "15535091",
      "id" : 15535091
    }, {
      "name" : "Mike Clark",
      "screen_name" : "clarkware",
      "indices" : [ 13, 23 ],
      "id_str" : "9941002",
      "id" : 9941002
    }, {
      "name" : "The Pragmatic Studio",
      "screen_name" : "pragmaticstudio",
      "indices" : [ 24, 40 ],
      "id_str" : "54202611",
      "id" : 54202611
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445560541344313345",
  "geo" : { },
  "id_str" : "445584716696387584",
  "in_reply_to_user_id" : 15535091,
  "text" : "@mellowcoder @clarkware @pragmaticstudio Good read. ctrl-L != cmd-K on Mac though. cmd-K clears screen *and* buffer, ctrl-l only screen.",
  "id" : 445584716696387584,
  "in_reply_to_status_id" : 445560541344313345,
  "created_at" : "2014-03-17 15:37:29 +0000",
  "in_reply_to_screen_name" : "mellowcoder",
  "in_reply_to_user_id_str" : "15535091",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aidan Feldman",
      "screen_name" : "aidanfeldman",
      "indices" : [ 38, 51 ],
      "id_str" : "18061835",
      "id" : 18061835
    }, {
      "name" : "Hacker Hours",
      "screen_name" : "HackerHours",
      "indices" : [ 84, 96 ],
      "id_str" : "995777874",
      "id" : 995777874
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0UZTkhm3Xf",
      "expanded_url" : "http:\/\/hackerhours.org\/diy-guide.html",
      "display_url" : "hackerhours.org\/diy-guide.html"
    } ]
  },
  "geo" : { },
  "id_str" : "445306212918104065",
  "text" : "If you want to create a hacker group, @aidanfeldman has done this in New York City (@hackerhours) and has advice at http:\/\/t.co\/0UZTkhm3Xf.",
  "id" : 445306212918104065,
  "created_at" : "2014-03-16 21:10:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "445248586050437120",
  "geo" : { },
  "id_str" : "445282580489707520",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms Congrats! Hope I can hear your keynote someday. We need &gt; focus on people\/comm issues &amp; I know you've thought about that a lot.",
  "id" : 445282580489707520,
  "in_reply_to_status_id" : 445248586050437120,
  "created_at" : "2014-03-16 19:36:54 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greenruby",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/wjxW8VSqfg",
      "expanded_url" : "https:\/\/gitprint.com\/",
      "display_url" : "gitprint.com"
    } ]
  },
  "geo" : { },
  "id_str" : "445281760759529472",
  "text" : "Thanks, #greenruby, for telling me about gitprint (https:\/\/t.co\/wjxW8VSqfg) for easily producing PDF's of Github markdown pages on github.",
  "id" : 445281760759529472,
  "created_at" : "2014-03-16 19:33:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/uTRZtTFz8A",
      "expanded_url" : "http:\/\/www.clickreadshare.com\/15-must-share-science-gifs\/",
      "display_url" : "clickreadshare.com\/15-must-share-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "444113293788327937",
  "text" : "Cool science-related animated gif's at http:\/\/t.co\/uTRZtTFz8A.",
  "id" : 444113293788327937,
  "created_at" : "2014-03-13 14:10:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443855395174768640",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi Thanks.  Just changed start_pos default val from nil to :first_record, max_count from nil to :infinite.  Good idea!",
  "id" : 443855395174768640,
  "created_at" : "2014-03-12 21:05:47 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443820495323287552",
  "text" : "This morning I sang in a quartet in front of 900 people at our all hands meeting. 1 screwup, but mostly did fine. Cool, but glad it's over.",
  "id" : 443820495323287552,
  "created_at" : "2014-03-12 18:47:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiland",
      "screen_name" : "jeremy6d",
      "indices" : [ 0, 9 ],
      "id_str" : "797183",
      "id" : 797183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443782199167709184",
  "geo" : { },
  "id_str" : "443785098518077440",
  "in_reply_to_user_id" : 797183,
  "text" : "@jeremy6d Oh, that's right, I stand corrected...you were defining (overwriting, in this case) a method on an instance of Array, not a class.",
  "id" : 443785098518077440,
  "in_reply_to_status_id" : 443782199167709184,
  "created_at" : "2014-03-12 16:26:27 +0000",
  "in_reply_to_screen_name" : "jeremy6d",
  "in_reply_to_user_id_str" : "797183",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiland",
      "screen_name" : "jeremy6d",
      "indices" : [ 0, 9 ],
      "id_str" : "797183",
      "id" : 797183
    }, {
      "name" : "JOBAIO",
      "screen_name" : "Jobaio",
      "indices" : [ 10, 17 ],
      "id_str" : "317862183",
      "id" : 317862183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443783407248896000",
  "geo" : { },
  "id_str" : "443784735928897537",
  "in_reply_to_user_id" : 797183,
  "text" : "@jeremy6d @Jobaio Wish I were there. ;)  I'd be very interested in any constructive criticism or support arguments.",
  "id" : 443784735928897537,
  "in_reply_to_status_id" : 443783407248896000,
  "created_at" : "2014-03-12 16:25:00 +0000",
  "in_reply_to_screen_name" : "jeremy6d",
  "in_reply_to_user_id_str" : "797183",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiland",
      "screen_name" : "jeremy6d",
      "indices" : [ 0, 9 ],
      "id_str" : "797183",
      "id" : 797183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443783161613656064",
  "in_reply_to_user_id" : 797183,
  "text" : "@jeremy6d You're very welcome, thank you too! For truly nested methods in Ruby, I think lambdas are our only option.",
  "id" : 443783161613656064,
  "created_at" : "2014-03-12 16:18:45 +0000",
  "in_reply_to_screen_name" : "jeremy6d",
  "in_reply_to_user_id_str" : "797183",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiland",
      "screen_name" : "jeremy6d",
      "indices" : [ 0, 9 ],
      "id_str" : "797183",
      "id" : 797183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443781522492260352",
  "in_reply_to_user_id" : 797183,
  "text" : "@jeremy6d Your example, though, defining methods on *another* class inside a method, makes good sense to me.",
  "id" : 443781522492260352,
  "created_at" : "2014-03-12 16:12:14 +0000",
  "in_reply_to_screen_name" : "jeremy6d",
  "in_reply_to_user_id_str" : "797183",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Weiland",
      "screen_name" : "jeremy6d",
      "indices" : [ 10, 19 ],
      "id_str" : "797183",
      "id" : 797183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/gLslg7KUW9",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/9510095",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443781100541054976",
  "text" : "Thanks to @jeremy6d for teaching me that Ruby supports inner methods. However, they become regular instance methods. https:\/\/t.co\/gLslg7KUW9",
  "id" : 443781100541054976,
  "created_at" : "2014-03-12 16:10:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443725297356382208",
  "text" : "Is there a weather app\/site that displays temp's in C and F at the same time so I can learn Celsius?",
  "id" : 443725297356382208,
  "created_at" : "2014-03-12 12:28:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 0, 5 ],
      "id_str" : "14816059",
      "id" : 14816059
    }, {
      "name" : "CVREG",
      "screen_name" : "cvreg",
      "indices" : [ 6, 12 ],
      "id_str" : "38036148",
      "id" : 38036148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443496125321203712",
  "geo" : { },
  "id_str" : "443531214839119872",
  "in_reply_to_user_id" : 14816059,
  "text" : "@chzy @cvreg Leaving.now. ; (",
  "id" : 443531214839119872,
  "in_reply_to_status_id" : 443496125321203712,
  "created_at" : "2014-03-11 23:37:36 +0000",
  "in_reply_to_screen_name" : "chzy",
  "in_reply_to_user_id_str" : "14816059",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 0, 5 ],
      "id_str" : "14816059",
      "id" : 14816059
    }, {
      "name" : "CVREG",
      "screen_name" : "cvreg",
      "indices" : [ 6, 12 ],
      "id_str" : "38036148",
      "id" : 38036148
    }, {
      "name" : "Jeff Morgan",
      "screen_name" : "chzy",
      "indices" : [ 13, 18 ],
      "id_str" : "14816059",
      "id" : 14816059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443441537624842240",
  "geo" : { },
  "id_str" : "443479126893408256",
  "in_reply_to_user_id" : 14816059,
  "text" : "@chzy @cvreg @chzy, the 1 day in the history of the universe that you and I will be in Richmond at the same time, and you can't make it?! :)",
  "id" : 443479126893408256,
  "in_reply_to_status_id" : 443441537624842240,
  "created_at" : "2014-03-11 20:10:37 +0000",
  "in_reply_to_screen_name" : "chzy",
  "in_reply_to_user_id_str" : "14816059",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CVREG",
      "screen_name" : "cvreg",
      "indices" : [ 38, 44 ],
      "id_str" : "38036148",
      "id" : 38036148
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/443475401881296897\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/za7Nsb2inn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BieKh0QCIAASraZ.jpg",
      "id_str" : "443475401885491200",
      "id" : 443475401885491200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BieKh0QCIAASraZ.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/za7Nsb2inn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/TB13y9SSk6",
      "expanded_url" : "http:\/\/www.meetup.com\/804RVA\/events\/169563482\/",
      "display_url" : "meetup.com\/804RVA\/events\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443475401881296897",
  "text" : "In Richmond to speak about lambdas at @cvreg, the Richmond Ruby meetup.  http:\/\/t.co\/TB13y9SSk6 http:\/\/t.co\/za7Nsb2inn",
  "id" : 443475401881296897,
  "created_at" : "2014-03-11 19:55:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 0, 11 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 12, 18 ],
      "id_str" : "16984400",
      "id" : 16984400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "443360918252961792",
  "geo" : { },
  "id_str" : "443474330933297152",
  "in_reply_to_user_id" : 9887102,
  "text" : "@metaskills @757rb  Thanks for the kind words.  The great questions and comments made it fun and engaging. I look forward to my next visit.",
  "id" : 443474330933297152,
  "in_reply_to_status_id" : 443360918252961792,
  "created_at" : "2014-03-11 19:51:34 +0000",
  "in_reply_to_screen_name" : "metaskills",
  "in_reply_to_user_id_str" : "9887102",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 3, 14 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 32, 46 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 60, 66 ],
      "id_str" : "16984400",
      "id" : 16984400
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 97, 108 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443472996758749184",
  "text" : "RT @metaskills: Thanks again to @keithrbennett for visiting @757rb. His talk on lambdas would be @jimweirich approved in my book! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 16, 30 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "757rb",
        "screen_name" : "757rb",
        "indices" : [ 44, 50 ],
        "id_str" : "16984400",
        "id" : 16984400
      }, {
        "name" : "Jim Weirich",
        "screen_name" : "jimweirich",
        "indices" : [ 81, 92 ],
        "id_str" : "9070452",
        "id" : 9070452
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/metaskills\/status\/443360918252961792\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Kt3uFOPRtw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiciZ-7CIAAfmSY.jpg",
        "id_str" : "443360918101958656",
        "id" : 443360918101958656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiciZ-7CIAAfmSY.jpg",
        "sizes" : [ {
          "h" : 243,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 138,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Kt3uFOPRtw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443360918252961792",
    "text" : "Thanks again to @keithrbennett for visiting @757rb. His talk on lambdas would be @jimweirich approved in my book! http:\/\/t.co\/Kt3uFOPRtw",
    "id" : 443360918252961792,
    "created_at" : "2014-03-11 12:20:54 +0000",
    "user" : {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "protected" : false,
      "id_str" : "9887102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593836365927882754\/WAy7ShNP_normal.png",
      "id" : 9887102,
      "verified" : false
    }
  },
  "id" : 443472996758749184,
  "created_at" : "2014-03-11 19:46:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke VanderHart",
      "screen_name" : "levanderhart",
      "indices" : [ 3, 16 ],
      "id_str" : "115507741",
      "id" : 115507741
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443443550093848576",
  "text" : "RT @levanderhart: Request: stop using handles that aren't your name. If I follow you, I care who you are, and I can't index all your clever\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443411584946565120",
    "text" : "Request: stop using handles that aren't your name. If I follow you, I care who you are, and I can't index all your clever handles mentally.",
    "id" : 443411584946565120,
    "created_at" : "2014-03-11 15:42:14 +0000",
    "user" : {
      "name" : "Luke VanderHart",
      "screen_name" : "levanderhart",
      "protected" : false,
      "id_str" : "115507741",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725753525913944064\/vzcltMC4_normal.jpg",
      "id" : 115507741,
      "verified" : false
    }
  },
  "id" : 443443550093848576,
  "created_at" : "2014-03-11 17:49:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/443202622674440192\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/t6KuypsW5F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiaSb9xIQAArX_T.jpg",
      "id_str" : "443202622477320192",
      "id" : 443202622477320192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiaSb9xIQAArX_T.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/t6KuypsW5F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443202622674440192",
  "text" : "The Atlantic Ocean at Virginia  Beach today. A reminder of our smallness in this world and universe. http:\/\/t.co\/t6KuypsW5F",
  "id" : 443202622674440192,
  "created_at" : "2014-03-11 01:51:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 3, 14 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 46, 60 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/3m7BkbnNIa",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443192150973751296",
  "text" : "RT @metaskills: For those interested, this is @keithrbennett\u2019s bag of tricks. https:\/\/t.co\/3m7BkbnNIa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 30, 44 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/3m7BkbnNIa",
        "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag",
        "display_url" : "github.com\/keithrbennett\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443165907494268928",
    "text" : "For those interested, this is @keithrbennett\u2019s bag of tricks. https:\/\/t.co\/3m7BkbnNIa",
    "id" : 443165907494268928,
    "created_at" : "2014-03-10 23:26:00 +0000",
    "user" : {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "protected" : false,
      "id_str" : "9887102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593836365927882754\/WAy7ShNP_normal.png",
      "id" : 9887102,
      "verified" : false
    }
  },
  "id" : 443192150973751296,
  "created_at" : "2014-03-11 01:10:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 3, 14 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 48, 62 ],
      "id_str" : "14401983",
      "id" : 14401983
    }, {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 80, 86 ],
      "id_str" : "16984400",
      "id" : 16984400
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/metaskills\/status\/443139293306167296\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TVqygMH6Pf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZY1toIAAAXeMl.jpg",
      "id_str" : "443139293146775552",
      "id" : 443139293146775552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZY1toIAAAXeMl.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TVqygMH6Pf"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443146519521554432",
  "text" : "RT @metaskills: At the Norfolk Tap Room feeding @keithrbennett before tonight's @757rb talk. Nerd fuel. #rubyfriends http:\/\/t.co\/TVqygMH6Pf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 32, 46 ],
        "id_str" : "14401983",
        "id" : 14401983
      }, {
        "name" : "757rb",
        "screen_name" : "757rb",
        "indices" : [ 64, 70 ],
        "id_str" : "16984400",
        "id" : 16984400
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/metaskills\/status\/443139293306167296\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/TVqygMH6Pf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZY1toIAAAXeMl.jpg",
        "id_str" : "443139293146775552",
        "id" : 443139293146775552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZY1toIAAAXeMl.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/TVqygMH6Pf"
      } ],
      "hashtags" : [ {
        "text" : "rubyfriends",
        "indices" : [ 88, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443139293306167296",
    "text" : "At the Norfolk Tap Room feeding @keithrbennett before tonight's @757rb talk. Nerd fuel. #rubyfriends http:\/\/t.co\/TVqygMH6Pf",
    "id" : 443139293306167296,
    "created_at" : "2014-03-10 21:40:15 +0000",
    "user" : {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "protected" : false,
      "id_str" : "9887102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/593836365927882754\/WAy7ShNP_normal.png",
      "id" : 9887102,
      "verified" : false
    }
  },
  "id" : 443146519521554432,
  "created_at" : "2014-03-10 22:08:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ken Collins",
      "screen_name" : "metaskills",
      "indices" : [ 12, 23 ],
      "id_str" : "9887102",
      "id" : 9887102
    }, {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 56, 62 ],
      "id_str" : "16984400",
      "id" : 16984400
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/443139366131871744\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/uZqpyGhzkH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZY588IAAAj7wY.jpg",
      "id_str" : "443139365976670208",
      "id" : 443139365976670208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZY588IAAAj7wY.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/uZqpyGhzkH"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443139366131871744",
  "text" : "Snacks with @metaskills before the Ruby Lambdas talk at @757rb.  #rubyfriends http:\/\/t.co\/uZqpyGhzkH",
  "id" : 443139366131871744,
  "created_at" : "2014-03-10 21:40:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 3, 9 ],
      "id_str" : "16984400",
      "id" : 16984400
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 128, 142 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/J8Zr9otfbz",
      "expanded_url" : "http:\/\/buff.ly\/1fQkKV8",
      "display_url" : "buff.ly\/1fQkKV8"
    } ]
  },
  "geo" : { },
  "id_str" : "443065574600765441",
  "text" : "RT @757rb: Come on out &amp; join us tonight at 6PM for Better Coding with Ruby Lambdas w\/ Keith Bennett http:\/\/t.co\/J8Zr9otfbz @keithrbennett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 117, 131 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/J8Zr9otfbz",
        "expanded_url" : "http:\/\/buff.ly\/1fQkKV8",
        "display_url" : "buff.ly\/1fQkKV8"
      } ]
    },
    "geo" : { },
    "id_str" : "443065471940960257",
    "text" : "Come on out &amp; join us tonight at 6PM for Better Coding with Ruby Lambdas w\/ Keith Bennett http:\/\/t.co\/J8Zr9otfbz @keithrbennett",
    "id" : 443065471940960257,
    "created_at" : "2014-03-10 16:46:54 +0000",
    "user" : {
      "name" : "757rb",
      "screen_name" : "757rb",
      "protected" : false,
      "id_str" : "16984400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261556230\/1079be6c4df43202c6dbc782f9b68706_normal.png",
      "id" : 16984400,
      "verified" : false
    }
  },
  "id" : 443065574600765441,
  "created_at" : "2014-03-10 16:47:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443053562697113600",
  "text" : "trick_bag is not so polished, but other than that, I'd appreciate any feedback about how it could be done better.",
  "id" : 443053562697113600,
  "created_at" : "2014-03-10 15:59:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/wkDp6Jl46G",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443053405242925057",
  "text" : "Published my trick_bag gem at https:\/\/t.co\/wkDp6Jl46G. Random but possibly useful Ruby enumerables, validations, and misc. utilities.",
  "id" : 443053405242925057,
  "created_at" : "2014-03-10 15:58:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0430\u0434\u044F \u041F\u0440\u0438\u043A\u043E\u043B\u044C\u043D\u0430\u044F",
      "screen_name" : "Hertz247",
      "indices" : [ 0, 9 ],
      "id_str" : "1909661160",
      "id" : 1909661160
    }, {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 10, 16 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442423548951666688",
  "text" : "@Hertz247 @Hertz bad service? How about treating your customers with good service instead of cutesy marketing campaigns?",
  "id" : 442423548951666688,
  "created_at" : "2014-03-08 22:16:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 1, 13 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    }, {
      "name" : "Brandon Linton",
      "screen_name" : "brandon_linton",
      "indices" : [ 23, 38 ],
      "id_str" : "45960017",
      "id" : 45960017
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/angelaharms\/status\/441958224564977665\/photo\/1",
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/syZhYUC9Gl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiImqc6CMAAbuDn.jpg",
      "id_str" : "441958224191696896",
      "id" : 441958224191696896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiImqc6CMAAbuDn.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/syZhYUC9Gl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442004931609120769",
  "text" : "\"@angelaharms: Thanks, @brandon_linton :) http:\/\/t.co\/syZhYUC9Gl\"  Amazingly hilarious and to the point.",
  "id" : 442004931609120769,
  "created_at" : "2014-03-07 18:32:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Graydon Hoare",
      "screen_name" : "graydon_moz",
      "indices" : [ 3, 15 ],
      "id_str" : "2771126580",
      "id" : 2771126580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442004000817573888",
  "text" : "RT @graydon_moz: Q: how many computer scientists does it take to calculate the optimal punchline to a joke about naming?\n\nA: cache invalida\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441966150801301505",
    "text" : "Q: how many computer scientists does it take to calculate the optimal punchline to a joke about naming?\n\nA: cache invalidation.",
    "id" : 441966150801301505,
    "created_at" : "2014-03-07 15:58:36 +0000",
    "user" : {
      "name" : "Graydon Hoare",
      "screen_name" : "graydon_pub",
      "protected" : false,
      "id_str" : "166154241",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1202995163\/graycode_normal.png",
      "id" : 166154241,
      "verified" : false
    }
  },
  "id" : 442004000817573888,
  "created_at" : "2014-03-07 18:29:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Prezi",
      "screen_name" : "prezi",
      "indices" : [ 65, 71 ],
      "id_str" : "35860484",
      "id" : 35860484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9nvdiTk7Tb",
      "expanded_url" : "http:\/\/blog.prezi.com\/latest\/2014\/2\/7\/10-most-common-rookie-mistakes-in-public-speaking.html",
      "display_url" : "blog.prezi.com\/latest\/2014\/2\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "441947691694559232",
  "text" : "Great article about \"10 Most Common Public Speaking Mistakes\" on @prezi blog at http:\/\/t.co\/9nvdiTk7Tb.",
  "id" : 441947691694559232,
  "created_at" : "2014-03-07 14:45:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Bryan Mandin",
      "screen_name" : "McTlnbskr",
      "indices" : [ 3, 13 ],
      "id_str" : "1183146410",
      "id" : 1183146410
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/McTlnbskr\/status\/441223009999675392\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zGupFJeOYb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh-J_WoCYAImoVh.jpg",
      "id_str" : "441223010003869698",
      "id" : 441223010003869698,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh-J_WoCYAImoVh.jpg",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 532
      }, {
        "h" : 272,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zGupFJeOYb"
    } ],
    "hashtags" : [ {
      "text" : "PHInternet",
      "indices" : [ 87, 98 ]
    }, {
      "text" : "InternetPH",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441263465597251584",
  "text" : "RT @McTlnbskr: Curious about the undersea cable wiring in the Philippines looks like?\n\n#PHInternet #InternetPH http:\/\/t.co\/zGupFJeOYb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/McTlnbskr\/status\/441223009999675392\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/zGupFJeOYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh-J_WoCYAImoVh.jpg",
        "id_str" : "441223010003869698",
        "id" : 441223010003869698,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh-J_WoCYAImoVh.jpg",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/zGupFJeOYb"
      } ],
      "hashtags" : [ {
        "text" : "PHInternet",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "InternetPH",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441223009999675392",
    "text" : "Curious about the undersea cable wiring in the Philippines looks like?\n\n#PHInternet #InternetPH http:\/\/t.co\/zGupFJeOYb",
    "id" : 441223009999675392,
    "created_at" : "2014-03-05 14:45:37 +0000",
    "user" : {
      "name" : "Robert Bryan Mandin",
      "screen_name" : "McTlnbskr",
      "protected" : false,
      "id_str" : "1183146410",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658259860484583424\/sYCznNlk_normal.png",
      "id" : 1183146410,
      "verified" : false
    }
  },
  "id" : 441263465597251584,
  "created_at" : "2014-03-05 17:26:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "757rb",
      "screen_name" : "757rb",
      "indices" : [ 3, 9 ],
      "id_str" : "16984400",
      "id" : 16984400
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 77, 91 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/pw6soXJfLf",
      "expanded_url" : "http:\/\/buff.ly\/1n3z3WF",
      "display_url" : "buff.ly\/1n3z3WF"
    } ]
  },
  "geo" : { },
  "id_str" : "440614493379244033",
  "text" : "RT @757rb: Join us next Monday 3\/10 for Better Coding with Ruby Lambdas with @keithrbennett! http:\/\/t.co\/pw6soXJfLf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 66, 80 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/pw6soXJfLf",
        "expanded_url" : "http:\/\/buff.ly\/1n3z3WF",
        "display_url" : "buff.ly\/1n3z3WF"
      } ]
    },
    "geo" : { },
    "id_str" : "440613034021896192",
    "text" : "Join us next Monday 3\/10 for Better Coding with Ruby Lambdas with @keithrbennett! http:\/\/t.co\/pw6soXJfLf",
    "id" : 440613034021896192,
    "created_at" : "2014-03-03 22:21:48 +0000",
    "user" : {
      "name" : "757rb",
      "screen_name" : "757rb",
      "protected" : false,
      "id_str" : "16984400",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000261556230\/1079be6c4df43202c6dbc782f9b68706_normal.png",
      "id" : 16984400,
      "verified" : false
    }
  },
  "id" : 440614493379244033,
  "created_at" : "2014-03-03 22:27:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Economist",
      "screen_name" : "TheEconomist",
      "indices" : [ 55, 68 ],
      "id_str" : "5988062",
      "id" : 5988062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/PKQyAWExWH",
      "expanded_url" : "http:\/\/www.fairfaxcounty.gov\/library\/news\/newsreleases\/news1914.htm",
      "display_url" : "fairfaxcounty.gov\/library\/news\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440310742059737089",
  "text" : "Awesome! My local library offers free online access to @TheEconomist &amp; other mags (http:\/\/t.co\/PKQyAWExWH). No more $100\/year subscription!",
  "id" : 440310742059737089,
  "created_at" : "2014-03-03 02:20:36 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]