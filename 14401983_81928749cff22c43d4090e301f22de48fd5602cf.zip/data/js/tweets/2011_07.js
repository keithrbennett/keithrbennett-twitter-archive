Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avery Edison",
      "screen_name" : "aedison",
      "indices" : [ 3, 11 ],
      "id_str" : "1471021",
      "id" : 1471021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "97677498824921089",
  "text" : "RT @aedison: Software patents in the real world: I now own the rights to \"opening doors\". Hope your business doesn't rely on moving betw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/birdhouseapp.com\" rel=\"nofollow\"\u003EBirdhouse\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "97306658027470849",
    "text" : "Software patents in the real world: I now own the rights to \"opening doors\". Hope your business doesn't rely on moving between rooms!",
    "id" : 97306658027470849,
    "created_at" : "2011-07-30 14:04:49 +0000",
    "user" : {
      "name" : "Avery Edison",
      "screen_name" : "aedison",
      "protected" : false,
      "id_str" : "1471021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813581018758254594\/FgyGORFJ_normal.jpg",
      "id" : 1471021,
      "verified" : true
    }
  },
  "id" : 97677498824921089,
  "created_at" : "2011-07-31 14:38:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "97442716836827136",
  "geo" : { },
  "id_str" : "97447388658155520",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler An open space conference would be somewhere in between. You could spend all day in a free form discussion, or in the hallways.",
  "id" : 97447388658155520,
  "in_reply_to_status_id" : 97442716836827136,
  "created_at" : "2011-07-30 23:24:02 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "96995178254045184",
  "geo" : { },
  "id_str" : "97045522191360000",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi starbucks drip coffee is awful everywhere imo. A few years ago they stopped making the good stuff. Only custom orders are good.",
  "id" : 97045522191360000,
  "in_reply_to_status_id" : 96995178254045184,
  "created_at" : "2011-07-29 20:47:10 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 110 ],
      "url" : "http:\/\/t.co\/cYro6mP",
      "expanded_url" : "http:\/\/krbtech.wordpress.com\/2011\/05\/28\/android-guis-the-case-against-gui-builders-and-data-driven-gui-configuration\/",
      "display_url" : "krbtech.wordpress.com\/2011\/05\/28\/and\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "87155416714317824",
  "geo" : { },
  "id_str" : "87389314610237440",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl I'm a newbie at Android, but wrote an article about XML vs. programmatic config at http:\/\/t.co\/cYro6mP.",
  "id" : 87389314610237440,
  "in_reply_to_status_id" : 87155416714317824,
  "created_at" : "2011-07-03 05:16:50 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]