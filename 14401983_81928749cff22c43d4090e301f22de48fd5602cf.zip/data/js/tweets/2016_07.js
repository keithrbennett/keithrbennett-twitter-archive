Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/758131939429593089\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/PLrVDcNRMU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoVs2_HUsAEevSG.jpg",
      "id_str" : "758131804192681985",
      "id" : 758131804192681985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoVs2_HUsAEevSG.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/PLrVDcNRMU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758131939429593089",
  "text" : "# vancouver bus stops are numbered &amp; you can send a text to get next bus numbers w\/arrival times (see bottom). https:\/\/t.co\/PLrVDcNRMU",
  "id" : 758131939429593089,
  "created_at" : "2016-07-27 02:48:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chokchai",
      "screen_name" : "juacompe",
      "indices" : [ 37, 46 ],
      "id_str" : "14555685",
      "id" : 14555685
    }, {
      "name" : "Jean Jordaan",
      "screen_name" : "neajj",
      "indices" : [ 53, 59 ],
      "id_str" : "14405320",
      "id" : 14405320
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/757990314514616320\/photo\/1",
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/3AXDpZADtU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoTfL0xUsAIux-P.jpg",
      "id_str" : "757976031542161410",
      "id" : 757976031542161410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoTfL0xUsAIux-P.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 4096,
        "resize" : "fit",
        "w" : 2304
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/3AXDpZADtU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757990314514616320",
  "text" : "Good times 2 nights ago in Bangkok w\/@juacompe &amp; @neajj on the last night of my 4 month Asia trip. In Vancouver now. https:\/\/t.co\/3AXDpZADtU",
  "id" : 757990314514616320,
  "created_at" : "2016-07-26 17:25:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/757422478419341312\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Rr2Eag92xT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoLnsbGVIAAHwSl.jpg",
      "id_str" : "757422437726232576",
      "id" : 757422437726232576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoLnsbGVIAAHwSl.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/Rr2Eag92xT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757422478419341312",
  "text" : "Bye for now, Asia, it's been a great 4 months. Next stop, Vancouver. Sad to leave but ready for the next chapter. https:\/\/t.co\/Rr2Eag92xT",
  "id" : 757422478419341312,
  "created_at" : "2016-07-25 03:49:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gay",
      "screen_name" : "saturnflyer",
      "indices" : [ 0, 12 ],
      "id_str" : "6173562",
      "id" : 6173562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756457641367461888",
  "geo" : { },
  "id_str" : "756749886096338944",
  "in_reply_to_user_id" : 6173562,
  "text" : "@saturnflyer Thanks, Jim. It's been a great adventure. I'll be home in a couple of weeks.",
  "id" : 756749886096338944,
  "in_reply_to_status_id" : 756457641367461888,
  "created_at" : "2016-07-23 07:16:47 +0000",
  "in_reply_to_screen_name" : "saturnflyer",
  "in_reply_to_user_id_str" : "6173562",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Van Vu",
      "screen_name" : "zeronevu",
      "indices" : [ 85, 94 ],
      "id_str" : "83762045",
      "id" : 83762045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756747288056180736\/photo\/1",
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/LeH4QPPbjs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoCBol8UIAAwJdf.jpg",
      "id_str" : "756747271778082816",
      "id" : 756747271778082816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoCBol8UIAAwJdf.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/LeH4QPPbjs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756747288056180736",
  "text" : "Historic Saigon City Hall as seen from 49th floor observatory of Saigon Skydeck with @zeronevu. https:\/\/t.co\/LeH4QPPbjs",
  "id" : 756747288056180736,
  "created_at" : "2016-07-23 07:06:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Van Vu",
      "screen_name" : "zeronevu",
      "indices" : [ 21, 30 ],
      "id_str" : "83762045",
      "id" : 83762045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756685480511496192\/photo\/1",
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/WDeI9wIcou",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoBJY9rUEAAoQuG.jpg",
      "id_str" : "756685430620164096",
      "id" : 756685430620164096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoBJY9rUEAAoQuG.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/WDeI9wIcou"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756685480511496192",
  "text" : "Enjoying coffee with @zeronevu in Ho Chi Minh City. #rubyfriends https:\/\/t.co\/WDeI9wIcou",
  "id" : 756685480511496192,
  "created_at" : "2016-07-23 03:00:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756455013380034560\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/ROHDmWc1aV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn93yzXVMAAJCoR.jpg",
      "id_str" : "756454977086763008",
      "id" : 756454977086763008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn93yzXVMAAJCoR.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ROHDmWc1aV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756455013380034560",
  "text" : "Crossing the street in Ho Chi Minh City is an adventure. Smtms I attach myself to locals. 1 guy even took my hand. \u263A https:\/\/t.co\/ROHDmWc1aV",
  "id" : 756455013380034560,
  "created_at" : "2016-07-22 11:45:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756453566261231616\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/yMIXs8H4mc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn92fDmUkAExAxV.jpg",
      "id_str" : "756453538335592449",
      "id" : 756453538335592449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn92fDmUkAExAxV.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/yMIXs8H4mc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756453566261231616",
  "text" : "An $8 hour long foot massage is just what the doctor ordered after walking a couple of miles in Ho Chi Minh City. https:\/\/t.co\/yMIXs8H4mc",
  "id" : 756453566261231616,
  "created_at" : "2016-07-22 11:39:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naresh Jain",
      "screen_name" : "nashjain",
      "indices" : [ 0, 9 ],
      "id_str" : "10411062",
      "id" : 10411062
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756354051944673280",
  "geo" : { },
  "id_str" : "756367624360103936",
  "in_reply_to_user_id" : 10411062,
  "text" : "@nashjain Awful.  When I remember, I edit web form text in my own editor &amp; then copy\/paste it into the form. Then I can save, email, etc.",
  "id" : 756367624360103936,
  "in_reply_to_status_id" : 756354051944673280,
  "created_at" : "2016-07-22 05:57:48 +0000",
  "in_reply_to_screen_name" : "nashjain",
  "in_reply_to_user_id_str" : "10411062",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756098049512919040\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/a7WgT7NpFt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4zI4DUIAAWdjl.jpg",
      "id_str" : "756098015023079424",
      "id" : 756098015023079424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4zI4DUIAAWdjl.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/a7WgT7NpFt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756098049512919040",
  "text" : "I've eaten pho hundreds of times before, but this is my first time doing it in Vietnam. https:\/\/t.co\/a7WgT7NpFt",
  "id" : 756098049512919040,
  "created_at" : "2016-07-21 12:06:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "756094353391677442",
  "geo" : { },
  "id_str" : "756096470315433984",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse Yes, it was. Amazing place. So many places for food, coffee, &amp; massage. Beats the DC area by so, so far for these.",
  "id" : 756096470315433984,
  "in_reply_to_status_id" : 756094353391677442,
  "created_at" : "2016-07-21 12:00:20 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/756063849304907776\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/bYjvBs7oUX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cn4UCj_UIAAIGWE.jpg",
      "id_str" : "756063821697916928",
      "id" : 756063821697916928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cn4UCj_UIAAIGWE.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/bYjvBs7oUX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "756063849304907776",
  "text" : "My first meal in Vietnam last night. Newbie mistake: grossly underestimate food quantity of menu items. https:\/\/t.co\/bYjvBs7oUX",
  "id" : 756063849304907776,
  "created_at" : "2016-07-21 09:50:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/755742717712359424\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/sb2N7F4kOR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnzv5toVYAEO8zT.jpg",
      "id_str" : "755742612271751169",
      "id" : 755742612271751169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnzv5toVYAEO8zT.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/sb2N7F4kOR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755742717712359424",
  "text" : "My ride from Bangkok to Ho Chi Minh City (Saigon), Vietnam. Just 1.5 hour flight. Will be my 1st time in Vietnam. https:\/\/t.co\/sb2N7F4kOR",
  "id" : 755742717712359424,
  "created_at" : "2016-07-20 12:34:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/755273661729288192\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ECSgguJLLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CntFXKkUEAAaGpU.jpg",
      "id_str" : "755273626790662144",
      "id" : 755273626790662144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CntFXKkUEAAaGpU.jpg",
      "sizes" : [ {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      } ],
      "display_url" : "pic.twitter.com\/ECSgguJLLA"
    } ],
    "hashtags" : [ {
      "text" : "Thailand",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755273661729288192",
  "text" : "I usually go for durian or mango shakes, but this coconut shake is amazing. Might become my new favorite. #Thailand https:\/\/t.co\/ECSgguJLLA",
  "id" : 755273661729288192,
  "created_at" : "2016-07-19 05:30:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/754693295322705920\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/WAzzqD0e7w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnk1hkFVIAAbzK7.jpg",
      "id_str" : "754693263299256320",
      "id" : 754693263299256320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnk1hkFVIAAbzK7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/WAzzqD0e7w"
    } ],
    "hashtags" : [ {
      "text" : "chiangmai",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754693295322705920",
  "text" : "Hordes of tourists at Chiang Mai's Weekend Market tonight. #chiangmai https:\/\/t.co\/WAzzqD0e7w",
  "id" : 754693295322705920,
  "created_at" : "2016-07-17 15:04:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "karma",
      "indices" : [ 134, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "754532342757203969",
  "text" : "2 days ago I heard my neighbor coughing thru the thin walls of my hotel. Caught myself annoyed and w\/o empathy. Today I have a cough. #karma",
  "id" : 754532342757203969,
  "created_at" : "2016-07-17 04:25:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "indices" : [ 3, 18 ],
      "id_str" : "18655567",
      "id" : 18655567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/752937977928491008\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/LE1OfwULpV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnL5F7OVMAAVhN0.jpg",
      "id_str" : "752937967916756992",
      "id" : 752937967916756992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnL5F7OVMAAVhN0.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/LE1OfwULpV"
    } ],
    "hashtags" : [ {
      "text" : "Brexit",
      "indices" : [ 50, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753095070660820992",
  "text" : "RT @stevesilberman: Finally, an expert comment on #Brexit. https:\/\/t.co\/LE1OfwULpV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stevesilberman\/status\/752937977928491008\/photo\/1",
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/LE1OfwULpV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnL5F7OVMAAVhN0.jpg",
        "id_str" : "752937967916756992",
        "id" : 752937967916756992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnL5F7OVMAAVhN0.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/LE1OfwULpV"
      } ],
      "hashtags" : [ {
        "text" : "Brexit",
        "indices" : [ 30, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752937977928491008",
    "text" : "Finally, an expert comment on #Brexit. https:\/\/t.co\/LE1OfwULpV",
    "id" : 752937977928491008,
    "created_at" : "2016-07-12 18:49:37 +0000",
    "user" : {
      "name" : "Steve Silberman",
      "screen_name" : "stevesilberman",
      "protected" : false,
      "id_str" : "18655567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801317729978449920\/1ZDKwlMv_normal.jpg",
      "id" : 18655567,
      "verified" : true
    }
  },
  "id" : 753095070660820992,
  "created_at" : "2016-07-13 05:13:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "753060977801830400",
  "geo" : { },
  "id_str" : "753092949592903680",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton Apparently. It worked for this one. \u263A",
  "id" : 753092949592903680,
  "in_reply_to_status_id" : 753060977801830400,
  "created_at" : "2016-07-13 05:05:25 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/752547382630363136\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/S1dO4phkVF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnGV0XIUsAEsGMz.jpg",
      "id_str" : "752547339542245377",
      "id" : 752547339542245377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnGV0XIUsAEsGMz.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/S1dO4phkVF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752547382630363136",
  "text" : "I drove a motor vehicle today for the fist time since leaving the USA 4 months ago. This 125 cc motorbike. https:\/\/t.co\/S1dO4phkVF",
  "id" : 752547382630363136,
  "created_at" : "2016-07-11 16:57:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RailsCasts",
      "screen_name" : "railscasts",
      "indices" : [ 1, 12 ],
      "id_str" : "22086312",
      "id" : 22086312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752538308647882752",
  "text" : ".@railscasts Ruby's Kernel#Array does the things in your quiz for Rails' Array.wrap.  wrap method is Rails-only, that functionality is not.",
  "id" : 752538308647882752,
  "created_at" : "2016-07-11 16:21:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/752473614851592193\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/S0ACt2KkAm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnFSumOVMAEDSWN.jpg",
      "id_str" : "752473573235699713",
      "id" : 752473573235699713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnFSumOVMAEDSWN.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      } ],
      "display_url" : "pic.twitter.com\/S0ACt2KkAm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752473614851592193",
  "text" : "Hello, Chiang Mai! Bean noodle shrimp pad thai, mango with sticky rice, water, all for under $4 at the food court. https:\/\/t.co\/S0ACt2KkAm",
  "id" : 752473614851592193,
  "created_at" : "2016-07-11 12:04:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Liles",
      "screen_name" : "bryanl",
      "indices" : [ 0, 7 ],
      "id_str" : "659933",
      "id" : 659933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751887883053793280",
  "geo" : { },
  "id_str" : "752102152957358080",
  "in_reply_to_user_id" : 659933,
  "text" : "@bryanl That sucks.  To state the obvious, he does not speak for me, or anyone I know, for that matter.",
  "id" : 752102152957358080,
  "in_reply_to_status_id" : 751887883053793280,
  "created_at" : "2016-07-10 11:28:21 +0000",
  "in_reply_to_screen_name" : "bryanl",
  "in_reply_to_user_id_str" : "659933",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 0, 13 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "752049050820554752",
  "geo" : { },
  "id_str" : "752100989579124736",
  "in_reply_to_user_id" : 479019528,
  "text" : "@JuanitoFatas I have had dreams like that from time to time for many years.  They haven't gotten me yet! :)",
  "id" : 752100989579124736,
  "in_reply_to_status_id" : 752049050820554752,
  "created_at" : "2016-07-10 11:23:43 +0000",
  "in_reply_to_screen_name" : "JuanitoFatas",
  "in_reply_to_user_id_str" : "479019528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/752085602372186112\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/R3LmIqPmes",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm_xzynVUAA9ay8.jpg",
      "id_str" : "752085534856531968",
      "id" : 752085534856531968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm_xzynVUAA9ay8.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/R3LmIqPmes"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752085602372186112",
  "text" : "Had to try this \"Bennett\" soap, found in Thailand supermarkets &amp; convenience stores. Not bad! https:\/\/t.co\/R3LmIqPmes",
  "id" : 752085602372186112,
  "created_at" : "2016-07-10 10:22:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 14, 23 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    }, {
      "name" : "Airbnb",
      "screen_name" : "Airbnb",
      "indices" : [ 34, 41 ],
      "id_str" : "17416571",
      "id" : 17416571
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751849741902712832",
  "geo" : { },
  "id_str" : "751850027211907073",
  "in_reply_to_user_id" : 14401983,
  "text" : "@onealexharms @zspencer But also, @airbnb hosts are individuals, not org's, and are less reliable as a result. Can cancel for many reasons.",
  "id" : 751850027211907073,
  "in_reply_to_status_id" : 751849741902712832,
  "created_at" : "2016-07-09 18:46:29 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "indices" : [ 0, 13 ],
      "id_str" : "15349954",
      "id" : 15349954
    }, {
      "name" : "Z",
      "screen_name" : "zspencer",
      "indices" : [ 14, 23 ],
      "id_str" : "4076569212",
      "id" : 4076569212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751848006228422657",
  "geo" : { },
  "id_str" : "751849741902712832",
  "in_reply_to_user_id" : 15349954,
  "text" : "@onealexharms @zspencer  Your host would benefit by letting you renew monthly; maximizes income for him\/her; but yes, there's a risk.",
  "id" : 751849741902712832,
  "in_reply_to_status_id" : 751848006228422657,
  "created_at" : "2016-07-09 18:45:21 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TD Bank",
      "screen_name" : "TDBank_US",
      "indices" : [ 0, 10 ],
      "id_str" : "67378997",
      "id" : 67378997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751848529123946497",
  "geo" : { },
  "id_str" : "751849037226078208",
  "in_reply_to_user_id" : 67378997,
  "text" : "@TDBank_US That's nothing negative about you.  Just that for people overseas they can't walk into your bank.",
  "id" : 751849037226078208,
  "in_reply_to_status_id" : 751848529123946497,
  "created_at" : "2016-07-09 18:42:33 +0000",
  "in_reply_to_screen_name" : "TDBank_US",
  "in_reply_to_user_id_str" : "67378997",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "TD Bank",
      "screen_name" : "TDBank_US",
      "indices" : [ 32, 42 ],
      "id_str" : "67378997",
      "id" : 67378997
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751535299193372672",
  "geo" : { },
  "id_str" : "751835658637877249",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler For extended hours, @TDBank_US is the best; but if you're outside the US that may not be helpful.",
  "id" : 751835658637877249,
  "in_reply_to_status_id" : 751535299193372672,
  "created_at" : "2016-07-09 17:49:24 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Chad Fowler)))",
      "screen_name" : "chadfowler",
      "indices" : [ 0, 11 ],
      "id_str" : "790205",
      "id" : 790205
    }, {
      "name" : "Charles Schwab Corp",
      "screen_name" : "CharlesSchwab",
      "indices" : [ 56, 70 ],
      "id_str" : "132703700",
      "id" : 132703700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751535299193372672",
  "geo" : { },
  "id_str" : "751835267464458240",
  "in_reply_to_user_id" : 790205,
  "text" : "@chadfowler For fee-free international ATM withdrawals, @CharlesSchwab is great.  Saved $100's in fees during my 4 months outside of USA.",
  "id" : 751835267464458240,
  "in_reply_to_status_id" : 751535299193372672,
  "created_at" : "2016-07-09 17:47:50 +0000",
  "in_reply_to_screen_name" : "chadfowler",
  "in_reply_to_user_id_str" : "790205",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Karr, Author",
      "screen_name" : "marykarrlit",
      "indices" : [ 3, 15 ],
      "id_str" : "155613846",
      "id" : 155613846
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marykarrlit\/status\/751560515219025920\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/wf2GbohysF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm4UTRIWAAEenJd.jpg",
      "id_str" : "751560509065920513",
      "id" : 751560509065920513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm4UTRIWAAEenJd.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 749
      } ],
      "display_url" : "pic.twitter.com\/wf2GbohysF"
    } ],
    "hashtags" : [ {
      "text" : "Dallas",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "hope",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "compassion",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751812182145241090",
  "text" : "RT @marykarrlit: Very moved by this post from a stranger's run-in with a #Dallas cop. #hope #compassion https:\/\/t.co\/wf2GbohysF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marykarrlit\/status\/751560515219025920\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/wf2GbohysF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm4UTRIWAAEenJd.jpg",
        "id_str" : "751560509065920513",
        "id" : 751560509065920513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm4UTRIWAAEenJd.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 551
        }, {
          "h" : 924,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 924,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 924,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/wf2GbohysF"
      } ],
      "hashtags" : [ {
        "text" : "Dallas",
        "indices" : [ 56, 63 ]
      }, {
        "text" : "hope",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "compassion",
        "indices" : [ 75, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751560515219025920",
    "text" : "Very moved by this post from a stranger's run-in with a #Dallas cop. #hope #compassion https:\/\/t.co\/wf2GbohysF",
    "id" : 751560515219025920,
    "created_at" : "2016-07-08 23:36:04 +0000",
    "user" : {
      "name" : "Mary Karr, Author",
      "screen_name" : "marykarrlit",
      "protected" : false,
      "id_str" : "155613846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696816134989881344\/IIq9VFrM_normal.jpg",
      "id" : 155613846,
      "verified" : true
    }
  },
  "id" : 751812182145241090,
  "created_at" : "2016-07-09 16:16:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rails Hurts",
      "screen_name" : "railshurts",
      "indices" : [ 1, 12 ],
      "id_str" : "2446537844",
      "id" : 2446537844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751464461236482048",
  "text" : ".@railshurts Re: your range include? question: Ruby DOES have range include?, but neither Ruby nor Rails takes a range argument.",
  "id" : 751464461236482048,
  "created_at" : "2016-07-08 17:14:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Filipowski",
      "screen_name" : "janfilipowski",
      "indices" : [ 0, 14 ],
      "id_str" : "41873047",
      "id" : 41873047
    }, {
      "name" : "Ivan Nemytchenko",
      "screen_name" : "inemation",
      "indices" : [ 15, 25 ],
      "id_str" : "38708784",
      "id" : 38708784
    }, {
      "name" : "Rails Hurts",
      "screen_name" : "railshurts",
      "indices" : [ 26, 37 ],
      "id_str" : "2446537844",
      "id" : 2446537844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "750307682993790976",
  "geo" : { },
  "id_str" : "751462442442498048",
  "in_reply_to_user_id" : 41873047,
  "text" : "@janfilipowski @inemation @railshurts I found this too and it's still up there 4 days later. It should be:  '[%s]' % 'same old drag'.",
  "id" : 751462442442498048,
  "in_reply_to_status_id" : 750307682993790976,
  "created_at" : "2016-07-08 17:06:22 +0000",
  "in_reply_to_screen_name" : "janfilipowski",
  "in_reply_to_user_id_str" : "41873047",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 49, 56 ],
      "id_str" : "13334762",
      "id" : 13334762
    }, {
      "name" : "Atlassian Bitbucket",
      "screen_name" : "Bitbucket",
      "indices" : [ 65, 75 ],
      "id_str" : "174379786",
      "id" : 174379786
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "youneverknow",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751395653813571584",
  "text" : "To be really safe, I keep a copy of an important @Github repo on @Bitbucket.  git remote add bitbucket... #youneverknow",
  "id" : 751395653813571584,
  "created_at" : "2016-07-08 12:40:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "Google",
      "indices" : [ 11, 18 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750924144842199040",
  "text" : "Well done, @google! Tried on a hunch, calculating hotel room fee + taxes from Thai Baht to dollars works in 1 step!: (2231 + 417) thb to usd",
  "id" : 750924144842199040,
  "created_at" : "2016-07-07 05:27:22 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "bsletten",
      "screen_name" : "bsletten",
      "indices" : [ 3, 12 ],
      "id_str" : "9630822",
      "id" : 9630822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "juno",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "750333426423607296",
  "text" : "RT @bsletten: There is daily evidence of how terrible we can be. Revel in this moment of how awesome we can be. #juno",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "juno",
        "indices" : [ 98, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "750176156276568064",
    "text" : "There is daily evidence of how terrible we can be. Revel in this moment of how awesome we can be. #juno",
    "id" : 750176156276568064,
    "created_at" : "2016-07-05 03:55:07 +0000",
    "user" : {
      "name" : "bsletten",
      "screen_name" : "bsletten",
      "protected" : false,
      "id_str" : "9630822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625812247126900737\/Zg7LZPo6_normal.jpg",
      "id" : 9630822,
      "verified" : false
    }
  },
  "id" : 750333426423607296,
  "created_at" : "2016-07-05 14:20:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Microsoft",
      "screen_name" : "Microsoft",
      "indices" : [ 36, 46 ],
      "id_str" : "74286565",
      "id" : 74286565
    }, {
      "name" : "Microsoft Office",
      "screen_name" : "Office",
      "indices" : [ 47, 54 ],
      "id_str" : "22209176",
      "id" : 22209176
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749890856329420800",
  "text" : "After multi-100 MB update download, @Microsoft @Office update says 'an error occurred' with no explanation of what happened or how to fix.",
  "id" : 749890856329420800,
  "created_at" : "2016-07-04 09:01:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749889564282482688",
  "text" : "Great for recreating VM's &amp; reusing host names in \/etc\/hosts, this removes that host's line in .ssh\/.known_hosts: ssh-keygen -R myhostname",
  "id" : 749889564282482688,
  "created_at" : "2016-07-04 08:56:19 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742391778095960064",
  "geo" : { },
  "id_str" : "749594976221143042",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi Yes, if my question is quick, as in \"I just want to know ['what time you close', 'what is your fax number',...].",
  "id" : 749594976221143042,
  "in_reply_to_status_id" : 742391778095960064,
  "created_at" : "2016-07-03 13:25:43 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "742768504135258113",
  "geo" : { },
  "id_str" : "749594038659985409",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi For me, downloading is extremely important because I want to watch the screencasts when I'm offline (e.g. in planes).",
  "id" : 749594038659985409,
  "in_reply_to_status_id" : 742768504135258113,
  "created_at" : "2016-07-03 13:22:00 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chase",
      "screen_name" : "Chase",
      "indices" : [ 1, 7 ],
      "id_str" : "274673392",
      "id" : 274673392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749541077401481217",
  "text" : ".@chase cust. service: \"We take pride in providing you w\/excellent service...a specialist will assist you...in greater than 50 minutes.\"",
  "id" : 749541077401481217,
  "created_at" : "2016-07-03 09:51:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Howard",
      "screen_name" : "adrianh",
      "indices" : [ 0, 8 ],
      "id_str" : "23513",
      "id" : 23513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749508657902215169",
  "geo" : { },
  "id_str" : "749524571900944384",
  "in_reply_to_user_id" : 23513,
  "text" : "@adrianh Don't mind me.  I was just being pedantic. ;)",
  "id" : 749524571900944384,
  "in_reply_to_status_id" : 749508657902215169,
  "created_at" : "2016-07-03 08:45:58 +0000",
  "in_reply_to_screen_name" : "adrianh",
  "in_reply_to_user_id_str" : "23513",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adrian Howard",
      "screen_name" : "adrianh",
      "indices" : [ 0, 8 ],
      "id_str" : "23513",
      "id" : 23513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749374630058663936",
  "geo" : { },
  "id_str" : "749504062983319553",
  "in_reply_to_user_id" : 23513,
  "text" : "@adrianh I think that would make it the hashtag de semaine. ;)",
  "id" : 749504062983319553,
  "in_reply_to_status_id" : 749374630058663936,
  "created_at" : "2016-07-03 07:24:28 +0000",
  "in_reply_to_screen_name" : "adrianh",
  "in_reply_to_user_id_str" : "23513",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 48, 56 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749199502318243841",
  "geo" : { },
  "id_str" : "749502655060250624",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann Well, it would have been more fun with @headius.  We toured around Cebu and Bohol for a couple of days &amp; it was good times.",
  "id" : 749502655060250624,
  "in_reply_to_status_id" : 749199502318243841,
  "created_at" : "2016-07-03 07:18:52 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "749251554763350018",
  "geo" : { },
  "id_str" : "749256983228788736",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Thank you, Sean.  You are even *more* awesome. ;)",
  "id" : 749256983228788736,
  "in_reply_to_status_id" : 749251554763350018,
  "created_at" : "2016-07-02 15:02:39 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/749158939774758912\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/2c6XoGAmCC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmWL7tRUEAAUOzU.jpg",
      "id_str" : "749158770907811840",
      "id" : 749158770907811840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmWL7tRUEAAUOzU.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/2c6XoGAmCC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "749158939774758912",
  "text" : "Well, this is a first.  Coffee Club staff in Phuket asked *me* for a photo, as I am such a regular customer here. https:\/\/t.co\/2c6XoGAmCC",
  "id" : 749158939774758912,
  "created_at" : "2016-07-02 08:33:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/mktP1cBy6W",
      "expanded_url" : "http:\/\/www.nolo.com\/",
      "display_url" : "nolo.com"
    } ]
  },
  "geo" : { },
  "id_str" : "749148959826800640",
  "text" : "For my fellow American friends, I highly recommend Nolo Press for empowering legal self help books. July 4th sale: https:\/\/t.co\/mktP1cBy6W",
  "id" : 749148959826800640,
  "created_at" : "2016-07-02 07:53:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30C9\u30CD\u3055\u3093\u89AA\u885B\u968A\u9577 \u307F\u3083\u3042",
      "screen_name" : "CelloMetalgirl",
      "indices" : [ 3, 18 ],
      "id_str" : "577096995",
      "id" : 577096995
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CelloMetalgirl\/status\/746494949688938496\/video\/1",
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/JTZIXyrcqh",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746494873130303493\/pu\/img\/CTVOw7gHlDXshgLI.jpg",
      "id_str" : "746494873130303493",
      "id" : 746494873130303493,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746494873130303493\/pu\/img\/CTVOw7gHlDXshgLI.jpg",
      "sizes" : [ {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JTZIXyrcqh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748891778162434051",
  "text" : "RT @CelloMetalgirl: \u6B7B\u306C\u307B\u3069\u7B11\u3063\u305F https:\/\/t.co\/JTZIXyrcqh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CelloMetalgirl\/status\/746494949688938496\/video\/1",
        "indices" : [ 8, 31 ],
        "url" : "https:\/\/t.co\/JTZIXyrcqh",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746494873130303493\/pu\/img\/CTVOw7gHlDXshgLI.jpg",
        "id_str" : "746494873130303493",
        "id" : 746494873130303493,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/746494873130303493\/pu\/img\/CTVOw7gHlDXshgLI.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/JTZIXyrcqh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746494949688938496",
    "text" : "\u6B7B\u306C\u307B\u3069\u7B11\u3063\u305F https:\/\/t.co\/JTZIXyrcqh",
    "id" : 746494949688938496,
    "created_at" : "2016-06-25 00:07:19 +0000",
    "user" : {
      "name" : "\u30C9\u30CD\u3055\u3093\u89AA\u885B\u968A\u9577 \u307F\u3083\u3042",
      "screen_name" : "CelloMetalgirl",
      "protected" : false,
      "id_str" : "577096995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789074888044584961\/587coOx9_normal.jpg",
      "id" : 577096995,
      "verified" : false
    }
  },
  "id" : 748891778162434051,
  "created_at" : "2016-07-01 14:51:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]