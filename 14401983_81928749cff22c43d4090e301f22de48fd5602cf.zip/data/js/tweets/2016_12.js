Grailbird.data.tweets_2016_12 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripAdvisor",
      "screen_name" : "TripAdvisor",
      "indices" : [ 1, 13 ],
      "id_str" : "16365636",
      "id" : 16365636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813612499123642368",
  "geo" : { },
  "id_str" : "813612822416367618",
  "in_reply_to_user_id" : 14401983,
  "text" : ".@TripAdvisor I can report individual reviews but want to report the hotel. Also, I raised the fraud question in my review but no response.",
  "id" : 813612822416367618,
  "in_reply_to_status_id" : 813612499123642368,
  "created_at" : "2016-12-27 05:09:47 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TripAdvisor",
      "screen_name" : "TripAdvisor",
      "indices" : [ 1, 13 ],
      "id_str" : "16365636",
      "id" : 16365636
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813612499123642368",
  "text" : ".@TripAdvisor I made a hotel decision based on what I now know are fraudulent reviews. Do you care? Googled but can't see how to report.",
  "id" : 813612499123642368,
  "created_at" : "2016-12-27 05:08:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "813546446041546752",
  "geo" : { },
  "id_str" : "813607552919273472",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Heh. No, about $6 total IIRC. Cube No. 7 is in the trendy Nimman area, has wifi, and hosts many meetups, including Beercamp.",
  "id" : 813607552919273472,
  "in_reply_to_status_id" : 813546446041546752,
  "created_at" : "2016-12-27 04:48:51 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/813341560465027072\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IVN6KWlNo1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/C0mR0Z0VIAE05on.jpg",
      "id_str" : "813341537186684929",
      "id" : 813341537186684929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/C0mR0Z0VIAE05on.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/IVN6KWlNo1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "813341560465027072",
  "text" : "Fish &amp; Chips and Mango Yogurt Smoothie at Cube No. 7 in Chiang Mai. Check out the face on the cherry tomato. https:\/\/t.co\/IVN6KWlNo1",
  "id" : 813341560465027072,
  "created_at" : "2016-12-26 11:11:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/Nkj9dDQdgm",
      "expanded_url" : "http:\/\/www.thaivisa.com\/forum\/topic\/959428-whats-the-most-hospitable-thing-a-thai-has-done-for-you\/?page=2",
      "display_url" : "thaivisa.com\/forum\/topic\/95\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "812878984258031616",
  "text" : "My answer to \"What's the most hospitable thing a Thai has done for you?\": https:\/\/t.co\/Nkj9dDQdgm (search page for \"Bennett\")",
  "id" : 812878984258031616,
  "created_at" : "2016-12-25 04:33:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Practical Dev",
      "screen_name" : "ThePracticalDev",
      "indices" : [ 0, 16 ],
      "id_str" : "2735246778",
      "id" : 2735246778
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "812207938186121216",
  "geo" : { },
  "id_str" : "812212961968209920",
  "in_reply_to_user_id" : 2735246778,
  "text" : "@ThePracticalDev Or: \"The purpose of software engineering is to provide functionality with as little complexity as possible.\"",
  "id" : 812212961968209920,
  "in_reply_to_status_id" : 812207938186121216,
  "created_at" : "2016-12-23 08:27:14 +0000",
  "in_reply_to_screen_name" : "ThePracticalDev",
  "in_reply_to_user_id_str" : "2735246778",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u03BB Calrissian",
      "screen_name" : "mattpodwysocki",
      "indices" : [ 0, 15 ],
      "id_str" : "12699642",
      "id" : 12699642
    }, {
      "name" : "Yehuda Katz",
      "screen_name" : "wycats",
      "indices" : [ 16, 23 ],
      "id_str" : "8526432",
      "id" : 8526432
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "811591742734602240",
  "geo" : { },
  "id_str" : "811614640530595840",
  "in_reply_to_user_id" : 12699642,
  "text" : "@mattpodwysocki @wycats Some org. decision makers will only permit a language for scripts if it is installed on Linux systems by default.",
  "id" : 811614640530595840,
  "in_reply_to_status_id" : 811591742734602240,
  "created_at" : "2016-12-21 16:49:44 +0000",
  "in_reply_to_screen_name" : "mattpodwysocki",
  "in_reply_to_user_id_str" : "12699642",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashish Tonse",
      "screen_name" : "atonse",
      "indices" : [ 0, 7 ],
      "id_str" : "13020032",
      "id" : 13020032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/SrKbfS1wt5",
      "expanded_url" : "http:\/\/askubuntu.com\/questions\/11925\/a-command-line-clipboard-copy-and-paste-utility",
      "display_url" : "askubuntu.com\/questions\/1192\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "811576861092413440",
  "geo" : { },
  "id_str" : "811611867172872193",
  "in_reply_to_user_id" : 13020032,
  "text" : "@atonse Great idea to chain them like that. There are utilities like pbcopy\/pbpaste for Unix and even Windows also!: https:\/\/t.co\/SrKbfS1wt5",
  "id" : 811611867172872193,
  "in_reply_to_status_id" : 811576861092413440,
  "created_at" : "2016-12-21 16:38:42 +0000",
  "in_reply_to_screen_name" : "atonse",
  "in_reply_to_user_id_str" : "13020032",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "radicalhelpfulness",
      "indices" : [ 94, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VRDn9T1yPo",
      "expanded_url" : "http:\/\/www.thaivisa.com\/forum\/topic\/959654-video-thai-student-draws-praise-after-helping-injured-dog-at-songkhla-intersection\/",
      "display_url" : "thaivisa.com\/forum\/topic\/95\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811543529776218112",
  "text" : "Thai girl braves traffic to save dog hit by car (see video at page bottom, starting at 2:20). #radicalhelpfulness https:\/\/t.co\/VRDn9T1yPo",
  "id" : 811543529776218112,
  "created_at" : "2016-12-21 12:07:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ruby",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/l6xRtf8mFB",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/612edb047f24943b13eb5572e35c99d8",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "810393865702219776",
  "text" : "Used this script to solve a trivia night problem. I love how #ruby lets you express a problem so concisely: https:\/\/t.co\/l6xRtf8mFB",
  "id" : 810393865702219776,
  "created_at" : "2016-12-18 07:58:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/809671524747649024\/photo\/1",
      "indices" : [ 149, 172 ],
      "url" : "https:\/\/t.co\/EzykcW3pCa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzyH8DhUoAEKoZi.jpg",
      "id_str" : "809671498826817537",
      "id" : 809671498826817537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzyH8DhUoAEKoZi.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/EzykcW3pCa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809671524747649024",
  "text" : "Leaving Vientiane &amp; Laos.  This is the Mekong River, w\/ Thailand on the other side. Tonight, Udon Thani. Then Bangkok &amp; home to  Chiang Mai. https:\/\/t.co\/EzykcW3pCa",
  "id" : 809671524747649024,
  "created_at" : "2016-12-16 08:08:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "indices" : [ 0, 7 ],
      "id_str" : "167533114",
      "id" : 167533114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809410118504816640",
  "geo" : { },
  "id_str" : "809415349107994625",
  "in_reply_to_user_id" : 167533114,
  "text" : "@6ftdan Still, I think you would be doing others a favor to hold them accountable.",
  "id" : 809415349107994625,
  "in_reply_to_status_id" : 809410118504816640,
  "created_at" : "2016-12-15 15:10:32 +0000",
  "in_reply_to_screen_name" : "6ftdan",
  "in_reply_to_user_id_str" : "167533114",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel P. Clark",
      "screen_name" : "6ftdan",
      "indices" : [ 0, 7 ],
      "id_str" : "167533114",
      "id" : 167533114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "809403980929503233",
  "geo" : { },
  "id_str" : "809409706858926080",
  "in_reply_to_user_id" : 167533114,
  "text" : "@6ftdan If you paid with a credit card, contact the card's bank &amp; dispute the charge. Sounds like a breach of (maybe implied) contract.",
  "id" : 809409706858926080,
  "in_reply_to_status_id" : 809403980929503233,
  "created_at" : "2016-12-15 14:48:06 +0000",
  "in_reply_to_screen_name" : "6ftdan",
  "in_reply_to_user_id_str" : "167533114",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laoairlines",
      "screen_name" : "Laoairlines",
      "indices" : [ 27, 39 ],
      "id_str" : "2162031649",
      "id" : 2162031649
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/809041817870082049\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/YxUlpnKs83",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzpLN5nUsAEH3uw.jpg",
      "id_str" : "809041785242562561",
      "id" : 809041785242562561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzpLN5nUsAEH3uw.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/YxUlpnKs83"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "809041817870082049",
  "text" : "Best airline snack ever on @laoairlines 30 minute flight LPQ - VTE: Banana, jackfruit, sweet potato, pumpkin, taro, &amp; pineapple. https:\/\/t.co\/YxUlpnKs83",
  "id" : 809041817870082049,
  "created_at" : "2016-12-14 14:26:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Mike Pastore \uD83D\uDCCE",
      "screen_name" : "mwpastore",
      "indices" : [ 9, 19 ],
      "id_str" : "19633055",
      "id" : 19633055
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/6L60DPJ6ps",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/59c8bafe188736f0c940fe757f40b4b6",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "808923279939555328",
  "geo" : { },
  "id_str" : "808990824134361088",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @mwpastore Difficult to discuss w\/short Twitter messages. Please see my explanation and code at gist at https:\/\/t.co\/6L60DPJ6ps.",
  "id" : 808990824134361088,
  "in_reply_to_status_id" : 808923279939555328,
  "created_at" : "2016-12-14 11:03:37 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/808947686678220800\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/emRun0jsX7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Czn1m3GVQAAIOK3.jpg",
      "id_str" : "808947656064057344",
      "id" : 808947656064057344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Czn1m3GVQAAIOK3.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/emRun0jsX7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808947686678220800",
  "text" : "On my way to Vientiane, Laos for a couple of days to get a long stay Thai visa. https:\/\/t.co\/emRun0jsX7",
  "id" : 808947686678220800,
  "created_at" : "2016-12-14 08:12:12 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mx. Evan Phoenix",
      "screen_name" : "evanphx",
      "indices" : [ 0, 8 ],
      "id_str" : "5444392",
      "id" : 5444392
    }, {
      "name" : "Jesse Cooke",
      "screen_name" : "jc00ke",
      "indices" : [ 9, 16 ],
      "id_str" : "14425908",
      "id" : 14425908
    }, {
      "name" : "Mike Perham",
      "screen_name" : "mperham",
      "indices" : [ 17, 25 ],
      "id_str" : "14060922",
      "id" : 14060922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "808862482915692544",
  "geo" : { },
  "id_str" : "808920004859142144",
  "in_reply_to_user_id" : 5444392,
  "text" : "@evanphx @jc00ke @mperham 1) Eliminate GIL 2) support lambda mode that won't let them modify (or even access?) local vars of their binding.",
  "id" : 808920004859142144,
  "in_reply_to_status_id" : 808862482915692544,
  "created_at" : "2016-12-14 06:22:12 +0000",
  "in_reply_to_screen_name" : "evanphx",
  "in_reply_to_user_id_str" : "5444392",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "808741622942830592",
  "text" : "Dubious about Google Translate's Thai for \"lint remover\". Store staff brought me to the pharmacy section w\/quizzical looks &amp; much giggling!",
  "id" : 808741622942830592,
  "created_at" : "2016-12-13 18:33:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/807923589190062084\/photo\/1",
      "indices" : [ 136, 159 ],
      "url" : "https:\/\/t.co\/fCAvcwHrwm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzZROQEVIAAn9o7.jpg",
      "id_str" : "807922488432730112",
      "id" : 807922488432730112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzZROQEVIAAn9o7.jpg",
      "sizes" : [ {
        "h" : 4096,
        "resize" : "fit",
        "w" : 2304
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/fCAvcwHrwm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807923589190062084",
  "text" : "Imagining what life was like in the times of the monks portrayed in wax in this temple. Where has humanity been, and where is it going? https:\/\/t.co\/fCAvcwHrwm",
  "id" : 807923589190062084,
  "created_at" : "2016-12-11 12:22:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807922350125481984",
  "text" : "I will have grown up quite a bit if I can become as patient and tolerant as so many of the Thai and foreign people I have met here.",
  "id" : 807922350125481984,
  "created_at" : "2016-12-11 12:17:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/807590381034422273\/photo\/1",
      "indices" : [ 133, 156 ],
      "url" : "https:\/\/t.co\/UHDjYbrxii",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzUjJa5VEAAgKLx.jpg",
      "id_str" : "807590352928444416",
      "id" : 807590352928444416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzUjJa5VEAAgKLx.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UHDjYbrxii"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "807590381034422273",
  "text" : "Treasure from the 24 hour fruit market in Chiang Mai -- papaya, jackfruit, longkong, coconut. Total cost , 150 baht, about $4.30 US. https:\/\/t.co\/UHDjYbrxii",
  "id" : 807590381034422273,
  "created_at" : "2016-12-10 14:18:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 0, 10 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806822132147552260",
  "in_reply_to_user_id" : 30973,
  "text" : "@starbucks Even w\/multiple staff here, English expertise is far less than virtually all of the dozens\/100's of *Thai* cafes I've visited.",
  "id" : 806822132147552260,
  "created_at" : "2016-12-08 11:26:00 +0000",
  "in_reply_to_screen_name" : "Starbucks",
  "in_reply_to_user_id_str" : "30973",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 0, 10 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806821485994090501",
  "in_reply_to_user_id" : 30973,
  "text" : "@starbucks Also, I realize I should speak Thai, but for cust. svc could you have an English speaking rep available by phone &amp; inform staff?",
  "id" : 806821485994090501,
  "created_at" : "2016-12-08 11:23:26 +0000",
  "in_reply_to_screen_name" : "Starbucks",
  "in_reply_to_user_id_str" : "30973",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 0, 10 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806820454795091968",
  "in_reply_to_user_id" : 30973,
  "text" : "@starbucks Your new Ram location in Chiang Mai, Thailand is beautiful, but the parking is motorbike-hostile, too far. I may not return.",
  "id" : 806820454795091968,
  "created_at" : "2016-12-08 11:19:21 +0000",
  "in_reply_to_screen_name" : "Starbucks",
  "in_reply_to_user_id_str" : "30973",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/806543208616341505\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/7Sz4ES5tHU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CzFqu0LVQAAzIwK.jpg",
      "id_str" : "806543160788729856",
      "id" : 806543160788729856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CzFqu0LVQAAzIwK.jpg",
      "sizes" : [ {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7Sz4ES5tHU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806543208616341505",
  "text" : "Instant karaoke friends from Singapore and Thailand at a Japanese karaoke restaurant in Chiang Mai. https:\/\/t.co\/7Sz4ES5tHU",
  "id" : 806543208616341505,
  "created_at" : "2016-12-07 16:57:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AirAsia",
      "screen_name" : "AirAsia",
      "indices" : [ 0, 8 ],
      "id_str" : "22919665",
      "id" : 22919665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "806042035413086208",
  "in_reply_to_user_id" : 22919665,
  "text" : "@airasia Thanks for all you do. Could you provide a way to save an entire chat conversation in your chat window? Currently not possible.",
  "id" : 806042035413086208,
  "created_at" : "2016-12-06 07:46:11 +0000",
  "in_reply_to_screen_name" : "AirAsia",
  "in_reply_to_user_id_str" : "22919665",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/805807307938402304\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/ATRJzbwIRq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cy7NdRmUcAAT2Fh.jpg",
      "id_str" : "805807286169923584",
      "id" : 805807286169923584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cy7NdRmUcAAT2Fh.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ATRJzbwIRq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805807307938402304",
  "text" : "Photo of Elvis with King Bhumibol of Thailand (also a formidable musician), as seen in Duke's Restaurant in Chiang Mai. https:\/\/t.co\/ATRJzbwIRq",
  "id" : 805807307938402304,
  "created_at" : "2016-12-05 16:13:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/805693329048383488\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/8nFVy7vwCJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cy5lyimUkAANM8J.jpg",
      "id_str" : "805693302301298688",
      "id" : 805693302301298688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cy5lyimUkAANM8J.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/8nFVy7vwCJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805693329048383488",
  "text" : "A coconut shredder at Mango Mania in Central Festival Mall in Chiang Mai. https:\/\/t.co\/8nFVy7vwCJ",
  "id" : 805693329048383488,
  "created_at" : "2016-12-05 08:40:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/805687761290153984\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/BRQJsJhT1W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cy5guFIUQAAHw-O.jpg",
      "id_str" : "805687728113205248",
      "id" : 805687728113205248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cy5guFIUQAAHw-O.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/BRQJsJhT1W"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805687761290153984",
  "text" : "Bought a pair of pants in Central dept. store in Chiang Mai. They cut them to my length on the spot. https:\/\/t.co\/BRQJsJhT1W",
  "id" : 805687761290153984,
  "created_at" : "2016-12-05 08:18:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "805352048552120320",
  "text" : "An Italian homeless invalid was dumped at a hotel here in Thailand. Can anyone translate Italian or Spanish to Thai or English by phone?",
  "id" : 805352048552120320,
  "created_at" : "2016-12-04 10:04:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Tilkov",
      "screen_name" : "stilkov",
      "indices" : [ 3, 11 ],
      "id_str" : "5325152",
      "id" : 5325152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/LRGKdaOXcm",
      "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/dec\/01\/stephen-hawking-dangerous-time-planet-inequality",
      "display_url" : "theguardian.com\/commentisfree\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805089355228266496",
  "text" : "RT @stilkov: \"This is the most dangerous time for our planet\" \u2013 Stephen Hawking  https:\/\/t.co\/LRGKdaOXcm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/LRGKdaOXcm",
        "expanded_url" : "https:\/\/www.theguardian.com\/commentisfree\/2016\/dec\/01\/stephen-hawking-dangerous-time-planet-inequality",
        "display_url" : "theguardian.com\/commentisfree\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "805020430985818112",
    "text" : "\"This is the most dangerous time for our planet\" \u2013 Stephen Hawking  https:\/\/t.co\/LRGKdaOXcm",
    "id" : 805020430985818112,
    "created_at" : "2016-12-03 12:06:41 +0000",
    "user" : {
      "name" : "Stefan Tilkov",
      "screen_name" : "stilkov",
      "protected" : false,
      "id_str" : "5325152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701711614752509953\/gohWPVhA_normal.jpg",
      "id" : 5325152,
      "verified" : false
    }
  },
  "id" : 805089355228266496,
  "created_at" : "2016-12-03 16:40:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/kKaQX5pTI5",
      "expanded_url" : "http:\/\/www.timesofisrael.com\/israeli-arabs-donate-wood-to-rebuild-burned-haifa-synagogue\/",
      "display_url" : "timesofisrael.com\/israeli-arabs-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "805050063768535040",
  "text" : "People who think all Arabs &amp; Muslims are terrorists, please read this: https:\/\/t.co\/kKaQX5pTI5 Love of peace &amp; brotherhood is universal.",
  "id" : 805050063768535040,
  "created_at" : "2016-12-03 14:04:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]