Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sau Sheong",
      "screen_name" : "sausheong",
      "indices" : [ 0, 10 ],
      "id_str" : "11879822",
      "id" : 11879822
    }, {
      "name" : "Dave Thomas",
      "screen_name" : "pragdave",
      "indices" : [ 20, 29 ],
      "id_str" : "6186692",
      "id" : 6186692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "361646429111992321",
  "geo" : { },
  "id_str" : "361855721123495939",
  "in_reply_to_user_id" : 11879822,
  "text" : "@sausheong You know @pragdave wrote a book about Elixir, right? I haven't read it, but he's an awesome writer.",
  "id" : 361855721123495939,
  "in_reply_to_status_id" : 361646429111992321,
  "created_at" : "2013-07-29 14:28:21 +0000",
  "in_reply_to_screen_name" : "sausheong",
  "in_reply_to_user_id_str" : "11879822",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360845163372879873",
  "text" : "Anyone have experience connecting with Confluence programmatically using Ruby or Java?  I've got some questions...",
  "id" : 360845163372879873,
  "created_at" : "2013-07-26 19:32:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ATMEZAc8Zw",
      "expanded_url" : "http:\/\/www.microcenter.com\/single_product_results.aspx?sku=690966",
      "display_url" : "microcenter.com\/single_product\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359311704020099073",
  "text" : "Micro Center is discounting the MacBook Pro MD101LL\/A 13.3\" from $1200 to $980 (http:\/\/t.co\/ATMEZAc8Zw); and Best Buy's price is $1,000.",
  "id" : 359311704020099073,
  "created_at" : "2013-07-22 13:59:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356630833030893570",
  "text" : "Went to another massage exchange meetup today.  Free 4 hands massage, and training from an expert certified massage therapist!",
  "id" : 356630833030893570,
  "created_at" : "2013-07-15 04:26:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/Ket5DkGaMQ",
      "expanded_url" : "http:\/\/httpcats.herokuapp.com\/",
      "display_url" : "httpcats.herokuapp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "356135303536316417",
  "geo" : { },
  "id_str" : "356135812292816897",
  "in_reply_to_user_id" : 14401983,
  "text" : "Also, HTTP Cats, at http:\/\/t.co\/Ket5DkGaMQ.",
  "id" : 356135812292816897,
  "in_reply_to_status_id" : 356135303536316417,
  "created_at" : "2013-07-13 19:39:28 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/xPZUiItqSW",
      "expanded_url" : "http:\/\/cc-logic.com\/blog\/2013\/7\/12\/the-real-meaning-of-http-status-codes",
      "display_url" : "cc-logic.com\/blog\/2013\/7\/12\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356135303536316417",
  "text" : "Funny\u2026check out HTTP status code meanings at http:\/\/t.co\/xPZUiItqSW, from Dave Collins of rubybn (Minnesota Ruby user group). Not the usual.",
  "id" : 356135303536316417,
  "created_at" : "2013-07-13 19:37:27 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Arlington Ruby",
      "screen_name" : "arlingtonruby",
      "indices" : [ 12, 26 ],
      "id_str" : "284339167",
      "id" : 284339167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "354224993623740416",
  "geo" : { },
  "id_str" : "354583454882598913",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia @arlingtonruby Heh...maybe a short one. ;)",
  "id" : 354583454882598913,
  "in_reply_to_status_id" : 354224993623740416,
  "created_at" : "2013-07-09 12:50:58 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354051602807656448",
  "text" : "Seems like fibers are just a way to organize your code, separating producer from consumer.",
  "id" : 354051602807656448,
  "created_at" : "2013-07-08 01:37:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354051399060955136",
  "text" : "Seems to me that comparing fibers w\/threads is misleading -- fibers have no real concurrency, do they? They all run in their resp. threads.",
  "id" : 354051399060955136,
  "created_at" : "2013-07-08 01:36:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Barry",
      "screen_name" : "pjb3",
      "indices" : [ 60, 65 ],
      "id_str" : "14306648",
      "id" : 14306648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/WQcy03YNo0",
      "expanded_url" : "http:\/\/paulbarry.com\/articles\/2010\/04\/01\/fibers-in-ruby-1-9",
      "display_url" : "paulbarry.com\/articles\/2010\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "354023080231841792",
  "text" : "Finally got around to learning about Ruby fibers -- Thanks, @pjb3 for the clear and simple article at http:\/\/t.co\/WQcy03YNo0.",
  "id" : 354023080231841792,
  "created_at" : "2013-07-07 23:44:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]