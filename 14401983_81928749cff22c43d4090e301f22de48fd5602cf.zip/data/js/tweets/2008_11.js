Grailbird.data.tweets_2008_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Meyer",
      "screen_name" : "sosiouxm3",
      "indices" : [ 0, 10 ],
      "id_str" : "17022661",
      "id" : 17022661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1029547679",
  "geo" : { },
  "id_str" : "1031638100",
  "in_reply_to_user_id" : 17022661,
  "text" : "@sosiouxm3 I like BBC for news: http:\/\/news.bbc.co.uk\/",
  "id" : 1031638100,
  "in_reply_to_status_id" : 1029547679,
  "created_at" : "2008-12-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "sosiouxm3",
  "in_reply_to_user_id_str" : "17022661",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahson Wardak",
      "screen_name" : "ahsonwardak",
      "indices" : [ 0, 12 ],
      "id_str" : "12224322",
      "id" : 12224322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1030028713",
  "geo" : { },
  "id_str" : "1031644519",
  "in_reply_to_user_id" : 12224322,
  "text" : "@ahsonwardak On first date, I got fortune \"You'll be rich\", she got \"Happiness is sitting next to you\".  She loved mine, not hers. FAIL!",
  "id" : 1031644519,
  "in_reply_to_status_id" : 1030028713,
  "created_at" : "2008-12-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahsonwardak",
  "in_reply_to_user_id_str" : "12224322",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "voodootikigod",
      "indices" : [ 0, 14 ],
      "id_str" : "637763",
      "id" : 637763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1030387171",
  "geo" : { },
  "id_str" : "1031649500",
  "in_reply_to_user_id" : 637763,
  "text" : "@voodootikigod Filipinos routinely eat garlic rice - chopped garlic cooked with the rice, even for breakfast w\/fish,eggs,sausage,etc. - yum",
  "id" : 1031649500,
  "in_reply_to_status_id" : 1030387171,
  "created_at" : "2008-12-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "voodootikigod",
  "in_reply_to_user_id_str" : "637763",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1033125920",
  "text" : "Finally started my technical blog: http:\/\/krbtech.wordpress.com\/",
  "id" : 1033125920,
  "created_at" : "2008-12-01 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Williams",
      "screen_name" : "voodootikigod",
      "indices" : [ 0, 14 ],
      "id_str" : "637763",
      "id" : 637763
    }, {
      "name" : "Chris Williams",
      "screen_name" : "voodootikigod",
      "indices" : [ 15, 29 ],
      "id_str" : "637763",
      "id" : 637763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1033198746",
  "geo" : { },
  "id_str" : "1033219163",
  "in_reply_to_user_id" : 637763,
  "text" : "@voodootikigod @voodootikigod I'd love to join you guys, but by now you're way past my nonexistent knowledge of Clojure\/Lisp.",
  "id" : 1033219163,
  "in_reply_to_status_id" : 1033198746,
  "created_at" : "2008-12-01 00:00:00 +0000",
  "in_reply_to_screen_name" : "voodootikigod",
  "in_reply_to_user_id_str" : "637763",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1027500684",
  "geo" : { },
  "id_str" : "1027529128",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight where do you get th rubyconf recordings?",
  "id" : 1027529128,
  "in_reply_to_status_id" : 1027500684,
  "created_at" : "2008-11-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1027982540",
  "geo" : { },
  "id_str" : "1027990905",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Joe, if you're open to Virginia for therapeutic massage, I know places.  I have some massage training and could help, but Reston.",
  "id" : 1027990905,
  "in_reply_to_status_id" : 1027982540,
  "created_at" : "2008-11-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1027996060",
  "geo" : { },
  "id_str" : "1028003990",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Understood. There is http:\/\/pmti.org\/index.php?id=7 (go to bottom of page) in Tenleytown.",
  "id" : 1028003990,
  "in_reply_to_status_id" : 1027996060,
  "created_at" : "2008-11-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1026627266",
  "text" : "Anyone want to beautify my pro bono page at http:\/\/bbsinc.biz\/ninmag\/?",
  "id" : 1026627266,
  "created_at" : "2008-11-27 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Hall",
      "screen_name" : "snifty",
      "indices" : [ 0, 7 ],
      "id_str" : "624323",
      "id" : 624323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1020059638",
  "geo" : { },
  "id_str" : "1020076374",
  "in_reply_to_user_id" : 624323,
  "text" : "@snifty Swedish 'nej' is no, Korean 'nay' is yes; Thai 'porn' means blessing, 'prik' is pepper; Swedish 'sex' is six, and 'bra' = well. ;)",
  "id" : 1020076374,
  "in_reply_to_status_id" : 1020059638,
  "created_at" : "2008-11-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "snifty",
  "in_reply_to_user_id_str" : "624323",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1019467415",
  "text" : "Found out my blog post on my teaching English in Thailand was posted at http:\/\/www.learn2give.blogspot.com\/ (search \"Bennett\").",
  "id" : 1019467415,
  "created_at" : "2008-11-23 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1019496388",
  "text" : "Humor: How to be cruel to old guys: http:\/\/twitpic.com\/nk2f",
  "id" : 1019496388,
  "created_at" : "2008-11-23 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ahson Wardak",
      "screen_name" : "ahsonwardak",
      "indices" : [ 0, 12 ],
      "id_str" : "12224322",
      "id" : 12224322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1016625383",
  "geo" : { },
  "id_str" : "1017325158",
  "in_reply_to_user_id" : 12224322,
  "text" : "@ahsonwardak Let me know if you'd rather do beer and karaoke in Falls Church...",
  "id" : 1017325158,
  "in_reply_to_status_id" : 1016625383,
  "created_at" : "2008-11-21 00:00:00 +0000",
  "in_reply_to_screen_name" : "ahsonwardak",
  "in_reply_to_user_id_str" : "12224322",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1014855360",
  "text" : "Ubuntu 8.10 brings my Toshiba laptop's wireless back to life!",
  "id" : 1014855360,
  "created_at" : "2008-11-20 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1015221618",
  "text" : "Why the Lucky Stiff tweets: \"well maybe I'll just blow up a nursing college and see how that goes.  Thanks everybody.\"  Real danger?",
  "id" : 1015221618,
  "created_at" : "2008-11-20 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1013537695",
  "text" : "energized in my work by the fantastic vocals and vibes of David Bisbal, star of the Spanish music world.",
  "id" : 1013537695,
  "created_at" : "2008-11-19 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1007124760",
  "text" : "at OpenSQLCamp in Charlottesville, Virginia, a data base semi-BarCamp. Trivia: 6% of world electricity used in data centers.",
  "id" : 1007124760,
  "created_at" : "2008-11-15 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1007226512",
  "text" : "At OpenSQLCamp, great talk by Postgres developer Bruce Momjian re: putting processing into the DB, slides at http:\/\/snipurl.com\/5jyu9",
  "id" : 1007226512,
  "created_at" : "2008-11-15 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1003060649",
  "text" : "In Novajug meeting on Seam.  It's a heroic attempt to simplify Java.  Coming from Ruby, all those annotations sure look like a kludge.",
  "id" : 1003060649,
  "created_at" : "2008-11-13 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "999233895",
  "text" : "In a Hampton Inn in NJ on the way back from NYC.  I love Hampton Inns.  Great room, low price, great work env w\/free wireless & coffeeallday",
  "id" : 999233895,
  "created_at" : "2008-11-10 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "996313616",
  "text" : "On a suburban train into Philly for Philly Bar Camp...",
  "id" : 996313616,
  "created_at" : "2008-11-08 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "992925335",
  "text" : "Palin thought Africa was a country, more at O'Reilly video at http:\/\/www.breitbart.tv\/?p=214383",
  "id" : 992925335,
  "created_at" : "2008-11-06 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "990643585",
  "text" : "The fool who realizes he is a fool is no longer a fool. - Nigerian proverb from poll watcher Richard from Nigeria",
  "id" : 990643585,
  "created_at" : "2008-11-05 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "990647670",
  "text" : "...mentioned while discussing Sarah Palin's \"foreign policy experience\"",
  "id" : 990647670,
  "created_at" : "2008-11-05 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "990684281",
  "text" : "Obama & McCain popular vote almost equal, but electoral votes are 194 to 69.  What a messed up system. at least time it's skewed my way.",
  "id" : 990684281,
  "created_at" : "2008-11-05 00:00:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Barry",
      "screen_name" : "pjb3",
      "indices" : [ 0, 5 ],
      "id_str" : "14306648",
      "id" : 14306648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "991067575",
  "geo" : { },
  "id_str" : "991101078",
  "in_reply_to_user_id" : 14306648,
  "text" : "@pjb3 But guys, it was *not* a landslide by popular vote; just 51% to 48%.  That disappoints me.",
  "id" : 991101078,
  "in_reply_to_status_id" : 991067575,
  "created_at" : "2008-11-05 00:00:00 +0000",
  "in_reply_to_screen_name" : "pjb3",
  "in_reply_to_user_id_str" : "14306648",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "989833442",
  "geo" : { },
  "id_str" : "989840974",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Concerned about privacy, I think.  Possibility of intimidation, even though one wouldn't know what he\/she voted for.",
  "id" : 989840974,
  "in_reply_to_status_id" : 989833442,
  "created_at" : "2008-11-04 00:00:00 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]