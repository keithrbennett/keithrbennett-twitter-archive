Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/8fZM8N91Ne",
      "expanded_url" : "http:\/\/www.gnu.org\/software\/screen\/manual\/screen.pdf",
      "display_url" : "gnu.org\/software\/scree\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505378998818705409",
  "text" : "Unix utilities, like Motown songs, never grow old.  Found a 'screen' utility manual, it was dated 2003! http:\/\/t.co\/8fZM8N91Ne",
  "id" : 505378998818705409,
  "created_at" : "2014-08-29 15:38:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 11, 18 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/a4qdKYEU6a",
      "expanded_url" : "https:\/\/www.united.com\/web\/en-Us\/apps\/mileageplus\/promotions\/registrationDetails.aspx?promoCode=A5753",
      "display_url" : "united.com\/web\/en-Us\/apps\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "504993814441127936",
  "text" : "Thank you, @united, for your 24 hour flexible booking policy, it was super helpful! Is it for *all* your bookings?  https:\/\/t.co\/a4qdKYEU6a",
  "id" : 504993814441127936,
  "created_at" : "2014-08-28 14:08:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0LDMq3XF97",
      "expanded_url" : "http:\/\/www.stickyminds.com\/better-software-magazine-subscription",
      "display_url" : "stickyminds.com\/better-softwar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503569517755527168",
  "text" : "Don't know how good it is, but this free subscription to \"Better Software\" magazine looks interesting: http:\/\/t.co\/0LDMq3XF97",
  "id" : 503569517755527168,
  "created_at" : "2014-08-24 15:48:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503276279022764032",
  "text" : ".@IMCACapital I don't appreciate your unsolicited and deceptive mailing containing a pseudo credit card. Never contact me again.",
  "id" : 503276279022764032,
  "created_at" : "2014-08-23 20:23:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Loncar",
      "screen_name" : "tbloncar",
      "indices" : [ 1, 10 ],
      "id_str" : "370541379",
      "id" : 370541379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500446907685425153",
  "geo" : { },
  "id_str" : "503182178982051841",
  "in_reply_to_user_id" : 370541379,
  "text" : ".@tbloncar ...but your point is a good one, and I should mention the overhead of lambda creation and GC in methods in future presentations.",
  "id" : 503182178982051841,
  "in_reply_to_status_id" : 500446907685425153,
  "created_at" : "2014-08-23 14:09:14 +0000",
  "in_reply_to_screen_name" : "tbloncar",
  "in_reply_to_user_id_str" : "370541379",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Loncar",
      "screen_name" : "tbloncar",
      "indices" : [ 1, 10 ],
      "id_str" : "370541379",
      "id" : 370541379
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/KEfrgmqitK",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/6263cbb698ff659723ef",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "500446907685425153",
  "geo" : { },
  "id_str" : "503181863964651520",
  "in_reply_to_user_id" : 370541379,
  "text" : ".@tbloncar Nice work. If performance is an issue we can move lambda creation outside of the method: https:\/\/t.co\/KEfrgmqitK \u2026",
  "id" : 503181863964651520,
  "in_reply_to_status_id" : 500446907685425153,
  "created_at" : "2014-08-23 14:07:59 +0000",
  "in_reply_to_screen_name" : "tbloncar",
  "in_reply_to_user_id_str" : "370541379",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cox",
      "screen_name" : "coxandrew",
      "indices" : [ 3, 13 ],
      "id_str" : "12692652",
      "id" : 12692652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503179222903713792",
  "text" : "RT @coxandrew: Been loving this little git trick since I learned it a few weeks ago. To switch to the last branch:\n\n$ git co -",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sites.google.com\/site\/yorufukurou\/\" rel=\"nofollow\"\u003EYoruFukurou\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501326027650760705",
    "text" : "Been loving this little git trick since I learned it a few weeks ago. To switch to the last branch:\n\n$ git co -",
    "id" : 501326027650760705,
    "created_at" : "2014-08-18 11:13:33 +0000",
    "user" : {
      "name" : "Andrew Cox",
      "screen_name" : "coxandrew",
      "protected" : false,
      "id_str" : "12692652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/500251002872680448\/FF_5PS4z_normal.jpeg",
      "id" : 12692652,
      "verified" : false
    }
  },
  "id" : 503179222903713792,
  "created_at" : "2014-08-23 13:57:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travis Loncar",
      "screen_name" : "tbloncar",
      "indices" : [ 3, 12 ],
      "id_str" : "370541379",
      "id" : 370541379
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 15, 29 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503046644255166464",
  "text" : "RT @tbloncar: .@keithrbennett's talk on using lambdas in Ruby was cool stuff. Here's a gist; re: in-method lambda performance. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 1, 15 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/BzRql6KUnP",
        "expanded_url" : "http:\/\/goo.gl\/ZqEJbt",
        "display_url" : "goo.gl\/ZqEJbt"
      } ]
    },
    "geo" : { },
    "id_str" : "500446907685425153",
    "text" : ".@keithrbennett's talk on using lambdas in Ruby was cool stuff. Here's a gist; re: in-method lambda performance. http:\/\/t.co\/BzRql6KUnP",
    "id" : 500446907685425153,
    "created_at" : "2014-08-16 01:00:15 +0000",
    "user" : {
      "name" : "Travis Loncar",
      "screen_name" : "tbloncar",
      "protected" : false,
      "id_str" : "370541379",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772958922726449152\/ZTl_53nj_normal.jpg",
      "id" : 370541379,
      "verified" : false
    }
  },
  "id" : 503046644255166464,
  "created_at" : "2014-08-23 05:10:40 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bokmann",
      "screen_name" : "bokmann",
      "indices" : [ 0, 8 ],
      "id_str" : "14662889",
      "id" : 14662889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501726037911552000",
  "geo" : { },
  "id_str" : "501731937883398144",
  "in_reply_to_user_id" : 14662889,
  "text" : "@bokmann No, I had an economy class ticket on United. I just pointed to that web page to illustrate the plane.",
  "id" : 501731937883398144,
  "in_reply_to_status_id" : 501726037911552000,
  "created_at" : "2014-08-19 14:06:30 +0000",
  "in_reply_to_screen_name" : "bokmann",
  "in_reply_to_user_id_str" : "14662889",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QCjkBgQFEO",
      "expanded_url" : "http:\/\/www.paramountbusinessjets.com\/private-jet-charter\/aircraft\/embraer-erj-145.html",
      "display_url" : "paramountbusinessjets.com\/private-jet-ch\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501450252713725952",
  "text" : "On last night's flight from LGA to IAD I had the best of both worlds -- a single seat that was both aisle and window. http:\/\/t.co\/QCjkBgQFEO",
  "id" : 501450252713725952,
  "created_at" : "2014-08-18 19:27:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa singer",
      "screen_name" : "lisasinger",
      "indices" : [ 9, 20 ],
      "id_str" : "21344441",
      "id" : 21344441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/tobfcDAZXb",
      "expanded_url" : "http:\/\/www.productcamp.org\/",
      "display_url" : "productcamp.org"
    } ]
  },
  "geo" : { },
  "id_str" : "501178574611558400",
  "text" : "TIL from @lisasinger: open space conferences are also big in the marketing world (Product Camp http:\/\/t.co\/tobfcDAZXb). Looks interesting.",
  "id" : 501178574611558400,
  "created_at" : "2014-08-18 01:27:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 6, 21 ],
      "id_str" : "16393800",
      "id" : 16393800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501124868898058241",
  "geo" : { },
  "id_str" : "501143696046182400",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH @AustinSeraphin I tried all Keynote export options and found none that would make the text accessible. So I did the text file.",
  "id" : 501143696046182400,
  "in_reply_to_status_id" : 501124868898058241,
  "created_at" : "2014-08-17 23:09:02 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 16, 21 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 22, 36 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/dMXZ2Hgw9R",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/0df037c29198ab401cf8",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "501054329311461376",
  "geo" : { },
  "id_str" : "501140141302611968",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin @_ZPH @steelcityruby No problem.  Source code from my Ruby Lambdas presentation (as text) is at https:\/\/t.co\/dMXZ2Hgw9R.",
  "id" : 501140141302611968,
  "in_reply_to_status_id" : 501054329311461376,
  "created_at" : "2014-08-17 22:54:55 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Austin Seraphin",
      "screen_name" : "AustinSeraphin",
      "indices" : [ 0, 15 ],
      "id_str" : "16393800",
      "id" : 16393800
    }, {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 123, 128 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/4CZiKxdGYY",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "500892142114734080",
  "geo" : { },
  "id_str" : "501030515592687616",
  "in_reply_to_user_id" : 16393800,
  "text" : "@AustinSeraphin My slides are at https:\/\/t.co\/4CZiKxdGYY, but do you mean you need source code as clipboard-able text? \/cc @_ZPH",
  "id" : 501030515592687616,
  "in_reply_to_status_id" : 500892142114734080,
  "created_at" : "2014-08-17 15:39:18 +0000",
  "in_reply_to_screen_name" : "AustinSeraphin",
  "in_reply_to_user_id_str" : "16393800",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila Shovlin",
      "screen_name" : "SheilaShovlin",
      "indices" : [ 0, 14 ],
      "id_str" : "236987305",
      "id" : 236987305
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 15, 29 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500458219018665985",
  "geo" : { },
  "id_str" : "500493876814413826",
  "in_reply_to_user_id" : 236987305,
  "text" : "@SheilaShovlin @SteelCityRuby Just arrived at Del's for the karaoke. Anyone of us here?",
  "id" : 500493876814413826,
  "in_reply_to_status_id" : 500458219018665985,
  "created_at" : "2014-08-16 04:06:53 +0000",
  "in_reply_to_screen_name" : "SheilaShovlin",
  "in_reply_to_user_id_str" : "236987305",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/500427672645038080\/photo\/1",
      "indices" : [ 126, 148 ],
      "url" : "http:\/\/t.co\/WbgmGWUfLv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvHgUO7CQAAT2w9.jpg",
      "id_str" : "500427671822548992",
      "id" : 500427671822548992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvHgUO7CQAAT2w9.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WbgmGWUfLv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500427672645038080",
  "text" : "GPS going berserk here in Pittsburgh. Went w\/the flow &amp; found great neighborhood pizza &amp; coffee shops in Mt. Lebanon. http:\/\/t.co\/WbgmGWUfLv",
  "id" : 500427672645038080,
  "created_at" : "2014-08-15 23:43:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 8, 19 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 116, 130 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyforgood",
      "indices" : [ 132, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500425452134334464",
  "text" : "Enjoyed @seanmarcia's educational, engaging talk on the bee crisis &amp; his project to assist in addressing it, at @steelcityruby. #rubyforgood",
  "id" : 500425452134334464,
  "created_at" : "2014-08-15 23:34:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "indices" : [ 3, 14 ],
      "id_str" : "33743565",
      "id" : 33743565
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 77, 91 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowledgebomb",
      "indices" : [ 92, 106 ]
    }, {
      "text" : "scrc14",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500424379638247424",
  "text" : "RT @scottefein: The more you know: you can define a class inside a lamda. -- @keithrbennett #knowledgebomb #scrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 61, 75 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "knowledgebomb",
        "indices" : [ 76, 90 ]
      }, {
        "text" : "scrc14",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.4546348, -80.0046509 ]
    },
    "id_str" : "500362604586754048",
    "text" : "The more you know: you can define a class inside a lamda. -- @keithrbennett #knowledgebomb #scrc14",
    "id" : 500362604586754048,
    "created_at" : "2014-08-15 19:25:15 +0000",
    "user" : {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "protected" : false,
      "id_str" : "33743565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595516147249778688\/GLhMmoKx_normal.jpg",
      "id" : 33743565,
      "verified" : false
    }
  },
  "id" : 500424379638247424,
  "created_at" : "2014-08-15 23:30:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "indices" : [ 3, 13 ],
      "id_str" : "14381906",
      "id" : 14381906
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 67, 81 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCRC14",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "Ruby",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500423980596346880",
  "text" : "RT @colindean: Thanks for the great #SCRC14\u00A0talk on #Ruby lambdas, @keithrbennett! Learned a lot!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 52, 66 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCRC14",
        "indices" : [ 21, 28 ]
      }, {
        "text" : "Ruby",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500363075443503104",
    "text" : "Thanks for the great #SCRC14\u00A0talk on #Ruby lambdas, @keithrbennett! Learned a lot!",
    "id" : 500363075443503104,
    "created_at" : "2014-08-15 19:27:08 +0000",
    "user" : {
      "name" : "Colin Dean",
      "screen_name" : "colindean",
      "protected" : false,
      "id_str" : "14381906",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658853412214210560\/7ZDMOSOv_normal.jpg",
      "id" : 14381906,
      "verified" : false
    }
  },
  "id" : 500423980596346880,
  "created_at" : "2014-08-15 23:29:09 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "indices" : [ 3, 10 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 107, 121 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCRC14",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500423668468838400",
  "text" : "RT @Strabd: \"We can use lambdas in places we can't use method definitions.\" (Like RSpec's describe block) \u2014@keithrbennett #SCRC14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 95, 109 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCRC14",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500362562375262208",
    "text" : "\"We can use lambdas in places we can't use method definitions.\" (Like RSpec's describe block) \u2014@keithrbennett #SCRC14",
    "id" : 500362562375262208,
    "created_at" : "2014-08-15 19:25:05 +0000",
    "user" : {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "protected" : false,
      "id_str" : "18032208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734414408617742336\/cBckSOC__normal.jpg",
      "id" : 18032208,
      "verified" : false
    }
  },
  "id" : 500423668468838400,
  "created_at" : "2014-08-15 23:27:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 3, 13 ],
      "id_str" : "25103",
      "id" : 25103
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 67, 81 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 82, 89 ]
    }, {
      "text" : "ruby",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500423074542788608",
  "text" : "RT @jessitron: Lambdas are a sharp tool, less coarse than a class. @keithrbennett #scrc14\nEspecially stabby lambdas! #ruby",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 52, 66 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 67, 74 ]
      }, {
        "text" : "ruby",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500369392249896960",
    "text" : "Lambdas are a sharp tool, less coarse than a class. @keithrbennett #scrc14\nEspecially stabby lambdas! #ruby",
    "id" : 500369392249896960,
    "created_at" : "2014-08-15 19:52:14 +0000",
    "user" : {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "protected" : false,
      "id_str" : "25103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728251919467057152\/Z2uk49Ww_normal.jpg",
      "id" : 25103,
      "verified" : false
    }
  },
  "id" : 500423074542788608,
  "created_at" : "2014-08-15 23:25:33 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "indices" : [ 3, 13 ],
      "id_str" : "25103",
      "id" : 25103
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 106, 120 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 121, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500418039276646401",
  "text" : "RT @jessitron: We don't define all variables at the instance level. Why should all methods be that scope? @keithrbennett #scrc14",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 91, 105 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500369107670540288",
    "text" : "We don't define all variables at the instance level. Why should all methods be that scope? @keithrbennett #scrc14",
    "id" : 500369107670540288,
    "created_at" : "2014-08-15 19:51:06 +0000",
    "user" : {
      "name" : "Jessica Kerr",
      "screen_name" : "jessitron",
      "protected" : false,
      "id_str" : "25103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728251919467057152\/Z2uk49Ww_normal.jpg",
      "id" : 25103,
      "verified" : false
    }
  },
  "id" : 500418039276646401,
  "created_at" : "2014-08-15 23:05:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Edmiston",
      "screen_name" : "edmistond",
      "indices" : [ 0, 10 ],
      "id_str" : "12054302",
      "id" : 12054302
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 11, 25 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/rdjwiAii83",
      "expanded_url" : "https:\/\/speakerdeck.com\/keithrbennett\/ruby-lambdas",
      "display_url" : "speakerdeck.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "500380133891772416",
  "geo" : { },
  "id_str" : "500417668235538434",
  "in_reply_to_user_id" : 12054302,
  "text" : "@edmistond @steelcityruby Slides from my Ruby Lambdas presentation are up at https:\/\/t.co\/rdjwiAii83.",
  "id" : 500417668235538434,
  "in_reply_to_status_id" : 500380133891772416,
  "created_at" : "2014-08-15 23:04:04 +0000",
  "in_reply_to_screen_name" : "edmistond",
  "in_reply_to_user_id_str" : "12054302",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "indices" : [ 3, 10 ],
      "id_str" : "18032208",
      "id" : 18032208
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500414490069196801",
  "text" : "RT @Strabd: \"Am I going to take a performance hit because I'm using a lambda instead of a method definition?\" \"Are you coding in Ruby?\" #SC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCRC14",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500363716291215361",
    "text" : "\"Am I going to take a performance hit because I'm using a lambda instead of a method definition?\" \"Are you coding in Ruby?\" #SCRC14",
    "id" : 500363716291215361,
    "created_at" : "2014-08-15 19:29:40 +0000",
    "user" : {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "protected" : false,
      "id_str" : "18032208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734414408617742336\/cBckSOC__normal.jpg",
      "id" : 18032208,
      "verified" : false
    }
  },
  "id" : 500414490069196801,
  "created_at" : "2014-08-15 22:51:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "indices" : [ 3, 10 ],
      "id_str" : "18032208",
      "id" : 18032208
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 123, 137 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500413826962313216",
  "text" : "RT @Strabd: \"The benefits of lambdas are so compelling that they justify varying from, or even changing, idiomatic Ruby.\" \u2014@keithrbennett #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 111, 125 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCRC14",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500357885311070208",
    "text" : "\"The benefits of lambdas are so compelling that they justify varying from, or even changing, idiomatic Ruby.\" \u2014@keithrbennett #SCRC14",
    "id" : 500357885311070208,
    "created_at" : "2014-08-15 19:06:30 +0000",
    "user" : {
      "name" : "Strand McCutchen",
      "screen_name" : "Strabd",
      "protected" : false,
      "id_str" : "18032208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734414408617742336\/cBckSOC__normal.jpg",
      "id" : 18032208,
      "verified" : false
    }
  },
  "id" : 500413826962313216,
  "created_at" : "2014-08-15 22:48:48 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheila Shovlin",
      "screen_name" : "SheilaShovlin",
      "indices" : [ 0, 14 ],
      "id_str" : "236987305",
      "id" : 236987305
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 15, 29 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500342149800808448",
  "geo" : { },
  "id_str" : "500413389848727553",
  "in_reply_to_user_id" : 236987305,
  "text" : "@SheilaShovlin @SteelCityRuby  Re: Del's for karaoke, starting 930\/10, ok if I tag along?  Anyone else interested? It's at 4428 Liberty Ave.",
  "id" : 500413389848727553,
  "in_reply_to_status_id" : 500342149800808448,
  "created_at" : "2014-08-15 22:47:04 +0000",
  "in_reply_to_screen_name" : "SheilaShovlin",
  "in_reply_to_user_id_str" : "236987305",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "indices" : [ 3, 14 ],
      "id_str" : "33743565",
      "id" : 33743565
    }, {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 30, 44 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scottefein\/status\/500357714938437633\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/HSMwcxBeQn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvGgr8PCEAAynkm.jpg",
      "id_str" : "500357710378831872",
      "id" : 500357710378831872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvGgr8PCEAAynkm.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/HSMwcxBeQn"
    } ],
    "hashtags" : [ {
      "text" : "scrc14",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500409116397809664",
  "text" : "RT @scottefein: And now up... @keithrbennett on Ruby Lamdas! Next time, we need more pictures of lambs. #scrc14 http:\/\/t.co\/HSMwcxBeQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Bennett",
        "screen_name" : "keithrbennett",
        "indices" : [ 14, 28 ],
        "id_str" : "14401983",
        "id" : 14401983
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scottefein\/status\/500357714938437633\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/HSMwcxBeQn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvGgr8PCEAAynkm.jpg",
        "id_str" : "500357710378831872",
        "id" : 500357710378831872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvGgr8PCEAAynkm.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/HSMwcxBeQn"
      } ],
      "hashtags" : [ {
        "text" : "scrc14",
        "indices" : [ 88, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.4534176, -80.0054461 ]
    },
    "id_str" : "500357714938437633",
    "text" : "And now up... @keithrbennett on Ruby Lamdas! Next time, we need more pictures of lambs. #scrc14 http:\/\/t.co\/HSMwcxBeQn",
    "id" : 500357714938437633,
    "created_at" : "2014-08-15 19:05:50 +0000",
    "user" : {
      "name" : "Scott Feinberg",
      "screen_name" : "scottefein",
      "protected" : false,
      "id_str" : "33743565",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/595516147249778688\/GLhMmoKx_normal.jpg",
      "id" : 33743565,
      "verified" : false
    }
  },
  "id" : 500409116397809664,
  "created_at" : "2014-08-15 22:30:05 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Shotwell",
      "screen_name" : "carl_talks",
      "indices" : [ 0, 11 ],
      "id_str" : "316861869",
      "id" : 316861869
    }, {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 12, 26 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500341733100908544",
  "geo" : { },
  "id_str" : "500408895014064128",
  "in_reply_to_user_id" : 316861869,
  "text" : "@carl_talks @steelcityruby Found KBOX on Yelp. Private karaoke room, $59\/hr,  holds &lt;= 15 people. No alcohol sold, but can bring own for fee",
  "id" : 500408895014064128,
  "in_reply_to_status_id" : 500341733100908544,
  "created_at" : "2014-08-15 22:29:12 +0000",
  "in_reply_to_screen_name" : "carl_talks",
  "in_reply_to_user_id_str" : "316861869",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500314733741105152",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby Anyone interested in karaoke tonight, maybe at KBox?",
  "id" : 500314733741105152,
  "created_at" : "2014-08-15 16:15:02 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 15, 22 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500143092486664192",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby @united got me to PIT, but not my suitcase (yet). I may be there late but I'll definitely be there in time for my talk.",
  "id" : 500143092486664192,
  "created_at" : "2014-08-15 04:53:00 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "indices" : [ 3, 15 ],
      "id_str" : "6539592",
      "id" : 6539592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498976418093858816",
  "text" : "RT @JimGaffigan: I didn\u2019t know I could be so sad, angry, stunned and grateful at the same time. RIP Robin Williams.  If you are in pain ple\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498976129215393795",
    "text" : "I didn\u2019t know I could be so sad, angry, stunned and grateful at the same time. RIP Robin Williams.  If you are in pain please seek help.",
    "id" : 498976129215393795,
    "created_at" : "2014-08-11 23:35:54 +0000",
    "user" : {
      "name" : "Jim Gaffigan",
      "screen_name" : "JimGaffigan",
      "protected" : false,
      "id_str" : "6539592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/810111809806094336\/GN-CiCn7_normal.jpg",
      "id" : 6539592,
      "verified" : true
    }
  },
  "id" : 498976418093858816,
  "created_at" : "2014-08-11 23:37:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Jos\u00E9 Valim",
      "screen_name" : "josevalim",
      "indices" : [ 8, 18 ],
      "id_str" : "10230812",
      "id" : 10230812
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/i20zrhs2gy",
      "expanded_url" : "http:\/\/www.meetup.com\/nyc-on-rails\/events\/195474622\/",
      "display_url" : "meetup.com\/nyc-on-rails\/e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498955322305048576",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH : @josevalim is presenting his Elixir language in New York City: http:\/\/t.co\/i20zrhs2gy \u2026. Another trip for you? :)",
  "id" : 498955322305048576,
  "created_at" : "2014-08-11 22:13:13 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Westman",
      "screen_name" : "westmaaan",
      "indices" : [ 0, 10 ],
      "id_str" : "21426674",
      "id" : 21426674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/L3les4Tx0z",
      "expanded_url" : "http:\/\/www.desmet-c.com\/",
      "display_url" : "desmet-c.com"
    } ]
  },
  "in_reply_to_status_id_str" : "498855145233735680",
  "geo" : { },
  "id_str" : "498873052365864962",
  "in_reply_to_user_id" : 21426674,
  "text" : "@westmaaan Mine was deSmet C, now open sourced and may be useful where a minimal implementation is needed. http:\/\/t.co\/L3les4Tx0z",
  "id" : 498873052365864962,
  "in_reply_to_status_id" : 498855145233735680,
  "created_at" : "2014-08-11 16:46:18 +0000",
  "in_reply_to_screen_name" : "westmaaan",
  "in_reply_to_user_id_str" : "21426674",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ariya Hidayat",
      "screen_name" : "AriyaHidayat",
      "indices" : [ 3, 16 ],
      "id_str" : "15608761",
      "id" : 15608761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498648149402324992",
  "text" : "RT @AriyaHidayat: This is your annual reminder that Java is to JavaScript as horse is to horseradish.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429111596627918848",
    "text" : "This is your annual reminder that Java is to JavaScript as horse is to horseradish.",
    "id" : 429111596627918848,
    "created_at" : "2014-01-31 04:39:11 +0000",
    "user" : {
      "name" : "Ariya Hidayat",
      "screen_name" : "AriyaHidayat",
      "protected" : false,
      "id_str" : "15608761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/688389064865648640\/ruegJvlb_normal.jpg",
      "id" : 15608761,
      "verified" : false
    }
  },
  "id" : 498648149402324992,
  "created_at" : "2014-08-11 01:52:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBrains",
      "screen_name" : "jetbrains",
      "indices" : [ 0, 10 ],
      "id_str" : "14146389",
      "id" : 14146389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubymine",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498566719578071041",
  "in_reply_to_user_id" : 14146389,
  "text" : "@jetbrains Disappointed my work is obstructed. I work with &gt;1 laptop at a time, but #rubymine  now permits only 1 open instance per license.",
  "id" : 498566719578071041,
  "created_at" : "2014-08-10 20:29:03 +0000",
  "in_reply_to_screen_name" : "jetbrains",
  "in_reply_to_user_id_str" : "14146389",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Walters",
      "screen_name" : "Greg_Walters",
      "indices" : [ 0, 13 ],
      "id_str" : "19011208",
      "id" : 19011208
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evernote",
      "indices" : [ 14, 23 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "307591566741098497",
  "geo" : { },
  "id_str" : "497384812991492096",
  "in_reply_to_user_id" : 19011208,
  "text" : "@Greg_Walters #evernote recently lost my most important note -- my To Do list.",
  "id" : 497384812991492096,
  "in_reply_to_status_id" : 307591566741098497,
  "created_at" : "2014-08-07 14:12:35 +0000",
  "in_reply_to_screen_name" : "Greg_Walters",
  "in_reply_to_user_id_str" : "19011208",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497196474069835777",
  "text" : "Just took my first round trip on the new Silver Line metro from Reston to Arlington (Virginia). Great to be able to work, read, and rest!",
  "id" : 497196474069835777,
  "created_at" : "2014-08-07 01:44:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ruby for Good",
      "screen_name" : "RubyforGood",
      "indices" : [ 3, 15 ],
      "id_str" : "2474347308",
      "id" : 2474347308
    }, {
      "name" : "Britney Wright",
      "screen_name" : "britneywright",
      "indices" : [ 18, 32 ],
      "id_str" : "26582920",
      "id" : 26582920
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyforGood",
      "indices" : [ 89, 101 ]
    }, {
      "text" : "CodeNewbie",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/bXwGOID58I",
      "expanded_url" : "http:\/\/alwaysbelearning.co\/2014\/08\/05\/ruby-for-good\/",
      "display_url" : "alwaysbelearning.co\/2014\/08\/05\/rub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496689694483447809",
  "text" : "RT @RubyforGood: \u201C@britneywright: I wrote an entirely too long recap of my experience at #RubyforGood. http:\/\/t.co\/bXwGOID58I #CodeNewbie\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Britney Wright",
        "screen_name" : "britneywright",
        "indices" : [ 1, 15 ],
        "id_str" : "26582920",
        "id" : 26582920
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RubyforGood",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "CodeNewbie",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/bXwGOID58I",
        "expanded_url" : "http:\/\/alwaysbelearning.co\/2014\/08\/05\/ruby-for-good\/",
        "display_url" : "alwaysbelearning.co\/2014\/08\/05\/rub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496675774263734272",
    "text" : "\u201C@britneywright: I wrote an entirely too long recap of my experience at #RubyforGood. http:\/\/t.co\/bXwGOID58I #CodeNewbie\u201D",
    "id" : 496675774263734272,
    "created_at" : "2014-08-05 15:15:07 +0000",
    "user" : {
      "name" : "Ruby for Good",
      "screen_name" : "RubyforGood",
      "protected" : false,
      "id_str" : "2474347308",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697258268054450176\/MzErtpn0_normal.png",
      "id" : 2474347308,
      "verified" : false
    }
  },
  "id" : 496689694483447809,
  "created_at" : "2014-08-05 16:10:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "@phad",
      "screen_name" : "phad",
      "indices" : [ 3, 8 ],
      "id_str" : "15580021",
      "id" : 15580021
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/phad\/status\/496645304503246848\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/2maPaS0Evz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuRwRdjIYAAmmzU.png",
      "id_str" : "496645304209661952",
      "id" : 496645304209661952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuRwRdjIYAAmmzU.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 111,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 195,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 1346
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2maPaS0Evz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496687881503928320",
  "text" : "RT @phad: Today's Dilbert. http:\/\/t.co\/2maPaS0Evz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/phad\/status\/496645304503246848\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/2maPaS0Evz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuRwRdjIYAAmmzU.png",
        "id_str" : "496645304209661952",
        "id" : 496645304209661952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuRwRdjIYAAmmzU.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 111,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 195,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 438,
          "resize" : "fit",
          "w" : 1346
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2maPaS0Evz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496645304503246848",
    "text" : "Today's Dilbert. http:\/\/t.co\/2maPaS0Evz",
    "id" : 496645304503246848,
    "created_at" : "2014-08-05 13:14:02 +0000",
    "user" : {
      "name" : "@phad",
      "screen_name" : "phad",
      "protected" : false,
      "id_str" : "15580021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2321150139\/aj3s6kdiya7hb78wjwx4_normal.png",
      "id" : 15580021,
      "verified" : false
    }
  },
  "id" : 496687881503928320,
  "created_at" : "2014-08-05 16:03:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Harrison",
      "screen_name" : "goodmike",
      "indices" : [ 0, 9 ],
      "id_str" : "14376222",
      "id" : 14376222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/P7SEZHx66m",
      "expanded_url" : "http:\/\/www.noaa.gov\/",
      "display_url" : "noaa.gov"
    } ]
  },
  "in_reply_to_status_id_str" : "496310719655444480",
  "geo" : { },
  "id_str" : "496316056856961025",
  "in_reply_to_user_id" : 14376222,
  "text" : "@goodmike Yeah, quite distracting, intentionally so.  There's always NOAA (http:\/\/t.co\/P7SEZHx66m), but they don't have frills like hourly.",
  "id" : 496316056856961025,
  "in_reply_to_status_id" : 496310719655444480,
  "created_at" : "2014-08-04 15:25:43 +0000",
  "in_reply_to_screen_name" : "goodmike",
  "in_reply_to_user_id_str" : "14376222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 3, 11 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496294479796518913",
  "text" : "RT @headius: We would like to have a US JRubyConf again, but even better would be JRuby tracks at some regular Ruby events. Ping me if inte\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/carbonandroid\" rel=\"nofollow\"\u003ECarbon for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496275085343223809",
    "text" : "We would like to have a US JRubyConf again, but even better would be JRuby tracks at some regular Ruby events. Ping me if interested!",
    "id" : 496275085343223809,
    "created_at" : "2014-08-04 12:42:55 +0000",
    "user" : {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "protected" : false,
      "id_str" : "9989362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/736361495756480513\/U0H_Wfk4_normal.jpg",
      "id" : 9989362,
      "verified" : false
    }
  },
  "id" : 496294479796518913,
  "created_at" : "2014-08-04 13:59:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 29, 40 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 42, 51 ],
      "id_str" : "2487631",
      "id" : 2487631
    }, {
      "name" : "kalimar maia",
      "screen_name" : "kalimar",
      "indices" : [ 53, 61 ],
      "id_str" : "15735455",
      "id" : 15735455
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyforgood",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496101859057471488",
  "text" : "Thanks so much to organizers @seanmarcia, @crsexton, @kalimar, and the great attendees at #rubyforgood for a wonderful weekend.",
  "id" : 496101859057471488,
  "created_at" : "2014-08-04 01:14:34 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496083585515155457",
  "text" : "Can add \"| pbcopy\" to put the processed text back in the clipboard. I needed this for copying Unicode source code in Keynote to an editor.",
  "id" : 496083585515155457,
  "created_at" : "2014-08-04 00:01:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496070729277120512",
  "text" : "Replace pesky Unicode line endings: pbpaste | ruby -e \"puts STDIN.read.gsub(%Q\u007B\\u2028\u007D, %Q\u007B\\n\u007D)\" # if on Mac &amp; text is in clipboard.",
  "id" : 496070729277120512,
  "created_at" : "2014-08-03 23:10:53 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joi",
      "screen_name" : "Joi_the_Artist",
      "indices" : [ 3, 18 ],
      "id_str" : "19192224",
      "id" : 19192224
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RPGweekend",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496070053356650497",
  "text" : "RT @Joi_the_Artist: OH: \"Self-driving cars would revolutionize country music. 'My truck took my dog and left me...'\" #RPGweekend",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RPGweekend",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496048445606883328",
    "text" : "OH: \"Self-driving cars would revolutionize country music. 'My truck took my dog and left me...'\" #RPGweekend",
    "id" : 496048445606883328,
    "created_at" : "2014-08-03 21:42:20 +0000",
    "user" : {
      "name" : "Joi",
      "screen_name" : "Joi_the_Artist",
      "protected" : false,
      "id_str" : "19192224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797142735010467840\/naXDBzah_normal.jpg",
      "id" : 19192224,
      "verified" : false
    }
  },
  "id" : 496070053356650497,
  "created_at" : "2014-08-03 23:08:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]