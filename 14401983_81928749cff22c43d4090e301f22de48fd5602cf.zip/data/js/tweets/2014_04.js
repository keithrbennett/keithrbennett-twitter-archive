Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    }, {
      "name" : "RubyMotion",
      "screen_name" : "RubyMotion",
      "indices" : [ 10, 21 ],
      "id_str" : "381521407",
      "id" : 381521407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459794128444743680",
  "geo" : { },
  "id_str" : "459836650022260737",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori @RubyMotion Y do Canadian airport codes begin with 'y'? O y?",
  "id" : 459836650022260737,
  "in_reply_to_status_id" : 459794128444743680,
  "created_at" : "2014-04-25 23:29:35 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 3, 15 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeorgeTakei\/status\/459340339749605376\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/1yBGTnNc4p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl_nmu3IUAAS75H.jpg",
      "id_str" : "459340339615387648",
      "id" : 459340339615387648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl_nmu3IUAAS75H.jpg",
      "sizes" : [ {
        "h" : 310,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 442
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 442
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 442
      } ],
      "display_url" : "pic.twitter.com\/1yBGTnNc4p"
    } ],
    "hashtags" : [ {
      "text" : "TheyreWithYouInThe",
      "indices" : [ 73, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459357657301012480",
  "text" : "RT @GeorgeTakei: Sometimes corporate brand messaging goes a bit too far. #TheyreWithYouInThe Flush http:\/\/t.co\/1yBGTnNc4p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GeorgeTakei\/status\/459340339749605376\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/1yBGTnNc4p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bl_nmu3IUAAS75H.jpg",
        "id_str" : "459340339615387648",
        "id" : 459340339615387648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bl_nmu3IUAAS75H.jpg",
        "sizes" : [ {
          "h" : 310,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 442
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 442
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 442
        } ],
        "display_url" : "pic.twitter.com\/1yBGTnNc4p"
      } ],
      "hashtags" : [ {
        "text" : "TheyreWithYouInThe",
        "indices" : [ 56, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459340339749605376",
    "text" : "Sometimes corporate brand messaging goes a bit too far. #TheyreWithYouInThe Flush http:\/\/t.co\/1yBGTnNc4p",
    "id" : 459340339749605376,
    "created_at" : "2014-04-24 14:37:25 +0000",
    "user" : {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "protected" : false,
      "id_str" : "237845487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/811285572711051264\/Uswu4kqS_normal.jpg",
      "id" : 237845487,
      "verified" : true
    }
  },
  "id" : 459357657301012480,
  "created_at" : "2014-04-24 15:46:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459355360110084096",
  "text" : "Authors who denigrate the use of std deviation as \"first year statistics\" should be more humble, esp. when they think \"fluxuate\" is a word.",
  "id" : 459355360110084096,
  "created_at" : "2014-04-24 15:37:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/U8XSy3jReL",
      "expanded_url" : "http:\/\/www.nbcnewyork.com\/news\/local\/Cat-Cafe-New-York-City-Broadway-Catachino-Coffee-Kittens-256110451.html",
      "display_url" : "nbcnewyork.com\/news\/local\/Cat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "459330180553523201",
  "text" : "I'm not into cats that much, but this Pop-Up Cat Cafe with free roaming cats sounds really cool: http:\/\/t.co\/U8XSy3jReL",
  "id" : 459330180553523201,
  "created_at" : "2014-04-24 13:57:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Dick",
      "screen_name" : "granitecoder",
      "indices" : [ 0, 13 ],
      "id_str" : "463073799",
      "id" : 463073799
    }, {
      "name" : "Tom Preston-Werner",
      "screen_name" : "mojombo",
      "indices" : [ 14, 22 ],
      "id_str" : "5502392",
      "id" : 5502392
    }, {
      "name" : "Hertz",
      "screen_name" : "Hertz",
      "indices" : [ 36, 42 ],
      "id_str" : "18001417",
      "id" : 18001417
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459098339834089472",
  "geo" : { },
  "id_str" : "459150225081643008",
  "in_reply_to_user_id" : 463073799,
  "text" : "@granitecoder @mojombo True for me. @hertz epic failure both at rental site and later with customer service. I don't trust them anymore.",
  "id" : 459150225081643008,
  "in_reply_to_status_id" : 459098339834089472,
  "created_at" : "2014-04-24 02:01:58 +0000",
  "in_reply_to_screen_name" : "granitecoder",
  "in_reply_to_user_id_str" : "463073799",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brent Ozar",
      "screen_name" : "BrentO",
      "indices" : [ 8, 15 ],
      "id_str" : "495643",
      "id" : 495643
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/S0XNamXu1n",
      "expanded_url" : "http:\/\/www.brentozar.com\/archive\/2013\/03\/you-dont-have-a-big-data-problem\/",
      "display_url" : "brentozar.com\/archive\/2013\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458959451538870272",
  "text" : "Enjoyed @BrentO's rant, er, blog post, about You Don't Have a Big Data Problem, at http:\/\/t.co\/S0XNamXu1n.",
  "id" : 458959451538870272,
  "created_at" : "2014-04-23 13:23:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "googleearth",
      "screen_name" : "googleearth",
      "indices" : [ 0, 12 ],
      "id_str" : "31285982",
      "id" : 31285982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/AdbzoG74Mu",
      "expanded_url" : "https:\/\/productforums.google.com\/forum\/#!topic\/earth\/Cozn0xtJ5XM",
      "display_url" : "productforums.google.com\/forum\/#!topic\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "457383169269174272",
  "in_reply_to_user_id" : 31285982,
  "text" : "@googleearth (Mac) was crashing whenever I tried searching. Deleting Move-Media-Player.plugin (from 2008!) fixed it: https:\/\/t.co\/AdbzoG74Mu",
  "id" : 457383169269174272,
  "created_at" : "2014-04-19 05:00:19 +0000",
  "in_reply_to_screen_name" : "googleearth",
  "in_reply_to_user_id_str" : "31285982",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/457250219919704064\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/FDlyee0L2d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Blh6pvDIYAAj7EE.png",
      "id_str" : "457250219600928768",
      "id" : 457250219600928768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Blh6pvDIYAAj7EE.png",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 656
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 656
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FDlyee0L2d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457281418414923776",
  "text" : "RT @SciencePorn: http:\/\/t.co\/FDlyee0L2d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/457250219919704064\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/FDlyee0L2d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Blh6pvDIYAAj7EE.png",
        "id_str" : "457250219600928768",
        "id" : 457250219600928768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Blh6pvDIYAAj7EE.png",
        "sizes" : [ {
          "h" : 491,
          "resize" : "fit",
          "w" : 656
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 656
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FDlyee0L2d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "457250219919704064",
    "text" : "http:\/\/t.co\/FDlyee0L2d",
    "id" : 457250219919704064,
    "created_at" : "2014-04-18 20:12:02 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 457281418414923776,
  "created_at" : "2014-04-18 22:16:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barney Stinson",
      "screen_name" : "itsBroStinson",
      "indices" : [ 3, 17 ],
      "id_str" : "456901717",
      "id" : 456901717
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455229883963424768",
  "text" : "RT @itsBroStinson: guys.. every day this week days is gonna be the same backwards..\n4\/12\/14\n4\/13\/14\n4\/14\/14\n4\/15\/14\n4\/16\/14\n4\/17\/14\n4\/18\/14\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "455157425839284224",
    "text" : "guys.. every day this week days is gonna be the same backwards..\n4\/12\/14\n4\/13\/14\n4\/14\/14\n4\/15\/14\n4\/16\/14\n4\/17\/14\n4\/18\/14\n4\/19\/14",
    "id" : 455157425839284224,
    "created_at" : "2014-04-13 01:36:01 +0000",
    "user" : {
      "name" : "Barney Stinson",
      "screen_name" : "itsBroStinson",
      "protected" : false,
      "id_str" : "456901717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2925485686\/23b6d30cdb4e3b6dca5ead7b351f06d1_normal.jpeg",
      "id" : 456901717,
      "verified" : false
    }
  },
  "id" : 455229883963424768,
  "created_at" : "2014-04-13 06:23:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/mJZdlwqH1i",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/formatters\/erb_renderer.rb",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455105586523545600",
  "text" : "Added an ERB Renderer class to my trick_bag gem that lets you limit ERB's access to only those values it needs. https:\/\/t.co\/mJZdlwqH1i",
  "id" : 455105586523545600,
  "created_at" : "2014-04-12 22:10:01 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/JU5plBWfEd",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/trick_bag\/blob\/master\/lib\/trick_bag\/timing\/timing.rb",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "455088424115269632",
  "text" : "Added a handy benchmark() method to my TrickBag gem: https:\/\/t.co\/JU5plBWfEd. Outputs result of Benchmark measure w\/a caption string.",
  "id" : 455088424115269632,
  "created_at" : "2014-04-12 21:01:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/hUPJwiNGuX",
      "expanded_url" : "http:\/\/vimeo.com\/91425662",
      "display_url" : "vimeo.com\/91425662"
    } ]
  },
  "geo" : { },
  "id_str" : "454656851742064640",
  "text" : "TIL at http:\/\/t.co\/hUPJwiNGuX: Heartbleed is simple: Attacker sends n bytes, says size is n+x, server sends n+x bytes from its memory.",
  "id" : 454656851742064640,
  "created_at" : "2014-04-11 16:26:55 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Cesal",
      "screen_name" : "AmyCesal",
      "indices" : [ 38, 47 ],
      "id_str" : "19817786",
      "id" : 19817786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ylvFCJyzxX",
      "expanded_url" : "http:\/\/sunlightfoundation.com\/blog\/2014\/03\/12\/datavizguide\/",
      "display_url" : "sunlightfoundation.com\/blog\/2014\/03\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "454417114443837440",
  "text" : "At the Data Visualization DC meetup.  @amycesal at Sunlight Foundation has a style guide for data visualization at http:\/\/t.co\/ylvFCJyzxX",
  "id" : 454417114443837440,
  "created_at" : "2014-04-11 00:34:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Westman",
      "screen_name" : "westmaaan",
      "indices" : [ 0, 10 ],
      "id_str" : "21426674",
      "id" : 21426674
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451350273454133249",
  "geo" : { },
  "id_str" : "451364684852367360",
  "in_reply_to_user_id" : 21426674,
  "text" : "@westmaaan Believe it or not, I have seen this message here in the US also. I think it's because of the music business, not Spotify.",
  "id" : 451364684852367360,
  "in_reply_to_status_id" : 451350273454133249,
  "created_at" : "2014-04-02 14:25:01 +0000",
  "in_reply_to_screen_name" : "westmaaan",
  "in_reply_to_user_id_str" : "21426674",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451096622068686848",
  "text" : "Going to the NoVa Atlassian User Group inaugural meeting of the  tonight. Working on automating Confluence content management w\/Ruby.",
  "id" : 451096622068686848,
  "created_at" : "2014-04-01 20:39:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]