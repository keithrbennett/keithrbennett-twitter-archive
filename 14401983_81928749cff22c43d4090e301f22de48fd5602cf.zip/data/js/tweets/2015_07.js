Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 84 ],
      "url" : "https:\/\/t.co\/Boutn0BuWK",
      "expanded_url" : "https:\/\/www.facebook.com\/star1045\/videos\/10152871613882066\/",
      "display_url" : "facebook.com\/star1045\/video\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626923799951355905",
  "text" : "Short man and dog video with a surprise and touching ending: https:\/\/t.co\/Boutn0BuWK",
  "id" : 626923799951355905,
  "created_at" : "2015-07-31 01:14:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Fyffe",
      "screen_name" : "sixty4bit",
      "indices" : [ 3, 13 ],
      "id_str" : "14375381",
      "id" : 14375381
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/Rpg5QNGjtr",
      "expanded_url" : "https:\/\/twitter.com\/fahrbier\/status\/620665850308231168",
      "display_url" : "twitter.com\/fahrbier\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "626387519794495488",
  "text" : "RT @sixty4bit: I knew our numbers were based on Arabic numbers, but I didn't know this... https:\/\/t.co\/Rpg5QNGjtr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/Rpg5QNGjtr",
        "expanded_url" : "https:\/\/twitter.com\/fahrbier\/status\/620665850308231168",
        "display_url" : "twitter.com\/fahrbier\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "622781591836827648",
    "text" : "I knew our numbers were based on Arabic numbers, but I didn't know this... https:\/\/t.co\/Rpg5QNGjtr",
    "id" : 622781591836827648,
    "created_at" : "2015-07-19 14:54:36 +0000",
    "user" : {
      "name" : "Carl Fyffe",
      "screen_name" : "sixty4bit",
      "protected" : false,
      "id_str" : "14375381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/54877176\/64-deux_medium_normal.png",
      "id" : 14375381,
      "verified" : false
    }
  },
  "id" : 626387519794495488,
  "created_at" : "2015-07-29 13:43:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lea",
      "screen_name" : "LegendaryLeaTV",
      "indices" : [ 3, 18 ],
      "id_str" : "111153722",
      "id" : 111153722
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LegendaryLeaTV\/status\/615963739964071936\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xD4vbxQmmd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxXwPaUMAAR-Xz.jpg",
      "id_str" : "615963735325159424",
      "id" : 615963735325159424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxXwPaUMAAR-Xz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 339
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 339
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 339
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 339
      } ],
      "display_url" : "pic.twitter.com\/xD4vbxQmmd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625865421795758081",
  "text" : "RT @LegendaryLeaTV: Years of gaming have taught me there is something behind this wall. http:\/\/t.co\/xD4vbxQmmd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LegendaryLeaTV\/status\/615963739964071936\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/xD4vbxQmmd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxXwPaUMAAR-Xz.jpg",
        "id_str" : "615963735325159424",
        "id" : 615963735325159424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxXwPaUMAAR-Xz.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 339
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 339
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 339
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 339
        } ],
        "display_url" : "pic.twitter.com\/xD4vbxQmmd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615963739964071936",
    "text" : "Years of gaming have taught me there is something behind this wall. http:\/\/t.co\/xD4vbxQmmd",
    "id" : 615963739964071936,
    "created_at" : "2015-06-30 19:22:54 +0000",
    "user" : {
      "name" : "Lea",
      "screen_name" : "LegendaryLeaTV",
      "protected" : false,
      "id_str" : "111153722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812126825740570624\/0Oyt3e1e_normal.jpg",
      "id" : 111153722,
      "verified" : false
    }
  },
  "id" : 625865421795758081,
  "created_at" : "2015-07-28 03:08:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consumers Union",
      "screen_name" : "ConsumersUnion",
      "indices" : [ 40, 55 ],
      "id_str" : "15311268",
      "id" : 15311268
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/UnFPbozHKZ",
      "expanded_url" : "https:\/\/consumersunion.org\/end-robocalls\/",
      "display_url" : "consumersunion.org\/end-robocalls\/"
    } ]
  },
  "geo" : { },
  "id_str" : "625301950628786176",
  "text" : "END ROBOCALLS: Please consider signing  @ConsumersUnion 's petition to end robocalls.  See https:\/\/t.co\/UnFPbozHKZ.",
  "id" : 625301950628786176,
  "created_at" : "2015-07-26 13:49:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PapasKitchen",
      "screen_name" : "Papas_Kitchen_",
      "indices" : [ 18, 33 ],
      "id_str" : "1960875037",
      "id" : 1960875037
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/624976282145681408\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/3Ub2k1DcHx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKxcnavUwAAJMFe.jpg",
      "id_str" : "624976280560123904",
      "id" : 624976280560123904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKxcnavUwAAJMFe.jpg",
      "sizes" : [ {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3Ub2k1DcHx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624976282145681408",
  "text" : "Had great time at @papas_kitchen_ Fri. night karaoke in Woodside, Queens, NYC. Super friendly crowd &amp; great singers. http:\/\/t.co\/3Ub2k1DcHx",
  "id" : 624976282145681408,
  "created_at" : "2015-07-25 16:15:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/2upol0Vy75",
      "expanded_url" : "http:\/\/crashworks.org\/if_programming_languages_were_vehicles\/",
      "display_url" : "crashworks.org\/if_programming\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "624971617152696320",
  "text" : "Not highly accurate, but funny -- if programming languages were vehicles: http:\/\/t.co\/2upol0Vy75",
  "id" : 624971617152696320,
  "created_at" : "2015-07-25 15:56:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JRuby Dev Team",
      "screen_name" : "jruby",
      "indices" : [ 3, 9 ],
      "id_str" : "16132186",
      "id" : 16132186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HBJI6D3gTy",
      "expanded_url" : "http:\/\/jruby.org\/download",
      "display_url" : "jruby.org\/download"
    } ]
  },
  "geo" : { },
  "id_str" : "624338997217726464",
  "text" : "RT @jruby: JRuby 9.0.0.0 has been released.  Major release == Major fun!\nhttp:\/\/t.co\/HBJI6D3gTy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/HBJI6D3gTy",
        "expanded_url" : "http:\/\/jruby.org\/download",
        "display_url" : "jruby.org\/download"
      } ]
    },
    "geo" : { },
    "id_str" : "623885086010650625",
    "text" : "JRuby 9.0.0.0 has been released.  Major release == Major fun!\nhttp:\/\/t.co\/HBJI6D3gTy",
    "id" : 623885086010650625,
    "created_at" : "2015-07-22 15:59:30 +0000",
    "user" : {
      "name" : "JRuby Dev Team",
      "screen_name" : "jruby",
      "protected" : false,
      "id_str" : "16132186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2159842315\/jruby-logo-standard-logo-stroke-large_normal.png",
      "id" : 16132186,
      "verified" : false
    }
  },
  "id" : 624338997217726464,
  "created_at" : "2015-07-23 22:03:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "indices" : [ 3, 9 ],
      "id_str" : "202571491",
      "id" : 202571491
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/idiot\/status\/618380755891322880\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/QrZ7hdbMQ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJTuBSnWsAE2a1E.jpg",
      "id_str" : "618380754800783361",
      "id" : 618380754800783361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJTuBSnWsAE2a1E.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 646
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/QrZ7hdbMQ3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623863847431053312",
  "text" : "RT @idiot: http:\/\/t.co\/QrZ7hdbMQ3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/idiot\/status\/618380755891322880\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/QrZ7hdbMQ3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJTuBSnWsAE2a1E.jpg",
        "id_str" : "618380754800783361",
        "id" : 618380754800783361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJTuBSnWsAE2a1E.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 646
        }, {
          "h" : 211,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 646
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QrZ7hdbMQ3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618380755891322880",
    "text" : "http:\/\/t.co\/QrZ7hdbMQ3",
    "id" : 618380755891322880,
    "created_at" : "2015-07-07 11:27:15 +0000",
    "user" : {
      "name" : "Visual Idiot",
      "screen_name" : "idiot",
      "protected" : false,
      "id_str" : "202571491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575994177843904512\/Su6OblHX_normal.jpeg",
      "id" : 202571491,
      "verified" : false
    }
  },
  "id" : 623863847431053312,
  "created_at" : "2015-07-22 14:35:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael James",
      "screen_name" : "michaeldotjames",
      "indices" : [ 3, 19 ],
      "id_str" : "63633650",
      "id" : 63633650
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622966581170208768",
  "text" : "RT @michaeldotjames: A SAFe (I mean waterfall) practitioner walks into a bar. The bartender says \"Why the long phase?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622843252576686080",
    "text" : "A SAFe (I mean waterfall) practitioner walks into a bar. The bartender says \"Why the long phase?\"",
    "id" : 622843252576686080,
    "created_at" : "2015-07-19 18:59:37 +0000",
    "user" : {
      "name" : "Michael James",
      "screen_name" : "michaeldotjames",
      "protected" : false,
      "id_str" : "63633650",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3074435458\/c8e2b897a2fcd7ddb15363c823732312_normal.png",
      "id" : 63633650,
      "verified" : false
    }
  },
  "id" : 622966581170208768,
  "created_at" : "2015-07-20 03:09:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 3, 17 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/qn6mvfNnEA",
      "expanded_url" : "https:\/\/ruby-operators.herokuapp.com\/#\/t-square",
      "display_url" : "ruby-operators.herokuapp.com\/#\/t-square"
    } ]
  },
  "geo" : { },
  "id_str" : "622798586485571584",
  "text" : "RT @yukihiro_matz: link: Ruby Operators - funny names\nhttps:\/\/t.co\/qn6mvfNnEA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/qn6mvfNnEA",
        "expanded_url" : "https:\/\/ruby-operators.herokuapp.com\/#\/t-square",
        "display_url" : "ruby-operators.herokuapp.com\/#\/t-square"
      } ]
    },
    "geo" : { },
    "id_str" : "622797317779750913",
    "text" : "link: Ruby Operators - funny names\nhttps:\/\/t.co\/qn6mvfNnEA",
    "id" : 622797317779750913,
    "created_at" : "2015-07-19 15:57:06 +0000",
    "user" : {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "protected" : false,
      "id_str" : "20104013",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511244255294001152\/v5phEU1O_normal.jpeg",
      "id" : 20104013,
      "verified" : false
    }
  },
  "id" : 622798586485571584,
  "created_at" : "2015-07-19 16:02:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Carter",
      "screen_name" : "withoutdoing",
      "indices" : [ 3, 16 ],
      "id_str" : "435020266",
      "id" : 435020266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "620961135714533376",
  "text" : "RT @withoutdoing: On the importance of tones:\n\u6F14\u793A (y\u01CEn sh\u00EC) to demonstrate \uD83C\uDFC4\n\u538C\u4E16 (y\u00E0n sh\u00EC) world-weary \uD83D\uDE3E\n\u8273\u8BD7 (y\u00E0n sh\u012B) erotic poetry \uD83D\uDE18\n\u773C\u5C4E (y\u01CEn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619146877741740032",
    "text" : "On the importance of tones:\n\u6F14\u793A (y\u01CEn sh\u00EC) to demonstrate \uD83C\uDFC4\n\u538C\u4E16 (y\u00E0n sh\u00EC) world-weary \uD83D\uDE3E\n\u8273\u8BD7 (y\u00E0n sh\u012B) erotic poetry \uD83D\uDE18\n\u773C\u5C4E (y\u01CEn sh\u01D0) eye boogers \uD83D\uDC40",
    "id" : 619146877741740032,
    "created_at" : "2015-07-09 14:11:33 +0000",
    "user" : {
      "name" : "Liz Carter",
      "screen_name" : "withoutdoing",
      "protected" : false,
      "id_str" : "435020266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600731240812032001\/Z4afrP4k_normal.jpg",
      "id" : 435020266,
      "verified" : true
    }
  },
  "id" : 620961135714533376,
  "created_at" : "2015-07-14 14:20:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 1, 10 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "620452948208783361",
  "geo" : { },
  "id_str" : "620641439786139648",
  "in_reply_to_user_id" : 14164724,
  "text" : ".@sarahmei Same is true for simplicity. Simplification can take time and energy but has dramatic benefit. Often this is not appreciated.",
  "id" : 620641439786139648,
  "in_reply_to_status_id" : 620452948208783361,
  "created_at" : "2015-07-13 17:10:24 +0000",
  "in_reply_to_screen_name" : "sarahmei",
  "in_reply_to_user_id_str" : "14164724",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/VH6QGZo5Zk",
      "expanded_url" : "https:\/\/twitter.com\/cmar\/status\/619897578738597888",
      "display_url" : "twitter.com\/cmar\/status\/61\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "620013701366595584",
  "text" : "Beautiful seascape. https:\/\/t.co\/VH6QGZo5Zk",
  "id" : 620013701366595584,
  "created_at" : "2015-07-11 23:36:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]