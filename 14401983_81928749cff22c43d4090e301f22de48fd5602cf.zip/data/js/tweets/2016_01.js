Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "indices" : [ 3, 13 ],
      "id_str" : "59341538",
      "id" : 59341538
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tehviking\/status\/693442057440858112\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/SPquQEDyC3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ-Z34xUUAAEw5l.jpg",
      "id_str" : "693442053049438208",
      "id" : 693442053049438208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ-Z34xUUAAEw5l.jpg",
      "sizes" : [ {
        "h" : 541,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 307,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 924,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1263,
        "resize" : "fit",
        "w" : 1400
      } ],
      "display_url" : "pic.twitter.com\/SPquQEDyC3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "694007780265463808",
  "text" : "RT @tehviking: ZOMG the first copy of my self-published book just arrived! https:\/\/t.co\/SPquQEDyC3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tehviking\/status\/693442057440858112\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/SPquQEDyC3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CZ-Z34xUUAAEw5l.jpg",
        "id_str" : "693442053049438208",
        "id" : 693442053049438208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZ-Z34xUUAAEw5l.jpg",
        "sizes" : [ {
          "h" : 541,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 924,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1263,
          "resize" : "fit",
          "w" : 1400
        } ],
        "display_url" : "pic.twitter.com\/SPquQEDyC3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "693442057440858112",
    "text" : "ZOMG the first copy of my self-published book just arrived! https:\/\/t.co\/SPquQEDyC3",
    "id" : 693442057440858112,
    "created_at" : "2016-01-30 14:34:04 +0000",
    "user" : {
      "name" : "Brandon Hays",
      "screen_name" : "tehviking",
      "protected" : false,
      "id_str" : "59341538",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431152612264509440\/r4L_jVW6_normal.jpeg",
      "id" : 59341538,
      "verified" : false
    }
  },
  "id" : 694007780265463808,
  "created_at" : "2016-02-01 04:02:03 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helio Cola",
      "screen_name" : "hacrods",
      "indices" : [ 0, 8 ],
      "id_str" : "2901793161",
      "id" : 2901793161
    }, {
      "name" : "Moneydance",
      "screen_name" : "moneydance",
      "indices" : [ 9, 20 ],
      "id_str" : "10103362",
      "id" : 10103362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "693020119488925697",
  "geo" : { },
  "id_str" : "693089778556735488",
  "in_reply_to_user_id" : 2901793161,
  "text" : "@hacrods @moneydance Sadly, wkhtmltopdf formatting not perfect. Better on Mac might be to script: 'open x.html', cmd-P [Enter], cmd-W. How?",
  "id" : 693089778556735488,
  "in_reply_to_status_id" : 693020119488925697,
  "created_at" : "2016-01-29 15:14:14 +0000",
  "in_reply_to_screen_name" : "hacrods",
  "in_reply_to_user_id_str" : "2901793161",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moneydance",
      "screen_name" : "moneydance",
      "indices" : [ 1, 12 ],
      "id_str" : "10103362",
      "id" : 10103362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692948010964238337",
  "text" : ".@moneydance To send wkhtmltopdf PDF output directly to printer on Mac, do this: wkhtmltopdf [opts] input.html \/dev\/stdout | lp [opts] -",
  "id" : 692948010964238337,
  "created_at" : "2016-01-29 05:50:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moneydance",
      "screen_name" : "moneydance",
      "indices" : [ 17, 28 ],
      "id_str" : "10103362",
      "id" : 10103362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/4Aqhwdiqgi",
      "expanded_url" : "http:\/\/wkhtmltopdf.org\/",
      "display_url" : "wkhtmltopdf.org"
    } ]
  },
  "geo" : { },
  "id_str" : "692937713725632518",
  "text" : "Print problems w\/@moneydance? Print to HTML, use https:\/\/t.co\/4Aqhwdiqgi to convert to PDF 1 HTML file at a time, --zoom 0.8 -O landscape.",
  "id" : 692937713725632518,
  "created_at" : "2016-01-29 05:09:59 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Code School",
      "screen_name" : "codeschool",
      "indices" : [ 0, 11 ],
      "id_str" : "240254617",
      "id" : 240254617
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "frustrated",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "692032302474342400",
  "in_reply_to_user_id" : 240254617,
  "text" : "@codeschool I asked a billing\/account ? on Jan 7 &amp; don't think it was answered. Contact a human only includes tech subjects. #frustrated",
  "id" : 692032302474342400,
  "created_at" : "2016-01-26 17:12:12 +0000",
  "in_reply_to_screen_name" : "codeschool",
  "in_reply_to_user_id_str" : "240254617",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/691729112780664833\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/449x1H0CZU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZmD7ztUEAAceGt.jpg",
      "id_str" : "691729081293869056",
      "id" : 691729081293869056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZmD7ztUEAAceGt.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/449x1H0CZU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691729112780664833",
  "text" : "Who's the lazy bum who didn't dig out his car? Oh, wait, that's me. I guess I won't be driving anywhere for a while. https:\/\/t.co\/449x1H0CZU",
  "id" : 691729112780664833,
  "created_at" : "2016-01-25 21:07:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/691004861333131264\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/OrZP7UEzBL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CZbxPdxVIAAOYYz.jpg",
      "id_str" : "691004840839815168",
      "id" : 691004840839815168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CZbxPdxVIAAOYYz.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OrZP7UEzBL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "691004861333131264",
  "text" : "Historic snowstorm in Washington, DC area. View from outside my window. And it's not over! https:\/\/t.co\/OrZP7UEzBL",
  "id" : 691004861333131264,
  "created_at" : "2016-01-23 21:09:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "690314225475018753",
  "text" : "When writing scripts\/programs that output info, *please* provide --yaml and --json options!  So helpful when automating use of your info.",
  "id" : 690314225475018753,
  "created_at" : "2016-01-21 23:25:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/aANs0onfIy",
      "expanded_url" : "https:\/\/www.washingtonpost.com\/news\/acts-of-faith\/wp\/2015\/12\/22\/muslims-protected-christians-from-extremists-in-kenya-bus-attack-reports-say\/?wpmm=1&wpisrc=nl_optimist",
      "display_url" : "washingtonpost.com\/news\/acts-of-f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "689282763023753217",
  "text" : "When peace and tolerance bind us more tightly than religious\/tribal identities, noble and heroic things happen: https:\/\/t.co\/aANs0onfIy",
  "id" : 689282763023753217,
  "created_at" : "2016-01-19 03:06:31 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScreenFlow",
      "screen_name" : "ScreenFlow",
      "indices" : [ 12, 23 ],
      "id_str" : "19742873",
      "id" : 19742873
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "686995615406882816",
  "text" : "I love you, @screenflow. Unequal volume of students in class recording was solved w\/\"Smooth Volume Levels\" and \"Remove Background Noise\".",
  "id" : 686995615406882816,
  "created_at" : "2016-01-12 19:38:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/Z9gezO83dQ",
      "expanded_url" : "http:\/\/www.smartertravel.com\/blogs\/today-in-travel\/how-to-get-refund-on-non-refundable-flight.html?id=17261625",
      "display_url" : "smartertravel.com\/blogs\/today-in\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "686674631105863680",
  "text" : "Interesting article on \"How to Get a Refund on a Non-Refundable Flight\n\", &lt;= 24 hours after purchase -- https:\/\/t.co\/Z9gezO83dQ",
  "id" : 686674631105863680,
  "created_at" : "2016-01-11 22:22:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685888511183056897",
  "geo" : { },
  "id_str" : "685889121043267584",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett Management is not permitted to remove the deli sign because it has been designated a landmark by the local community board.",
  "id" : 685889121043267584,
  "in_reply_to_status_id" : 685888511183056897,
  "created_at" : "2016-01-09 18:21:24 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/685888511183056897\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/6WtiONeHqY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYTD9H_WAAAGljv.jpg",
      "id_str" : "685888498151325696",
      "id" : 685888498151325696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYTD9H_WAAAGljv.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6WtiONeHqY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "685888511183056897",
  "text" : "In my hometown, Flushing, NY. Symbolic of the demographic change, former Kosher delicatessen is now a Chinese rest. https:\/\/t.co\/6WtiONeHqY",
  "id" : 685888511183056897,
  "created_at" : "2016-01-09 18:18:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "685507808826159104",
  "geo" : { },
  "id_str" : "685527080986120192",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz That's probably Chinese. Although Korean can be expressed in Hanja (Chinese chars), they usually use their native Hangul char. set.",
  "id" : 685527080986120192,
  "in_reply_to_status_id" : 685507808826159104,
  "created_at" : "2016-01-08 18:22:47 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]