Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285657739617792000",
  "text" : "Anyone know of an Oracle DB instance I could use for testing JRuby\/Rails access?  Or know a truly simple installation procedure or VM?",
  "id" : 285657739617792000,
  "created_at" : "2012-12-31 08:04:47 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285468749304311808",
  "geo" : { },
  "id_str" : "285475035664232448",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton Or, the lazy way, rm ~\/.ssh\/known_hosts. ;)",
  "id" : 285475035664232448,
  "in_reply_to_status_id" : 285468749304311808,
  "created_at" : "2012-12-30 19:58:47 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285467988927320065",
  "geo" : { },
  "id_str" : "285471277819523074",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien I'd be happy to pair with you on it if you want.",
  "id" : 285471277819523074,
  "in_reply_to_status_id" : 285467988927320065,
  "created_at" : "2012-12-30 19:43:51 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 113 ],
      "url" : "https:\/\/t.co\/5FbfvCqq",
      "expanded_url" : "https:\/\/github.com\/jruby\/activerecord-jdbc-adapter\/pull\/284",
      "display_url" : "github.com\/jruby\/activere\u2026"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/pS5wCdot",
      "expanded_url" : "http:\/\/markmail.org\/thread\/4ptn3e55txs2jmwy",
      "display_url" : "markmail.org\/thread\/4ptn3e5\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "285407648965341184",
  "geo" : { },
  "id_str" : "285458960222400512",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Also, there's currently a bug in activerecord-jdbc-adapter (soon fixed).  See https:\/\/t.co\/5FbfvCqq and http:\/\/t.co\/pS5wCdot.",
  "id" : 285458960222400512,
  "in_reply_to_status_id" : 285407648965341184,
  "created_at" : "2012-12-30 18:54:54 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Sexton",
      "screen_name" : "crsexton",
      "indices" : [ 0, 9 ],
      "id_str" : "2487631",
      "id" : 2487631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285446170266988544",
  "geo" : { },
  "id_str" : "285456157282271233",
  "in_reply_to_user_id" : 2487631,
  "text" : "@crsexton No particular night or weekend day. They close at 9:00. Maybe traffic not so bad 7 or 7:30. That's why I thought weekend though.",
  "id" : 285456157282271233,
  "in_reply_to_status_id" : 285446170266988544,
  "created_at" : "2012-12-30 18:43:46 +0000",
  "in_reply_to_screen_name" : "crsexton",
  "in_reply_to_user_id_str" : "2487631",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285407648965341184",
  "geo" : { },
  "id_str" : "285455415838384129",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Either, but is this for the Oracle JDBC jar?  If so, cleanest way may be to write a gem like the trivially simple jdbc-mysql.",
  "id" : 285455415838384129,
  "in_reply_to_status_id" : 285407648965341184,
  "created_at" : "2012-12-30 18:40:49 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285218456486428672",
  "geo" : { },
  "id_str" : "285231253328904194",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien No, but hum a few bars, and I'll fake it. ;)  I'd be happy to take a look at it; I've worked with all those parts separately.",
  "id" : 285231253328904194,
  "in_reply_to_status_id" : 285218456486428672,
  "created_at" : "2012-12-30 03:50:04 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    }, {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 10, 22 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285106345877848065",
  "geo" : { },
  "id_str" : "285150613715705856",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori @RonJeffries Tks. Rsync good idea for sync'ing changes, but for 1 time copy I think the daemon setup is overkill. ssh\/tar simpler!",
  "id" : 285150613715705856,
  "in_reply_to_status_id" : 285106345877848065,
  "created_at" : "2012-12-29 22:29:38 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    }, {
      "name" : "Paul McKellar",
      "screen_name" : "pm",
      "indices" : [ 14, 17 ],
      "id_str" : "662423",
      "id" : 662423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285072983779840000",
  "geo" : { },
  "id_str" : "285106053018972160",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien @pm I visit tech meetups, meet devs I've met online, and hack in coworking spaces on my vacations, mostly in Asia.",
  "id" : 285106053018972160,
  "in_reply_to_status_id" : 285072983779840000,
  "created_at" : "2012-12-29 19:32:34 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Jeffries",
      "screen_name" : "RonJeffries",
      "indices" : [ 0, 12 ],
      "id_str" : "14979481",
      "id" : 14979481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/Aj9LxEFQ",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/12\/29\/copying-rvm-data-between-hosts-using-ssh-scp-and-netcat\/",
      "display_url" : "bbs-software.com\/blog\/2012\/12\/2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "285049955171848192",
  "geo" : { },
  "id_str" : "285104865460502528",
  "in_reply_to_user_id" : 14979481,
  "text" : "@RonJeffries Just posted an article about exactly that, at http:\/\/t.co\/Aj9LxEFQ.  Best approach I found is at very end of post.",
  "id" : 285104865460502528,
  "in_reply_to_status_id" : 285049955171848192,
  "created_at" : "2012-12-29 19:27:51 +0000",
  "in_reply_to_screen_name" : "RonJeffries",
  "in_reply_to_user_id_str" : "14979481",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/Aj9LxEFQ",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/12\/29\/copying-rvm-data-between-hosts-using-ssh-scp-and-netcat\/",
      "display_url" : "bbs-software.com\/blog\/2012\/12\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285104504955875328",
  "text" : "Just posted \"Copying (RVM) Data Between Hosts Using ssh, scp, and netcat\", at http:\/\/t.co\/Aj9LxEFQ. Great for data transfers to new machines",
  "id" : 285104504955875328,
  "created_at" : "2012-12-29 19:26:25 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 6, 18 ],
      "id_str" : "11458102",
      "id" : 11458102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284772743180853248",
  "geo" : { },
  "id_str" : "284805041582374912",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi @coreyhaines Easy to *forget* the dot too. ;)  For occasional use, .call is prob. better, but if used more often, it's too verbose.",
  "id" : 284805041582374912,
  "in_reply_to_status_id" : 284772743180853248,
  "created_at" : "2012-12-28 23:36:27 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    }, {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 14, 19 ],
      "id_str" : "52593",
      "id" : 52593
    }, {
      "name" : "\u00AF\\_(\u30C4)_\/\u00AF\u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "coreyhaines",
      "indices" : [ 20, 32 ],
      "id_str" : "11458102",
      "id" : 11458102
    }, {
      "name" : "Jim Weirich",
      "screen_name" : "jimweirich",
      "indices" : [ 33, 44 ],
      "id_str" : "9070452",
      "id" : 9070452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/jGoGsPKp",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/11\/05\/intro-to-functional-programming-in-ruby\/",
      "display_url" : "bbs-software.com\/blog\/2012\/11\/0\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284775642220879872",
  "geo" : { },
  "id_str" : "284804228587876352",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien @avdi @coreyhaines @jimweirich I too use that notation, e.g. in my Intro to FP in Ruby article at http:\/\/t.co\/jGoGsPKp.",
  "id" : 284804228587876352,
  "in_reply_to_status_id" : 284775642220879872,
  "created_at" : "2012-12-28 23:33:14 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2615 J. B. Rainsberger",
      "screen_name" : "jbrains",
      "indices" : [ 0, 8 ],
      "id_str" : "14554494",
      "id" : 14554494
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 9, 15 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/MtGE6G67",
      "expanded_url" : "http:\/\/www.bbs-software.com\/blog\/2012\/09\/16\/stealth-conditionals-in-ruby\/",
      "display_url" : "bbs-software.com\/blog\/2012\/09\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284669706160443392",
  "geo" : { },
  "id_str" : "284689425659740161",
  "in_reply_to_user_id" : 14554494,
  "text" : "@jbrains @peeja which is why I question the widespread use of 1-line \"stealth\" conditionals, tho' I use them sometimes. http:\/\/t.co\/MtGE6G67",
  "id" : 284689425659740161,
  "in_reply_to_status_id" : 284669706160443392,
  "created_at" : "2012-12-28 15:57:03 +0000",
  "in_reply_to_screen_name" : "jbrains",
  "in_reply_to_user_id_str" : "14554494",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "indices" : [ 3, 12 ],
      "id_str" : "91333167",
      "id" : 91333167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284688396440461312",
  "text" : "RT @climagic: [Ctrl--] # Manual lists this as Ctrl-_ but Ctrl-- usually works too. Incremental undo of command line edits.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/suso.suso.org\/xulu\/Command_Line_Magic\" rel=\"nofollow\"\u003ECLI Magic poster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "284661443977166848",
    "text" : "[Ctrl--] # Manual lists this as Ctrl-_ but Ctrl-- usually works too. Incremental undo of command line edits.",
    "id" : 284661443977166848,
    "created_at" : "2012-12-28 14:05:51 +0000",
    "user" : {
      "name" : "Command Line Magic",
      "screen_name" : "climagic",
      "protected" : false,
      "id_str" : "91333167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535876218\/climagic-icon_normal.png",
      "id" : 91333167,
      "verified" : false
    }
  },
  "id" : 284688396440461312,
  "created_at" : "2012-12-28 15:52:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sayanee",
      "screen_name" : "sayanee_",
      "indices" : [ 0, 9 ],
      "id_str" : "3054721",
      "id" : 3054721
    }, {
      "name" : "Venkatesh Pillai",
      "screen_name" : "vapzone",
      "indices" : [ 10, 18 ],
      "id_str" : "14865898",
      "id" : 14865898
    }, {
      "name" : "Chinmay",
      "screen_name" : "ntt",
      "indices" : [ 19, 23 ],
      "id_str" : "1706681",
      "id" : 1706681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284519088410206208",
  "geo" : { },
  "id_str" : "284524835491700736",
  "in_reply_to_user_id" : 3054721,
  "text" : "@sayanee_ @vapzone @ntt I think you meant je *peux* parler -- peau means skin.  Or did you know that? :)",
  "id" : 284524835491700736,
  "in_reply_to_status_id" : 284519088410206208,
  "created_at" : "2012-12-28 05:03:01 +0000",
  "in_reply_to_screen_name" : "sayanee_",
  "in_reply_to_user_id_str" : "3054721",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Fowler",
      "screen_name" : "martinfowler",
      "indices" : [ 0, 13 ],
      "id_str" : "16665197",
      "id" : 16665197
    }, {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 14, 21 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284128420617678848",
  "geo" : { },
  "id_str" : "284221652068347905",
  "in_reply_to_user_id" : 16665197,
  "text" : "@martinfowler @marick Agreed. AmEx also great for 1 yr extended warranty, purchase protection.  For Costco members, no annual fee &amp; 1+% back",
  "id" : 284221652068347905,
  "in_reply_to_status_id" : 284128420617678848,
  "created_at" : "2012-12-27 08:58:17 +0000",
  "in_reply_to_screen_name" : "martinfowler",
  "in_reply_to_user_id_str" : "16665197",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284122851282407424",
  "geo" : { },
  "id_str" : "284217405733994497",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick Lots of fraud out there; credit card companies like when you notify them in advance re: foreign travel so they know not to question.",
  "id" : 284217405733994497,
  "in_reply_to_status_id" : 284122851282407424,
  "created_at" : "2012-12-27 08:41:24 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284122851282407424",
  "geo" : { },
  "id_str" : "284216811334008832",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick For foreign travel, Capital One cards charge 0% fee for foreign exchange; other cards usually charge &gt;= 2%.",
  "id" : 284216811334008832,
  "in_reply_to_status_id" : 284122851282407424,
  "created_at" : "2012-12-27 08:39:02 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 0, 7 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https:\/\/t.co\/dStgg3FX",
      "expanded_url" : "https:\/\/creditcards.chase.com\/airline-credit-cards.aspx?jp_ltg=leftnav&CELL=6RRW&MSC=IQ31197453",
      "display_url" : "creditcards.chase.com\/airline-credit\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "284122851282407424",
  "geo" : { },
  "id_str" : "284216637018738690",
  "in_reply_to_user_id" : 8864512,
  "text" : "@marick Chase credit cards great for rewards; e.g. United card gives 30,000 miles, 1 free checked bag (https:\/\/t.co\/dStgg3FX).",
  "id" : 284216637018738690,
  "in_reply_to_status_id" : 284122851282407424,
  "created_at" : "2012-12-27 08:38:21 +0000",
  "in_reply_to_screen_name" : "marick",
  "in_reply_to_user_id_str" : "8864512",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenrick Chien",
      "screen_name" : "kenrickchien",
      "indices" : [ 0, 13 ],
      "id_str" : "655883",
      "id" : 655883
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "284048438172200960",
  "geo" : { },
  "id_str" : "284080298277339136",
  "in_reply_to_user_id" : 655883,
  "text" : "@kenrickchien Congratulations to you and your family for your brand new human being! :)",
  "id" : 284080298277339136,
  "in_reply_to_status_id" : 284048438172200960,
  "created_at" : "2012-12-26 23:36:35 +0000",
  "in_reply_to_screen_name" : "kenrickchien",
  "in_reply_to_user_id_str" : "655883",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Where's the blue?",
      "screen_name" : "cupakromer",
      "indices" : [ 44, 55 ],
      "id_str" : "520859958",
      "id" : 520859958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "284022251035189248",
  "text" : "Very cool string to bit value formatter: RT @cupakromer Trolling radbot with `bits = -&gt;(str)\u007Bstr.bytes.map\u007B|b| b.to_s(2).rjust(8,?0)\u007D.join\u007D`",
  "id" : 284022251035189248,
  "created_at" : "2012-12-26 19:45:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/ZYSdRSfz",
      "expanded_url" : "http:\/\/www.freecycle.org\/",
      "display_url" : "freecycle.org"
    } ]
  },
  "geo" : { },
  "id_str" : "283976694749089792",
  "text" : "If you have stuff to give away to individuals (not org's), and have it picked up, check out http:\/\/t.co\/ZYSdRSfz. Get free stuff too.",
  "id" : 283976694749089792,
  "created_at" : "2012-12-26 16:44:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/283312023851397120\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/ZY5AzrF0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A-6GyOGCcAA3KXp.jpg",
      "id_str" : "283312023905923072",
      "id" : 283312023905923072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A-6GyOGCcAA3KXp.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2592,
        "resize" : "fit",
        "w" : 1944
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ZY5AzrF0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "283312023851397120",
  "text" : "No offense, restaurants, but I like my cooking better. Noodles, chicken, broccoli, corn, curry powder, and honey. http:\/\/t.co\/ZY5AzrF0",
  "id" : 283312023851397120,
  "created_at" : "2012-12-24 20:43:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    }, {
      "name" : "Lonnie Bowe",
      "screen_name" : "lonniebowe",
      "indices" : [ 6, 17 ],
      "id_str" : "24790961",
      "id" : 24790961
    }, {
      "name" : "Kel Cecil",
      "screen_name" : "praisechaos",
      "indices" : [ 18, 30 ],
      "id_str" : "11688512",
      "id" : 11688512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Intellij",
      "indices" : [ 31, 40 ]
    }, {
      "text" : "Idea",
      "indices" : [ 41, 46 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281862143614263296",
  "geo" : { },
  "id_str" : "283236769774854145",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH @lonniebowe @praisechaos #Intellij #Idea is good for other languages, data formats, DB, etc. too. Great XML support w\/XPath.",
  "id" : 283236769774854145,
  "in_reply_to_status_id" : 281862143614263296,
  "created_at" : "2012-12-24 15:44:42 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Robson",
      "screen_name" : "shr",
      "indices" : [ 0, 4 ],
      "id_str" : "8076192",
      "id" : 8076192
    }, {
      "name" : "Er!CkZon",
      "screen_name" : "ckzon",
      "indices" : [ 5, 11 ],
      "id_str" : "721403780261142528",
      "id" : 721403780261142528
    }, {
      "name" : "Rob Burns",
      "screen_name" : "rpburns",
      "indices" : [ 12, 20 ],
      "id_str" : "19177085",
      "id" : 19177085
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "excellentmassage",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "283041099528941568",
  "geo" : { },
  "id_str" : "283062383591686144",
  "in_reply_to_user_id" : 8076192,
  "text" : "@shr @ckzon @rpburns I met an expert redhaired Japanese massage teacher in Chiang Mai who planned to open a school in Pai. #excellentmassage",
  "id" : 283062383591686144,
  "in_reply_to_status_id" : 283041099528941568,
  "created_at" : "2012-12-24 04:11:45 +0000",
  "in_reply_to_screen_name" : "shr",
  "in_reply_to_user_id_str" : "8076192",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282955000517386240",
  "geo" : { },
  "id_str" : "283030461301813248",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi Don't forget though that you were uniquely qualified to execute that plan. That had a lot to do with it. ;)",
  "id" : 283030461301813248,
  "in_reply_to_status_id" : 282955000517386240,
  "created_at" : "2012-12-24 02:04:55 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/WRdAkgJF",
      "expanded_url" : "http:\/\/j.mp\/VebWwg",
      "display_url" : "j.mp\/VebWwg"
    }, {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/QIIQ0yzG",
      "expanded_url" : "http:\/\/j.mp\/U5grG5",
      "display_url" : "j.mp\/U5grG5"
    } ]
  },
  "geo" : { },
  "id_str" : "283016599466823681",
  "text" : "Campy 1979 DEC commercials for Digibits 0\/1 Cereal (http:\/\/t.co\/WRdAkgJF) and DecPaste disk cleaner (http:\/\/t.co\/QIIQ0yzG).",
  "id" : 283016599466823681,
  "created_at" : "2012-12-24 01:09:50 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "objo",
      "screen_name" : "objo",
      "indices" : [ 0, 5 ],
      "id_str" : "2190330632",
      "id" : 2190330632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282670531516461056",
  "text" : "@objo Congrats!  I've been rediscovering bicycling.  My record so far is 35 miles.  What we're doing is good for the body *and* soul.",
  "id" : 282670531516461056,
  "created_at" : "2012-12-23 02:14:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "282624793872850945",
  "geo" : { },
  "id_str" : "282669853314265088",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius Those who know your contributions are very grateful.  It's not the quantity of your friends that count, it's the quality. ;)",
  "id" : 282669853314265088,
  "in_reply_to_status_id" : 282624793872850945,
  "created_at" : "2012-12-23 02:11:59 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snuggsi \u2708\uFE0F",
      "screen_name" : "snuggsi",
      "indices" : [ 13, 21 ],
      "id_str" : "121639673",
      "id" : 121639673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282609310180204544",
  "text" : "Awesome...RT @snuggsi This is Snuggs telling you: Stressed spelled backwards is desserts. That is all.",
  "id" : 282609310180204544,
  "created_at" : "2012-12-22 22:11:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/ZcFFGjt5",
      "expanded_url" : "http:\/\/www.dailycal.org\/2012\/05\/30\/friends-and-family-remember-uc-berkeley-alum-tarek-saleh\/",
      "display_url" : "dailycal.org\/2012\/05\/30\/fri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282599718591266816",
  "text" : "RIP, Tarek Corwin Saleh, son of long-ago friends of mine.  The world has lost one of its finest young men. http:\/\/t.co\/ZcFFGjt5",
  "id" : 282599718591266816,
  "created_at" : "2012-12-22 21:33:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mehdi Khalili",
      "screen_name" : "MehdiKhalili",
      "indices" : [ 0, 13 ],
      "id_str" : "281270972",
      "id" : 281270972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/g2DnofWt",
      "expanded_url" : "http:\/\/bit.ly\/12pGsGy",
      "display_url" : "bit.ly\/12pGsGy"
    }, {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/C9IDpLTs",
      "expanded_url" : "http:\/\/keithrbennett.wordpress.com\/2010\/09\/12\/painful-patriotism\/",
      "display_url" : "keithrbennett.wordpress.com\/2010\/09\/12\/pai\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281919903743766528",
  "in_reply_to_user_id" : 281270972,
  "text" : "@MehdiKhalili http:\/\/t.co\/g2DnofWt Yes, we do have ignorant Americans, but I feel far closer to you than to them. http:\/\/t.co\/C9IDpLTs",
  "id" : 281919903743766528,
  "created_at" : "2012-12-21 00:31:57 +0000",
  "in_reply_to_screen_name" : "MehdiKhalili",
  "in_reply_to_user_id_str" : "281270972",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ASTcell",
      "screen_name" : "astcell",
      "indices" : [ 3, 11 ],
      "id_str" : "15004063",
      "id" : 15004063
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281904964236873729",
  "text" : "RT @astcell: People are making end of the world jokes like there's no tomorrow!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "281859244775596032",
    "text" : "People are making end of the world jokes like there's no tomorrow!",
    "id" : 281859244775596032,
    "created_at" : "2012-12-20 20:30:55 +0000",
    "user" : {
      "name" : "ASTcell",
      "screen_name" : "astcell",
      "protected" : false,
      "id_str" : "15004063",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2300802144\/xmjflsawr388779sq6jg_normal.jpeg",
      "id" : 15004063,
      "verified" : false
    }
  },
  "id" : 281904964236873729,
  "created_at" : "2012-12-20 23:32:35 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RubyMine",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/5KuMGhRG",
      "expanded_url" : "http:\/\/www.jetbrains.com\/ruby\/buy\/?ncountryCodeForm=US",
      "display_url" : "jetbrains.com\/ruby\/buy\/?ncou\u2026"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/cSmg9q6A",
      "expanded_url" : "http:\/\/www.jetbrains.com\/specials\/index.jsp",
      "display_url" : "jetbrains.com\/specials\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281882939216777216",
  "text" : "#RubyMine personal license only $17 for a few hours (http:\/\/t.co\/5KuMGhRG).  Other JetBrains discounts available too at http:\/\/t.co\/cSmg9q6A",
  "id" : 281882939216777216,
  "created_at" : "2012-12-20 22:05:04 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281878972730601472",
  "text" : "Hmmm, Redhot and cluttering\u2026a recruiter's email: \"3 years of exp. in base infrastruture dependencies (RedHot,clutering,Perl,Java,Oracle)\"",
  "id" : 281878972730601472,
  "created_at" : "2012-12-20 21:49:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "281023507947716608",
  "geo" : { },
  "id_str" : "281482619730948096",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Doh!  You're right.  ! works fine, no need for !!!.  It's (thing) that does not necessarily == (!!thing) I was thinking of.",
  "id" : 281482619730948096,
  "in_reply_to_status_id" : 281023507947716608,
  "created_at" : "2012-12-19 19:34:20 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/VVMDne3O",
      "expanded_url" : "http:\/\/eval.in",
      "display_url" : "eval.in"
    } ]
  },
  "geo" : { },
  "id_str" : "280694687189327873",
  "text" : "http:\/\/t.co\/VVMDne3O -- like gist, but it's alive. ;) -- a site where you can post *and run* code in several languages.",
  "id" : 280694687189327873,
  "created_at" : "2012-12-17 15:23:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Somerville",
      "screen_name" : "charliesome",
      "indices" : [ 3, 15 ],
      "id_str" : "16142240",
      "id" : 16142240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/XpdDcoQ1",
      "expanded_url" : "http:\/\/eval.in\/4817",
      "display_url" : "eval.in\/4817"
    } ]
  },
  "geo" : { },
  "id_str" : "280693528055664640",
  "text" : "RT @charliesome \u2026Singleton methods *ruin* performance of common operations in Ruby. http:\/\/t.co\/XpdDcoQ1",
  "id" : 280693528055664640,
  "created_at" : "2012-12-17 15:18:46 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/PkOOg2rB",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/12\/14\/arts\/design\/museum-of-mathematics-at-madison-square-park.html",
      "display_url" : "nytimes.com\/2012\/12\/14\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280636520136835072",
  "text" : "This new math museum in New York City may not be perfect, but it sounds like fun. http:\/\/t.co\/PkOOg2rB",
  "id" : 280636520136835072,
  "created_at" : "2012-12-17 11:32:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280508968797888512",
  "geo" : { },
  "id_str" : "280510249788657664",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja The other day, I wanted to retweet a bumper sticker. ;)",
  "id" : 280510249788657664,
  "in_reply_to_status_id" : 280508968797888512,
  "created_at" : "2012-12-17 03:10:29 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280487135256141824",
  "geo" : { },
  "id_str" : "280506001894035456",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg I like Pimsleur CD's to learn languages.  Audio only, but my study time is in my car.  Expensive, but available at libraries.",
  "id" : 280506001894035456,
  "in_reply_to_status_id" : 280487135256141824,
  "created_at" : "2012-12-17 02:53:37 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "indices" : [ 3, 12 ],
      "id_str" : "14164724",
      "id" : 14164724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/rC8MwbCu",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/mjs538\/moments-that-restored-our-faith-in-humanity-this-y",
      "display_url" : "buzzfeed.com\/mjs538\/moments\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "280348156603023360",
  "text" : "RT @sarahmei: I needed this after Friday. Thanks, humanity. You aren't so bad. http:\/\/t.co\/rC8MwbCu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/rC8MwbCu",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/mjs538\/moments-that-restored-our-faith-in-humanity-this-y",
        "display_url" : "buzzfeed.com\/mjs538\/moments\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "280126029203386368",
    "text" : "I needed this after Friday. Thanks, humanity. You aren't so bad. http:\/\/t.co\/rC8MwbCu",
    "id" : 280126029203386368,
    "created_at" : "2012-12-16 01:43:44 +0000",
    "user" : {
      "name" : "Sarah Mei",
      "screen_name" : "sarahmei",
      "protected" : false,
      "id_str" : "14164724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731640298820894720\/SD43wVMV_normal.jpg",
      "id" : 14164724,
      "verified" : false
    }
  },
  "id" : 280348156603023360,
  "created_at" : "2012-12-16 16:26:23 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 0, 7 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "280046396302848000",
  "geo" : { },
  "id_str" : "280344861016727553",
  "in_reply_to_user_id" : 3948061,
  "text" : "@elight Some Clojurists I know say Lighttable is cool but not quite there yet. How about free Community edition of Intellij Idea w\/plugin?",
  "id" : 280344861016727553,
  "in_reply_to_status_id" : 280046396302848000,
  "created_at" : "2012-12-16 16:13:18 +0000",
  "in_reply_to_screen_name" : "elight",
  "in_reply_to_user_id_str" : "3948061",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280017128868937728",
  "text" : "Apparently the distance between prime numbers approaching 1,000,000 averages only about 14. Very surprised, I thought it would be way more.",
  "id" : 280017128868937728,
  "created_at" : "2012-12-15 18:31:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279871435269353474",
  "geo" : { },
  "id_str" : "279974536705892352",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz It would work, but I think it cleaner for a var. used later\/only as a boolean to be true or false. Clearer if you log\/print the value.",
  "id" : 279974536705892352,
  "in_reply_to_status_id" : 279871435269353474,
  "created_at" : "2012-12-15 15:41:45 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keng \u2602",
      "screen_name" : "kengggg",
      "indices" : [ 3, 11 ],
      "id_str" : "5840312",
      "id" : 5840312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/czh4ac3s",
      "expanded_url" : "http:\/\/instagr.am\/p\/TQC0oQCJuL\/",
      "display_url" : "instagr.am\/p\/TQC0oQCJuL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "279973330419847169",
  "text" : "RT @kengggg: Collaborative sleepers @ Opendream (\u0E42\u0E2D\u0E40\u0E1E\u0E48\u0E19\u0E14\u0E23\u0E35\u0E21) http:\/\/t.co\/czh4ac3s",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 68 ],
        "url" : "http:\/\/t.co\/czh4ac3s",
        "expanded_url" : "http:\/\/instagr.am\/p\/TQC0oQCJuL\/",
        "display_url" : "instagr.am\/p\/TQC0oQCJuL\/"
      } ]
    },
    "geo" : { },
    "id_str" : "279867627151691777",
    "text" : "Collaborative sleepers @ Opendream (\u0E42\u0E2D\u0E40\u0E1E\u0E48\u0E19\u0E14\u0E23\u0E35\u0E21) http:\/\/t.co\/czh4ac3s",
    "id" : 279867627151691777,
    "created_at" : "2012-12-15 08:36:56 +0000",
    "user" : {
      "name" : "Keng \u2602",
      "screen_name" : "kengggg",
      "protected" : false,
      "id_str" : "5840312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/805073009719377920\/TPWB__nl_normal.jpg",
      "id" : 5840312,
      "verified" : false
    }
  },
  "id" : 279973330419847169,
  "created_at" : "2012-12-15 15:36:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Julian",
      "screen_name" : "jonathanjulian",
      "indices" : [ 0, 15 ],
      "id_str" : "14846101",
      "id" : 14846101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 129 ],
      "url" : "https:\/\/t.co\/23GxgR9E",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/euler\/commit\/587c1352a6dbeb8e13d666bfe9bcd22d906bd6d2",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279792558836703232",
  "in_reply_to_user_id" : 14846101,
  "text" : "@jonathanjulian Thanks!  No more 3 bangs, simpler now using Enumerable.none? instead of detect.  Commit at  https:\/\/t.co\/23GxgR9E.",
  "id" : 279792558836703232,
  "created_at" : "2012-12-15 03:38:38 +0000",
  "in_reply_to_screen_name" : "jonathanjulian",
  "in_reply_to_user_id_str" : "14846101",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 139 ],
      "url" : "https:\/\/t.co\/FdlMhi9o",
      "expanded_url" : "https:\/\/gist.github.com\/4290991",
      "display_url" : "gist.github.com\/4290991"
    } ]
  },
  "geo" : { },
  "id_str" : "279783574041931776",
  "text" : "A Ruby first for me\u2026used 3 bangs (!!!) -- 2 to convert a truthy value to true or false, and another one to negate it: https:\/\/t.co\/FdlMhi9o",
  "id" : 279783574041931776,
  "created_at" : "2012-12-15 03:02:56 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/vSIc8TEW",
      "expanded_url" : "http:\/\/www.wodfriends.org",
      "display_url" : "wodfriends.org"
    } ]
  },
  "in_reply_to_status_id_str" : "279773406994518016",
  "geo" : { },
  "id_str" : "279776160966144003",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia Yes, WO&amp;D Trail (http:\/\/t.co\/vSIc8TEW) is excellent, but 2 mi from me. It goes from Alexandria to Purcellville (past Leesburg).",
  "id" : 279776160966144003,
  "in_reply_to_status_id" : 279773406994518016,
  "created_at" : "2012-12-15 02:33:29 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/EvRxgAvV",
      "expanded_url" : "http:\/\/img.ly\/qQuK",
      "display_url" : "img.ly\/qQuK"
    } ]
  },
  "geo" : { },
  "id_str" : "279771061728473089",
  "text" : "30 mile bicycle ride today, Reston &lt;-&gt; Leesburg, VA.  If this house I saw is a tree house, it's a very cool one. http:\/\/t.co\/EvRxgAvV",
  "id" : 279771061728473089,
  "created_at" : "2012-12-15 02:13:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Peabody",
      "screen_name" : "marcpeabody",
      "indices" : [ 3, 15 ],
      "id_str" : "18827544",
      "id" : 18827544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279727847042588672",
  "text" : "RT @marcpeabody: Make positive contributions to the mental well-being of those around you.  Smile more. Talk to strangers. Make someone  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279672157871697921",
    "text" : "Make positive contributions to the mental well-being of those around you.  Smile more. Talk to strangers. Make someone feel cared for.",
    "id" : 279672157871697921,
    "created_at" : "2012-12-14 19:40:13 +0000",
    "user" : {
      "name" : "Marc Peabody",
      "screen_name" : "marcpeabody",
      "protected" : false,
      "id_str" : "18827544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775679471227592704\/pIEBN2xD_normal.jpg",
      "id" : 18827544,
      "verified" : false
    }
  },
  "id" : 279727847042588672,
  "created_at" : "2012-12-14 23:21:30 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/pYuKdSZh",
      "expanded_url" : "http:\/\/gfx.io\/",
      "display_url" : "gfx.io"
    } ]
  },
  "in_reply_to_status_id_str" : "279646682319290368",
  "geo" : { },
  "id_str" : "279726358773497856",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja The link is http:\/\/t.co\/pYuKdSZh. Also, I'm not sure, but I think if you use an add'l monitor, you're using both graphics adapters.",
  "id" : 279726358773497856,
  "in_reply_to_status_id" : 279646682319290368,
  "created_at" : "2012-12-14 23:15:35 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279646682319290368",
  "geo" : { },
  "id_str" : "279725172989239296",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja I think onboard graphics uses half the power, so if you use gfxCardStatus or the like, you can extend your use without AC power.",
  "id" : 279725172989239296,
  "in_reply_to_status_id" : 279646682319290368,
  "created_at" : "2012-12-14 23:10:52 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arun Agrawal",
      "screen_name" : "arunagw",
      "indices" : [ 0, 8 ],
      "id_str" : "4612661",
      "id" : 4612661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279601135839485952",
  "geo" : { },
  "id_str" : "279601924616101890",
  "in_reply_to_user_id" : 4612661,
  "text" : "@arunagw Yes, e.g. using 'scp -r' for recursive directory copy\u2026or did I misunderstand your need?",
  "id" : 279601924616101890,
  "in_reply_to_status_id" : 279601135839485952,
  "created_at" : "2012-12-14 15:01:08 +0000",
  "in_reply_to_screen_name" : "arunagw",
  "in_reply_to_user_id_str" : "4612661",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arun Agrawal",
      "screen_name" : "arunagw",
      "indices" : [ 0, 8 ],
      "id_str" : "4612661",
      "id" : 4612661
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "279537454162259969",
  "geo" : { },
  "id_str" : "279600913205841921",
  "in_reply_to_user_id" : 4612661,
  "text" : "@arunagw Can you use scp\/sftp?",
  "id" : 279600913205841921,
  "in_reply_to_status_id" : 279537454162259969,
  "created_at" : "2012-12-14 14:57:07 +0000",
  "in_reply_to_screen_name" : "arunagw",
  "in_reply_to_user_id_str" : "4612661",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Al0w42tb",
      "expanded_url" : "http:\/\/www.upworthy.com\/2-monkeys-were-paid-unequally-see-what-happens-next?c=upw1",
      "display_url" : "upworthy.com\/2-monkeys-were\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "279434249201938433",
  "text" : "This video explains why my parents were so careful to treat my twin brother and me equally as we grew up. http:\/\/t.co\/Al0w42tb",
  "id" : 279434249201938433,
  "created_at" : "2012-12-14 03:54:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278874918991568896",
  "text" : "The bumper sticker was the predecessor of the tweet.  Saw one that said \"The closer you follow me, the slower I'll go.\" Wanted to retweet.",
  "id" : 278874918991568896,
  "created_at" : "2012-12-12 14:52:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/52ZJ2oQi",
      "expanded_url" : "http:\/\/techportal.inviqa.com\/2012\/03\/15\/mysql-alternatives-to-mysql\/",
      "display_url" : "techportal.inviqa.com\/2012\/03\/15\/mys\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277886960020910080",
  "text" : "Interesting comparison of MySQL w\/its forks Percona, MariaDB, and Drizzle at http:\/\/t.co\/52ZJ2oQi, but is Postgres superior to all 4?",
  "id" : 277886960020910080,
  "created_at" : "2012-12-09 21:26:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/LhPF4CLX",
      "expanded_url" : "http:\/\/picascii.com\/",
      "display_url" : "picascii.com"
    } ]
  },
  "geo" : { },
  "id_str" : "277549937657520128",
  "text" : "Crazy and cool\u2026convert a photo or graphic image to an HTML or text string that, when printed, resembles the original: http:\/\/t.co\/LhPF4CLX.",
  "id" : 277549937657520128,
  "created_at" : "2012-12-08 23:07:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/lMLDQfPA",
      "expanded_url" : "http:\/\/www.techrepublic.com\/blog\/programming-and-development\/use-interactiveeditor-with-irb-for-an-inside-out-ruby-ide\/4125",
      "display_url" : "techrepublic.com\/blog\/programmi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277203712613683200",
  "text" : "'interactive_editor' gem lets you edit text in irb with your editor, and saves\/loads\/runs the text when you save\/quit. http:\/\/t.co\/lMLDQfPA",
  "id" : 277203712613683200,
  "created_at" : "2012-12-08 00:11:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/w6NTpVQ5",
      "expanded_url" : "http:\/\/sequel.rubyforge.org\/rdoc\/files\/README_rdoc.html",
      "display_url" : "sequel.rubyforge.org\/rdoc\/files\/REA\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "277138768853606400",
  "text" : "Super impressed with the sequel gem (http:\/\/t.co\/w6NTpVQ5).  Nice abstraction of SQL but still close to the metal for good performance.",
  "id" : 277138768853606400,
  "created_at" : "2012-12-07 19:53:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 111 ],
      "url" : "https:\/\/t.co\/0qKJF1D1",
      "expanded_url" : "https:\/\/github.com\/keithrbennett\/karaoke-list\/commit\/6912452f372cb613f2180fde9247fe03154073b7",
      "display_url" : "github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276737059316703233",
  "text" : "Woohoo!  Made my Rails app JRuby compatible with just a few lines of configuration code.  https:\/\/t.co\/0qKJF1D1",
  "id" : 276737059316703233,
  "created_at" : "2012-12-06 17:17:11 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 47, 53 ]
    }, {
      "text" : "rubyhangout",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276502967543283712",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius gave an excellent in-depth session on #jruby at #rubyhangout tonight and acknowledged the JVM developers who make JRuby possible.",
  "id" : 276502967543283712,
  "created_at" : "2012-12-06 01:46:59 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "nathenharvey",
      "screen_name" : "nathenharvey",
      "indices" : [ 0, 13 ],
      "id_str" : "15926485",
      "id" : 15926485
    }, {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 14, 22 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "The Ruby Hangout",
      "screen_name" : "RubyHangout",
      "indices" : [ 23, 35 ],
      "id_str" : "788178800",
      "id" : 788178800
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubyhangout",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276493042662387712",
  "geo" : { },
  "id_str" : "276497580358242305",
  "in_reply_to_user_id" : 15926485,
  "text" : "@nathenharvey @headius @RubyHangout #rubyhangout I have a question for Charlie in the Google Plus discussion.",
  "id" : 276497580358242305,
  "in_reply_to_status_id" : 276493042662387712,
  "created_at" : "2012-12-06 01:25:34 +0000",
  "in_reply_to_screen_name" : "nathenharvey",
  "in_reply_to_user_id_str" : "15926485",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Copeland",
      "screen_name" : "davetron5000",
      "indices" : [ 0, 13 ],
      "id_str" : "5660222",
      "id" : 5660222
    }, {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 14, 24 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276083873308372992",
  "geo" : { },
  "id_str" : "276088579552333825",
  "in_reply_to_user_id" : 5660222,
  "text" : "@davetron5000 @grossberg Cool, so Joe's mult. values could be an inst. of a class with a to_ary() method. Good to know, but overkill?",
  "id" : 276088579552333825,
  "in_reply_to_status_id" : 276083873308372992,
  "created_at" : "2012-12-04 22:20:21 +0000",
  "in_reply_to_screen_name" : "davetron5000",
  "in_reply_to_user_id_str" : "5660222",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276085394515304448",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg I like explicit array notation for returning mult. vals., eg. [x, y] instead of return x, y. Makes clear what it actually is.",
  "id" : 276085394515304448,
  "created_at" : "2012-12-04 22:07:42 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276062808351862784",
  "geo" : { },
  "id_str" : "276082934614736896",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Agreed.  It's like you said\/implied about method_missing (right?), it should be used sparingly and with care.",
  "id" : 276082934614736896,
  "in_reply_to_status_id" : 276062808351862784,
  "created_at" : "2012-12-04 21:57:55 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276056783624237056",
  "geo" : { },
  "id_str" : "276057792832487424",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg Both work, so do you mean when to use which one, given that the method returns an array either way?",
  "id" : 276057792832487424,
  "in_reply_to_status_id" : 276056783624237056,
  "created_at" : "2012-12-04 20:18:01 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 0, 10 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276001662638903298",
  "geo" : { },
  "id_str" : "276055558023413760",
  "in_reply_to_user_id" : 6264782,
  "text" : "@grossberg In Ruby, mult ret vals *are* an array. Try 7.divmod(2). You can unpack w\/mult var's: div,mod =7.divmod(2). Semantically better.",
  "id" : 276055558023413760,
  "in_reply_to_status_id" : 276001662638903298,
  "created_at" : "2012-12-04 20:09:08 +0000",
  "in_reply_to_screen_name" : "grossberg",
  "in_reply_to_user_id_str" : "6264782",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Stadig",
      "screen_name" : "pjstadig",
      "indices" : [ 0, 9 ],
      "id_str" : "22193049",
      "id" : 22193049
    }, {
      "name" : "f0gus",
      "screen_name" : "fogus",
      "indices" : [ 10, 16 ],
      "id_str" : "14375110",
      "id" : 14375110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/P7sR5dDP",
      "expanded_url" : "http:\/\/www.hulu.com\/watch\/19312",
      "display_url" : "hulu.com\/watch\/19312"
    } ]
  },
  "in_reply_to_status_id_str" : "275756747975708672",
  "geo" : { },
  "id_str" : "275801885489897472",
  "in_reply_to_user_id" : 22193049,
  "text" : "@pjstadig @fogus Reminds me of the \"you mock me\" SNL skit by John Malkovitch, Jon Lovitz, and Dana Carvey (http:\/\/t.co\/P7sR5dDP).",
  "id" : 275801885489897472,
  "in_reply_to_status_id" : 275756747975708672,
  "created_at" : "2012-12-04 03:21:08 +0000",
  "in_reply_to_screen_name" : "pjstadig",
  "in_reply_to_user_id_str" : "22193049",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "indices" : [ 3, 13 ],
      "id_str" : "6264782",
      "id" : 6264782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275752900544843776",
  "text" : "RT @grossberg: I can't believe how interested people are in something so unimportant as Kate Middleton\u2019s pregnancy. And then I remember: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "275751545591701504",
    "text" : "I can't believe how interested people are in something so unimportant as Kate Middleton\u2019s pregnancy. And then I remember: sports.",
    "id" : 275751545591701504,
    "created_at" : "2012-12-04 00:01:06 +0000",
    "user" : {
      "name" : "Joe Grossberg",
      "screen_name" : "grossberg",
      "protected" : false,
      "id_str" : "6264782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544224243622223872\/EEBEN2zY_normal.png",
      "id" : 6264782,
      "verified" : false
    }
  },
  "id" : 275752900544843776,
  "created_at" : "2012-12-04 00:06:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SingSnap.com",
      "screen_name" : "SingSnap",
      "indices" : [ 0, 9 ],
      "id_str" : "19748753",
      "id" : 19748753
    }, {
      "name" : "Gmail",
      "screen_name" : "gmail",
      "indices" : [ 48, 54 ],
      "id_str" : "38679388",
      "id" : 38679388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "275701907887108096",
  "in_reply_to_user_id" : 19748753,
  "text" : "@singsnap Please contact me at my Twitter id + \"@gmail.com\". I'd like to embed links to recordings on your site in my karaoke web app.",
  "id" : 275701907887108096,
  "created_at" : "2012-12-03 20:43:51 +0000",
  "in_reply_to_screen_name" : "SingSnap",
  "in_reply_to_user_id_str" : "19748753",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Nutter",
      "screen_name" : "headius",
      "indices" : [ 0, 8 ],
      "id_str" : "9989362",
      "id" : 9989362
    }, {
      "name" : "Sara Nutter",
      "screen_name" : "saranutter",
      "indices" : [ 9, 20 ],
      "id_str" : "198783148",
      "id" : 198783148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/3ZR5lS9u",
      "expanded_url" : "http:\/\/www.amazon.com\/gp\/product\/B000HEUJVO\/ref=oh_details_o03_s00_i00",
      "display_url" : "amazon.com\/gp\/product\/B00\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "275453817011712001",
  "geo" : { },
  "id_str" : "275465323740811264",
  "in_reply_to_user_id" : 9989362,
  "text" : "@headius @saranutter I recommend body or maternity pillows for back issues. Check out this one for example: http:\/\/t.co\/3ZR5lS9u.",
  "id" : 275465323740811264,
  "in_reply_to_status_id" : 275453817011712001,
  "created_at" : "2012-12-03 05:03:45 +0000",
  "in_reply_to_screen_name" : "headius",
  "in_reply_to_user_id_str" : "9989362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "275398314839654400",
  "geo" : { },
  "id_str" : "275444529979592704",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms Nice!  My favorite part: \"the intersection of software development and love\".  If only my Google navigator could get me there.",
  "id" : 275444529979592704,
  "in_reply_to_status_id" : 275398314839654400,
  "created_at" : "2012-12-03 03:41:08 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]