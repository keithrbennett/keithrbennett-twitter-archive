Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mahdi Yusuf \uD83D\uDCAF",
      "screen_name" : "myusuf3",
      "indices" : [ 3, 11 ],
      "id_str" : "14233236",
      "id" : 14233236
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/myusuf3\/status\/746972180034904065\/photo\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/dOZAb8vbeQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl3HPDvVEAELwX_.jpg",
      "id_str" : "746972174729154561",
      "id" : 746972174729154561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl3HPDvVEAELwX_.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/dOZAb8vbeQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748495991410552832",
  "text" : "RT @myusuf3: https:\/\/t.co\/dOZAb8vbeQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/myusuf3\/status\/746972180034904065\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/dOZAb8vbeQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cl3HPDvVEAELwX_.jpg",
        "id_str" : "746972174729154561",
        "id" : 746972174729154561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cl3HPDvVEAELwX_.jpg",
        "sizes" : [ {
          "h" : 446,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 446,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/dOZAb8vbeQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "746972180034904065",
    "text" : "https:\/\/t.co\/dOZAb8vbeQ",
    "id" : 746972180034904065,
    "created_at" : "2016-06-26 07:43:40 +0000",
    "user" : {
      "name" : "Mahdi Yusuf \uD83D\uDCAF",
      "screen_name" : "myusuf3",
      "protected" : false,
      "id_str" : "14233236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623574162569826304\/4DWQ9dz2_normal.jpg",
      "id" : 14233236,
      "verified" : false
    }
  },
  "id" : 748495991410552832,
  "created_at" : "2016-06-30 12:38:45 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wyndham Worldwide",
      "screen_name" : "Wyndham",
      "indices" : [ 0, 8 ],
      "id_str" : "2690900346",
      "id" : 2690900346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748199183744589824",
  "in_reply_to_user_id" : 2690900346,
  "text" : "@wyndham Your 3-5 day turnaround time for customer questions is not very traveller-friendly.  People need quick responses for travel plans.",
  "id" : 748199183744589824,
  "created_at" : "2016-06-29 16:59:20 +0000",
  "in_reply_to_screen_name" : "Wyndham",
  "in_reply_to_user_id_str" : "2690900346",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Da Cunha",
      "screen_name" : "__ddc__",
      "indices" : [ 0, 8 ],
      "id_str" : "22897700",
      "id" : 22897700
    }, {
      "name" : "RailsGirls Paris",
      "screen_name" : "RailsGirlsParis",
      "indices" : [ 9, 25 ],
      "id_str" : "1872814622",
      "id" : 1872814622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746529386136887296",
  "geo" : { },
  "id_str" : "746537070961688576",
  "in_reply_to_user_id" : 22897700,
  "text" : "@__ddc__ @RailsGirlsParis Merci, mon ami. J'essayerai de les contacter si je visite Paris.",
  "id" : 746537070961688576,
  "in_reply_to_status_id" : 746529386136887296,
  "created_at" : "2016-06-25 02:54:42 +0000",
  "in_reply_to_screen_name" : "__ddc__",
  "in_reply_to_user_id_str" : "22897700",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Marcia",
      "screen_name" : "seanmarcia",
      "indices" : [ 0, 11 ],
      "id_str" : "257046682",
      "id" : 257046682
    }, {
      "name" : "Casey Watts!",
      "screen_name" : "kyloma",
      "indices" : [ 12, 19 ],
      "id_str" : "13656282",
      "id" : 13656282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746388528716718080",
  "geo" : { },
  "id_str" : "746389848135602176",
  "in_reply_to_user_id" : 257046682,
  "text" : "@seanmarcia @kyloma Yes, the one and only!",
  "id" : 746389848135602176,
  "in_reply_to_status_id" : 746388528716718080,
  "created_at" : "2016-06-24 17:09:41 +0000",
  "in_reply_to_screen_name" : "seanmarcia",
  "in_reply_to_user_id_str" : "257046682",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 14, 29 ],
      "id_str" : "234656248",
      "id" : 234656248
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/746364609011941376\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/XveZ4cgmpZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CludVkRUsAU_z4e.jpg",
      "id_str" : "746363157099098117",
      "id" : 746363157099098117,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CludVkRUsAU_z4e.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/XveZ4cgmpZ"
    } ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "rubyfriends",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746364609011941376",
  "text" : "#rubykaraoke, @reddotrubyconf 2016 in Singapore #rubyfriends photo #2 https:\/\/t.co\/XveZ4cgmpZ",
  "id" : 746364609011941376,
  "created_at" : "2016-06-24 15:29:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 14, 29 ],
      "id_str" : "234656248",
      "id" : 234656248
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/746362802562949124\/photo\/1",
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/ojMtC54aBb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cluc8V5UsAIP494.jpg",
      "id_str" : "746362723743608834",
      "id" : 746362723743608834,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cluc8V5UsAIP494.jpg",
      "sizes" : [ {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/ojMtC54aBb"
    } ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 0, 12 ]
    }, {
      "text" : "rubyfriends",
      "indices" : [ 48, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746362802562949124",
  "text" : "#rubykaraoke, @reddotrubyconf 2016 in Singapore #rubyfriends photo #1 https:\/\/t.co\/ojMtC54aBb",
  "id" : 746362802562949124,
  "created_at" : "2016-06-24 15:22:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 0, 15 ],
      "id_str" : "234656248",
      "id" : 234656248
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 16, 23 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "Winston Teo Yong Wei",
      "screen_name" : "winstonyw",
      "indices" : [ 24, 34 ],
      "id_str" : "8977842",
      "id" : 8977842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746335079790583811",
  "in_reply_to_user_id" : 234656248,
  "text" : "@reddotrubyconf @hone02 @winstonyw  I couldn't make it to afterparty but hope to meet you for karaoke at KBox, Lucky Chinatown, at 10:00+.",
  "id" : 746335079790583811,
  "created_at" : "2016-06-24 13:32:03 +0000",
  "in_reply_to_screen_name" : "reddotrubyconf",
  "in_reply_to_user_id_str" : "234656248",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winston Teo Yong Wei",
      "screen_name" : "winstonyw",
      "indices" : [ 0, 10 ],
      "id_str" : "8977842",
      "id" : 8977842
    }, {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 11, 18 ],
      "id_str" : "15317640",
      "id" : 15317640
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "746160257622171648",
  "geo" : { },
  "id_str" : "746202520272306178",
  "in_reply_to_user_id" : 8977842,
  "text" : "@winstonyw @hone02 Excellent, I'm in.",
  "id" : 746202520272306178,
  "in_reply_to_status_id" : 746160257622171648,
  "created_at" : "2016-06-24 04:45:19 +0000",
  "in_reply_to_screen_name" : "winstonyw",
  "in_reply_to_user_id_str" : "8977842",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/eHOS8Qkb9n",
      "expanded_url" : "http:\/\/www.goodreads.com\/quotes\/1716-travel-is-fatal-to-prejudice-bigotry-and-narrow-mindedness-and-many",
      "display_url" : "goodreads.com\/quotes\/1716-tr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745955430690521089",
  "text" : "Great quote by Mark Twain: \"Travel is fatal to prejudice, bigotry and narrow-mindedness...[check out the rest]\" (https:\/\/t.co\/eHOS8Qkb9n)",
  "id" : 745955430690521089,
  "created_at" : "2016-06-23 12:23:28 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 1, 15 ],
      "id_str" : "20104013",
      "id" : 20104013
    }, {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 53, 68 ],
      "id_str" : "234656248",
      "id" : 234656248
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/745801978400256000\/photo\/1",
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/HD4u7OTxHm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Clme7zAVAAAK5P1.jpg",
      "id_str" : "745801963447582720",
      "id" : 745801963447582720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Clme7zAVAAAK5P1.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 576
      } ],
      "display_url" : "pic.twitter.com\/HD4u7OTxHm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745801978400256000",
  "text" : ".@yukihiro_matz gives the opening keynote address at @reddotrubyconf. So great to be here. https:\/\/t.co\/HD4u7OTxHm",
  "id" : 745801978400256000,
  "created_at" : "2016-06-23 02:13:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 33, 48 ],
      "id_str" : "234656248",
      "id" : 234656248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/W0YHTMf9rD",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Bugis,_Singapore",
      "display_url" : "en.wikipedia.org\/wiki\/Bugis,_Si\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745658849076535297",
  "text" : "Arrived in Singapore tonight for @reddotrubyconf.  My neighborhood, Bugis, has a very interesting past: https:\/\/t.co\/W0YHTMf9rD",
  "id" : 745658849076535297,
  "created_at" : "2016-06-22 16:44:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745556122224963584",
  "geo" : { },
  "id_str" : "745603500806045697",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Not sure. Probably Thailand &amp; maybe somewhere else in SE Asia for a week or 2, then home to the USA.",
  "id" : 745603500806045697,
  "in_reply_to_status_id" : 745556122224963584,
  "created_at" : "2016-06-22 13:05:01 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745519701262925824",
  "geo" : { },
  "id_str" : "745536594396864512",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Singapore, for Red Dot RubyConf.",
  "id" : 745536594396864512,
  "in_reply_to_status_id" : 745519701262925824,
  "created_at" : "2016-06-22 08:39:10 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/745510969099485184\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/OoLGDSm46G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CliWPhLVEAUy9bV.jpg",
      "id_str" : "745510931677908997",
      "id" : 745510931677908997,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CliWPhLVEAUy9bV.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/OoLGDSm46G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745510969099485184",
  "text" : "At airport leaving Philippines after ~ 2 months here. Edgar makes my sneakers new with a toothbrush &amp; laundry soap. https:\/\/t.co\/OoLGDSm46G",
  "id" : 745510969099485184,
  "created_at" : "2016-06-22 06:57:20 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ice\/fairy type",
      "screen_name" : "rebeccaheckyea",
      "indices" : [ 3, 18 ],
      "id_str" : "1081520288",
      "id" : 1081520288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rebeccaheckyea\/status\/745329283602649088\/photo\/1",
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/lB95uf0Y0e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClfxBh_UgAABoiv.jpg",
      "id_str" : "745329271959224320",
      "id" : 745329271959224320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClfxBh_UgAABoiv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 497,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 548,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/lB95uf0Y0e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745497726192738304",
  "text" : "RT @rebeccaheckyea: https:\/\/t.co\/lB95uf0Y0e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rebeccaheckyea\/status\/745329283602649088\/photo\/1",
        "indices" : [ 0, 23 ],
        "url" : "https:\/\/t.co\/lB95uf0Y0e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ClfxBh_UgAABoiv.jpg",
        "id_str" : "745329271959224320",
        "id" : 745329271959224320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClfxBh_UgAABoiv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 497,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 548,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/lB95uf0Y0e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "745329283602649088",
    "text" : "https:\/\/t.co\/lB95uf0Y0e",
    "id" : 745329283602649088,
    "created_at" : "2016-06-21 18:55:23 +0000",
    "user" : {
      "name" : "ice\/fairy type",
      "screen_name" : "rebeccaheckyea",
      "protected" : false,
      "id_str" : "1081520288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/764618756349763584\/-eb-Sid__normal.jpg",
      "id" : 1081520288,
      "verified" : false
    }
  },
  "id" : 745497726192738304,
  "created_at" : "2016-06-22 06:04:43 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yukihiro Matsumoto",
      "screen_name" : "yukihiro_matz",
      "indices" : [ 0, 14 ],
      "id_str" : "20104013",
      "id" : 20104013
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reddotrubyconf",
      "indices" : [ 62, 77 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "745390291775946754",
  "geo" : { },
  "id_str" : "745494962997862400",
  "in_reply_to_user_id" : 20104013,
  "text" : "@yukihiro_matz SIN no more!  Kidding...I am arriving tonight. #reddotrubyconf",
  "id" : 745494962997862400,
  "in_reply_to_status_id" : 745390291775946754,
  "created_at" : "2016-06-22 05:53:44 +0000",
  "in_reply_to_screen_name" : "yukihiro_matz",
  "in_reply_to_user_id_str" : "20104013",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 3, 8 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/BcfqhyQ9Zw",
      "expanded_url" : "https:\/\/iterm2.com\/documentation-images.html",
      "display_url" : "iterm2.com\/documentation-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "745290208489312256",
  "text" : "RT @baaz: TIL you can now view images inline in iTerm2, I'm going to do this a lot: https:\/\/t.co\/BcfqhyQ9Zw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/BcfqhyQ9Zw",
        "expanded_url" : "https:\/\/iterm2.com\/documentation-images.html",
        "display_url" : "iterm2.com\/documentation-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "744956536271867905",
    "text" : "TIL you can now view images inline in iTerm2, I'm going to do this a lot: https:\/\/t.co\/BcfqhyQ9Zw",
    "id" : 744956536271867905,
    "created_at" : "2016-06-20 18:14:13 +0000",
    "user" : {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "protected" : false,
      "id_str" : "16821853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752872869667999744\/w1-t-Ejj_normal.jpg",
      "id" : 16821853,
      "verified" : false
    }
  },
  "id" : 745290208489312256,
  "created_at" : "2016-06-21 16:20:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terence Lee",
      "screen_name" : "hone02",
      "indices" : [ 0, 7 ],
      "id_str" : "15317640",
      "id" : 15317640
    }, {
      "name" : "RedDotRubyConf",
      "screen_name" : "reddotrubyconf",
      "indices" : [ 8, 23 ],
      "id_str" : "234656248",
      "id" : 234656248
    }, {
      "name" : "Winston Teo Yong Wei",
      "screen_name" : "winstonyw",
      "indices" : [ 24, 34 ],
      "id_str" : "8977842",
      "id" : 8977842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rubykaraoke",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "744774950108561409",
  "geo" : { },
  "id_str" : "744796986260365317",
  "in_reply_to_user_id" : 15317640,
  "text" : "@hone02 @reddotrubyconf @winstonyw YES!!! KARAOKE!!! :)  #rubykaraoke",
  "id" : 744796986260365317,
  "in_reply_to_status_id" : 744774950108561409,
  "created_at" : "2016-06-20 07:40:13 +0000",
  "in_reply_to_screen_name" : "hone02",
  "in_reply_to_user_id_str" : "15317640",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyConf Philippines",
      "screen_name" : "RubyConfPH",
      "indices" : [ 103, 114 ],
      "id_str" : "1920753961",
      "id" : 1920753961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/744054011591016448\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oVb27gpJ4H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClNo-wiWQAEYH5A.jpg",
      "id_str" : "744053790836408321",
      "id" : 744053790836408321,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClNo-wiWQAEYH5A.jpg",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/oVb27gpJ4H"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "744054011591016448",
  "text" : "Finally met the elusive Ruby\/sysadmin expert botp in Cagayan de Oro a couple of days ago. #rubyfriends @rubyconfph https:\/\/t.co\/oVb27gpJ4H",
  "id" : 744054011591016448,
  "created_at" : "2016-06-18 06:27:54 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743712699440234496\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/UkQZJyuVvw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClIypyAUsAAcqJr.jpg",
      "id_str" : "743712581848707072",
      "id" : 743712581848707072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClIypyAUsAAcqJr.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UkQZJyuVvw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743712699440234496",
  "text" : "My flight CGY -&gt; CEB cost less than $50 US, less than a taxi to the other side of my metro area at home. https:\/\/t.co\/UkQZJyuVvw",
  "id" : 743712699440234496,
  "created_at" : "2016-06-17 07:51:39 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743711032112119808\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/uqbNj3mSoj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClIxH2EUoAATmSz.jpg",
      "id_str" : "743710899312041984",
      "id" : 743710899312041984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClIxH2EUoAATmSz.jpg",
      "sizes" : [ {
        "h" : 2064,
        "resize" : "fit",
        "w" : 1161
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1152
      } ],
      "display_url" : "pic.twitter.com\/uqbNj3mSoj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743711032112119808",
  "text" : "Good bye, Cagayan de Oro. Just arrived in Cebu, my home away from home. https:\/\/t.co\/uqbNj3mSoj",
  "id" : 743711032112119808,
  "created_at" : "2016-06-17 07:45:02 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743645497345204224\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/wGHq10i9vC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClH1Rj7VAAA-aNi.jpg",
      "id_str" : "743645095543504896",
      "id" : 743645095543504896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClH1Rj7VAAA-aNi.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/wGHq10i9vC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743645497345204224",
  "text" : "Public transport in Cagayan de Oro. For 6 pesos, about 14 cents US. https:\/\/t.co\/wGHq10i9vC",
  "id" : 743645497345204224,
  "created_at" : "2016-06-17 03:24:37 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743645146298736640\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/JcurcyA46M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClH03haUYAAVJJO.jpg",
      "id_str" : "743644648191582208",
      "id" : 743644648191582208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClH03haUYAAVJJO.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/JcurcyA46M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743645146298736640",
  "text" : "Watching the big basketball game through the window at Centrio Mall in Cagayan de Oro. https:\/\/t.co\/JcurcyA46M",
  "id" : 743645146298736640,
  "created_at" : "2016-06-17 03:23:13 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743631422544445440\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/aEP9U0fpZa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClHoCFyVAAAdDjB.jpg",
      "id_str" : "743630536103493632",
      "id" : 743630536103493632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClHoCFyVAAAdDjB.jpg",
      "sizes" : [ {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 1032
      } ],
      "display_url" : "pic.twitter.com\/aEP9U0fpZa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743631422544445440",
  "text" : "Filipinos say they are not great at basketball, but I'm amazed they have the fortitude to play outdoors in the heat. https:\/\/t.co\/aEP9U0fpZa",
  "id" : 743631422544445440,
  "created_at" : "2016-06-17 02:28:41 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Feminella",
      "screen_name" : "jxxf",
      "indices" : [ 3, 8 ],
      "id_str" : "19463693",
      "id" : 19463693
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "git",
      "indices" : [ 16, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743628435923165185",
  "text" : "RT @jxxf: Using #git 2.9+? You should immediately enable `--compaction-heuristic` for improved diffs. Comparison below. https:\/\/t.co\/vXmDmY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jxxf\/status\/742799938501890048\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/vXmDmYg5l3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck70mykWYAAyOc1.jpg",
        "id_str" : "742799935809150976",
        "id" : 742799935809150976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck70mykWYAAyOc1.jpg",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 267
        }, {
          "h" : 330,
          "resize" : "fit",
          "w" : 267
        } ],
        "display_url" : "pic.twitter.com\/vXmDmYg5l3"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jxxf\/status\/742799938501890048\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/vXmDmYg5l3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck70myfWkAEdBl-.jpg",
        "id_str" : "742799935788191745",
        "id" : 742799935788191745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck70myfWkAEdBl-.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 261
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 261
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 261
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 261
        } ],
        "display_url" : "pic.twitter.com\/vXmDmYg5l3"
      } ],
      "hashtags" : [ {
        "text" : "git",
        "indices" : [ 6, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "742799938501890048",
    "text" : "Using #git 2.9+? You should immediately enable `--compaction-heuristic` for improved diffs. Comparison below. https:\/\/t.co\/vXmDmYg5l3",
    "id" : 742799938501890048,
    "created_at" : "2016-06-14 19:24:40 +0000",
    "user" : {
      "name" : "John Feminella",
      "screen_name" : "jxxf",
      "protected" : false,
      "id_str" : "19463693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3348427561\/9d7f08f1e103a16c8debd169301b9944_normal.jpeg",
      "id" : 19463693,
      "verified" : false
    }
  },
  "id" : 743628435923165185,
  "created_at" : "2016-06-17 02:16:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/743627714922352640\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/j0DIoJIZHQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ClHlVhxUsAADNct.jpg",
      "id_str" : "743627571498102784",
      "id" : 743627571498102784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ClHlVhxUsAADNct.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 383
      } ],
      "display_url" : "pic.twitter.com\/j0DIoJIZHQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743627714922352640",
  "text" : "At my hotel plaza in Cagayan de Oro. Watching the Warriors\/Cavaliers game. Filipinos are huge fans of US basketball. https:\/\/t.co\/j0DIoJIZHQ",
  "id" : 743627714922352640,
  "created_at" : "2016-06-17 02:13:57 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "allie_p",
      "screen_name" : "allie_p",
      "indices" : [ 0, 8 ],
      "id_str" : "15954702",
      "id" : 15954702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "743297426753105926",
  "geo" : { },
  "id_str" : "743333806573162496",
  "in_reply_to_user_id" : 15954702,
  "text" : "@allie_p Don't be shy about calling front desk, especially if it affects your sleep.  It's their job to protect customers from each other.",
  "id" : 743333806573162496,
  "in_reply_to_status_id" : 743297426753105926,
  "created_at" : "2016-06-16 06:46:04 +0000",
  "in_reply_to_screen_name" : "allie_p",
  "in_reply_to_user_id_str" : "15954702",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hover",
      "screen_name" : "hover",
      "indices" : [ 0, 6 ],
      "id_str" : "15399101",
      "id" : 15399101
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743077274803572738",
  "in_reply_to_user_id" : 15399101,
  "text" : "@hover Why would your Manage DNS page be consuming 60% of my CPU (on a new Mac)?",
  "id" : 743077274803572738,
  "created_at" : "2016-06-15 13:46:42 +0000",
  "in_reply_to_screen_name" : "hover",
  "in_reply_to_user_id_str" : "15399101",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Global Delight",
      "screen_name" : "GlobalDelight",
      "indices" : [ 1, 15 ],
      "id_str" : "20301481",
      "id" : 20301481
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743076295454515200",
  "text" : ".@globaldelight 's Boom volume boosting software has \u221E bells &amp; whistles I don't need, but disables HDMI audio output! First do no harm!",
  "id" : 743076295454515200,
  "created_at" : "2016-06-15 13:42:49 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firefox \uD83E\uDD8A\uD83C\uDF0D",
      "screen_name" : "firefox",
      "indices" : [ 33, 41 ],
      "id_str" : "2142731",
      "id" : 2142731
    }, {
      "name" : "KAYAK",
      "screen_name" : "KAYAK",
      "indices" : [ 61, 67 ],
      "id_str" : "28535982",
      "id" : 28535982
    }, {
      "name" : "Firefox \uD83E\uDD8A\uD83C\uDF0D",
      "screen_name" : "firefox",
      "indices" : [ 104, 112 ],
      "id_str" : "2142731",
      "id" : 2142731
    }, {
      "name" : "KAYAK",
      "screen_name" : "KAYAK",
      "indices" : [ 122, 128 ],
      "id_str" : "28535982",
      "id" : 28535982
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743075437887119360",
  "text" : "New about:performance feature in @firefox 47.0 showed that a @kayak page was consuming 50% CPU!  Kudos, @firefox!  Shame, @kayak!",
  "id" : 743075437887119360,
  "created_at" : "2016-06-15 13:39:24 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/742698673671278595\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/MNgbXEe3GO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ck6YdJPVEAAtxyi.jpg",
      "id_str" : "742698615026552832",
      "id" : 742698615026552832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ck6YdJPVEAAtxyi.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 1161,
        "resize" : "fit",
        "w" : 2064
      } ],
      "display_url" : "pic.twitter.com\/MNgbXEe3GO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742698673671278595",
  "text" : "Pleasantly surprised that seats in this propeller plane from Davao to Cagayan de Oro were spacious and comfortable. https:\/\/t.co\/MNgbXEe3GO",
  "id" : 742698673671278595,
  "created_at" : "2016-06-14 12:42:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740911840235036676",
  "geo" : { },
  "id_str" : "741178917009006592",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi What have you used to move your blog to a new host? I find WP bu\/restore util only partial, DB data but not themes, plugins, etc.",
  "id" : 741178917009006592,
  "in_reply_to_status_id" : 740911840235036676,
  "created_at" : "2016-06-10 08:03:18 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Avdi Grimm",
      "screen_name" : "avdi",
      "indices" : [ 0, 5 ],
      "id_str" : "52593",
      "id" : 52593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740726106123292672",
  "geo" : { },
  "id_str" : "740780335407976449",
  "in_reply_to_user_id" : 52593,
  "text" : "@avdi My concern w\/WP is difficulty of backup\/restore, since it has configuration, themes, DB, etc. Also, DB schema changes over time. No?",
  "id" : 740780335407976449,
  "in_reply_to_status_id" : 740726106123292672,
  "created_at" : "2016-06-09 05:39:29 +0000",
  "in_reply_to_screen_name" : "avdi",
  "in_reply_to_user_id_str" : "52593",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ma. Teresa T. Cruz",
      "screen_name" : "MaTeresaTCruz",
      "indices" : [ 0, 14 ],
      "id_str" : "1249100528",
      "id" : 1249100528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740731134342889472",
  "geo" : { },
  "id_str" : "740778152662827016",
  "in_reply_to_user_id" : 1249100528,
  "text" : "@MaTeresaTCruz What kind of volunteer work?  Re: renewal, you may need to do the 29 day extension I did before extending further.",
  "id" : 740778152662827016,
  "in_reply_to_status_id" : 740731134342889472,
  "created_at" : "2016-06-09 05:30:49 +0000",
  "in_reply_to_screen_name" : "MaTeresaTCruz",
  "in_reply_to_user_id_str" : "1249100528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PayPal",
      "screen_name" : "PayPal",
      "indices" : [ 0, 7 ],
      "id_str" : "30018058",
      "id" : 30018058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740588619413356545",
  "in_reply_to_user_id" : 30018058,
  "text" : "@paypal I need to see payee, foreign currency amt, home currency amt, &amp; balance for each transaction.  Possible?",
  "id" : 740588619413356545,
  "created_at" : "2016-06-08 16:57:40 +0000",
  "in_reply_to_screen_name" : "PayPal",
  "in_reply_to_user_id_str" : "30018058",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ma. Teresa T. Cruz",
      "screen_name" : "MaTeresaTCruz",
      "indices" : [ 0, 14 ],
      "id_str" : "1249100528",
      "id" : 1249100528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740558545838473216",
  "geo" : { },
  "id_str" : "740586147617726464",
  "in_reply_to_user_id" : 1249100528,
  "text" : "@MaTeresaTCruz No idea, I'd google it. Where are you located?",
  "id" : 740586147617726464,
  "in_reply_to_status_id" : 740558545838473216,
  "created_at" : "2016-06-08 16:47:51 +0000",
  "in_reply_to_screen_name" : "MaTeresaTCruz",
  "in_reply_to_user_id_str" : "1249100528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ma. Teresa T. Cruz",
      "screen_name" : "MaTeresaTCruz",
      "indices" : [ 0, 14 ],
      "id_str" : "1249100528",
      "id" : 1249100528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740551439500476416",
  "geo" : { },
  "id_str" : "740558253445128192",
  "in_reply_to_user_id" : 1249100528,
  "text" : "@MaTeresaTCruz Must bring fee, passport, passport photo, photocopies of passport info page and Philippine entry stamp page.",
  "id" : 740558253445128192,
  "in_reply_to_status_id" : 740551439500476416,
  "created_at" : "2016-06-08 14:57:01 +0000",
  "in_reply_to_screen_name" : "MaTeresaTCruz",
  "in_reply_to_user_id_str" : "1249100528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ma. Teresa T. Cruz",
      "screen_name" : "MaTeresaTCruz",
      "indices" : [ 0, 14 ],
      "id_str" : "1249100528",
      "id" : 1249100528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740551439500476416",
  "geo" : { },
  "id_str" : "740557915820417025",
  "in_reply_to_user_id" : 1249100528,
  "text" : "@MaTeresaTCruz 3,230p, cash only I think.  This is for a 29-day extension of the automatic 31-day visa you get on arrival.",
  "id" : 740557915820417025,
  "in_reply_to_status_id" : 740551439500476416,
  "created_at" : "2016-06-08 14:55:40 +0000",
  "in_reply_to_screen_name" : "MaTeresaTCruz",
  "in_reply_to_user_id_str" : "1249100528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juanito Fatas \u30D5\u30A1\u30CB\u30FC\u30C8",
      "screen_name" : "JuanitoFatas",
      "indices" : [ 0, 13 ],
      "id_str" : "479019528",
      "id" : 479019528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "740200785384865792",
  "geo" : { },
  "id_str" : "740491140403585026",
  "in_reply_to_user_id" : 479019528,
  "text" : "@JuanitoFatas Maybe an independent repair shop could fix it while you wait?",
  "id" : 740491140403585026,
  "in_reply_to_status_id" : 740200785384865792,
  "created_at" : "2016-06-08 10:30:20 +0000",
  "in_reply_to_screen_name" : "JuanitoFatas",
  "in_reply_to_user_id_str" : "479019528",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "740490881367580674",
  "text" : "Was fearing hassles but the (Phils.) Bureau of Immigration in Davao was helpful &amp; efficient processing my visa extension. Less than 1 hour!",
  "id" : 740490881367580674,
  "created_at" : "2016-06-08 10:29:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabriel Jaldon",
      "screen_name" : "gjaldon",
      "indices" : [ 5, 13 ],
      "id_str" : "97492858",
      "id" : 97492858
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/keithrbennett\/status\/737948548117856256\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/yi3ZZhZaST",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cj24SuOUgAEh7Xa.jpg",
      "id_str" : "737948545743880193",
      "id" : 737948545743880193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cj24SuOUgAEh7Xa.jpg",
      "sizes" : [ {
        "h" : 2322,
        "resize" : "fit",
        "w" : 4128
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yi3ZZhZaST"
    } ],
    "hashtags" : [ {
      "text" : "rubyfriends",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737948548117856256",
  "text" : "With @gjaldon &amp; Maria Famador, a Ruby couple (!) at dinner at their nice home in Davao, Philippines. #rubyfriends https:\/\/t.co\/yi3ZZhZaST",
  "id" : 737948548117856256,
  "created_at" : "2016-06-01 10:06:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]