Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/a9nsI9G1",
      "expanded_url" : "http:\/\/www.jetbrains.com\/ruby\/buy\/index.jsp",
      "display_url" : "jetbrains.com\/ruby\/buy\/index\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "130770841100230656",
  "text" : "JetBrains cut their RubyMine price from $70 to $35 for a personal license (http:\/\/t.co\/a9nsI9G1).",
  "id" : 130770841100230656,
  "created_at" : "2011-10-30 22:19:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130561794304512000",
  "text" : "Wow...after Ubuntu 11.10 upgrade, I had slow wifi ping times of &gt; 1.0 sec.  Strangely, logging in in \"Ubuntu 2D\" mode fixed it.",
  "id" : 130561794304512000,
  "created_at" : "2011-10-30 08:28:52 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130069377642020864",
  "text" : "Cut RubyMine memory usage by 250 MB by starting in 32-bit mode.  Find it in Mac Finder, right-click, Get Info, check \"Open in 32-bit mode\".",
  "id" : 130069377642020864,
  "created_at" : "2011-10-28 23:52:10 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/NaCS6HkQ",
      "expanded_url" : "http:\/\/vpap.org",
      "display_url" : "vpap.org"
    } ]
  },
  "geo" : { },
  "id_str" : "128146475745165312",
  "text" : "Researching local candidates.  http:\/\/t.co\/NaCS6HkQ good for finances, but where can I find out about their beliefs & accomplishments?",
  "id" : 128146475745165312,
  "created_at" : "2011-10-23 16:31:15 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jayfajardo",
      "screen_name" : "jayfajardo",
      "indices" : [ 12, 23 ],
      "id_str" : "14145978",
      "id" : 14145978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "roofcamp",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/2cbKaxan",
      "expanded_url" : "http:\/\/www.roofcamp.net\/",
      "display_url" : "roofcamp.net"
    } ]
  },
  "geo" : { },
  "id_str" : "126854488022712321",
  "text" : "Congrats to @jayfajardo for creating #roofcamp (http:\/\/t.co\/2cbKaxan) to help grow the tech community and industry in the Philippines.",
  "id" : 126854488022712321,
  "created_at" : "2011-10-20 02:57:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barcampphilly",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126684028802826240",
  "text" : "Bummed I'll probably have to miss #barcampphilly because of a cold-like virus.",
  "id" : 126684028802826240,
  "created_at" : "2011-10-19 15:40:00 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mobileappdc",
      "indices" : [ 3, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125258709411708928",
  "text" : "At #mobileappdc.  Anyone know anything about using JRuby to test Android apps written in Java?",
  "id" : 125258709411708928,
  "created_at" : "2011-10-15 17:16:18 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Bacigalupo",
      "screen_name" : "tonybgoode",
      "indices" : [ 0, 11 ],
      "id_str" : "2852911",
      "id" : 2852911
    }, {
      "name" : "New Work Cities",
      "screen_name" : "nwc",
      "indices" : [ 12, 16 ],
      "id_str" : "14204194",
      "id" : 14204194
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124198332066304000",
  "in_reply_to_user_id" : 2852911,
  "text" : "@tonybgoode @nwc Thanks, Tony, er, Mr. Mayor, for the warm welcome to New Work City, great coworking space in Manhattan.",
  "id" : 124198332066304000,
  "created_at" : "2011-10-12 19:02:44 +0000",
  "in_reply_to_screen_name" : "tonybgoode",
  "in_reply_to_user_id_str" : "2852911",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JetBlue Airways",
      "screen_name" : "JetBlue",
      "indices" : [ 0, 8 ],
      "id_str" : "6449282",
      "id" : 6449282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122449728079278081",
  "in_reply_to_user_id" : 6449282,
  "text" : "@jetblue's seat assignment failed to work on either Safari or Firefox on the Mac; I had to dust off a Windows box and use IE.  Fail!",
  "id" : 122449728079278081,
  "created_at" : "2011-10-07 23:14:24 +0000",
  "in_reply_to_screen_name" : "JetBlue",
  "in_reply_to_user_id_str" : "6449282",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/m6EsEA6s",
      "expanded_url" : "http:\/\/tinyurl.com\/3r5gpj8",
      "display_url" : "tinyurl.com\/3r5gpj8"
    } ]
  },
  "geo" : { },
  "id_str" : "120298001251057664",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett  Rubyists, why is inject twice as slow?: http:\/\/t.co\/m6EsEA6s",
  "id" : 120298001251057664,
  "created_at" : "2011-10-02 00:44:13 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Cooper",
      "screen_name" : "peterc",
      "indices" : [ 5, 12 ],
      "id_str" : "33493",
      "id" : 33493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120195588452122624",
  "text" : "+1: \"@peterc: From everything I read, I infer the ideal tech conference would run noon-8pm instead of 9-5 ;-)\"",
  "id" : 120195588452122624,
  "created_at" : "2011-10-01 17:57:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]