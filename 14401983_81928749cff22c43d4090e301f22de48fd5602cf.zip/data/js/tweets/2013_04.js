Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327927176777306113",
  "text" : "Is there a way\/app\/utility to download all content of an RSS feed, preferably Mac OS or Linux?",
  "id" : 327927176777306113,
  "created_at" : "2013-04-26 23:28:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Patterson",
      "screen_name" : "tenderlove",
      "indices" : [ 0, 11 ],
      "id_str" : "14761655",
      "id" : 14761655
    }, {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 12, 18 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Nsu2fJBd7u",
      "expanded_url" : "http:\/\/img.ly\/unOu",
      "display_url" : "img.ly\/unOu"
    } ]
  },
  "in_reply_to_status_id_str" : "327879669103882240",
  "geo" : { },
  "id_str" : "327919704373080065",
  "in_reply_to_user_id" : 14761655,
  "text" : "@tenderlove @peeja And I don't always pose with wax statues\u2026this one was in a shopping mall in Bangkok last year. http:\/\/t.co\/Nsu2fJBd7u",
  "id" : 327919704373080065,
  "in_reply_to_status_id" : 327879669103882240,
  "created_at" : "2013-04-26 22:58:44 +0000",
  "in_reply_to_screen_name" : "tenderlove",
  "in_reply_to_user_id_str" : "14761655",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TorqueBox Team",
      "screen_name" : "torquebox",
      "indices" : [ 0, 10 ],
      "id_str" : "39003585",
      "id" : 39003585
    }, {
      "name" : "Bob 'Snuffy' McW",
      "screen_name" : "bobmcwhirter",
      "indices" : [ 53, 66 ],
      "id_str" : "9366492",
      "id" : 9366492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jruby",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/lQ9xeJkh9G",
      "expanded_url" : "http:\/\/www.meetup.com\/DC-JBug\/events\/115426602\/",
      "display_url" : "meetup.com\/DC-JBug\/events\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327087183326482433",
  "in_reply_to_user_id" : 39003585,
  "text" : "@torquebox (JRuby\/JBoss integration) presentation by @bobmcwhirter in Reston, Virginia, June 6. http:\/\/t.co\/lQ9xeJkh9G  #jruby",
  "id" : 327087183326482433,
  "created_at" : "2013-04-24 15:50:36 +0000",
  "in_reply_to_screen_name" : "torquebox",
  "in_reply_to_user_id_str" : "39003585",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Indefinitely AWOL",
      "screen_name" : "_ZPH",
      "indices" : [ 0, 5 ],
      "id_str" : "737649619",
      "id" : 737649619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324959093028687873",
  "geo" : { },
  "id_str" : "324986312337801217",
  "in_reply_to_user_id" : 737649619,
  "text" : "@_ZPH Yes, like a real glacier, it's expensive to move. ;)  It's intended to replace, e.g., tape archives that are rarely read.",
  "id" : 324986312337801217,
  "in_reply_to_status_id" : 324959093028687873,
  "created_at" : "2013-04-18 20:42:29 +0000",
  "in_reply_to_screen_name" : "_ZPH",
  "in_reply_to_user_id_str" : "737649619",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "324956114426929154",
  "text" : "At the AWS Summit in New York City.  The great functionality and reasonable prices are pretty amazing. New to me: Glacier long term storage.",
  "id" : 324956114426929154,
  "created_at" : "2013-04-18 18:42:29 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    }, {
      "name" : "Rubby ThoughtLeaders",
      "screen_name" : "RubyLeaders",
      "indices" : [ 9, 21 ],
      "id_str" : "1325350567",
      "id" : 1325350567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324264344944799744",
  "geo" : { },
  "id_str" : "324273589052383232",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl @RubyLeaders Oops, sorry, I've heard people say stuff like that seriously, so I didn't realize it was sarcasm.",
  "id" : 324273589052383232,
  "in_reply_to_status_id" : 324264344944799744,
  "created_at" : "2013-04-16 21:30:22 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rubby ThoughtLeaders",
      "screen_name" : "RubyLeaders",
      "indices" : [ 0, 12 ],
      "id_str" : "1325350567",
      "id" : 1325350567
    }, {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 13, 21 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "324235803599446016",
  "geo" : { },
  "id_str" : "324261194963759104",
  "in_reply_to_user_id" : 1325350567,
  "text" : "@RubyLeaders @mguterl I think that's wishful thinking. The probable result will just be fewer bug reports, and not many more fixes.",
  "id" : 324261194963759104,
  "in_reply_to_status_id" : 324235803599446016,
  "created_at" : "2013-04-16 20:41:08 +0000",
  "in_reply_to_screen_name" : "RubyLeaders",
  "in_reply_to_user_id_str" : "1325350567",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/zEkcGeF5kS",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/04\/14\/sunday-review\/indentured-servitude-in-the-persian-gulf.html?nl=todaysheadlines&emc=edit_th_20130414",
      "display_url" : "nytimes.com\/2013\/04\/14\/sun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323600381747818496",
  "text" : "Mean people suck.  Rich Qataris enslaving Filipino and other guest workers: http:\/\/t.co\/zEkcGeF5kS",
  "id" : 323600381747818496,
  "created_at" : "2013-04-15 00:55:17 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Thomas",
      "screen_name" : "pragdave",
      "indices" : [ 0, 9 ],
      "id_str" : "6186692",
      "id" : 6186692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "322152043936641025",
  "geo" : { },
  "id_str" : "322495344309055488",
  "in_reply_to_user_id" : 6186692,
  "text" : "@pragdave Works for me in Win 8 w\/Ruby 1.9.3-p392 (I get the message dialog.)",
  "id" : 322495344309055488,
  "in_reply_to_status_id" : 322152043936641025,
  "created_at" : "2013-04-11 23:44:16 +0000",
  "in_reply_to_screen_name" : "pragdave",
  "in_reply_to_user_id_str" : "6186692",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322480355770781696",
  "text" : "And, Win 8 security updates downloading but waiting for days to complete installation *by default* perplexes me.",
  "id" : 322480355770781696,
  "created_at" : "2013-04-11 22:44:42 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322479556365791232",
  "text" : "Furthermore, supposedly legitimate annoyware (Yahoo Toolbar, I'm looking at you) would never be tolerated on Mac OS or Linux.",
  "id" : 322479556365791232,
  "created_at" : "2013-04-11 22:41:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322477691041378304",
  "text" : "After dabbling in Windows 8 with open mind, I've come to believe that its UI is stunningly cryptic, confusing, nonintuitive, and amateurish.",
  "id" : 322477691041378304,
  "created_at" : "2013-04-11 22:34:07 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "indices" : [ 3, 13 ],
      "id_str" : "14253068",
      "id" : 14253068
    }, {
      "name" : "Adelaide Craft",
      "screen_name" : "prismatic",
      "indices" : [ 90, 100 ],
      "id_str" : "4845792891",
      "id" : 4845792891
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/pUBCgF0u4J",
      "expanded_url" : "http:\/\/prsm.tc\/8739ub",
      "display_url" : "prsm.tc\/8739ub"
    } ]
  },
  "geo" : { },
  "id_str" : "322468416613146627",
  "text" : "RT @mfeathers: North Korean Missile Test Delayed by Windows 8  http:\/\/t.co\/pUBCgF0u4J via @prismatic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/getprismatic.com\" rel=\"nofollow\"\u003Egetprismatic.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adelaide Craft",
        "screen_name" : "prismatic",
        "indices" : [ 75, 85 ],
        "id_str" : "4845792891",
        "id" : 4845792891
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/pUBCgF0u4J",
        "expanded_url" : "http:\/\/prsm.tc\/8739ub",
        "display_url" : "prsm.tc\/8739ub"
      } ]
    },
    "geo" : { },
    "id_str" : "322445566707642368",
    "text" : "North Korean Missile Test Delayed by Windows 8  http:\/\/t.co\/pUBCgF0u4J via @prismatic",
    "id" : 322445566707642368,
    "created_at" : "2013-04-11 20:26:28 +0000",
    "user" : {
      "name" : "Michael Feathers",
      "screen_name" : "mfeathers",
      "protected" : false,
      "id_str" : "14253068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715287671040421888\/A3dghRgj_normal.jpg",
      "id" : 14253068,
      "verified" : false
    }
  },
  "id" : 322468416613146627,
  "created_at" : "2013-04-11 21:57:16 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cassandra Faris",
      "screen_name" : "cassandrafaris",
      "indices" : [ 3, 18 ],
      "id_str" : "76635078",
      "id" : 76635078
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322123764781416448",
  "text" : "RT @cassandrafaris: It is currently 42F in Cleveland &amp; 82F in Columbus. This is ridiculous, even by Ohio standards.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "322083104321843200",
    "text" : "It is currently 42F in Cleveland &amp; 82F in Columbus. This is ridiculous, even by Ohio standards.",
    "id" : 322083104321843200,
    "created_at" : "2013-04-10 20:26:10 +0000",
    "user" : {
      "name" : "Cassandra Faris",
      "screen_name" : "cassandrafaris",
      "protected" : false,
      "id_str" : "76635078",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725347182686048257\/C8Tu7Io4_normal.jpg",
      "id" : 76635078,
      "verified" : false
    }
  },
  "id" : 322123764781416448,
  "created_at" : "2013-04-10 23:07:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grovv",
      "screen_name" : "thegrovv",
      "indices" : [ 0, 9 ],
      "id_str" : "1334652362",
      "id" : 1334652362
    }, {
      "name" : "Startup Weekend",
      "screen_name" : "StartupWeekend",
      "indices" : [ 10, 25 ],
      "id_str" : "7315022",
      "id" : 7315022
    }, {
      "name" : "Minh Nguyen",
      "screen_name" : "minhn21",
      "indices" : [ 26, 34 ],
      "id_str" : "6331922",
      "id" : 6331922
    }, {
      "name" : "Robert Austin",
      "screen_name" : "oatkiller",
      "indices" : [ 35, 45 ],
      "id_str" : "24427428",
      "id" : 24427428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "320995603729481728",
  "geo" : { },
  "id_str" : "321103195579482112",
  "in_reply_to_user_id" : 1334652362,
  "text" : "@thegrovv @StartupWeekend @minhn21 @oatkiller Great working with you all\u2026what a weekend!  And I wrote my first production rails app!",
  "id" : 321103195579482112,
  "in_reply_to_status_id" : 320995603729481728,
  "created_at" : "2013-04-08 03:32:22 +0000",
  "in_reply_to_screen_name" : "thegrovv",
  "in_reply_to_user_id_str" : "1334652362",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]