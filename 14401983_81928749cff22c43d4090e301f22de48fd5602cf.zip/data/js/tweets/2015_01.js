Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/k8vlXhXXQA",
      "expanded_url" : "http:\/\/www.howtogeek.com\/208070\/new-to-linux-dont-use-ubuntu-youll-probably-like-linux-mint-better\/",
      "display_url" : "howtogeek.com\/208070\/new-to-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "561003780276518913",
  "text" : "A brief but helpful article contrasting Ubuntu and Linux Mint: http:\/\/t.co\/k8vlXhXXQA",
  "id" : 561003780276518913,
  "created_at" : "2015-01-30 03:31:38 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kdiff3",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560523236380000256",
  "text" : "#kdiff3 is a cool file\/directory graphical compare utility on Unix and it can be brew installed on a Mac!  What else do you use for this?",
  "id" : 560523236380000256,
  "created_at" : "2015-01-28 19:42:08 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560485820940173313",
  "geo" : { },
  "id_str" : "560520662595678210",
  "in_reply_to_user_id" : 14401983,
  "text" : "@mguterl Found a free Mac-only solution: Use VLC; select View|Show Audio Effects Button; press it (lower right); check Enable; adjust volume",
  "id" : 560520662595678210,
  "in_reply_to_status_id" : 560485820940173313,
  "created_at" : "2015-01-28 19:31:54 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Guterl",
      "screen_name" : "mguterl",
      "indices" : [ 0, 8 ],
      "id_str" : "15404880",
      "id" : 15404880
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "560272294099312641",
  "geo" : { },
  "id_str" : "560485820940173313",
  "in_reply_to_user_id" : 15404880,
  "text" : "@mguterl Thanks, I've bought Boom in the past, but it annoys me that Apple does not expose this setting &amp; I have to buy software to do it.",
  "id" : 560485820940173313,
  "in_reply_to_status_id" : 560272294099312641,
  "created_at" : "2015-01-28 17:13:27 +0000",
  "in_reply_to_screen_name" : "mguterl",
  "in_reply_to_user_id_str" : "15404880",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RubyTapas",
      "screen_name" : "rubytapas",
      "indices" : [ 9, 19 ],
      "id_str" : "309845557",
      "id" : 309845557
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ubuntu",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "560260181796593664",
  "text" : "Watching @rubytapas episodes in a noisy coffee shop, my Mac just isn't loud enough.  No problem, used my #ubuntu VM &amp; adjusted sound &gt; 100%.",
  "id" : 560260181796593664,
  "created_at" : "2015-01-28 02:16:51 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/1nBZPsS9hQ",
      "expanded_url" : "http:\/\/d3exkutavo4sli.cloudfront.net\/wp-content\/uploads\/2014\/12\/Norway-to-Antartica-1024x520.jpg",
      "display_url" : "d3exkutavo4sli.cloudfront.net\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/iWMSbvoJaL",
      "expanded_url" : "http:\/\/www.stumbleupon.com\/su\/4HNwJN\/1TNo0!_MW:420Y0c!j\/news.buzzbuzzhome.com\/2014\/12\/coolest-maps-2014.html",
      "display_url" : "stumbleupon.com\/su\/4HNwJN\/1TNo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559388081598758912",
  "text" : "Map showing straight line route from Norway to Antartica by sea: http:\/\/t.co\/1nBZPsS9hQ . From article at http:\/\/t.co\/iWMSbvoJaL .",
  "id" : 559388081598758912,
  "created_at" : "2015-01-25 16:31:26 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/TVrWHy7hhs",
      "expanded_url" : "http:\/\/www.slate.com\/content\/dam\/slate\/articles\/arts\/culturebox\/2014\/05\/CBOX_BlattLanguage_2.jpg.CROP.original-original.jpg",
      "display_url" : "slate.com\/content\/dam\/sl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "559387278850940930",
  "text" : "Fascinating map of US states and which language is spoken most other than English and Spanish: http:\/\/t.co\/TVrWHy7hhs",
  "id" : 559387278850940930,
  "created_at" : "2015-01-25 16:28:14 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "558054880666214401",
  "geo" : { },
  "id_str" : "558059116980338690",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja It's a little klunky but works well for me and runs on Linux\/Mac\/Win: Moneydance. Also data is local, not on cloud. Uses double entry",
  "id" : 558059116980338690,
  "in_reply_to_status_id" : 558054880666214401,
  "created_at" : "2015-01-22 00:30:36 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Davis",
      "screen_name" : "the_zenspider",
      "indices" : [ 0, 14 ],
      "id_str" : "989841691",
      "id" : 989841691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "557718397094744065",
  "geo" : { },
  "id_str" : "557719564637995009",
  "in_reply_to_user_id" : 989841691,
  "text" : "@the_zenspider We differ over the value of the distinction betw failures &amp; errors. I mentioned gem authors to acknowledge your disagreement.",
  "id" : 557719564637995009,
  "in_reply_to_status_id" : 557718397094744065,
  "created_at" : "2015-01-21 02:01:20 +0000",
  "in_reply_to_screen_name" : "the_zenspider",
  "in_reply_to_user_id_str" : "989841691",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "minitest",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/HODQybZBEV",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/de04e1f5852e3052ed41",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557704405144051714",
  "text" : "#minitest author(s) don't like the idea but to test that exceptions of a specific type are *not* raised, check out https:\/\/t.co\/HODQybZBEV .",
  "id" : 557704405144051714,
  "created_at" : "2015-01-21 01:01:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel Camba",
      "screen_name" : "MiguelCamba",
      "indices" : [ 0, 12 ],
      "id_str" : "97302787",
      "id" : 97302787
    }, {
      "name" : "RubyTapas",
      "screen_name" : "rubytapas",
      "indices" : [ 45, 55 ],
      "id_str" : "309845557",
      "id" : 309845557
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/6LEs7gDFub",
      "expanded_url" : "http:\/\/miguelcamba.com\/blog\/2013\/05\/04\/rubytapas-dot-com-downloader-how-to-download-files-from-https-with-authentication\/",
      "display_url" : "miguelcamba.com\/blog\/2013\/05\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "557544697900838912",
  "in_reply_to_user_id" : 97302787,
  "text" : "@MiguelCamba \"Thank you\" * 1_000_000 for the @rubytapas downloading script at http:\/\/t.co\/6LEs7gDFub. Saved me a ton of time.",
  "id" : 557544697900838912,
  "created_at" : "2015-01-20 14:26:29 +0000",
  "in_reply_to_screen_name" : "MiguelCamba",
  "in_reply_to_user_id_str" : "97302787",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "556888664132026368",
  "geo" : { },
  "id_str" : "556955594771664897",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Stop complaining. At least you HAVE hair. ;)",
  "id" : 556955594771664897,
  "in_reply_to_status_id" : 556888664132026368,
  "created_at" : "2015-01-18 23:25:36 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "indices" : [ 3, 10 ],
      "id_str" : "8864512",
      "id" : 8864512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556945656318029825",
  "text" : "RT @marick: No one ever got fired for buying IBM^h^h^h Microsoft^h^h^h^h^h^h^h^h^h AWS.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "556941262704881665",
    "text" : "No one ever got fired for buying IBM^h^h^h Microsoft^h^h^h^h^h^h^h^h^h AWS.",
    "id" : 556941262704881665,
    "created_at" : "2015-01-18 22:28:39 +0000",
    "user" : {
      "name" : "Brian Marick",
      "screen_name" : "marick",
      "protected" : false,
      "id_str" : "8864512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/584531811637731329\/maOKJHGh_normal.jpg",
      "id" : 8864512,
      "verified" : false
    }
  },
  "id" : 556945656318029825,
  "created_at" : "2015-01-18 22:46:06 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/UjZOumVasA",
      "expanded_url" : "https:\/\/gist.github.com\/keithrbennett\/1e6a9b027474513060a2",
      "display_url" : "gist.github.com\/keithrbennett\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "556084594387476480",
  "geo" : { },
  "id_str" : "556096608153370627",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja Sorry, hard to fit in a tweet.  Here's a gist: https:\/\/t.co\/UjZOumVasA.  Why Test::Unit and not Minitest?  Using an older Ruby?",
  "id" : 556096608153370627,
  "in_reply_to_status_id" : 556084594387476480,
  "created_at" : "2015-01-16 14:32:17 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Jaros",
      "screen_name" : "peeja",
      "indices" : [ 0, 6 ],
      "id_str" : "709433",
      "id" : 709433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "555765004944015360",
  "geo" : { },
  "id_str" : "555931155607072768",
  "in_reply_to_user_id" : 709433,
  "text" : "@peeja w\/Minitest: require 'minitest\/autorun' &amp; then just ruby test\/mydir\/*. W\/rake: rake test TEST=filemask. Can't verify this now though.",
  "id" : 555931155607072768,
  "in_reply_to_status_id" : 555765004944015360,
  "created_at" : "2015-01-16 03:34:50 +0000",
  "in_reply_to_screen_name" : "peeja",
  "in_reply_to_user_id_str" : "709433",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Dinwiddie",
      "screen_name" : "gdinwiddie",
      "indices" : [ 0, 11 ],
      "id_str" : "36691457",
      "id" : 36691457
    }, {
      "name" : "United",
      "screen_name" : "united",
      "indices" : [ 36, 43 ],
      "id_str" : "260907612",
      "id" : 260907612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "553970810315354113",
  "geo" : { },
  "id_str" : "554010060821893121",
  "in_reply_to_user_id" : 36691457,
  "text" : "@gdinwiddie Last year my baggage on @United was delivered a day late twice, on flights from Washington to Pittsburgh and Wash. to\nBangalore.",
  "id" : 554010060821893121,
  "in_reply_to_status_id" : 553970810315354113,
  "created_at" : "2015-01-10 20:21:06 +0000",
  "in_reply_to_screen_name" : "gdinwiddie",
  "in_reply_to_user_id_str" : "36691457",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "indices" : [ 3, 17 ],
      "id_str" : "4620451",
      "id" : 4620451
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BadAstronomer\/status\/553223153301061632\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QP5FPlz4qw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B61xhgiCUAAH7HG.jpg",
      "id_str" : "553223149718753280",
      "id" : 553223149718753280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B61xhgiCUAAH7HG.jpg",
      "sizes" : [ {
        "h" : 589,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 589,
        "resize" : "fit",
        "w" : 590
      } ],
      "display_url" : "pic.twitter.com\/QP5FPlz4qw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gw4OhcJ8Cv",
      "expanded_url" : "http:\/\/www.slate.com\/blogs\/bad_astronomy\/2015\/01\/08\/optical_illusion_the_bulging_checkboard_illusion.html",
      "display_url" : "slate.com\/blogs\/bad_astr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "553256059067203585",
  "text" : "RT @BadAstronomer: An optical illusion that\u2019ll make your eyes bulge out. But how does it work? http:\/\/t.co\/gw4OhcJ8Cv http:\/\/t.co\/QP5FPlz4qw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BadAstronomer\/status\/553223153301061632\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/QP5FPlz4qw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B61xhgiCUAAH7HG.jpg",
        "id_str" : "553223149718753280",
        "id" : 553223149718753280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B61xhgiCUAAH7HG.jpg",
        "sizes" : [ {
          "h" : 589,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 590
        } ],
        "display_url" : "pic.twitter.com\/QP5FPlz4qw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/gw4OhcJ8Cv",
        "expanded_url" : "http:\/\/www.slate.com\/blogs\/bad_astronomy\/2015\/01\/08\/optical_illusion_the_bulging_checkboard_illusion.html",
        "display_url" : "slate.com\/blogs\/bad_astr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "553223153301061632",
    "text" : "An optical illusion that\u2019ll make your eyes bulge out. But how does it work? http:\/\/t.co\/gw4OhcJ8Cv http:\/\/t.co\/QP5FPlz4qw",
    "id" : 553223153301061632,
    "created_at" : "2015-01-08 16:14:12 +0000",
    "user" : {
      "name" : "Phil Plait",
      "screen_name" : "BadAstronomer",
      "protected" : false,
      "id_str" : "4620451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680871217516052480\/aZf1lCDR_normal.jpg",
      "id" : 4620451,
      "verified" : true
    }
  },
  "id" : 553256059067203585,
  "created_at" : "2015-01-08 18:24:58 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lord Pinky",
      "screen_name" : "HiddenPinky",
      "indices" : [ 3, 15 ],
      "id_str" : "835553228",
      "id" : 835553228
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553254645687386112",
  "text" : "RT @HiddenPinky: The limerick writers on Twitter\nCan be justifiably bitter\nThe limited length\nIs weakness, not strength\nAnd throws our last\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "552436829912596481",
    "text" : "The limerick writers on Twitter\nCan be justifiably bitter\nThe limited length\nIs weakness, not strength\nAnd throws our last lines down the sh",
    "id" : 552436829912596481,
    "created_at" : "2015-01-06 12:09:38 +0000",
    "user" : {
      "name" : "Lord Pinky",
      "screen_name" : "HiddenPinky",
      "protected" : false,
      "id_str" : "835553228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/813447599881523200\/gBzxBrtS_normal.jpg",
      "id" : 835553228,
      "verified" : false
    }
  },
  "id" : 553254645687386112,
  "created_at" : "2015-01-08 18:19:21 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Balint Erdi",
      "screen_name" : "baaz",
      "indices" : [ 0, 5 ],
      "id_str" : "16821853",
      "id" : 16821853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552396006110007296",
  "geo" : { },
  "id_str" : "552552036869214208",
  "in_reply_to_user_id" : 16821853,
  "text" : "@baaz Either fine w\/friends\/family\/coworkers\/etc., but strangers asking when they don't care is an insincere time waster. I've done it too.",
  "id" : 552552036869214208,
  "in_reply_to_status_id" : 552396006110007296,
  "created_at" : "2015-01-06 19:47:26 +0000",
  "in_reply_to_screen_name" : "baaz",
  "in_reply_to_user_id_str" : "16821853",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Bennett",
      "screen_name" : "keithrbennett",
      "indices" : [ 0, 14 ],
      "id_str" : "14401983",
      "id" : 14401983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "552177645191184384",
  "geo" : { },
  "id_str" : "552192286923427840",
  "in_reply_to_user_id" : 14401983,
  "text" : "@keithrbennett To clarify, I meant the superficial greetings between strangers, where a negative answer would be awkward and inappropriate.",
  "id" : 552192286923427840,
  "in_reply_to_status_id" : 552177645191184384,
  "created_at" : "2015-01-05 19:57:55 +0000",
  "in_reply_to_screen_name" : "keithrbennett",
  "in_reply_to_user_id_str" : "14401983",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "552177645191184384",
  "text" : "Dear world, rest assured that I care about you and if you need me I will try to be there for you. Now can we stop with the how are you's?",
  "id" : 552177645191184384,
  "created_at" : "2015-01-05 18:59:44 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "indices" : [ 3, 13 ],
      "id_str" : "18137723",
      "id" : 18137723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551531085394608129",
  "text" : "RT @raganwald: I\u2019be seen what Google thinks I should click. I can\u2019t wait to put them in charge of telling my car where it should go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "551483224640081920",
    "text" : "I\u2019be seen what Google thinks I should click. I can\u2019t wait to put them in charge of telling my car where it should go.",
    "id" : 551483224640081920,
    "created_at" : "2015-01-03 21:00:21 +0000",
    "user" : {
      "name" : "Reginald deBRAIDEWAD",
      "screen_name" : "raganwald",
      "protected" : false,
      "id_str" : "18137723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/803237381310648320\/Ze_mlK6T_normal.jpg",
      "id" : 18137723,
      "verified" : false
    }
  },
  "id" : 551531085394608129,
  "created_at" : "2015-01-04 00:10:32 +0000",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori M Olson",
      "screen_name" : "wndxlori",
      "indices" : [ 0, 9 ],
      "id_str" : "30369946",
      "id" : 30369946
    }, {
      "name" : "Evan Light",
      "screen_name" : "elight",
      "indices" : [ 38, 45 ],
      "id_str" : "3948061",
      "id" : 3948061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "551502008549531648",
  "geo" : { },
  "id_str" : "551530527308931072",
  "in_reply_to_user_id" : 30369946,
  "text" : "@wndxlori Do you have a good scanner? @elight once recommended Fujitsu's ScanSnap scanner to me and it's made such a difference.",
  "id" : 551530527308931072,
  "in_reply_to_status_id" : 551502008549531648,
  "created_at" : "2015-01-04 00:08:19 +0000",
  "in_reply_to_screen_name" : "wndxlori",
  "in_reply_to_user_id_str" : "30369946",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steel City Ruby Conf",
      "screen_name" : "SteelCityRuby",
      "indices" : [ 0, 14 ],
      "id_str" : "404851600",
      "id" : 404851600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "551468170809442307",
  "in_reply_to_user_id" : 404851600,
  "text" : "@SteelCityRuby Sorry to hear there won't be a conf in 2015, but thanks for the memories, &amp; I hope to see you again in one form or another.",
  "id" : 551468170809442307,
  "created_at" : "2015-01-03 20:00:32 +0000",
  "in_reply_to_screen_name" : "SteelCityRuby",
  "in_reply_to_user_id_str" : "404851600",
  "user" : {
    "name" : "Keith Bennett",
    "screen_name" : "keithrbennett",
    "protected" : false,
    "id_str" : "14401983",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493394363544662016\/EA2JJdli_normal.jpeg",
    "id" : 14401983,
    "verified" : false
  }
} ]