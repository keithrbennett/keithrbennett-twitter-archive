var user_details =  {
  "screen_name" : "keithrbennett",
  "location" : "Reston, Virginia, USA",
  "full_name" : "Keith Bennett",
  "bio" : "Longtime software developer, specializing in Ruby, with European and Asian experience and language expertise.",
  "id" : "14401983",
  "created_at" : "2008-04-15 22:34:31 +0000"
}